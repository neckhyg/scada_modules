package org.snmp4j.mp;

import java.io.Serializable;
import java.util.Arrays;
import org.snmp4j.TransportMapping;
import org.snmp4j.security.SecurityModel;
import org.snmp4j.security.SecurityStateReference;
import org.snmp4j.smi.Address;
import org.snmp4j.smi.OctetString;

public class StateReference
  implements Serializable
{
  private static final long serialVersionUID = 7385215386971310699L;
  private Address address;
  private transient TransportMapping transportMapping;
  private byte[] contextEngineID;
  private byte[] contextName;
  private SecurityModel securityModel;
  private byte[] securityName;
  private int securityLevel;
  private SecurityStateReference securityStateReference;
  private int msgID;
  private int maxSizeResponseScopedPDU;
  private int msgFlags;
  private PduHandle pduHandle;
  private byte[] securityEngineID;
  private int errorCode = 0;

  public StateReference()
  {
  }

  public StateReference(PduHandle pduHandle, Address peerAddress, TransportMapping peerTransport, SecurityModel secModel, byte[] secName, int errorCode)
  {
    this(0, 0, 65535, pduHandle, peerAddress, peerTransport, null, secModel, secName, 1, null, null, null, errorCode);
  }

  public StateReference(int msgID, int msgFlags, int maxSizeResponseScopedPDU, PduHandle pduHandle, Address peerAddress, TransportMapping peerTransport, byte[] secEngineID, SecurityModel secModel, byte[] secName, int secLevel, byte[] contextEngineID, byte[] contextName, SecurityStateReference secStateReference, int errorCode)
  {
    this.msgID = msgID;
    this.msgFlags = msgFlags;
    this.maxSizeResponseScopedPDU = maxSizeResponseScopedPDU;
    this.pduHandle = pduHandle;
    this.address = peerAddress;
    this.transportMapping = peerTransport;
    this.securityEngineID = secEngineID;
    this.securityModel = secModel;
    this.securityName = secName;
    this.securityLevel = secLevel;
    this.contextEngineID = contextEngineID;
    this.contextName = contextName;
    this.securityStateReference = secStateReference;
    this.errorCode = errorCode;
  }

  public boolean isReportable() {
    return (this.msgFlags & 0x4) > 0;
  }

  public Address getAddress() {
    return this.address;
  }
  public void setAddress(Address address) {
    this.address = address;
  }
  public void setContextEngineID(byte[] contextEngineID) {
    this.contextEngineID = contextEngineID;
  }
  public byte[] getContextEngineID() {
    return this.contextEngineID;
  }
  public void setContextName(byte[] contextName) {
    this.contextName = contextName;
  }
  public byte[] getContextName() {
    return this.contextName;
  }
  public void setSecurityModel(SecurityModel securityModel) {
    this.securityModel = securityModel;
  }
  public SecurityModel getSecurityModel() {
    return this.securityModel;
  }
  public void setSecurityName(byte[] securityName) {
    this.securityName = securityName;
  }
  public byte[] getSecurityName() {
    return this.securityName;
  }
  public void setSecurityLevel(int securityLevel) {
    this.securityLevel = securityLevel;
  }
  public int getSecurityLevel() {
    return this.securityLevel;
  }
  public void setSecurityStateReference(SecurityStateReference securityStateReference) {
    this.securityStateReference = securityStateReference;
  }
  public SecurityStateReference getSecurityStateReference() {
    return this.securityStateReference;
  }
  public void setMsgID(int msgID) {
    this.msgID = msgID;
  }
  public int getMsgID() {
    return this.msgID;
  }
  public void setMsgFlags(int msgFlags) {
    this.msgFlags = msgFlags;
  }
  public int getMsgFlags() {
    return this.msgFlags;
  }
  public void setMaxSizeResponseScopedPDU(int maxSizeResponseScopedPDU) {
    this.maxSizeResponseScopedPDU = maxSizeResponseScopedPDU;
  }
  public int getMaxSizeResponseScopedPDU() {
    return this.maxSizeResponseScopedPDU;
  }
  public PduHandle getPduHandle() {
    return this.pduHandle;
  }

  public byte[] getSecurityEngineID() {
    return this.securityEngineID;
  }

  public int getErrorCode() {
    return this.errorCode;
  }

  public TransportMapping getTransportMapping() {
    return this.transportMapping;
  }

  public void setPduHandle(PduHandle pduHandle) {
    this.pduHandle = pduHandle;
  }

  public void setSecurityEngineID(byte[] securityEngineID) {
    this.securityEngineID = securityEngineID;
  }

  public void setErrorCode(int errorCode) {
    this.errorCode = errorCode;
  }

  public void setTransportMapping(TransportMapping transportMapping) {
    this.transportMapping = transportMapping;
  }

  public boolean equals(Object o) {
    if ((o instanceof StateReference)) {
      StateReference other = (StateReference)o;
      return ((this.msgID == other.msgID) && (this.pduHandle == null) && (other.pduHandle == null)) || ((this.pduHandle != null) && (this.pduHandle.equals(other.getPduHandle())) && (Arrays.equals(this.securityEngineID, other.securityEngineID)) && (this.securityModel.equals(other.securityModel)) && (Arrays.equals(this.securityName, other.securityName)) && (this.securityLevel == other.securityLevel) && (Arrays.equals(this.contextEngineID, other.contextEngineID)) && (Arrays.equals(this.contextName, other.contextName)));
    }

    return false;
  }

  public int hashCode() {
    return this.msgID;
  }

  public String toString() {
    return "StateReference[msgID=" + this.msgID + ",pduHandle=" + this.pduHandle + ",securityEngineID=" + OctetString.fromByteArray(this.securityEngineID) + ",securityModel=" + this.securityModel + ",securityName=" + OctetString.fromByteArray(this.securityName) + ",securityLevel=" + this.securityLevel + ",contextEngineID=" + OctetString.fromByteArray(this.contextEngineID) + ",contextName=" + OctetString.fromByteArray(this.contextName) + "]";
  }
}