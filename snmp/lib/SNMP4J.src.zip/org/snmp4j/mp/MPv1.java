package org.snmp4j.mp;

import java.io.IOException;
import java.nio.ByteBuffer;
import org.snmp4j.MessageDispatcher;
import org.snmp4j.MutablePDU;
import org.snmp4j.PDU;
import org.snmp4j.PDUv1;
import org.snmp4j.ScopedPDU;
import org.snmp4j.Target;
import org.snmp4j.asn1.BER;
import org.snmp4j.asn1.BER.MutableByte;
import org.snmp4j.asn1.BERInputStream;
import org.snmp4j.asn1.BEROutputStream;
import org.snmp4j.log.LogAdapter;
import org.snmp4j.log.LogFactory;
import org.snmp4j.security.SecurityModels;
import org.snmp4j.smi.Address;
import org.snmp4j.smi.Integer32;
import org.snmp4j.smi.OctetString;
import org.snmp4j.util.PDUFactory;

public class MPv1
  implements MessageProcessingModel
{
  public static final int ID = 0;
  private static final LogAdapter logger = LogFactory.getLogger(MPv1.class);

  protected PDUFactory incomingPDUFactory = new PDUFactory() {
    public PDU createPDU(Target target) {
      return new PDUv1();
    }
  };

  public MPv1()
  {
  }

  public MPv1(PDUFactory incomingPDUFactory)
  {
    if (incomingPDUFactory != null)
      this.incomingPDUFactory = incomingPDUFactory;
  }

  public int getID()
  {
    return 0;
  }

  public int prepareOutgoingMessage(Address transportAddress, int maxMessageSize, int messageProcessingModel, int securityModel, byte[] securityName, int securityLevel, PDU pdu, boolean expectResponse, PduHandle sendPduHandle, Address destTransportAddress, BEROutputStream outgoingMessage)
    throws IOException
  {
    if ((securityLevel != 1) || (securityModel != 1))
    {
      logger.error("MPv1 used with unsupported security model");
      return -1402;
    }
    if ((pdu instanceof ScopedPDU)) {
      String txt = "ScopedPDU must not be used with MPv1";
      logger.error(txt);
      throw new IllegalArgumentException(txt);
    }

    if (!isProtocolVersionSupported(messageProcessingModel)) {
      logger.error("MPv1 used with unsupported SNMP version");
      return -1402;
    }

    OctetString community = new OctetString(securityName);
    Integer32 version = new Integer32(messageProcessingModel);

    int length = pdu.getBERLength();
    length += community.getBERLength();
    length += version.getBERLength();

    ByteBuffer buf = ByteBuffer.allocate(length + BER.getBERLengthOfLength(length) + 1);

    outgoingMessage.setBuffer(buf);

    BER.encodeHeader(outgoingMessage, 48, length);
    version.encodeBER(outgoingMessage);

    community.encodeBER(outgoingMessage);
    pdu.encodeBER(outgoingMessage);

    return 0;
  }

  public int prepareResponseMessage(int messageProcessingModel, int maxMessageSize, int securityModel, byte[] securityName, int securityLevel, PDU pdu, int maxSizeResponseScopedPDU, StateReference stateReference, StatusInformation statusInformation, BEROutputStream outgoingMessage)
    throws IOException
  {
    return prepareOutgoingMessage(stateReference.getAddress(), maxMessageSize, messageProcessingModel, securityModel, securityName, securityLevel, pdu, false, stateReference.getPduHandle(), null, outgoingMessage);
  }

  public int prepareDataElements(MessageDispatcher messageDispatcher, Address transportAddress, BERInputStream wholeMsg, Integer32 messageProcessingModel, Integer32 securityModel, OctetString securityName, Integer32 securityLevel, MutablePDU pdu, PduHandle sendPduHandle, Integer32 maxSizeResponseScopedPDU, StatusInformation statusInformation, MutableStateReference stateReference)
    throws IOException
  {
    BER.MutableByte mutableByte = new BER.MutableByte();
    int length = BER.decodeHeader(wholeMsg, mutableByte);
    int startPos = (int)wholeMsg.getPosition();
    if (mutableByte.getValue() != 48) {
      String txt = "SNMPv1 PDU must start with a SEQUENCE";
      logger.error(txt);
      throw new IOException(txt);
    }
    Integer32 version = new Integer32();
    version.decodeBER(wholeMsg);

    securityName.decodeBER(wholeMsg);
    securityLevel.setValue(1);
    securityModel.setValue(1);
    messageProcessingModel.setValue(0);

    PDU v1PDU = this.incomingPDUFactory.createPDU(null);
    pdu.setPdu(v1PDU);
    v1PDU.decodeBER(wholeMsg);

    BER.checkSequenceLength(length, (int)wholeMsg.getPosition() - startPos, v1PDU);

    sendPduHandle.setTransactionID(v1PDU.getRequestID().getValue());

    StateReference stateRef = new StateReference(sendPduHandle, transportAddress, null, SecurityModels.getInstance().getSecurityModel(securityModel), securityName.getValue(), 0);

    stateReference.setStateReference(stateRef);

    return 0;
  }

  public boolean isProtocolVersionSupported(int snmpProtocolVersion) {
    return snmpProtocolVersion == 0;
  }

  public void releaseStateReference(PduHandle pduHandle)
  {
  }
}