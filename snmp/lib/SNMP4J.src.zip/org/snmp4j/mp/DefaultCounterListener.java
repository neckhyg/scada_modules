package org.snmp4j.mp;

import java.util.Hashtable;
import org.snmp4j.event.CounterEvent;
import org.snmp4j.event.CounterListener;
import org.snmp4j.smi.Counter32;
import org.snmp4j.smi.OID;
import org.snmp4j.smi.Variable;
import org.snmp4j.smi.VariableBinding;

public class DefaultCounterListener
  implements CounterListener
{
  private Hashtable counters = new Hashtable(50);

  public synchronized void incrementCounter(CounterEvent event)
  {
    OID id = event.getOid();
    VariableBinding counter = (VariableBinding)this.counters.get(id);
    if (counter == null) {
      counter = new VariableBinding(id, new Counter32(1L));
      this.counters.put(id, counter);
    }
    else {
      ((Counter32)counter.getVariable()).increment();
    }

    event.setCurrentValue((Variable)counter.getVariable().clone());
  }
}