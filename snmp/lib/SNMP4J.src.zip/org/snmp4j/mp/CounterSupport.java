package org.snmp4j.mp;

import java.util.Vector;
import org.snmp4j.event.CounterEvent;
import org.snmp4j.event.CounterListener;

public class CounterSupport
{
  protected static CounterSupport instance = null;
  private transient Vector counterListeners;

  public static CounterSupport getInstance()
  {
    if (instance == null) {
      instance = new CounterSupport();
    }
    return instance;
  }

  public synchronized void addCounterListener(CounterListener listener)
  {
    Vector v = this.counterListeners == null ? new Vector(2) : (Vector)this.counterListeners.clone();

    if (!v.contains(listener)) {
      v.addElement(listener);
      this.counterListeners = v;
    }
  }

  public synchronized void removeCounterListener(CounterListener listener)
  {
    if ((this.counterListeners != null) && (this.counterListeners.contains(listener))) {
      Vector v = (Vector)this.counterListeners.clone();
      v.removeElement(listener);
      this.counterListeners = v;
    }
  }

  public void fireIncrementCounter(CounterEvent event)
  {
    if (this.counterListeners != null) {
      Vector listeners = this.counterListeners;
      int count = listeners.size();
      for (int i = 0; i < count; i++)
        ((CounterListener)listeners.elementAt(i)).incrementCounter(event);
    }
  }
}