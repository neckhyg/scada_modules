package org.snmp4j.mp;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.Vector;
import java.util.WeakHashMap;
import org.snmp4j.MessageDispatcher;
import org.snmp4j.MessageException;
import org.snmp4j.MutablePDU;
import org.snmp4j.PDU;
import org.snmp4j.ScopedPDU;
import org.snmp4j.Target;
import org.snmp4j.asn1.BER;
import org.snmp4j.asn1.BER.MutableByte;
import org.snmp4j.asn1.BERInputStream;
import org.snmp4j.asn1.BEROutputStream;
import org.snmp4j.asn1.BERSerializable;
import org.snmp4j.event.CounterEvent;
import org.snmp4j.event.SnmpEngineEvent;
import org.snmp4j.event.SnmpEngineListener;
import org.snmp4j.log.LogAdapter;
import org.snmp4j.log.LogFactory;
import org.snmp4j.security.AuthenticationProtocol;
import org.snmp4j.security.PrivacyProtocol;
import org.snmp4j.security.SecurityModel;
import org.snmp4j.security.SecurityModels;
import org.snmp4j.security.SecurityParameters;
import org.snmp4j.security.SecurityProtocols;
import org.snmp4j.security.SecurityStateReference;
import org.snmp4j.security.USM;
import org.snmp4j.smi.Address;
import org.snmp4j.smi.Integer32;
import org.snmp4j.smi.OID;
import org.snmp4j.smi.OctetString;
import org.snmp4j.smi.VariableBinding;
import org.snmp4j.util.PDUFactory;

public class MPv3
  implements MessageProcessingModel
{
  public static final int ID = 3;
  public static final int MPv3_REPORTABLE_FLAG = 4;
  public static final int MAX_MESSAGE_ID = 2147483647;
  public static final int MAXLEN_ENGINE_ID = 32;
  public static final int MINLEN_ENGINE_ID = 5;
  private static final int MAX_HEADER_PAYLOAD_LENGTH = new OctetString("").getBERLength() + 3 * new Integer32(2147483647).getBERLength();

  private static final int MAX_HEADER_LENGTH = MAX_HEADER_PAYLOAD_LENGTH + BER.getBERLengthOfLength(MAX_HEADER_PAYLOAD_LENGTH) + 1;
  private SecurityProtocols securityProtocols;
  private static final LogAdapter logger = LogFactory.getLogger(MPv3.class);
  private SecurityModels securityModels;
  private Cache cache;
  private Hashtable engineIDs;
  private byte[] localEngineID;
  private int currentMsgID = new Random().nextInt(2147483647);

  private static int enterpriseID = 4976;
  private CounterSupport counterSupport;
  transient Vector snmpEngineListeners;
  protected PDUFactory incomingPDUFactory = new PDUFactory() {
    public PDU createPDU(Target target) {
      return new ScopedPDU();
    }
  };

  public MPv3()
  {
    this(createLocalEngineID(), null);
  }

  public MPv3(byte[] localEngineID)
  {
    this(localEngineID, null);
    setLocalEngineID(localEngineID);
  }

  public MPv3(byte[] localEngineID, PDUFactory incomingPDUFactory)
  {
    this(localEngineID, incomingPDUFactory, SecurityProtocols.getInstance(), SecurityModels.getInstance(), CounterSupport.getInstance());
  }

  public MPv3(USM usm)
  {
    this(usm.getLocalEngineID().getValue(), null, SecurityProtocols.getInstance(), SecurityModels.getCollection(new SecurityModel[] { usm }), CounterSupport.getInstance());
  }

  public MPv3(byte[] localEngineID, PDUFactory incomingPDUFactory, SecurityProtocols secProtocols, SecurityModels secModels, CounterSupport counterSupport)
  {
    if (incomingPDUFactory != null) {
      this.incomingPDUFactory = incomingPDUFactory;
    }
    this.engineIDs = new Hashtable();
    this.cache = new Cache();
    if (secProtocols == null) {
      throw new NullPointerException();
    }
    this.securityProtocols = secProtocols;
    if (secModels == null) {
      throw new NullPointerException();
    }
    this.securityModels = secModels;
    if (counterSupport == null) {
      throw new NullPointerException();
    }
    this.counterSupport = counterSupport;
    setLocalEngineID(localEngineID);
  }

  public static byte[] createLocalEngineID()
  {
    byte[] engineID = new byte[5];
    engineID[0] = (byte)(0x80 | enterpriseID >> 24 & 0xFF);
    engineID[1] = (byte)(enterpriseID >> 16 & 0xFF);
    engineID[2] = (byte)(enterpriseID >> 8 & 0xFF);
    engineID[3] = (byte)(enterpriseID & 0xFF);
    engineID[4] = 2;
    OctetString os = new OctetString();
    try {
      byte[] b = InetAddress.getLocalHost().getAddress();
      if (b.length == 4) {
        engineID[4] = 1;
      }
      os.setValue(b);
    }
    catch (UnknownHostException ex) {
      logger.debug("Local host cannot be determined for creation of local engine ID");
      engineID[4] = 4;
      os.setValue("SNMP4J".getBytes());
    }
    OctetString ownEngineID = new OctetString(engineID);
    ownEngineID.append(os);
    return ownEngineID.getValue();
  }

  public static byte[] createLocalEngineID(OctetString id)
  {
    byte[] engineID = new byte[5];
    engineID[0] = (byte)(0x80 | enterpriseID >> 24 & 0xFF);
    engineID[1] = (byte)(enterpriseID >> 16 & 0xFF);
    engineID[2] = (byte)(enterpriseID >> 8 & 0xFF);
    engineID[3] = (byte)(enterpriseID & 0xFF);
    engineID[4] = 4;
    OctetString ownEngineID = new OctetString(engineID);
    ownEngineID.append(id);
    return ownEngineID.getValue();
  }

  public void setLocalEngineID(byte[] engineID)
  {
    if ((engineID == null) || (engineID.length < 5) || (engineID.length > 32))
    {
      throw new IllegalArgumentException("Illegal (local) engine ID");
    }
    this.localEngineID = engineID;
  }

  public byte[] getLocalEngineID()
  {
    byte[] retval = new byte[this.localEngineID.length];
    System.arraycopy(this.localEngineID, 0, retval, 0, this.localEngineID.length);
    return retval;
  }

  public void initDefaults()
  {
    this.securityProtocols.addDefaultProtocols();
  }

  public AuthenticationProtocol getAuthProtocol(OID id)
  {
    return this.securityProtocols.getAuthenticationProtocol(id);
  }

  public PrivacyProtocol getPrivProtocol(OID id)
  {
    return this.securityProtocols.getPrivacyProtocol(id);
  }

  public SecurityModel getSecurityModel(int id)
  {
    return this.securityModels.getSecurityModel(new Integer32(id));
  }

  public int getID() {
    return 3;
  }

  public boolean isProtocolVersionSupported(int version) {
    return version == 3;
  }

  public boolean addEngineID(Address address, OctetString engineID)
  {
    if (!Arrays.equals(this.localEngineID, engineID.getValue())) {
      this.engineIDs.put(address, engineID);
      if (this.snmpEngineListeners != null) {
        fireEngineChanged(new SnmpEngineEvent(this, 1, engineID, address));
      }

      return true;
    }
    return false;
  }

  public OctetString getEngineID(Address address)
  {
    return (OctetString)this.engineIDs.get(address);
  }

  public OctetString removeEngineID(Address address)
  {
    OctetString engineID = (OctetString)this.engineIDs.remove(address);
    if ((engineID != null) && (this.snmpEngineListeners != null)) {
      fireEngineChanged(new SnmpEngineEvent(this, 2, engineID, address));
    }

    return engineID;
  }

  public synchronized int getNextMessageID()
  {
    if (this.currentMsgID >= 2147483647) {
      this.currentMsgID = 1;
    }
    return this.currentMsgID++;
  }

  public SecurityProtocols getSecurityProtocols()
  {
    return this.securityProtocols;
  }

  public void setSecurityProtocols(SecurityProtocols securityProtocols)
  {
    this.securityProtocols = securityProtocols;
  }

  protected int getDefaultSecurityModel()
  {
    return 3;
  }

  public void releaseStateReference(PduHandle pduHandle) {
    this.cache.deleteEntry(pduHandle);
  }

  public int prepareOutgoingMessage(Address transportAddress, int maxMessageSize, int messageProcessingModel, int securityModel, byte[] securityName, int securityLevel, PDU pdu, boolean expectResponse, PduHandle sendPduHandle, Address destTransportAddress, BEROutputStream outgoingMessage)
    throws IOException
  {
    if (!(pdu instanceof ScopedPDU)) {
      throw new IllegalArgumentException("MPv3 only accepts ScopedPDU instances as pdu parameter");
    }

    ScopedPDU scopedPDU = (ScopedPDU)pdu;

    byte[] secEngineID = null;
    OctetString securityEngineID = (OctetString)this.engineIDs.get(transportAddress);

    if (securityEngineID != null) {
      secEngineID = securityEngineID.getValue();
      if (scopedPDU.getContextEngineID().length() == 0) {
        switch (pdu.getType()) {
        case -90:
        case -89:
          OctetString localEngineID = new OctetString(getLocalEngineID());
          if (logger.isDebugEnabled()) {
            logger.debug("Context engine ID of scoped PDU is empty! Setting it to local engine ID: " + localEngineID.toHexString());
          }

          scopedPDU.setContextEngineID(localEngineID);
        }

        if (logger.isDebugEnabled()) {
          logger.debug("Context engine ID of scoped PDU is empty! Setting it to authoritative engine ID: " + securityEngineID.toHexString());
        }

        scopedPDU.setContextEngineID(new OctetString(secEngineID));
      }
    }
    else
    {
      secEngineID = new byte[0];
    }

    if (pdu.isConfirmedPdu()) {
      if (secEngineID.length == 0) {
        securityLevel = 1;
        securityModel = getDefaultSecurityModel();

        scopedPDU = (ScopedPDU)scopedPDU.clone();
        scopedPDU.clear();
      }

    }
    else if (scopedPDU.getContextEngineID().length() == 0) {
      if (logger.isDebugEnabled()) {
        logger.debug("Context engine ID of unconfirmed scoped PDU is empty! Setting it to local engine ID");
      }

      scopedPDU.setContextEngineID(new OctetString(this.localEngineID));
    }

    int scopedPDULength = scopedPDU.getBERLength();
    BEROutputStream scopedPdu = new BEROutputStream(ByteBuffer.allocate(scopedPDULength));

    scopedPDU.encodeBER(scopedPdu);

    HeaderData headerData = new HeaderData();
    int flags = 0;
    switch (securityLevel) {
    case 1:
      flags = 0;
      break;
    case 2:
      flags = 1;
      break;
    case 3:
      flags = 3;
    }

    if (scopedPDU.isConfirmedPdu()) {
      flags |= 4;
    }
    else {
      secEngineID = this.localEngineID;
    }

    int msgID = getNextMessageID();
    headerData.setMsgFlags(flags);
    headerData.setMsgID(msgID);
    headerData.setMsgMaxSize(maxMessageSize);
    headerData.setSecurityModel(securityModel);

    ByteBuffer globalDataBuffer = ByteBuffer.allocate(headerData.getBERLength());

    BEROutputStream globalDataOutputStream = new BEROutputStream(globalDataBuffer);

    headerData.encodeBER(globalDataOutputStream);

    BERInputStream scopedPDUInput = new BERInputStream(scopedPdu.rewind());

    SecurityModel secModel = this.securityModels.getSecurityModel(new Integer32(securityModel));

    if (secModel == null) {
      return -1402;
    }

    SecurityParameters securityParameters = secModel.newSecurityParametersInstance();

    int status = secModel.generateRequestMessage(messageProcessingModel, globalDataBuffer.array(), maxMessageSize, securityModel, secEngineID, securityName, securityLevel, scopedPDUInput, securityParameters, outgoingMessage);

    if ((status == 0) && 
      (expectResponse)) {
      this.cache.addEntry(new StateReference(msgID, flags, maxMessageSize, sendPduHandle, transportAddress, null, secEngineID, secModel, securityName, securityLevel, scopedPDU.getContextEngineID().getValue(), scopedPDU.getContextName().getValue(), null, status));
    }

    return status;
  }

  public int prepareResponseMessage(int messageProcessingModel, int maxMessageSize, int securityModel, byte[] securityName, int securityLevel, PDU pdu, int maxSizeResponseScopedPDU, StateReference stateReference, StatusInformation statusInformation, BEROutputStream outgoingMessage)
    throws IOException
  {
    StateReference cacheEntry = this.cache.popEntry(stateReference.getMsgID());
    if (cacheEntry == null) {
      return -1409;
    }

    int scopedPDULength = pdu.getBERLength();
    BEROutputStream scopedPDU;
    if (scopedPDULength > maxSizeResponseScopedPDU) {
      PDU tooBigPDU = new ScopedPDU((ScopedPDU)pdu);
      tooBigPDU.clear();
      tooBigPDU.setRequestID(pdu.getRequestID());
      tooBigPDU.setErrorStatus(1);
      tooBigPDU.setErrorIndex(0);
      scopedPDULength = tooBigPDU.getBERLength();
      BEROutputStream scopedPDU = new BEROutputStream(ByteBuffer.allocate(scopedPDULength));
      tooBigPDU.encodeBER(scopedPDU);
    }
    else {
      scopedPDU = new BEROutputStream(ByteBuffer.allocate(scopedPDULength));
      pdu.encodeBER(scopedPDU);
    }

    HeaderData headerData = new HeaderData();
    int flags = 0;
    switch (securityLevel) {
    case 1:
      flags = 0;
      break;
    case 2:
      flags = 1;
      break;
    case 3:
      flags = 3;
    }

    headerData.setMsgFlags(flags);
    headerData.setMsgID(stateReference.getMsgID());
    headerData.setMsgMaxSize(maxMessageSize);
    headerData.setSecurityModel(securityModel);

    ByteBuffer globalDataBuffer = ByteBuffer.allocate(headerData.getBERLength());

    BEROutputStream globalDataOutputStream = new BEROutputStream(globalDataBuffer);

    headerData.encodeBER(globalDataOutputStream);
    OctetString securityEngineID;
    switch (pdu.getType()) {
    case -94:
    case -92:
    case -89:
    case -88:
      securityEngineID = new OctetString(this.localEngineID);
      break;
    case -93:
    case -91:
    case -90:
    default:
      securityEngineID = new OctetString(cacheEntry.getSecurityEngineID());
    }

    BERInputStream scopedPDUInput = new BERInputStream(scopedPDU.rewind());

    SecurityModel secModel = this.securityModels.getSecurityModel(new Integer32(securityModel));

    SecurityParameters securityParameters = secModel.newSecurityParametersInstance();

    int status = secModel.generateResponseMessage(getID(), globalDataBuffer.array(), maxMessageSize, securityModel, securityEngineID.getValue(), securityName, securityLevel, scopedPDUInput, cacheEntry.getSecurityStateReference(), securityParameters, outgoingMessage);

    return status;
  }

  public int sendReport(MessageDispatcher messageDispatcher, ScopedPDU pdu, int securityLevel, int securityModel, OctetString securityName, int maxSizeResponseScopedPDU, StateReference stateReference, VariableBinding payload)
  {
    ScopedPDU reportPDU = new ScopedPDU();
    reportPDU.setType(-88);
    if (pdu != null) {
      reportPDU.setContextEngineID(pdu.getContextEngineID());
      reportPDU.setContextName(pdu.getContextName());
      reportPDU.setRequestID(pdu.getRequestID());
    }
    reportPDU.add(payload);
    StatusInformation statusInformation = new StatusInformation();
    try {
      int status = messageDispatcher.returnResponsePdu(getID(), securityModel, securityName.getValue(), securityLevel, reportPDU, maxSizeResponseScopedPDU, stateReference, statusInformation);

      if (status != 0) {
        logger.warn("Error while sending report: " + status);
        return -1400;
      }
    }
    catch (MessageException mex) {
      logger.error("Error while sending report: " + mex.getMessage());
      return -1400;
    }
    return 0;
  }

  public int prepareDataElements(MessageDispatcher messageDispatcher, Address transportAddress, BERInputStream wholeMsg, Integer32 messageProcessingModel, Integer32 securityModel, OctetString securityName, Integer32 securityLevel, MutablePDU pdu, PduHandle sendPduHandle, Integer32 maxSizeResponseScopedPDU, StatusInformation statusInformation, MutableStateReference mutableStateReference)
  {
    try
    {
      StateReference stateReference = new StateReference();

      if (mutableStateReference.getStateReference() != null) {
        stateReference.setTransportMapping(mutableStateReference.getStateReference().getTransportMapping());
      }

      messageProcessingModel.setValue(3);
      wholeMsg.mark(16);

      BER.MutableByte type = new BER.MutableByte();
      int length = BER.decodeHeader(wholeMsg, type);
      if (type.getValue() != 48) {
        return -1408;
      }
      long lengthOfLength = wholeMsg.getPosition();
      wholeMsg.reset();
      wholeMsg.mark(length);
      if (wholeMsg.skip(lengthOfLength) != lengthOfLength) {
        return -1408;
      }

      Integer32 snmpVersion = new Integer32();
      snmpVersion.decodeBER(wholeMsg);
      if (snmpVersion.getValue() != 3)
      {
        throw new RuntimeException("Internal error unexpected snmp version read");
      }

      HeaderData header = new HeaderData();
      header.decodeBER(wholeMsg);
      securityModel.setValue(header.getSecurityModel());

      stateReference.setMsgID(header.getMsgID());
      stateReference.setMsgFlags(header.getMsgFlags());
      stateReference.setAddress(transportAddress);

      mutableStateReference.setStateReference(stateReference);

      maxSizeResponseScopedPDU.setValue(header.msgMaxSize.getValue() - MAX_HEADER_LENGTH);

      ScopedPDU scopedPdu = new ScopedPDU();
      pdu.setPdu(scopedPdu);

      SecurityModel secModel = this.securityModels.getSecurityModel(securityModel);
      if (secModel == null) {
        logger.error("RFC3412 §7.2.4 - Unsupported security model: " + securityModel);

        CounterEvent event = new CounterEvent(this, SnmpConstants.snmpUnknownSecurityModels);

        fireIncrementCounter(event);
        return -1402;
      }

      switch (header.getMsgFlags() & 0x3) {
      case 3:
        securityLevel.setValue(3);
        break;
      case 0:
        securityLevel.setValue(1);
        break;
      case 1:
        securityLevel.setValue(2);
        break;
      case 2:
      default:
        securityLevel.setValue(1);
        logger.debug("RFC3412 §7.2.5 - Invalid message (illegal msgFlags)");
        CounterEvent event = new CounterEvent(this, SnmpConstants.snmpInvalidMsgs);

        fireIncrementCounter(event);

        return -1405;
      }

      int secParametersPosition = (int)wholeMsg.getPosition();

      SecurityParameters secParameters = secModel.newSecurityParametersInstance();

      secParameters.decodeBER(wholeMsg);
      secParameters.setSecurityParametersPosition(secParametersPosition);

      boolean reportableFlag = (header.getMsgFlags() & 0x4) > 0;

      OctetString securityEngineID = new OctetString();

      SecurityStateReference secStateReference = secModel.newSecurityStateReference();

      wholeMsg.reset();

      BEROutputStream scopedPDU = new BEROutputStream();
      int status = secModel.processIncomingMsg(snmpVersion.getValue(), header.getMsgMaxSize() - MAX_HEADER_LENGTH, secParameters, secModel, securityLevel.getValue(), wholeMsg, securityEngineID, securityName, scopedPDU, maxSizeResponseScopedPDU, secStateReference, statusInformation);

      wholeMsg.close();
      if (status == 0) {
        try {
          BERInputStream scopedPduStream = new BERInputStream(scopedPDU.rewind());

          scopedPdu.decodeBER(scopedPduStream);
          sendPduHandle.setTransactionID(scopedPdu.getRequestID().getValue());

          addEngineID(transportAddress, securityEngineID);
        }
        catch (IOException iox) {
          logger.warn("ASN.1 parse error: " + iox.getMessage());
          if (logger.isDebugEnabled()) {
            iox.printStackTrace();
          }
          CounterEvent event = new CounterEvent(this, SnmpConstants.snmpInASNParseErrs);

          fireIncrementCounter(event);
          return -1408;
        }
        if (((scopedPdu.getContextEngineID() == null) || (scopedPdu.getContextEngineID().length() == 0)) && (scopedPdu.getType() != -94) && (scopedPdu.getType() != -88))
        {
          CounterEvent event = new CounterEvent(this, SnmpConstants.snmpUnknownPDUHandlers);

          fireIncrementCounter(event);
          VariableBinding errorIndication = new VariableBinding(event.getOid(), event.getCurrentValue());

          statusInformation.setErrorIndication(errorIndication);
          status = -1415;
        }
      }

      if (status != 0) {
        if ((reportableFlag) && (statusInformation.getErrorIndication() != null))
        {
          try
          {
            if (scopedPDU.getBuffer() != null) {
              BERInputStream scopedPduStream = new BERInputStream(scopedPDU.rewind());

              scopedPdu.decodeBER(scopedPduStream);
            }
            else {
              scopedPdu = null;
            }
          }
          catch (IOException iox) {
            logger.warn(iox);
            scopedPdu = null;
          }

          StateReference cacheEntry = new StateReference(header.getMsgID(), header.getMsgFlags(), maxSizeResponseScopedPDU.getValue(), sendPduHandle, transportAddress, null, securityEngineID.getValue(), secModel, securityName.getValue(), securityLevel.getValue(), scopedPdu == null ? new byte[0] : scopedPdu.getContextEngineID().getValue(), scopedPdu == null ? new byte[0] : scopedPdu.getContextName().getValue(), secStateReference, status);

          this.cache.addEntry(cacheEntry);

          int reportStatus = sendReport(messageDispatcher, scopedPdu, statusInformation.getSecurityLevel().getValue(), secModel.getID(), securityName, maxSizeResponseScopedPDU.getValue(), stateReference, statusInformation.getErrorIndication());

          if (reportStatus != 0) {
            logger.warn("Sending report failed with error code: " + reportStatus);
          }
        }

        return -1414;
      }

      stateReference.setAddress(transportAddress);
      stateReference.setSecurityName(securityName.getValue());
      stateReference.setContextEngineID(scopedPdu.getContextEngineID().getValue());
      stateReference.setContextName(scopedPdu.getContextName().getValue());
      stateReference.setMaxSizeResponseScopedPDU(maxSizeResponseScopedPDU.getValue());

      stateReference.setMsgID(header.getMsgID());
      stateReference.setMsgFlags(header.getMsgFlags());
      stateReference.setSecurityEngineID(securityEngineID.getValue());
      stateReference.setSecurityLevel(securityLevel.getValue());
      stateReference.setSecurityModel(secModel);
      stateReference.setSecurityStateReference(secStateReference);
      stateReference.setPduHandle(sendPduHandle);

      if ((scopedPdu.getType() == -94) || (scopedPdu.getType() == -88))
      {
        StateReference cacheEntry = this.cache.popEntry(header.getMsgID());
        if (cacheEntry != null) {
          if (logger.isDebugEnabled()) {
            logger.debug("RFC3412 §7.2.10 - Received PDU (msgID=" + header.getMsgID() + ") is a response or " + "an internal class message. PduHandle.transactionID = " + cacheEntry.getPduHandle().getTransactionID());
          }

          sendPduHandle.copyFrom(cacheEntry.getPduHandle());

          if (scopedPdu.getType() == -88)
          {
            statusInformation.setContextEngineID(scopedPdu.getContextEngineID().getValue());
            statusInformation.setContextName(scopedPdu.getContextName().getValue());
            statusInformation.setSecurityLevel(securityLevel);

            if (((cacheEntry.getSecurityEngineID().length != 0) && (!securityEngineID.equals(cacheEntry.getSecurityEngineID()))) || (secModel.getID() != cacheEntry.getSecurityModel().getID()) || ((!securityName.equals(cacheEntry.getSecurityName())) && (securityName.length() != 0)))
            {
              if (logger.isDebugEnabled()) {
                logger.debug("RFC 3412 §7.2.11 - Received report message does not match sent message");
              }

              mutableStateReference.setStateReference(null);
              return -1410;
            }
            if ((!addEngineID(cacheEntry.getAddress(), securityEngineID)) && 
              (logger.isWarnEnabled())) {
              logger.warn("Engine ID '" + securityEngineID + "' could not be added to engine ID cache for " + "target address '" + cacheEntry.getAddress() + "' because engine ID matches local engine ID");
            }

            mutableStateReference.setStateReference(null);
            logger.debug("MPv3 finished");
            return 0;
          }
          if (scopedPdu.getType() == -94) {
            if (((!securityEngineID.equals(cacheEntry.getSecurityEngineID())) && (cacheEntry.getSecurityEngineID().length != 0)) || (secModel.getID() != cacheEntry.getSecurityModel().getID()) || (!securityName.equals(cacheEntry.getSecurityName())) || (securityLevel.getValue() != cacheEntry.getSecurityLevel()) || ((!scopedPdu.getContextEngineID().equals(cacheEntry.getContextEngineID())) && (cacheEntry.getContextEngineID().length != 0)) || ((!scopedPdu.getContextName().equals(cacheEntry.getContextName())) && (cacheEntry.getContextName().length != 0)))
            {
              logger.debug("RFC 3412 §7.2.12.b - Received response message does not match sent message");

              mutableStateReference.setStateReference(null);
              return -1410;
            }

            mutableStateReference.setStateReference(null);
            logger.debug("MPv3 finished");
            return 0;
          }
        }
        else {
          if (logger.isDebugEnabled()) {
            logger.debug("RFC3412 §7.2.10 - Received PDU (msgID=" + header.getMsgID() + ") is a response or " + "internal class message, but cached " + "information for the msgID could not be found");
          }

          return -1409;
        }
      }
      else {
        logger.debug("RFC3412 §7.2.10 - Received PDU is NOT a response or internal class message -> unchanged PduHandle = " + sendPduHandle);
      }

      switch (scopedPdu.getType()) {
      case -96:
      case -95:
      case -93:
      case -91:
      case -90:
        if (securityEngineID.length() == 0) {
          logger.debug("Received confirmed message with 0 length security engine ID");
        }
        else if (!securityEngineID.equals(this.localEngineID)) {
          if (logger.isDebugEnabled()) {
            logger.debug("RFC 3412 §7.2.13.a - Security engine ID " + securityEngineID.toHexString() + " does not match local engine ID " + new OctetString(this.localEngineID).toHexString());
          }

          mutableStateReference.setStateReference(null);
          return -1406;
        }
        int cacheStatus = this.cache.addEntry(stateReference);
        if (cacheStatus == -1404) {
          mutableStateReference.setStateReference(null);
        }
        return 0;
      case -92:
      case -89:
        mutableStateReference.setStateReference(null);
        return 0;
      case -94:
      }

      return -1400;
    }
    catch (IOException iox) {
      logger.warn("MPv3 parse error: " + iox.getMessage());
      if (logger.isDebugEnabled())
        iox.printStackTrace();
    }
    return -1408;
  }

  public void setSecurityModels(SecurityModels securityModels)
  {
    this.securityModels = securityModels;
  }

  public SecurityModels getSecurityModels()
  {
    return this.securityModels;
  }

  public static int getEnterpriseID()
  {
    return enterpriseID;
  }

  public static void setEnterpriseID(int newEnterpriseID)
  {
    enterpriseID = newEnterpriseID;
  }

  protected void fireIncrementCounter(CounterEvent e)
  {
    if (this.counterSupport != null)
      this.counterSupport.fireIncrementCounter(e);
  }

  public CounterSupport getCounterSupport()
  {
    return this.counterSupport;
  }

  public void setCounterSupport(CounterSupport counterSupport)
  {
    if (counterSupport == null) {
      throw new NullPointerException();
    }
    this.counterSupport = counterSupport;
  }

  public synchronized void addSnmpEngineListener(SnmpEngineListener l)
  {
    if (this.snmpEngineListeners == null) {
      this.snmpEngineListeners = new Vector();
    }
    this.snmpEngineListeners.add(l);
  }

  public synchronized void removeSnmpEngineListener(SnmpEngineListener l)
  {
    if (this.snmpEngineListeners != null)
      this.snmpEngineListeners.remove(l);
  }

  public PDU createPDU(Target target)
  {
    return new ScopedPDU();
  }

  protected void fireEngineChanged(SnmpEngineEvent engineEvent)
  {
    if (this.snmpEngineListeners != null) {
      Vector listeners = this.snmpEngineListeners;
      int count = listeners.size();
      for (int i = 0; i < count; i++)
        ((SnmpEngineListener)listeners.elementAt(i)).engineChanged(engineEvent);
    }
  }

  protected static class HeaderData
    implements BERSerializable
  {
    public static final byte FLAG_AUTH = 1;
    public static final byte FLAG_PRIV = 2;
    Integer32 msgID = new Integer32(0);
    Integer32 msgMaxSize = new Integer32(2147483647);
    OctetString msgFlags = new OctetString(new byte[1]);
    Integer32 securityModel = new Integer32(0);

    public void setMsgID(int msgID) {
      this.msgID.setValue(msgID);
    }

    public int getMsgID() {
      return this.msgID.getValue();
    }

    public void setMsgMaxSize(int msgMaxSize) {
      this.msgMaxSize.setValue(msgMaxSize);
    }

    public int getMsgMaxSize() {
      return this.msgMaxSize.getValue();
    }

    public void setMsgFlags(int flags) {
      this.msgFlags.getValue()[0] = (byte)flags;
    }

    public int getMsgFlags() {
      return this.msgFlags.getValue()[0] & 0xFF;
    }

    public void setSecurityModel(int model) {
      this.securityModel.setValue(model);
    }

    public int getSecurityModel() {
      return this.securityModel.getValue();
    }

    public int getBERPayloadLength() {
      int length = this.msgID.getBERLength();
      length += this.msgMaxSize.getBERLength();
      length += this.msgFlags.getBERLength();
      length += this.securityModel.getBERLength();
      return length;
    }

    public int getBERLength() {
      int length = getBERPayloadLength();
      length += BER.getBERLengthOfLength(length) + 1;
      return length;
    }

    public void decodeBER(BERInputStream message) throws IOException {
      BER.MutableByte type = new BER.MutableByte();
      int length = BER.decodeHeader(message, type);
      if (type.getValue() != 48) {
        throw new IOException("Unexpected sequence header type: " + type.getValue());
      }

      this.msgID.decodeBER(message);
      this.msgMaxSize.decodeBER(message);
      if (this.msgMaxSize.getValue() < 484) {
        throw new IOException("Invalid msgMaxSize: " + this.msgMaxSize);
      }
      this.msgFlags.decodeBER(message);
      if (this.msgFlags.length() != 1) {
        throw new IOException("Message flags length != 1: " + this.msgFlags.length());
      }
      this.securityModel.decodeBER(message);
      if (MPv3.logger.isDebugEnabled()) {
        MPv3.logger.debug("SNMPv3 header decoded: msgId=" + this.msgID + ", msgMaxSize=" + this.msgMaxSize + ", msgFlags=" + this.msgFlags.toHexString() + ", secModel=" + this.securityModel);
      }

      BER.checkSequenceLength(length, this);
    }

    public void encodeBER(OutputStream outputStream) throws IOException {
      BER.encodeHeader(outputStream, 48, getBERPayloadLength());
      this.msgID.encodeBER(outputStream);
      this.msgMaxSize.encodeBER(outputStream);
      this.msgFlags.encodeBER(outputStream);
      this.securityModel.encodeBER(outputStream);
    }
  }

  protected static class Cache
  {
    private Map entries = new WeakHashMap(25);

    public synchronized int addEntry(StateReference entry)
    {
      if (MPv3.logger.isDebugEnabled()) {
        MPv3.logger.debug("Adding cache entry: " + entry);
      }
      StateReference existing = (StateReference)this.entries.get(entry.getPduHandle());

      if ((existing != null) && 
        (existing.equals(entry))) {
        if (MPv3.logger.isDebugEnabled()) {
          MPv3.logger.debug("Doubled message: " + entry);
        }
        return -1404;
      }

      PduHandle key = entry.getPduHandle();

      entry.setPduHandle(null);
      this.entries.put(key, entry);
      return 0;
    }

    public synchronized boolean deleteEntry(PduHandle pduHandle)
    {
      StateReference e = (StateReference)this.entries.remove(pduHandle);
      return e != null;
    }

    public synchronized StateReference popEntry(int msgID)
    {
      for (Iterator it = this.entries.keySet().iterator(); it.hasNext(); ) {
        PduHandle key = (PduHandle)it.next();
        StateReference e = (StateReference)this.entries.get(key);
        if ((e != null) && (e.getMsgID() == msgID)) {
          it.remove();
          e.setPduHandle(key);
          if (MPv3.logger.isDebugEnabled()) {
            MPv3.logger.debug("Removed cache entry: " + e);
          }
          return e;
        }
      }
      return null;
    }
  }

  protected static class CacheEntry extends StateReference
  {
    int msgID;
    long transactionID;
    byte[] secEngineID;
    SecurityModel secModel;
    byte[] secName;
    int secLevel;
    byte[] contextEngineID;
    byte[] contextName;
    SecurityStateReference secStateReference;
    int errorCode;

    public CacheEntry(int msgID, long reqID, byte[] secEngineID, SecurityModel secModel, byte[] secName, int secLevel, byte[] contextEngineID, byte[] contextName, SecurityStateReference secStateReference, int errorCode)
    {
      this.msgID = msgID;
      this.transactionID = reqID;
      this.secEngineID = secEngineID;
      this.secModel = secModel;
      this.secName = secName;
      this.secLevel = secLevel;
      this.contextEngineID = contextEngineID;
      this.contextName = contextName;
      this.secStateReference = secStateReference;
      this.errorCode = errorCode;
    }
  }
}