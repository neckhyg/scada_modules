package org.snmp4j.mp;

import java.io.Serializable;
import org.snmp4j.smi.Integer32;
import org.snmp4j.smi.VariableBinding;

public class StatusInformation
  implements Serializable
{
  private static final long serialVersionUID = 9053403603288070071L;
  private VariableBinding errorIndication;
  private byte[] contextName;
  private byte[] contextEngineID;
  private Integer32 securityLevel;

  public StatusInformation()
  {
  }

  public StatusInformation(VariableBinding errorIndication, byte[] contextName, byte[] contextEngineID, Integer32 securityLevel)
  {
    this.errorIndication = errorIndication;
    this.contextName = contextName;
    this.contextEngineID = contextEngineID;
    this.securityLevel = securityLevel;
  }

  public VariableBinding getErrorIndication() {
    return this.errorIndication;
  }
  public void setErrorIndication(VariableBinding errorIndication) {
    this.errorIndication = errorIndication;
  }
  public void setContextName(byte[] contextName) {
    this.contextName = contextName;
  }
  public byte[] getContextName() {
    return this.contextName;
  }
  public void setContextEngineID(byte[] contextEngineID) {
    this.contextEngineID = contextEngineID;
  }
  public byte[] getContextEngineID() {
    return this.contextEngineID;
  }
  public void setSecurityLevel(Integer32 securityLevel) {
    this.securityLevel = securityLevel;
  }
  public Integer32 getSecurityLevel() {
    return this.securityLevel;
  }

  public String toString() {
    if (this.errorIndication == null) {
      return "noError";
    }
    return this.errorIndication.toString();
  }
}