package org.snmp4j.mp;

public class MutableStateReference
{
  private StateReference stateReference;

  public StateReference getStateReference()
  {
    return this.stateReference;
  }
  public void setStateReference(StateReference stateReference) {
    this.stateReference = stateReference;
  }
}