package org.snmp4j.mp;

import java.io.IOException;
import org.snmp4j.MessageDispatcher;
import org.snmp4j.MutablePDU;
import org.snmp4j.PDU;
import org.snmp4j.asn1.BERInputStream;
import org.snmp4j.asn1.BEROutputStream;
import org.snmp4j.smi.Address;
import org.snmp4j.smi.Integer32;
import org.snmp4j.smi.OctetString;

public abstract interface MessageProcessingModel
{
  public static final int MPv1 = 0;
  public static final int MPv2c = 1;
  public static final int MPv2u = 2;
  public static final int MPv3 = 3;

  public abstract int getID();

  public abstract int prepareOutgoingMessage(Address paramAddress1, int paramInt1, int paramInt2, int paramInt3, byte[] paramArrayOfByte, int paramInt4, PDU paramPDU, boolean paramBoolean, PduHandle paramPduHandle, Address paramAddress2, BEROutputStream paramBEROutputStream)
    throws IOException;

  public abstract int prepareResponseMessage(int paramInt1, int paramInt2, int paramInt3, byte[] paramArrayOfByte, int paramInt4, PDU paramPDU, int paramInt5, StateReference paramStateReference, StatusInformation paramStatusInformation, BEROutputStream paramBEROutputStream)
    throws IOException;

  public abstract int prepareDataElements(MessageDispatcher paramMessageDispatcher, Address paramAddress, BERInputStream paramBERInputStream, Integer32 paramInteger321, Integer32 paramInteger322, OctetString paramOctetString, Integer32 paramInteger323, MutablePDU paramMutablePDU, PduHandle paramPduHandle, Integer32 paramInteger324, StatusInformation paramStatusInformation, MutableStateReference paramMutableStateReference)
    throws IOException;

  public abstract boolean isProtocolVersionSupported(int paramInt);

  public abstract void releaseStateReference(PduHandle paramPduHandle);
}