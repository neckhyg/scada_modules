package org.snmp4j.mp;

import java.io.Serializable;

public class PduHandle
  implements Serializable
{
  private static final long serialVersionUID = -6365764428974409942L;
  public static final int NONE = -2147483648;
  private int transactionID = -2147483648;

  public PduHandle()
  {
  }

  public PduHandle(int transactionID)
  {
    setTransactionID(transactionID);
  }

  public int getTransactionID()
  {
    return this.transactionID;
  }

  public void setTransactionID(int transactionID)
  {
    this.transactionID = transactionID;
  }

  public void copyFrom(PduHandle other)
  {
    setTransactionID(other.transactionID);
  }

  public boolean equals(Object obj)
  {
    if ((obj instanceof PduHandle)) {
      return this.transactionID == ((PduHandle)obj).transactionID;
    }
    return false;
  }

  public int hashCode()
  {
    return this.transactionID;
  }

  public String toString() {
    return "PduHandle[" + this.transactionID + "]";
  }
}