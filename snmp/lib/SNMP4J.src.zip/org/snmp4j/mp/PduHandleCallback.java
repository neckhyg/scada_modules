package org.snmp4j.mp;

public abstract interface PduHandleCallback
{
  public abstract void pduHandleAssigned(PduHandle paramPduHandle, Object paramObject);
}