package org.snmp4j;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Vector;
import org.snmp4j.asn1.BER;
import org.snmp4j.asn1.BER.MutableByte;
import org.snmp4j.asn1.BERInputStream;
import org.snmp4j.smi.OctetString;

public class ScopedPDU extends PDU
{
  private static final long serialVersionUID = 4343157159110407279L;
  private OctetString contextEngineID = new OctetString();
  private OctetString contextName = new OctetString();

  public ScopedPDU()
  {
  }

  public ScopedPDU(ScopedPDU other)
  {
    super(other);
    this.contextEngineID = ((OctetString)other.contextEngineID.clone());
    this.contextName = ((OctetString)other.contextName.clone());
  }

  public void setContextEngineID(OctetString contextEngineID)
  {
    if (contextEngineID == null) {
      throw new NullPointerException("Context engine ID must not be null");
    }
    this.contextEngineID = contextEngineID;
  }

  public OctetString getContextEngineID()
  {
    return this.contextEngineID;
  }

  public void setContextName(OctetString contextName)
  {
    if (contextName == null) {
      throw new NullPointerException("Context name must not be null");
    }
    this.contextName = contextName;
  }

  public OctetString getContextName()
  {
    return this.contextName;
  }

  public int getBERLength() {
    int length = getBERPayloadLength();
    length += 1 + BER.getBERLengthOfLength(length);
    return length;
  }

  public int getBERPayloadLength() {
    int length = super.getBERLength();
    int cid = this.contextEngineID == null ? 0 : this.contextEngineID.length();
    int cn = this.contextName == null ? 0 : this.contextName.length();
    length += BER.getBERLengthOfLength(cid) + 1 + cid + BER.getBERLengthOfLength(cn) + 1 + cn;

    return length;
  }

  public void encodeBER(OutputStream outputStream) throws IOException {
    BER.encodeHeader(outputStream, 48, getBERPayloadLength());
    this.contextEngineID.encodeBER(outputStream);
    this.contextName.encodeBER(outputStream);
    super.encodeBER(outputStream);
  }

  public Object clone()
  {
    return new ScopedPDU(this);
  }

  public void decodeBER(BERInputStream inputStream)
    throws IOException
  {
    BER.MutableByte mutableByte = new BER.MutableByte();
    int length = BER.decodeHeader(inputStream, mutableByte);
    long startPos = inputStream.getPosition();
    this.contextEngineID.decodeBER(inputStream);
    this.contextName.decodeBER(inputStream);
    super.decodeBER(inputStream);
    if (BER.isCheckSequenceLength())
      BER.checkSequenceLength(length, (int)(inputStream.getPosition() - startPos), this);
  }

  public String toString()
  {
    StringBuffer buf = new StringBuffer();
    buf.append(getTypeString(this.type));
    buf.append("[reqestID=");
    buf.append(this.requestID);
    buf.append(", errorStatus=");
    buf.append(this.errorStatus);
    buf.append(", errorIndex=");
    buf.append(this.errorIndex);
    buf.append(", VBS[");
    for (int i = 0; i < this.variableBindings.size(); i++) {
      buf.append(this.variableBindings.get(i));
      if (i + 1 < this.variableBindings.size()) {
        buf.append("; ");
      }
    }
    buf.append("]]");
    return buf.toString();
  }
}