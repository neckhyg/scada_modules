package org.snmp4j.security;

import java.io.IOException;
import org.snmp4j.asn1.BERInputStream;
import org.snmp4j.asn1.BEROutputStream;
import org.snmp4j.mp.StatusInformation;
import org.snmp4j.smi.Integer32;
import org.snmp4j.smi.OctetString;

public abstract interface SecurityModel
{
  public static final int SECURITY_MODEL_ANY = 0;
  public static final int SECURITY_MODEL_SNMPv1 = 1;
  public static final int SECURITY_MODEL_SNMPv2c = 2;
  public static final int SECURITY_MODEL_USM = 3;

  public abstract int getID();

  public abstract SecurityParameters newSecurityParametersInstance();

  public abstract SecurityStateReference newSecurityStateReference();

  public abstract int generateRequestMessage(int paramInt1, byte[] paramArrayOfByte1, int paramInt2, int paramInt3, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, int paramInt4, BERInputStream paramBERInputStream, SecurityParameters paramSecurityParameters, BEROutputStream paramBEROutputStream)
    throws IOException;

  public abstract int generateResponseMessage(int paramInt1, byte[] paramArrayOfByte1, int paramInt2, int paramInt3, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, int paramInt4, BERInputStream paramBERInputStream, SecurityStateReference paramSecurityStateReference, SecurityParameters paramSecurityParameters, BEROutputStream paramBEROutputStream)
    throws IOException;

  public abstract int processIncomingMsg(int paramInt1, int paramInt2, SecurityParameters paramSecurityParameters, SecurityModel paramSecurityModel, int paramInt3, BERInputStream paramBERInputStream, OctetString paramOctetString1, OctetString paramOctetString2, BEROutputStream paramBEROutputStream, Integer32 paramInteger32, SecurityStateReference paramSecurityStateReference, StatusInformation paramStatusInformation)
    throws IOException;
}