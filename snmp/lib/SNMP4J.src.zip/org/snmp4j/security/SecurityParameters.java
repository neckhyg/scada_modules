package org.snmp4j.security;

import org.snmp4j.asn1.BERSerializable;

public abstract interface SecurityParameters extends BERSerializable
{
  public abstract int getSecurityParametersPosition();

  public abstract void setSecurityParametersPosition(int paramInt);

  public abstract int getBERMaxLength(int paramInt);
}