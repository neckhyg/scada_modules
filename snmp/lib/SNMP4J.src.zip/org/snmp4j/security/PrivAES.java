package org.snmp4j.security;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.snmp4j.log.LogAdapter;
import org.snmp4j.log.LogFactory;
import org.snmp4j.smi.OctetString;

public abstract class PrivAES
  implements PrivacyProtocol
{
  private static final int DECRYPT_PARAMS_LENGTH = 8;
  private static final LogAdapter logger = LogFactory.getLogger(PrivAES.class);
  private int keyBytes;
  protected Salt salt;

  public PrivAES(int keyBytes)
  {
    if ((keyBytes != 16) && (keyBytes != 24) && (keyBytes != 32)) {
      throw new IllegalArgumentException("Only 128, 192 and 256 bit AES is allowed. Requested (" + 8 * keyBytes + ").");
    }

    this.keyBytes = keyBytes;
    this.salt = Salt.getInstance();
  }

  public byte[] encrypt(byte[] unencryptedData, int offset, int length, byte[] encryptionKey, long engineBoots, long engineTime, DecryptParams decryptParams)
  {
    byte[] initVect = new byte[16];
    long my_salt = this.salt.getNext();

    if (encryptionKey.length < this.keyBytes) {
      throw new IllegalArgumentException("Needed key length is " + this.keyBytes + ". Got only " + encryptionKey.length + ".");
    }

    if ((decryptParams.array == null) || (decryptParams.length < 8))
    {
      decryptParams.array = new byte[8];
    }
    decryptParams.length = 8;
    decryptParams.offset = 0;

    initVect[0] = (byte)(int)(engineBoots >> 24 & 0xFF);
    initVect[1] = (byte)(int)(engineBoots >> 16 & 0xFF);
    initVect[2] = (byte)(int)(engineBoots >> 8 & 0xFF);
    initVect[3] = (byte)(int)(engineBoots & 0xFF);
    initVect[4] = (byte)(int)(engineTime >> 24 & 0xFF);
    initVect[5] = (byte)(int)(engineTime >> 16 & 0xFF);
    initVect[6] = (byte)(int)(engineTime >> 8 & 0xFF);
    initVect[7] = (byte)(int)(engineTime & 0xFF);
    int i = 56; for (int j = 8; i >= 0; j++) {
      initVect[j] = (byte)(int)(my_salt >> i & 0xFF);

      i -= 8;
    }

    for (int i = 0; i < 8; i++) {
      decryptParams.array[i] = initVect[(i + 8)];
    }
    if (logger.isDebugEnabled()) {
      logger.debug("initVect is " + asHex(initVect));
    }

    byte[] encryptedData = null;
    try
    {
      Cipher alg = Cipher.getInstance("AES/CFB/NoPadding");
      SecretKeySpec key = new SecretKeySpec(encryptionKey, 0, this.keyBytes, "AES");

      IvParameterSpec ivSpec = new IvParameterSpec(initVect);
      alg.init(1, key, ivSpec);
      encryptedData = alg.doFinal(unencryptedData, offset, length);

      if (logger.isDebugEnabled()) {
        logger.debug("aes encrypt: Data to encrypt " + asHex(unencryptedData));

        logger.debug("aes encrypt: used key " + asHex(encryptionKey));

        logger.debug("aes encrypt: created privacy_params " + asHex(decryptParams.array));

        logger.debug("aes encrypt: encrypted Data  " + asHex(encryptedData));
      }
    }
    catch (Exception e)
    {
      logger.error("Encrypt Exception " + e);
    }

    return encryptedData;
  }

  public byte[] decrypt(byte[] cryptedData, int offset, int length, byte[] decryptionKey, long engineBoots, long engineTime, DecryptParams decryptParams)
  {
    byte[] initVect = new byte[16];

    if (decryptionKey.length < this.keyBytes) {
      throw new IllegalArgumentException("Needed key length is " + this.keyBytes + ". Got only " + decryptionKey.length + ".");
    }

    initVect[0] = (byte)(int)(engineBoots >> 24 & 0xFF);
    initVect[1] = (byte)(int)(engineBoots >> 16 & 0xFF);
    initVect[2] = (byte)(int)(engineBoots >> 8 & 0xFF);
    initVect[3] = (byte)(int)(engineBoots & 0xFF);
    initVect[4] = (byte)(int)(engineTime >> 24 & 0xFF);
    initVect[5] = (byte)(int)(engineTime >> 16 & 0xFF);
    initVect[6] = (byte)(int)(engineTime >> 8 & 0xFF);
    initVect[7] = (byte)(int)(engineTime & 0xFF);
    for (int i = 0; i < 8; i++) {
      initVect[(i + 8)] = decryptParams.array[(i + decryptParams.offset)];
    }

    if (logger.isDebugEnabled()) {
      logger.debug("initVect is " + asHex(initVect));
    }

    byte[] decryptedData = null;
    try
    {
      Cipher alg = Cipher.getInstance("AES/CFB/NoPadding");
      SecretKeySpec key = new SecretKeySpec(decryptionKey, 0, this.keyBytes, "AES");

      IvParameterSpec ivSpec = new IvParameterSpec(initVect);
      alg.init(2, key, ivSpec);
      decryptedData = alg.doFinal(cryptedData, offset, length);

      if (logger.isDebugEnabled()) {
        logger.debug("aes decrypt: Data to decrypt " + asHex(cryptedData));

        logger.debug("aes decrypt: used key " + asHex(decryptionKey));

        logger.debug("aes decrypt: used privacy_params " + asHex(decryptParams.array));

        logger.debug("aes decrypt: decrypted Data  " + asHex(decryptedData));
      }
    }
    catch (Exception e)
    {
      logger.error("Decrypt Exception " + e);
    }

    return decryptedData;
  }

  public int getEncryptedLength(int scopedPDULength) {
    return scopedPDULength;
  }

  public static String asHex(byte[] buf)
  {
    return new OctetString(buf).toHexString();
  }

  public int getMinKeyLength() {
    return this.keyBytes;
  }

  public int getMaxKeyLength() {
    return getMinKeyLength();
  }

  public int getDecryptParamsLength() {
    return 8;
  }

  public byte[] extendShortKey(byte[] shortKey, OctetString password, byte[] engineID, AuthenticationProtocol authProtocol)
  {
    byte[] extKey = new byte[getMinKeyLength()];
    int length = shortKey.length;
    for (int i = 0; i < length; i++) {
      extKey[i] = shortKey[i];
    }

    while (length < extKey.length)
    {
      byte[] hash = authProtocol.hash(extKey, 0, length);

      if (hash == null) {
        return null;
      }
      int bytesToCopy = extKey.length - length;
      if (bytesToCopy > authProtocol.getDigestLength()) {
        bytesToCopy = authProtocol.getDigestLength();
      }
      System.arraycopy(hash, 0, extKey, length, bytesToCopy);

      length += bytesToCopy;
    }
    return extKey;
  }
}