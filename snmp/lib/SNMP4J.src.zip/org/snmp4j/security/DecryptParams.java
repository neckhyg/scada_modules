package org.snmp4j.security;

public class DecryptParams
{
  public byte[] array;
  public int offset;
  public int length;

  public DecryptParams(byte[] array, int offset, int length)
  {
    this.array = array;
    this.offset = offset;
    this.length = length;
  }

  public DecryptParams()
  {
    this.array = null;
    this.offset = 0;
    this.length = 0;
  }

  public void setValues(byte[] array, int offset, int length)
  {
    this.array = array;
    this.offset = offset;
    this.length = length;
  }
}