package org.snmp4j.security;

import org.snmp4j.smi.OID;

public class PrivAES192 extends PrivAES
{
  private static final long serialVersionUID = -3496699866363408441L;
  public static final OID ID = new OID(" 1.3.6.1.4.1.4976.2.2.1.1.1");

  public PrivAES192()
  {
    super(24);
  }

  public OID getID()
  {
    return (OID)ID.clone();
  }
}