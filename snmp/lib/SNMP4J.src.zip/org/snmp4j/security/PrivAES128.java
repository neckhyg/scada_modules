package org.snmp4j.security;

import org.snmp4j.smi.OID;

public class PrivAES128 extends PrivAES
{
  private static final long serialVersionUID = 4358221830402784741L;
  public static final OID ID = new OID("1.3.6.1.6.3.10.1.2.4");

  public PrivAES128()
  {
    super(16);
  }

  public OID getID()
  {
    return (OID)ID.clone();
  }
}