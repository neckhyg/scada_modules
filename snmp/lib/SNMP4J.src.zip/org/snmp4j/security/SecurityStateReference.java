package org.snmp4j.security;

public abstract interface SecurityStateReference
{
}