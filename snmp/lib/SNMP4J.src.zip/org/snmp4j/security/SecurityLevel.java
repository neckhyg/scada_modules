package org.snmp4j.security;

public final class SecurityLevel
{
  public static final int NOAUTH_NOPRIV = 1;
  public static final int AUTH_NOPRIV = 2;
  public static final int AUTH_PRIV = 3;
}