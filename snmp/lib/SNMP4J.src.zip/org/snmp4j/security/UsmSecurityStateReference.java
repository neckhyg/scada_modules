package org.snmp4j.security;

public class UsmSecurityStateReference
  implements SecurityStateReference
{
  private byte[] userName;
  private byte[] securityName;
  private byte[] securityEngineID;
  private AuthenticationProtocol authenticationProtocol;
  private PrivacyProtocol privacyProtocol;
  private byte[] authenticationKey;
  private byte[] privacyKey;
  private int securityLevel;

  public byte[] getUserName()
  {
    return this.userName;
  }
  public void setUserName(byte[] userName) {
    this.userName = userName;
  }
  public void setSecurityName(byte[] securityName) {
    this.securityName = securityName;
  }
  public byte[] getSecurityName() {
    return this.securityName;
  }
  public void setSecurityEngineID(byte[] securityEngineID) {
    this.securityEngineID = securityEngineID;
  }
  public byte[] getSecurityEngineID() {
    return this.securityEngineID;
  }
  public void setAuthenticationProtocol(AuthenticationProtocol authenticationProtocol) {
    this.authenticationProtocol = authenticationProtocol;
  }
  public AuthenticationProtocol getAuthenticationProtocol() {
    return this.authenticationProtocol;
  }
  public void setPrivacyProtocol(PrivacyProtocol privacyProtocol) {
    this.privacyProtocol = privacyProtocol;
  }
  public PrivacyProtocol getPrivacyProtocol() {
    return this.privacyProtocol;
  }
  public void setAuthenticationKey(byte[] authenticationKey) {
    this.authenticationKey = authenticationKey;
  }
  public byte[] getAuthenticationKey() {
    return this.authenticationKey;
  }
  public void setPrivacyKey(byte[] privacyKey) {
    this.privacyKey = privacyKey;
  }
  public byte[] getPrivacyKey() {
    return this.privacyKey;
  }
  public void setSecurityLevel(int securityLevel) {
    this.securityLevel = securityLevel;
  }
  public int getSecurityLevel() {
    return this.securityLevel;
  }
}