package org.snmp4j.security;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.Vector;
import org.snmp4j.asn1.BER;
import org.snmp4j.asn1.BER.MutableByte;
import org.snmp4j.asn1.BERInputStream;
import org.snmp4j.asn1.BEROutputStream;
import org.snmp4j.event.CounterEvent;
import org.snmp4j.event.UsmUserEvent;
import org.snmp4j.event.UsmUserListener;
import org.snmp4j.log.LogAdapter;
import org.snmp4j.log.LogFactory;
import org.snmp4j.mp.CounterSupport;
import org.snmp4j.mp.SnmpConstants;
import org.snmp4j.mp.StatusInformation;
import org.snmp4j.smi.Integer32;
import org.snmp4j.smi.OID;
import org.snmp4j.smi.OctetString;
import org.snmp4j.smi.VariableBinding;

public class USM
  implements SecurityModel
{
  private static final int MAXLEN_USMUSERNAME = 32;
  private static final LogAdapter logger = LogFactory.getLogger(USM.class);
  private UsmUserTable userTable;
  private UsmTimeTable timeTable;
  private OctetString localEngineID;
  private boolean engineDiscoveryEnabled = true;
  private SecurityProtocols securityProtocols;
  private transient Vector usmUserListeners;
  private CounterSupport counterSupport;

  public USM(SecurityProtocols securityProtocols, OctetString localEngineID, int engineBoots)
  {
    this.localEngineID = localEngineID;
    this.timeTable = new UsmTimeTable(localEngineID, engineBoots);
    this.userTable = new UsmUserTable();
    this.securityProtocols = securityProtocols;
    this.counterSupport = CounterSupport.getInstance();
  }

  public int getID() {
    return 3;
  }

  public void setLocalEngine(OctetString localEngineID, int engineBoots, int engineTime)
  {
    this.localEngineID = localEngineID;
    this.timeTable.setLocalTime(new UsmTimeEntry(localEngineID, engineBoots, engineTime));
  }

  public OctetString getLocalEngineID()
  {
    return this.localEngineID;
  }

  public void setEngineBoots(int engineBoots)
  {
    this.timeTable.setEngineBoots(engineBoots);
  }

  public int getEngineBoots()
  {
    return this.timeTable.getEngineBoots();
  }

  public int getEngineTime()
  {
    return this.timeTable.getEngineTime();
  }

  public SecurityParameters newSecurityParametersInstance() {
    return new UsmSecurityParameters();
  }

  public SecurityStateReference newSecurityStateReference() {
    return new UsmSecurityStateReference();
  }

  private static byte[] buildMessageBuffer(BERInputStream scopedPDU)
    throws IOException
  {
    scopedPDU.mark(16);
    int readLengthBytes = (int)scopedPDU.getPosition();
    BER.MutableByte mutableByte = new BER.MutableByte();
    int length = BER.decodeHeader(scopedPDU, mutableByte);
    readLengthBytes = (int)scopedPDU.getPosition() - readLengthBytes;
    byte[] buf = new byte[length + readLengthBytes];
    scopedPDU.reset();

    int offset = 0;
    int avail = scopedPDU.available();
    while ((offset < buf.length) && (avail > 0)) {
      int read = scopedPDU.read(buf, offset, buf.length - offset);
      if (read < 0) {
        break;
      }
      offset += read;
    }
    return buf;
  }

  private static byte[] buildWholeMessage(Integer32 snmpVersion, byte[] scopedPdu, byte[] globalData, UsmSecurityParameters usmSecurityParameters)
    throws IOException
  {
    int length = snmpVersion.getBERLength() + globalData.length + usmSecurityParameters.getBERLength() + scopedPdu.length;

    int totalLength = BER.getBERLengthOfLength(length) + length + 1;

    ByteArrayOutputStream os = new ByteArrayOutputStream(totalLength);
    BER.encodeHeader(os, 48, length);
    snmpVersion.encodeBER(os);
    os.write(globalData);
    usmSecurityParameters.encodeBER(os);
    os.write(scopedPdu);
    int secParamsPos = 1 + snmpVersion.getBERLength() + BER.getBERLengthOfLength(length) + globalData.length;

    usmSecurityParameters.setSecurityParametersPosition(secParamsPos);
    return os.toByteArray();
  }

  public int generateRequestMessage(int snmpVersion, byte[] globalData, int maxMessageSize, int securityModel, byte[] securityEngineID, byte[] securityName, int securityLevel, BERInputStream scopedPDU, SecurityParameters securityParameters, BEROutputStream wholeMsg)
    throws IOException
  {
    return generateResponseMessage(snmpVersion, globalData, maxMessageSize, securityModel, securityEngineID, securityName, securityLevel, scopedPDU, null, securityParameters, wholeMsg);
  }

  public boolean hasUser(OctetString engineID, OctetString securityName)
  {
    UsmUserEntry entry = this.userTable.getUser(engineID, securityName);
    if (entry == null) {
      entry = this.userTable.getUser(securityName);
      if ((entry == null) && (securityName.length() > 0)) {
        return false;
      }
    }
    return true;
  }

  public UsmUserEntry getUser(OctetString engineID, OctetString securityName) {
    if (logger.isDebugEnabled()) {
      logger.debug("getUser(engineID=" + engineID.toHexString() + ", securityName=" + securityName.toString() + ")");
    }

    UsmUserEntry entry = this.userTable.getUser(engineID, securityName);
    if (entry == null) {
      entry = this.userTable.getUser(securityName);
      if ((entry == null) && (securityName.length() > 0)) {
        if (logger.isDebugEnabled()) {
          logger.debug("USM.getUser - User '" + securityName + "' unknown");
        }
        return null;
      }

      if ((entry == null) || (engineID.length() == 0))
      {
        entry = new UsmUserEntry();
        entry.setUserName(securityName);
        entry.setUsmUser(new UsmUser(securityName, null, null, null, null));
        return entry;
      }

      OID authProtocolOID = entry.getUsmUser().getAuthenticationProtocol();
      OID privProtocolOID = entry.getUsmUser().getPrivacyProtocol();
      if (authProtocolOID != null)
      {
        byte[] authKey;
        byte[] authKey;
        if (entry.getUsmUser().isLocalized()) {
          authKey = entry.getUsmUser().getAuthenticationPassphrase().getValue();
        }
        else
        {
          authKey = this.securityProtocols.passwordToKey(authProtocolOID, entry.getUsmUser().getAuthenticationPassphrase(), engineID.getValue());
        }

        byte[] privKey = null;
        if (privProtocolOID != null) {
          if (entry.getUsmUser().isLocalized()) {
            privKey = entry.getUsmUser().getPrivacyPassphrase().getValue();
          }
          else {
            privKey = this.securityProtocols.passwordToKey(privProtocolOID, authProtocolOID, entry.getUsmUser().getPrivacyPassphrase(), engineID.getValue());
          }

        }

        entry = addLocalizedUser(engineID.getValue(), securityName, authProtocolOID, authKey, privProtocolOID, privKey);
      }

    }

    return entry;
  }

  public int generateResponseMessage(int snmpVersion, byte[] globalData, int maxMessageSize, int securityModel, byte[] securityEngineID, byte[] securityName, int securityLevel, BERInputStream scopedPDU, SecurityStateReference securityStateReference, SecurityParameters securityParameters, BEROutputStream wholeMsg)
    throws IOException
  {
    UsmSecurityParameters usmSecurityParams = (UsmSecurityParameters)securityParameters;

    if (securityStateReference != null)
    {
      UsmSecurityStateReference usmSecurityStateReference = (UsmSecurityStateReference)securityStateReference;

      if (usmSecurityStateReference.getSecurityEngineID() == null) {
        usmSecurityParams.setAuthoritativeEngineID(securityEngineID);
        usmSecurityStateReference.setSecurityEngineID(securityEngineID);
      }
      if (usmSecurityStateReference.getSecurityName() == null) {
        OctetString userName = new OctetString(securityName);
        usmSecurityStateReference.setSecurityName(userName.getValue());
        usmSecurityParams.setUserName(userName);

        OctetString secName = getSecurityName(new OctetString(securityEngineID), userName);

        if ((secName != null) && (secName.length() <= 32))
        {
          usmSecurityParams.setUserName(secName);
        }
      }
      else
      {
        usmSecurityParams.setUserName(new OctetString(usmSecurityStateReference.getSecurityName()));
      }
      usmSecurityParams.setAuthenticationProtocol(usmSecurityStateReference.getAuthenticationProtocol());

      usmSecurityParams.setPrivacyProtocol(usmSecurityStateReference.getPrivacyProtocol());

      usmSecurityParams.setAuthenticationKey(usmSecurityStateReference.getAuthenticationKey());

      usmSecurityParams.setPrivacyKey(usmSecurityStateReference.getPrivacyKey());
    }
    else {
      OctetString secEngineID = new OctetString();
      if (securityEngineID != null) {
        secEngineID.setValue(securityEngineID);
      }
      OctetString secName = new OctetString(securityName);
      UsmUserEntry user;
      if (secEngineID.length() == 0)
      {
        UsmUserEntry user;
        if (isEngineDiscoveryEnabled()) {
          user = new UsmUserEntry();
        }
        else {
          if (logger.isDebugEnabled()) {
            logger.debug("Engine ID unknown and discovery disabled");
          }
          return 1410;
        }
      }
      else {
        user = getUser(secEngineID, secName);
      }
      if (user == null) {
        if (logger.isDebugEnabled()) {
          logger.debug("Security name not found for engineID=" + secEngineID.toHexString() + ", securityName=" + secName.toHexString());
        }

        return 1404;
      }
      AuthenticationProtocol auth = this.securityProtocols.getAuthenticationProtocol(user.getUsmUser().getAuthenticationProtocol());

      PrivacyProtocol priv = this.securityProtocols.getPrivacyProtocol(user.getUsmUser().getPrivacyProtocol());

      usmSecurityParams.setAuthenticationProtocol(auth);
      usmSecurityParams.setPrivacyProtocol(priv);
      usmSecurityParams.setAuthenticationKey(user.getAuthenticationKey());
      usmSecurityParams.setPrivacyKey(user.getPrivacyKey());
      usmSecurityParams.setUserName(user.getUsmUser().getSecurityName());
      usmSecurityParams.setAuthoritativeEngineID(secEngineID.getValue());
    }

    if (usmSecurityParams.getAuthoritativeEngineID().length > 32) {
      logger.error("Engine ID too long: " + usmSecurityParams.getAuthoritativeEngineID().length + ">" + 32 + " for " + new OctetString(usmSecurityParams.getAuthoritativeEngineID()).toHexString());

      return 1401;
    }
    if (securityName.length > 32) {
      logger.error("Security name too long: " + usmSecurityParams.getAuthoritativeEngineID().length + ">" + 32 + " for " + new OctetString(securityName).toHexString());

      return 1401;
    }

    if (securityLevel >= 2) {
      if (securityStateReference != null)
      {
        usmSecurityParams.setAuthoritativeEngineBoots(getEngineBoots());
        usmSecurityParams.setAuthoritativeEngineTime(getEngineTime());
      }
      else
      {
        OctetString secEngineID = new OctetString(securityEngineID);
        UsmTimeEntry entry = this.timeTable.getTime(secEngineID);
        if (entry == null) {
          entry = new UsmTimeEntry(secEngineID, usmSecurityParams.getAuthoritativeEngineBoots(), usmSecurityParams.getAuthoritativeEngineTime());

          this.timeTable.addEntry(entry);
        }
        else {
          usmSecurityParams.setAuthoritativeEngineBoots(entry.getEngineBoots());
          usmSecurityParams.setAuthoritativeEngineTime(entry.getLatestReceivedTime());
        }
      }

    }

    if ((securityLevel >= 2) && (usmSecurityParams.getAuthenticationProtocol() == null))
    {
      return 1403;
    }

    byte[] scopedPduBytes = buildMessageBuffer(scopedPDU);

    if (securityLevel == 3) {
      if (usmSecurityParams.getPrivacyProtocol() == null) {
        if (logger.isDebugEnabled()) {
          logger.debug("Unsupported security level (missing or unsupported privacy protocol)");
        }
        return 1403;
      }
      logger.debug("RFC3414 §3.1.4.a Outgoing message needs to be encrypted");

      DecryptParams decryptParams = new DecryptParams();
      byte[] encryptedScopedPdu = usmSecurityParams.getPrivacyProtocol().encrypt(scopedPduBytes, 0, scopedPduBytes.length, usmSecurityParams.getPrivacyKey(), usmSecurityParams.getAuthoritativeEngineBoots(), usmSecurityParams.getAuthoritativeEngineTime(), decryptParams);

      if (encryptedScopedPdu == null) {
        if (logger.isDebugEnabled()) {
          logger.debug("Encryption error");
        }
        return 1405;
      }
      usmSecurityParams.setPrivacyParameters(new OctetString(decryptParams.array));

      OctetString encryptedString = new OctetString(encryptedScopedPdu);
      BEROutputStream os = new BEROutputStream(ByteBuffer.allocate(encryptedString.getBERLength()));

      encryptedString.encodeBER(os);
      scopedPduBytes = os.getBuffer().array();
    }
    else {
      logger.debug("RFC3414 §3.1.4.b Outgoing message is not encrypted");
      usmSecurityParams.setPrivacyParameters(new OctetString());
    }
    byte[] wholeMessage;
    if (securityLevel >= 2)
    {
      byte[] blank = new byte[12];

      usmSecurityParams.setAuthenticationParameters(new OctetString(blank));
      byte[] wholeMessage = buildWholeMessage(new Integer32(snmpVersion), scopedPduBytes, globalData, usmSecurityParams);

      int authParamsPos = usmSecurityParams.getAuthParametersPosition() + usmSecurityParams.getSecurityParametersPosition();

      boolean authOK = usmSecurityParams.getAuthenticationProtocol().authenticate(usmSecurityParams.getAuthenticationKey(), wholeMessage, 0, wholeMessage.length, new ByteArrayWindow(wholeMessage, authParamsPos, 12));

      if (!authOK) {
        if (logger.isDebugEnabled()) {
          logger.debug("Outgoing message could not be authenticated");
        }
        return 1407;
      }
    }
    else
    {
      usmSecurityParams.setAuthoritativeEngineBoots(0);
      usmSecurityParams.setAuthenticationParameters(new OctetString());
      usmSecurityParams.setAuthoritativeEngineTime(0);

      wholeMessage = buildWholeMessage(new Integer32(snmpVersion), scopedPduBytes, globalData, usmSecurityParams);
    }

    ByteBuffer buf = (ByteBuffer)ByteBuffer.wrap(wholeMessage).position(wholeMessage.length);

    wholeMsg.setBuffer(buf);

    return 0;
  }

  private OctetString getSecurityName(OctetString engineID, OctetString userName)
  {
    if (userName.length() == 0) {
      return userName;
    }
    UsmUserEntry user = this.userTable.getUser(engineID, userName);
    if (user != null) {
      return user.getUsmUser().getSecurityName();
    }
    if (isEngineDiscoveryEnabled()) {
      user = this.userTable.getUser(userName);
      if (user != null) {
        return user.getUsmUser().getSecurityName();
      }
    }
    return null;
  }

  public int processIncomingMsg(int snmpVersion, int maxMessageSize, SecurityParameters securityParameters, SecurityModel securityModel, int securityLevel, BERInputStream wholeMsg, OctetString securityEngineID, OctetString securityName, BEROutputStream scopedPDU, Integer32 maxSizeResponseScopedPDU, SecurityStateReference securityStateReference, StatusInformation statusInfo)
    throws IOException
  {
    UsmSecurityParameters usmSecurityParameters = (UsmSecurityParameters)securityParameters;

    UsmSecurityStateReference usmSecurityStateReference = (UsmSecurityStateReference)securityStateReference;

    securityEngineID.setValue(usmSecurityParameters.getAuthoritativeEngineID());

    byte[] message = buildMessageBuffer(wholeMsg);

    if ((securityEngineID.length() == 0) || (this.timeTable.checkEngineID(securityEngineID, isEngineDiscoveryEnabled()) != 0))
    {
      if (logger.isDebugEnabled()) {
        logger.debug("RFC3414 §3.2.3 Unknown engine ID: " + securityEngineID.toHexString());
      }

      securityEngineID.setValue(usmSecurityParameters.getAuthoritativeEngineID());

      securityName.setValue(usmSecurityParameters.getUserName().getValue());

      if (statusInfo != null) {
        CounterEvent event = new CounterEvent(this, SnmpConstants.usmStatsUnknownEngineIDs);

        fireIncrementCounter(event);
        statusInfo.setSecurityLevel(new Integer32(securityLevel));
        statusInfo.setErrorIndication(new VariableBinding(event.getOid(), event.getCurrentValue()));
      }

      return 1410;
    }

    securityName.setValue(usmSecurityParameters.getUserName().getValue());

    int scopedPDUPosition = usmSecurityParameters.getScopedPduPosition();

    if ((usmSecurityParameters.getUserName().length() > 0) || (securityLevel > 1))
    {
      OctetString secName = getSecurityName(securityEngineID, usmSecurityParameters.getUserName());

      if (secName == null) {
        if (logger.isDebugEnabled()) {
          logger.debug("RFC3414 §3.2.4 Unknown security name: " + securityName.toHexString());
        }

        if (statusInfo != null) {
          CounterEvent event = new CounterEvent(this, SnmpConstants.usmStatsUnknownUserNames);

          fireIncrementCounter(event);
          statusInfo.setSecurityLevel(new Integer32(1));
          statusInfo.setErrorIndication(new VariableBinding(event.getOid(), event.getCurrentValue()));
        }

        return 1404;
      }
    }
    else {
      if (logger.isDebugEnabled()) {
        logger.debug("Accepting zero length security name");
      }
      securityName.setValue(new byte[0]);
    }

    if ((usmSecurityParameters.getUserName().length() > 0) || (securityLevel > 1))
    {
      UsmUserEntry user = getUser(securityEngineID, securityName);
      if (user == null) {
        if (logger.isDebugEnabled()) {
          logger.debug("RFC3414 §3.2.4 Unknown security name: " + securityName.toHexString() + " for engine ID " + securityEngineID.toHexString());
        }

        CounterEvent event = new CounterEvent(this, SnmpConstants.usmStatsUnknownUserNames);

        fireIncrementCounter(event);
        if (statusInfo != null) {
          statusInfo.setSecurityLevel(new Integer32(1));
          statusInfo.setErrorIndication(new VariableBinding(event.getOid(), event.getCurrentValue()));
        }

        return 1404;
      }

      usmSecurityStateReference.setUserName(user.getUserName().getValue());

      AuthenticationProtocol auth = this.securityProtocols.getAuthenticationProtocol(user.getUsmUser().getAuthenticationProtocol());

      PrivacyProtocol priv = this.securityProtocols.getPrivacyProtocol(user.getUsmUser().getPrivacyProtocol());

      if (((securityLevel >= 2) && (auth == null)) || ((securityLevel >= 3) && (priv == null)))
      {
        if (logger.isDebugEnabled()) {
          logger.debug("RFC3414 §3.2.5 - Unsupported security level: " + securityLevel);
        }

        CounterEvent event = new CounterEvent(this, SnmpConstants.usmStatsUnsupportedSecLevels);

        fireIncrementCounter(event);
        statusInfo.setSecurityLevel(new Integer32(1));
        statusInfo.setErrorIndication(new VariableBinding(event.getOid(), event.getCurrentValue()));

        return 1403;
      }
      if (securityLevel >= 2) {
        if (statusInfo != null) {
          int authParamsPos = usmSecurityParameters.getAuthParametersPosition() + usmSecurityParameters.getSecurityParametersPosition();

          boolean authentic = auth.isAuthentic(user.getAuthenticationKey(), message, 0, message.length, new ByteArrayWindow(message, authParamsPos, 12));

          if (!authentic) {
            if (logger.isDebugEnabled()) {
              logger.debug("RFC3414 §3.2.6 Wrong digest -> authentication failure: " + usmSecurityParameters.getAuthenticationParameters().toHexString());
            }

            CounterEvent event = new CounterEvent(this, SnmpConstants.usmStatsWrongDigests);

            fireIncrementCounter(event);
            statusInfo.setSecurityLevel(new Integer32(1));
            statusInfo.setErrorIndication(new VariableBinding(event.getOid(), event.getCurrentValue()));

            return 1408;
          }
          usmSecurityStateReference.setAuthenticationKey(user.getAuthenticationKey());
          usmSecurityStateReference.setPrivacyKey(user.getPrivacyKey());
          usmSecurityStateReference.setAuthenticationProtocol(auth);
          usmSecurityStateReference.setPrivacyProtocol(priv);

          int status = this.timeTable.checkTime(new UsmTimeEntry(securityEngineID, usmSecurityParameters.getAuthoritativeEngineBoots(), usmSecurityParameters.getAuthoritativeEngineTime()));

          switch (status) {
          case 1411:
            logger.debug("RFC3414 §3.2.7.a Not in time window; engineID='" + securityEngineID + "', engineBoots=" + usmSecurityParameters.getAuthoritativeEngineBoots() + ", engineTime=" + usmSecurityParameters.getAuthoritativeEngineTime());

            CounterEvent event = new CounterEvent(this, SnmpConstants.usmStatsNotInTimeWindows);

            fireIncrementCounter(event);
            statusInfo.setSecurityLevel(new Integer32(2));
            statusInfo.setErrorIndication(new VariableBinding(event.getOid(), event.getCurrentValue()));

            return status;
          case 1410:
            if (logger.isDebugEnabled()) {
              logger.debug("RFC3414 §3.2.7.b - Unkown engine ID: " + securityEngineID);
            }

            CounterEvent event = new CounterEvent(this, SnmpConstants.usmStatsUnknownEngineIDs);

            fireIncrementCounter(event);
            statusInfo.setSecurityLevel(new Integer32(2));
            statusInfo.setErrorIndication(new VariableBinding(event.getOid(), event.getCurrentValue()));

            return status;
          }

        }

        if (securityLevel >= 3) {
          OctetString privParams = usmSecurityParameters.getPrivacyParameters();
          DecryptParams decryptParams = new DecryptParams(privParams.getValue(), 0, privParams.length());
          try
          {
            int scopedPDUHeaderLength = message.length - scopedPDUPosition;
            ByteBuffer bis = ByteBuffer.wrap(message, scopedPDUPosition, scopedPDUHeaderLength);

            BERInputStream scopedPDUHeader = new BERInputStream(bis);
            long headerStartingPosition = scopedPDUHeader.getPosition();
            int scopedPDULength = BER.decodeHeader(scopedPDUHeader, new BER.MutableByte());

            int scopedPDUPayloadPosition = scopedPDUPosition + (int)(scopedPDUHeader.getPosition() - headerStartingPosition);

            scopedPDUHeader.close();
            scopedPDUHeader = null;
            byte[] scopedPduBytes = priv.decrypt(message, scopedPDUPayloadPosition, scopedPDULength, user.getPrivacyKey(), usmSecurityParameters.getAuthoritativeEngineBoots(), usmSecurityParameters.getAuthoritativeEngineTime(), decryptParams);

            ByteBuffer buf = ByteBuffer.wrap(scopedPduBytes);
            scopedPDU.setFilledBuffer(buf);
          }
          catch (Exception ex) {
            logger.debug("RFC 3414 §3.2.8 Decryption error: " + ex.getMessage());
            return 1406;
          }
        }
        else {
          int scopedPduLength = message.length - scopedPDUPosition;
          ByteBuffer buf = ByteBuffer.wrap(message, scopedPDUPosition, scopedPduLength);

          scopedPDU.setFilledBuffer(buf);
        }
      }
      else {
        int scopedPduLength = message.length - scopedPDUPosition;
        ByteBuffer buf = ByteBuffer.wrap(message, scopedPDUPosition, scopedPduLength);

        scopedPDU.setFilledBuffer(buf);
      }
    }
    else {
      int scopedPduLength = message.length - scopedPDUPosition;
      ByteBuffer buf = ByteBuffer.wrap(message, scopedPDUPosition, scopedPduLength);

      scopedPDU.setFilledBuffer(buf);
    }

    int maxSecParamsOverhead = usmSecurityParameters.getBERMaxLength(securityLevel);

    maxSizeResponseScopedPDU.setValue(maxMessageSize - maxSecParamsOverhead);

    usmSecurityStateReference.setSecurityName(securityName.getValue());
    return 0;
  }

  protected void fireIncrementCounter(CounterEvent e) {
    this.counterSupport.fireIncrementCounter(e);
  }

  public void addUser(OctetString userName, UsmUser user)
  {
    addUser(userName, new OctetString(), user);
  }

  public void addUser(OctetString userName, OctetString engineID, UsmUser user)
  {
    byte[] authKey = null;
    byte[] privKey = null;
    if ((engineID != null) && (engineID.length() > 0) && 
      (user.getAuthenticationProtocol() != null)) {
      if (user.isLocalized()) {
        authKey = user.getAuthenticationPassphrase().getValue();
      }
      else {
        authKey = this.securityProtocols.passwordToKey(user.getAuthenticationProtocol(), user.getAuthenticationPassphrase(), engineID.getValue());
      }

      if (user.getPrivacyProtocol() != null)
        if (user.isLocalized()) {
          privKey = user.getPrivacyPassphrase().getValue();
        }
        else
          privKey = this.securityProtocols.passwordToKey(user.getPrivacyProtocol(), user.getAuthenticationProtocol(), user.getPrivacyPassphrase(), engineID.getValue());
    }
    OctetString userEngineID;
    OctetString userEngineID;
    if (user.isLocalized()) {
      userEngineID = user.getLocalizationEngineID();
    }
    else {
      userEngineID = engineID == null ? new OctetString() : engineID;
    }
    UsmUserEntry entry = new UsmUserEntry(userName, userEngineID, user);

    entry.setAuthenticationKey(authKey);
    entry.setPrivacyKey(privKey);
    this.userTable.addUser(entry);
    fireUsmUserChange(new UsmUserEvent(this, entry, 1));
  }

  public void updateUser(UsmUserEntry entry)
  {
    UsmUserEntry oldEntry = this.userTable.addUser(entry);
    fireUsmUserChange(new UsmUserEvent(this, entry, oldEntry == null ? 1 : 3));
  }

  public void setUsers(UsmUser[] users)
  {
    if ((users == null) || (users.length == 0)) {
      this.userTable.clear();
    }
    else {
      Vector v = new Vector(users.length);
      for (int i = 0; i < users.length; i++) {
        UsmUserEntry entry = new UsmUserEntry(users[i].getSecurityName(), (UsmUser)users[i].clone());

        v.add(entry);
      }
      this.userTable.setUsers(v);
    }
  }

  public UsmUserTable getUserTable()
  {
    return this.userTable;
  }

  public UsmTimeTable getTimeTable()
  {
    return this.timeTable;
  }

  public UsmUser removeUser(OctetString engineID, OctetString userName)
  {
    UsmUserEntry entry = this.userTable.removeUser(engineID, userName);
    if (entry != null) {
      fireUsmUserChange(new UsmUserEvent(this, entry, 2));
      return entry.getUsmUser();
    }
    return null;
  }

  public void removeAllUsers()
  {
    this.userTable.clear();
    fireUsmUserChange(new UsmUserEvent(this, null, 2));
  }

  public UsmUserEntry addLocalizedUser(byte[] engineID, OctetString userName, OID authProtocol, byte[] authKey, OID privProtocol, byte[] privKey)
  {
    UsmUserEntry newEntry = new UsmUserEntry(engineID, userName, authProtocol, authKey, privProtocol, privKey);

    this.userTable.addUser(newEntry);
    fireUsmUserChange(new UsmUserEvent(this, newEntry, 1));

    return newEntry;
  }

  public boolean isEngineDiscoveryEnabled()
  {
    return this.engineDiscoveryEnabled;
  }

  public void setEngineDiscoveryEnabled(boolean engineDiscoveryEnabled)
  {
    this.engineDiscoveryEnabled = engineDiscoveryEnabled;
  }

  public synchronized void removeUsmUserListener(UsmUserListener l)
  {
    if ((this.usmUserListeners != null) && (this.usmUserListeners.contains(l))) {
      Vector v = (Vector)this.usmUserListeners.clone();
      v.removeElement(l);
      this.usmUserListeners = v;
    }
  }

  public synchronized void addUsmUserListener(UsmUserListener l)
  {
    Vector v = this.usmUserListeners == null ? new Vector(2) : (Vector)this.usmUserListeners.clone();

    if (!v.contains(l)) {
      v.addElement(l);
      this.usmUserListeners = v;
    }
  }

  public void removeEngineTime(OctetString engineID)
  {
    this.timeTable.removeEntry(engineID);
  }

  protected void fireUsmUserChange(UsmUserEvent e)
  {
    if (this.usmUserListeners != null) {
      Vector listeners = this.usmUserListeners;
      int count = listeners.size();
      for (int i = 0; i < count; i++)
        ((UsmUserListener)listeners.elementAt(i)).usmUserChange(e);
    }
  }

  public CounterSupport getCounterSupport()
  {
    return this.counterSupport;
  }

  public SecurityProtocols getSecurityProtocols()
  {
    return this.securityProtocols;
  }

  public void setCounterSupport(CounterSupport counterSupport)
  {
    if (counterSupport == null) {
      throw new NullPointerException();
    }
    this.counterSupport = counterSupport;
  }
}