package org.snmp4j.security;

import org.snmp4j.smi.OID;

public class PrivAES256 extends PrivAES
{
  private static final long serialVersionUID = -4678800188622949146L;
  public static final OID ID = new OID(" 1.3.6.1.4.1.4976.2.2.1.1.2");

  public PrivAES256()
  {
    super(32);
  }

  public OID getID()
  {
    return (OID)ID.clone();
  }
}