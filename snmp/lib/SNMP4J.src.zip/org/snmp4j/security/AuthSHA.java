package org.snmp4j.security;

import org.snmp4j.smi.OID;

public class AuthSHA extends AuthGeneric
{
  private static final long serialVersionUID = 2355896418236397919L;
  public static final OID ID = new OID("1.3.6.1.6.3.10.1.1.3");

  public AuthSHA() {
    super("SHA-1", 20);
  }

  public OID getID() {
    return (OID)ID.clone();
  }
}