package org.snmp4j.security;

import java.io.Serializable;
import org.snmp4j.smi.OctetString;

public class UsmTimeEntry
  implements Serializable
{
  private static final long serialVersionUID = -8064483016765127449L;
  private OctetString engineID;
  private int engineBoots;
  private int timeDiff;
  private int latestReceivedTime;

  public UsmTimeEntry(OctetString engineID, int engineBoots, int engineTime)
  {
    this.engineID = engineID;
    this.engineBoots = engineBoots;
    setEngineTime(engineTime);
  }

  public OctetString getEngineID() {
    return this.engineID;
  }

  public int getEngineBoots() {
    return this.engineBoots;
  }

  public void setEngineBoots(int engineBoots) {
    this.engineBoots = engineBoots;
  }

  public int getTimeDiff() {
    return this.timeDiff;
  }

  public void setTimeDiff(int timeDiff) {
    this.timeDiff = timeDiff;
  }

  public int getLatestReceivedTime()
  {
    return this.latestReceivedTime;
  }

  public void setLatestReceivedTime(int latestReceivedTime)
  {
    this.latestReceivedTime = latestReceivedTime;
  }

  public void setEngineTime(int engineTime)
  {
    this.latestReceivedTime = engineTime;
    this.timeDiff = (engineTime - (int)(System.currentTimeMillis() / 1000L));
  }
}