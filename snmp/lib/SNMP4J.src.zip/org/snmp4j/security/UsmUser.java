package org.snmp4j.security;

import org.snmp4j.User;
import org.snmp4j.smi.OID;
import org.snmp4j.smi.OctetString;

public class UsmUser
  implements User, Comparable, Cloneable
{
  private static final long serialVersionUID = -2258973598142206767L;
  private OctetString securityName;
  private OctetString authenticationPassphrase;
  private OctetString privacyPassphrase;
  private OID authenticationProtocol;
  private OID privacyProtocol;
  private OctetString localizationEngineID;

  public UsmUser(OctetString securityName, OID authenticationProtocol, OctetString authenticationPassphrase, OID privacyProtocol, OctetString privacyPassphrase)
  {
    if (securityName == null) {
      throw new NullPointerException();
    }
    if ((authenticationProtocol != null) && (authenticationPassphrase != null) && (authenticationPassphrase.length() < 8))
    {
      throw new IllegalArgumentException("USM passphrases must be at least 8 bytes long (RFC3414 §11.2)");
    }

    if ((privacyProtocol != null) && (privacyPassphrase != null) && (privacyPassphrase.length() < 8))
    {
      throw new IllegalArgumentException("USM passphrases must be at least 8 bytes long (RFC3414 §11.2)");
    }

    this.securityName = securityName;
    this.authenticationProtocol = authenticationProtocol;
    this.authenticationPassphrase = authenticationPassphrase;
    this.privacyProtocol = privacyProtocol;
    this.privacyPassphrase = privacyPassphrase;
  }

  public UsmUser(OctetString securityName, OID authenticationProtocol, OctetString authenticationPassphrase, OID privacyProtocol, OctetString privacyPassphrase, OctetString localizationEngineID)
  {
    this(securityName, authenticationProtocol, authenticationPassphrase, privacyProtocol, privacyPassphrase);

    this.localizationEngineID = localizationEngineID;
  }

  public OctetString getSecurityName()
  {
    return (OctetString)this.securityName.clone();
  }

  public OID getAuthenticationProtocol()
  {
    if (this.authenticationProtocol == null) {
      return null;
    }
    return (OID)this.authenticationProtocol.clone();
  }

  public OID getPrivacyProtocol()
  {
    if (this.privacyProtocol == null) {
      return null;
    }
    return (OID)this.privacyProtocol.clone();
  }

  public OctetString getAuthenticationPassphrase()
  {
    if (this.authenticationPassphrase == null) {
      return null;
    }
    return (OctetString)this.authenticationPassphrase.clone();
  }

  public OctetString getPrivacyPassphrase()
  {
    if (this.privacyPassphrase == null) {
      return null;
    }
    return (OctetString)this.privacyPassphrase.clone();
  }

  public OctetString getLocalizationEngineID()
  {
    return this.localizationEngineID;
  }

  public boolean isLocalized()
  {
    return this.localizationEngineID != null;
  }

  public int getSecurityModel()
  {
    return 3;
  }

  public int compareTo(Object o)
  {
    UsmUser other = (UsmUser)o;
    return this.securityName.compareTo(other.securityName);
  }

  public Object clone() {
    UsmUser copy = new UsmUser(this.securityName, this.authenticationProtocol, this.authenticationPassphrase, this.privacyProtocol, this.privacyPassphrase, this.localizationEngineID);

    return copy;
  }

  public String toString() {
    return "UsmUser[secName=" + this.securityName + ",authProtocol=" + this.authenticationProtocol + ",authPassphrase=" + this.authenticationPassphrase + ",privProtocol=" + this.privacyProtocol + ",privPassphrase=" + this.privacyPassphrase + ",localizationEngineID=" + getLocalizationEngineID() + "]";
  }
}