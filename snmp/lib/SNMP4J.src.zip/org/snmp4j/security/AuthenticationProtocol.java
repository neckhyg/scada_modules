package org.snmp4j.security;

import org.snmp4j.smi.OID;
import org.snmp4j.smi.OctetString;

public abstract interface AuthenticationProtocol extends SecurityProtocol
{
  public static final int MESSAGE_AUTHENTICATION_CODE_LENGTH = 12;

  public abstract boolean authenticate(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt1, int paramInt2, ByteArrayWindow paramByteArrayWindow);

  public abstract boolean isAuthentic(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt1, int paramInt2, ByteArrayWindow paramByteArrayWindow);

  public abstract byte[] changeDelta(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3);

  public abstract OID getID();

  public abstract byte[] passwordToKey(OctetString paramOctetString, byte[] paramArrayOfByte);

  public abstract byte[] hash(byte[] paramArrayOfByte);

  public abstract byte[] hash(byte[] paramArrayOfByte, int paramInt1, int paramInt2);

  public abstract int getDigestLength();
}