package org.snmp4j.security;

import org.snmp4j.smi.OID;
import org.snmp4j.smi.OctetString;

public abstract interface PrivacyProtocol extends SecurityProtocol
{
  public abstract byte[] encrypt(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, long paramLong1, long paramLong2, DecryptParams paramDecryptParams);

  public abstract byte[] decrypt(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, long paramLong1, long paramLong2, DecryptParams paramDecryptParams);

  public abstract OID getID();

  public abstract int getEncryptedLength(int paramInt);

  public abstract int getMinKeyLength();

  public abstract int getMaxKeyLength();

  public abstract int getDecryptParamsLength();

  public abstract byte[] extendShortKey(byte[] paramArrayOfByte1, OctetString paramOctetString, byte[] paramArrayOfByte2, AuthenticationProtocol paramAuthenticationProtocol);
}