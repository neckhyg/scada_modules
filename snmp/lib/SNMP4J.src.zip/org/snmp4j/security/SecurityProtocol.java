package org.snmp4j.security;

import java.io.Serializable;
import org.snmp4j.smi.OID;

public abstract interface SecurityProtocol extends Serializable
{
  public abstract OID getID();
}