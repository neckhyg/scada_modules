package org.snmp4j.security;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import org.snmp4j.log.LogAdapter;
import org.snmp4j.log.LogFactory;
import org.snmp4j.smi.OctetString;

public abstract class AuthGeneric
  implements AuthenticationProtocol
{
  private static final LogAdapter logger = LogFactory.getLogger(AuthGeneric.class);
  private int digestLength;
  private String protoName;

  public AuthGeneric(String protoName, int digestLength)
  {
    this.protoName = protoName;
    this.digestLength = digestLength;
  }

  public int getDigestLength() {
    return this.digestLength;
  }

  protected MessageDigest getDigestObject()
  {
    MessageDigest md;
    try
    {
      md = MessageDigest.getInstance(this.protoName);
    }
    catch (NoSuchAlgorithmException e) {
      throw new InternalError(this.protoName + " not supported in this VM.");
    }

    return md;
  }

  public boolean authenticate(byte[] authenticationKey, byte[] message, int messageOffset, int messageLength, ByteArrayWindow digest)
  {
    MessageDigest md = getDigestObject();

    byte[] k_ipad = new byte[64];
    byte[] k_opad = new byte[64];

    for (int i = 0; i < 12; i++) {
      digest.set(i, 0);
    }

    for (int i = 0; i < authenticationKey.length; i++) {
      k_ipad[i] = (byte)(authenticationKey[i] ^ 0x36);
      k_opad[i] = (byte)(authenticationKey[i] ^ 0x5C);
    }
    for (int i = authenticationKey.length; i < 64; i++) {
      k_ipad[i] = 54;
      k_opad[i] = 92;
    }

    md.update(k_ipad);
    md.update(message, messageOffset, messageLength);
    byte[] newDigest = md.digest();

    md.reset();
    md.update(k_opad);
    md.update(newDigest);
    newDigest = md.digest();

    for (int i = 0; i < 12; i++) {
      digest.set(i, newDigest[i]);
    }
    return true;
  }

  public boolean isAuthentic(byte[] authenticationKey, byte[] message, int messageOffset, int messageLength, ByteArrayWindow digest)
  {
    ByteArrayWindow origDigest = new ByteArrayWindow(new byte[12], 0, 12);

    System.arraycopy(digest.getValue(), digest.getOffset(), origDigest.getValue(), 0, 12);

    if (!authenticate(authenticationKey, message, messageOffset, messageLength, digest))
    {
      return false;
    }
    return digest.equals(origDigest, 12);
  }

  public byte[] changeDelta(byte[] oldKey, byte[] newKey, byte[] random)
  {
    MessageDigest hash = getDigestObject();

    int digestLength = hash.getDigestLength();

    if (logger.isDebugEnabled()) {
      logger.debug(this.protoName + "oldKey: " + new OctetString(oldKey).toHexString());

      logger.debug(this.protoName + "newKey: " + new OctetString(newKey).toHexString());

      logger.debug(this.protoName + "random: " + new OctetString(random).toHexString());
    }

    int iterations = (oldKey.length - 1) / hash.getDigestLength();

    OctetString tmp = new OctetString(oldKey);
    OctetString delta = new OctetString();
    for (int k = 0; k < iterations; k++) {
      tmp.append(random);
      hash.update(tmp.getValue());
      tmp.setValue(hash.digest());
      delta.append(new byte[digestLength]);
      for (int kk = 0; kk < digestLength; kk++) {
        delta.set(k * digestLength + kk, (byte)(tmp.get(kk) ^ newKey[(k * digestLength + kk)]));
      }

    }

    tmp.append(random);
    hash.update(tmp.getValue());
    tmp = new OctetString(hash.digest(), 0, oldKey.length - delta.length());
    for (int j = 0; j < tmp.length(); j++) {
      tmp.set(j, (byte)(tmp.get(j) ^ newKey[(iterations * digestLength + j)]));
    }
    byte[] keyChange = new byte[random.length + delta.length() + tmp.length()];
    System.arraycopy(random, 0, keyChange, 0, random.length);
    System.arraycopy(delta.getValue(), 0, keyChange, random.length, delta.length());

    System.arraycopy(tmp.getValue(), 0, keyChange, random.length + delta.length(), tmp.length());

    if (logger.isDebugEnabled()) {
      logger.debug(this.protoName + "keyChange:" + new OctetString(keyChange).toHexString());
    }

    return keyChange;
  }

  public byte[] passwordToKey(OctetString passwordString, byte[] engineID)
  {
    MessageDigest md = getDigestObject();

    byte[] buf = new byte[64];
    int password_index = 0;
    int count = 0;
    byte[] password = passwordString.getValue();

    while (count < 1048576) {
      for (int i = 0; i < 64; i++)
      {
        buf[i] = password[(password_index++ % password.length)];
      }
      md.update(buf);
      count += 64;
    }
    byte[] digest = md.digest();
    if (logger.isDebugEnabled()) {
      logger.debug(this.protoName + "First digest: " + new OctetString(digest).toHexString());
    }

    md.reset();
    md.update(digest);
    md.update(engineID);
    md.update(digest);
    digest = md.digest();
    if (logger.isDebugEnabled()) {
      logger.debug(this.protoName + "localized key: " + new OctetString(digest).toHexString());
    }

    return digest;
  }

  public byte[] hash(byte[] data) {
    MessageDigest md = getDigestObject();
    md.update(data);
    return md.digest();
  }

  public byte[] hash(byte[] data, int offset, int length) {
    MessageDigest md = getDigestObject();
    md.update(data, offset, length);
    return md.digest();
  }
}