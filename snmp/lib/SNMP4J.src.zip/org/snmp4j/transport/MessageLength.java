package org.snmp4j.transport;

import java.io.Serializable;

public class MessageLength
  implements Serializable
{
  private static final long serialVersionUID = -2722178759367760246L;
  private int payloadLength;
  private int headerLength;

  public MessageLength(int headerLength, int payloadLength)
  {
    this.payloadLength = payloadLength;
    this.headerLength = headerLength;
  }

  public int getPayloadLength()
  {
    return this.payloadLength;
  }

  public int getHeaderLength()
  {
    return this.headerLength;
  }

  public int getMessageLength()
  {
    return this.headerLength + this.payloadLength;
  }

  public String toString() {
    return MessageLength.class.getName() + "[headerLength=" + this.headerLength + ",payloadLength=" + this.payloadLength + "]";
  }
}