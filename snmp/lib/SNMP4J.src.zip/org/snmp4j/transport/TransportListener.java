package org.snmp4j.transport;

import java.nio.ByteBuffer;
import org.snmp4j.TransportMapping;
import org.snmp4j.smi.Address;

public abstract interface TransportListener
{
  public abstract void processMessage(TransportMapping paramTransportMapping, Address paramAddress, ByteBuffer paramByteBuffer);
}