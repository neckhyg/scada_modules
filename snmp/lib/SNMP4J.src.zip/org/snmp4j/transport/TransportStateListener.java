package org.snmp4j.transport;

import java.util.EventListener;

public abstract interface TransportStateListener extends EventListener
{
  public abstract void connectionStateChanged(TransportStateEvent paramTransportStateEvent);
}