package org.snmp4j.transport;

import org.snmp4j.MessageException;

public class UnsupportedAddressClassException extends MessageException
{
  private static final long serialVersionUID = -864696255672171900L;
  private Class addressClass;

  public UnsupportedAddressClassException(String message, Class addressClass)
  {
    super(message);
    this.addressClass = addressClass;
  }

  public Class getAddressClass()
  {
    return this.addressClass;
  }
}