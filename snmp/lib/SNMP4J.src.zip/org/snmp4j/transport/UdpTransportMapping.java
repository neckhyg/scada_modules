package org.snmp4j.transport;

import java.io.IOException;
import org.snmp4j.smi.Address;
import org.snmp4j.smi.UdpAddress;

public abstract class UdpTransportMapping extends AbstractTransportMapping
{
  protected UdpAddress udpAddress;

  public UdpTransportMapping(UdpAddress udpAddress)
  {
    this.udpAddress = udpAddress;
  }

  public Class getSupportedAddressClass() {
    return UdpAddress.class;
  }

  public UdpAddress getAddress()
  {
    return this.udpAddress;
  }

  public Address getListenAddress() {
    return this.udpAddress;
  }

  public abstract void listen()
    throws IOException;

  public abstract void close()
    throws IOException;

  public abstract void sendMessage(Address paramAddress, byte[] paramArrayOfByte)
    throws IOException;
}