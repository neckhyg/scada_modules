package org.snmp4j.transport;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.nio.channels.CancelledKeyException;
import java.nio.channels.ClosedChannelException;
import java.nio.channels.SelectableChannel;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Collection;
import java.util.Date;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Set;
import java.util.TimerTask;
import org.snmp4j.SNMP4JSettings;
import org.snmp4j.asn1.BER;
import org.snmp4j.asn1.BER.MutableByte;
import org.snmp4j.asn1.BERInputStream;
import org.snmp4j.log.LogAdapter;
import org.snmp4j.log.LogFactory;
import org.snmp4j.smi.Address;
import org.snmp4j.smi.OctetString;
import org.snmp4j.smi.TcpAddress;
import org.snmp4j.util.CommonTimer;
import org.snmp4j.util.ThreadFactory;
import org.snmp4j.util.TimerFactory;
import org.snmp4j.util.WorkerTask;

public class DefaultTcpTransportMapping extends TcpTransportMapping
{
  private static final LogAdapter logger = LogFactory.getLogger(DefaultTcpTransportMapping.class);

  private Map sockets = new Hashtable();
  private WorkerTask server;
  private ServerThread serverThread;
  private CommonTimer socketCleaner;
  private long connectionTimeout = 60000L;
  private boolean serverEnabled = false;
  private static final int MIN_SNMP_HEADER_LENGTH = 6;
  private MessageLengthDecoder messageLengthDecoder = new SnmpMesssageLengthDecoder();

  public DefaultTcpTransportMapping()
    throws UnknownHostException, IOException
  {
    super(new TcpAddress(InetAddress.getLocalHost(), 0));
  }

  public DefaultTcpTransportMapping(TcpAddress serverAddress)
    throws UnknownHostException, IOException
  {
    super(serverAddress);
    this.serverEnabled = true;
  }

  public synchronized void listen()
    throws IOException
  {
    if (this.server != null) {
      throw new SocketException("Port already listening");
    }
    this.serverThread = new ServerThread();
    this.server = SNMP4JSettings.getThreadFactory().createWorkerThread("DefaultTCPTransportMapping_" + getAddress(), this.serverThread, true);

    if (this.connectionTimeout > 0L)
    {
      this.socketCleaner = SNMP4JSettings.getTimerFactory().createTimer();
    }
    this.server.run();
  }

  public void setPriority(int newPriority)
  {
    WorkerTask st = this.server;
    if ((st instanceof Thread))
      ((Thread)st).setPriority(newPriority);
  }

  public int getPriority()
  {
    WorkerTask st = this.server;
    if ((st instanceof Thread)) {
      return ((Thread)st).getPriority();
    }

    return 5;
  }

  public void setThreadName(String name)
  {
    WorkerTask st = this.server;
    if ((st instanceof Thread))
      ((Thread)st).setName(name);
  }

  public String getThreadName()
  {
    WorkerTask st = this.server;
    if (st != null) {
      return ((Thread)st).getName();
    }

    return null;
  }

  public void close()
  {
    WorkerTask st = this.server;
    if (st != null) {
      st.terminate();
      st.interrupt();
      try {
        st.join();
      }
      catch (InterruptedException ex) {
        logger.warn(ex);
      }
      this.server = null;
      for (Iterator it = this.sockets.values().iterator(); it.hasNext(); ) {
        SocketEntry entry = (SocketEntry)it.next();
        Socket s = entry.getSocket();
        if (s != null) {
          try {
            SocketChannel sc = s.getChannel();
            s.close();
            if (logger.isDebugEnabled()) {
              logger.debug("Socket to " + entry.getPeerAddress() + " closed");
            }
            if (sc != null) {
              sc.close();
              if (logger.isDebugEnabled()) {
                logger.debug("Socket channel to " + entry.getPeerAddress() + " closed");
              }
            }

          }
          catch (IOException iox)
          {
            logger.debug(iox);
          }
        }
      }
      if (this.socketCleaner != null) {
        this.socketCleaner.cancel();
      }
      this.socketCleaner = null;
    }
  }

  public synchronized boolean close(Address remoteAddress)
    throws IOException
  {
    if (logger.isDebugEnabled()) {
      logger.debug("Closing socket for peer address " + remoteAddress);
    }
    SocketEntry entry = (SocketEntry)this.sockets.remove(remoteAddress);
    if (entry != null) {
      Socket s = entry.getSocket();
      if (s != null) {
        SocketChannel sc = entry.getSocket().getChannel();
        entry.getSocket().close();
        if (logger.isInfoEnabled()) {
          logger.info("Socket to " + entry.getPeerAddress() + " closed");
        }
        if (sc != null) {
          sc.close();
          if (logger.isDebugEnabled()) {
            logger.debug("Closed socket channel for peer address " + remoteAddress);
          }
        }
      }

      return true;
    }
    return false;
  }

  public void sendMessage(Address address, byte[] message)
    throws IOException
  {
    if (this.server == null) {
      listen();
    }
    this.serverThread.sendMessage(address, message);
  }

  public long getConnectionTimeout()
  {
    return this.connectionTimeout;
  }

  public void setConnectionTimeout(long connectionTimeout)
  {
    this.connectionTimeout = connectionTimeout;
  }

  public boolean isServerEnabled()
  {
    return this.serverEnabled;
  }

  public MessageLengthDecoder getMessageLengthDecoder() {
    return this.messageLengthDecoder;
  }

  public void setServerEnabled(boolean serverEnabled)
  {
    this.serverEnabled = serverEnabled;
  }

  public void setMessageLengthDecoder(MessageLengthDecoder messageLengthDecoder)
  {
    if (messageLengthDecoder == null) {
      throw new NullPointerException();
    }
    this.messageLengthDecoder = messageLengthDecoder;
  }

  public int getMaxInboundMessageSize()
  {
    return super.getMaxInboundMessageSize();
  }

  public void setMaxInboundMessageSize(int maxInboundMessageSize)
  {
    this.maxInboundMessageSize = maxInboundMessageSize;
  }

  private synchronized void timeoutSocket(SocketEntry entry)
  {
    if (this.connectionTimeout > 0L)
      this.socketCleaner.schedule(new SocketTimeout(entry), this.connectionTimeout);
  }

  public boolean isListening()
  {
    return this.server != null;
  }

  protected void setSocketOptions(ServerSocket serverSocket)
  {
  }

  class ServerThread
    implements WorkerTask
  {
    private byte[] buf;
    private volatile boolean stop = false;
    private Throwable lastError = null;
    private ServerSocketChannel ssc;
    private Selector selector;
    private LinkedList pending = new LinkedList();

    public ServerThread() throws IOException {
      this.buf = new byte[DefaultTcpTransportMapping.this.getMaxInboundMessageSize()];

      this.selector = Selector.open();

      if (DefaultTcpTransportMapping.this.serverEnabled)
      {
        this.ssc = ServerSocketChannel.open();
        this.ssc.configureBlocking(false);

        InetSocketAddress isa = new InetSocketAddress(DefaultTcpTransportMapping.this.tcpAddress.getInetAddress(), DefaultTcpTransportMapping.this.tcpAddress.getPort());

        DefaultTcpTransportMapping.this.setSocketOptions(this.ssc.socket());
        this.ssc.socket().bind(isa);

        this.ssc.register(this.selector, 16);
      }
    }

    private void processPending() {
      synchronized (this.pending) {
        for (int i = 0; i < this.pending.size(); i++) {
          DefaultTcpTransportMapping.SocketEntry entry = (DefaultTcpTransportMapping.SocketEntry)this.pending.getFirst();
          try
          {
            if (entry.getSocket().isConnected()) {
              entry.addRegistration(this.selector, 4);
            }
            else
              entry.addRegistration(this.selector, 8);
          }
          catch (CancelledKeyException ckex)
          {
            DefaultTcpTransportMapping.logger.warn(ckex);
            this.pending.remove(entry);
            try {
              entry.getSocket().getChannel().close();
              TransportStateEvent e = new TransportStateEvent(DefaultTcpTransportMapping.this, entry.getPeerAddress(), 4, null);

              DefaultTcpTransportMapping.this.fireConnectionStateChanged(e);
            }
            catch (IOException ex) {
              DefaultTcpTransportMapping.logger.error(ex);
            }
          }
          catch (IOException iox) {
            DefaultTcpTransportMapping.logger.error(iox);
            this.pending.remove(entry);
            try
            {
              entry.getSocket().getChannel().close();
              TransportStateEvent e = new TransportStateEvent(DefaultTcpTransportMapping.this, entry.getPeerAddress(), 4, iox);

              DefaultTcpTransportMapping.this.fireConnectionStateChanged(e);
            }
            catch (IOException ex) {
              DefaultTcpTransportMapping.logger.error(ex);
            }
            this.lastError = iox;
            if (SNMP4JSettings.isFowardRuntimeExceptions())
              throw new RuntimeException(iox);
          }
        }
      }
    }

    public Throwable getLastError()
    {
      return this.lastError;
    }

    public void sendMessage(Address address, byte[] message)
      throws IOException
    {
      Socket s = null;
      DefaultTcpTransportMapping.SocketEntry entry = (DefaultTcpTransportMapping.SocketEntry)DefaultTcpTransportMapping.this.sockets.get(address);
      if (DefaultTcpTransportMapping.logger.isDebugEnabled()) {
        DefaultTcpTransportMapping.logger.debug("Looking up connection for destination '" + address + "' returned: " + entry);

        DefaultTcpTransportMapping.logger.debug(DefaultTcpTransportMapping.this.sockets.toString());
      }
      if (entry != null) {
        s = entry.getSocket();
      }
      if ((s == null) || (s.isClosed()) || (!s.isConnected())) {
        if (DefaultTcpTransportMapping.logger.isDebugEnabled()) {
          DefaultTcpTransportMapping.logger.debug("Socket for address '" + address + "' is closed, opening it...");
        }

        synchronized (this.pending) {
          this.pending.remove(entry);
        }
        SocketChannel sc = null;
        try {
          InetSocketAddress targetAddress = new InetSocketAddress(((TcpAddress)address).getInetAddress(), ((TcpAddress)address).getPort());

          if ((s == null) || (s.isClosed()))
          {
            sc = SocketChannel.open();
            sc.configureBlocking(false);
            sc.connect(targetAddress);
          }
          else {
            sc = s.getChannel();
            sc.configureBlocking(false);
            if (!sc.isConnectionPending()) {
              sc.connect(targetAddress);
            }
          }
          s = sc.socket();
          entry = new DefaultTcpTransportMapping.SocketEntry(DefaultTcpTransportMapping.this, (TcpAddress)address, s);
          entry.addMessage(message);
          DefaultTcpTransportMapping.this.sockets.put(address, entry);

          synchronized (this.pending) {
            this.pending.add(entry);
          }

          this.selector.wakeup();
          DefaultTcpTransportMapping.logger.debug("Trying to connect to " + address);
        }
        catch (IOException iox) {
          DefaultTcpTransportMapping.logger.error(iox);
          throw iox;
        }
      }
      else {
        entry.addMessage(message);
        synchronized (this.pending) {
          this.pending.addFirst(entry);
        }
        DefaultTcpTransportMapping.logger.debug("Waking up selector for new message");
        this.selector.wakeup();
      }
    }

    public void run()
    {
      try
      {
        while (!this.stop) {
          try {
            if (this.selector.select() > 0) {
              if (this.stop)
              {
                break;
              }
              Set readyKeys = this.selector.selectedKeys();
              Iterator it = readyKeys.iterator();

              while (it.hasNext()) {
                try {
                  SelectionKey sk = (SelectionKey)it.next();
                  it.remove();
                  SocketChannel readChannel = null;
                  TcpAddress incomingAddress = null;
                  if (sk.isAcceptable()) {
                    DefaultTcpTransportMapping.logger.debug("Key is acceptable");

                    ServerSocketChannel nextReady = (ServerSocketChannel)sk.channel();

                    Socket s = nextReady.accept().socket();
                    readChannel = s.getChannel();
                    readChannel.configureBlocking(false);

                    incomingAddress = new TcpAddress(s.getInetAddress(), s.getPort());

                    DefaultTcpTransportMapping.SocketEntry entry = new DefaultTcpTransportMapping.SocketEntry(DefaultTcpTransportMapping.this, incomingAddress, s);
                    entry.addRegistration(this.selector, 1);
                    DefaultTcpTransportMapping.this.sockets.put(incomingAddress, entry);
                    DefaultTcpTransportMapping.this.timeoutSocket(entry);
                    TransportStateEvent e = new TransportStateEvent(DefaultTcpTransportMapping.this, incomingAddress, 1, null);

                    DefaultTcpTransportMapping.this.fireConnectionStateChanged(e);
                    if (e.isCancelled()) {
                      DefaultTcpTransportMapping.logger.warn("Incoming connection cancelled");
                      s.close();
                      DefaultTcpTransportMapping.this.sockets.remove(incomingAddress);
                      readChannel = null;
                    }
                  }
                  else if (sk.isReadable()) {
                    DefaultTcpTransportMapping.logger.debug("Key is readable");
                    readChannel = (SocketChannel)sk.channel();
                    incomingAddress = new TcpAddress(readChannel.socket().getInetAddress(), readChannel.socket().getPort());
                  }
                  else if (sk.isWritable()) {
                    DefaultTcpTransportMapping.logger.debug("Key is writable");
                    incomingAddress = writeData(sk, incomingAddress);
                  }
                  else if (sk.isConnectable()) {
                    DefaultTcpTransportMapping.logger.debug("Key is connectable");
                    connectChannel(sk, incomingAddress);
                  }

                  if (readChannel != null) {
                    DefaultTcpTransportMapping.logger.debug("Key is reading");
                    try {
                      readMessage(sk, readChannel, incomingAddress);
                    }
                    catch (IOException iox)
                    {
                      DefaultTcpTransportMapping.logger.warn(iox);
                      sk.cancel();
                      readChannel.close();
                      TransportStateEvent e = new TransportStateEvent(DefaultTcpTransportMapping.this, incomingAddress, 2, iox);

                      DefaultTcpTransportMapping.this.fireConnectionStateChanged(e);
                    }
                  }
                }
                catch (CancelledKeyException ckex) {
                  if (DefaultTcpTransportMapping.logger.isDebugEnabled()) {
                    DefaultTcpTransportMapping.logger.debug("Selection key cancelled, skipping it");
                  }
                }
              }
            }
          }
          catch (NullPointerException npex)
          {
            npex.printStackTrace();
            DefaultTcpTransportMapping.logger.warn("NullPointerException within select()?");
            this.stop = true;
          }
          processPending();
        }
        if (this.ssc != null) {
          this.ssc.close();
        }
        if (this.selector != null)
          this.selector.close();
      }
      catch (IOException iox)
      {
        DefaultTcpTransportMapping.logger.error(iox);
        this.lastError = iox;
      }
      if (!this.stop) {
        this.stop = true;
        synchronized (DefaultTcpTransportMapping.this) {
          DefaultTcpTransportMapping.access$602(DefaultTcpTransportMapping.this, null);
        }
      }
      if (DefaultTcpTransportMapping.logger.isDebugEnabled())
        DefaultTcpTransportMapping.logger.debug("Worker task finished: " + getClass().getName());
    }

    private void connectChannel(SelectionKey sk, TcpAddress incomingAddress)
    {
      DefaultTcpTransportMapping.SocketEntry entry = (DefaultTcpTransportMapping.SocketEntry)sk.attachment();
      try {
        SocketChannel sc = (SocketChannel)sk.channel();
        if (!sc.isConnected()) {
          if (sc.finishConnect()) {
            sc.configureBlocking(false);
            DefaultTcpTransportMapping.logger.debug("Connected to " + entry.getPeerAddress());

            DefaultTcpTransportMapping.this.timeoutSocket(entry);
            entry.removeRegistration(this.selector, 8);
            entry.addRegistration(this.selector, 4);
          }
          else {
            entry = null;
          }
        }
        if (entry != null) {
          Address addr = incomingAddress == null ? entry.getPeerAddress() : incomingAddress;

          DefaultTcpTransportMapping.logger.debug("Fire connected event for " + addr);
          TransportStateEvent e = new TransportStateEvent(DefaultTcpTransportMapping.this, addr, 1, null);

          DefaultTcpTransportMapping.this.fireConnectionStateChanged(e);
        }
      }
      catch (IOException iox) {
        DefaultTcpTransportMapping.logger.warn(iox);
        sk.cancel();
        closeChannel(sk.channel());
        if (entry != null)
          this.pending.remove(entry);
      }
    }

    private TcpAddress writeData(SelectionKey sk, TcpAddress incomingAddress)
    {
      DefaultTcpTransportMapping.SocketEntry entry = (DefaultTcpTransportMapping.SocketEntry)sk.attachment();
      try {
        SocketChannel sc = (SocketChannel)sk.channel();
        incomingAddress = new TcpAddress(sc.socket().getInetAddress(), sc.socket().getPort());

        if (!entry.hasMessage()) {
          synchronized (this.pending) {
            this.pending.remove(entry);
            entry.removeRegistration(this.selector, 4);
          }
        }
        if (entry != null)
          writeMessage(entry, sc);
      }
      catch (IOException iox)
      {
        DefaultTcpTransportMapping.logger.warn(iox);
        TransportStateEvent e = new TransportStateEvent(DefaultTcpTransportMapping.this, incomingAddress, 2, iox);

        DefaultTcpTransportMapping.this.fireConnectionStateChanged(e);

        closeChannel(sk.channel());
      }
      return incomingAddress;
    }

    private void closeChannel(SelectableChannel channel) {
      try {
        channel.close();
      }
      catch (IOException channelCloseException) {
        DefaultTcpTransportMapping.logger.warn(channelCloseException);
      }
    }

    private void readMessage(SelectionKey sk, SocketChannel readChannel, TcpAddress incomingAddress) throws IOException
    {
      DefaultTcpTransportMapping.SocketEntry entry = (DefaultTcpTransportMapping.SocketEntry)DefaultTcpTransportMapping.this.sockets.get(incomingAddress);
      if (entry != null)
      {
        entry.used();
        ByteBuffer readBuffer = entry.getReadBuffer();
        if (readBuffer != null) {
          readChannel.read(readBuffer);
          if (readBuffer.hasRemaining()) {
            entry.addRegistration(this.selector, 1);
          }
          else {
            entry.setReadBuffer(null);
            dispatchMessage(incomingAddress, readBuffer, readBuffer.capacity());
          }
          return;
        }
      }
      ByteBuffer byteBuffer = ByteBuffer.wrap(this.buf);
      byteBuffer.limit(DefaultTcpTransportMapping.this.messageLengthDecoder.getMinHeaderLength());
      if (!readChannel.isOpen()) {
        sk.cancel();
        if (DefaultTcpTransportMapping.logger.isDebugEnabled()) {
          DefaultTcpTransportMapping.logger.debug("Read channel not open, no bytes read from " + incomingAddress);
        }

        return;
      }
      long bytesRead = 0L;
      try {
        bytesRead = readChannel.read(byteBuffer);
        if (DefaultTcpTransportMapping.logger.isDebugEnabled()) {
          DefaultTcpTransportMapping.logger.debug("Reading header " + bytesRead + " bytes from " + incomingAddress);
        }
      }
      catch (ClosedChannelException ccex)
      {
        sk.cancel();
        if (DefaultTcpTransportMapping.logger.isDebugEnabled()) {
          DefaultTcpTransportMapping.logger.debug("Read channel not open, no bytes read from " + incomingAddress);
        }

        return;
      }
      MessageLength messageLength = new MessageLength(0, -2147483648);
      if (bytesRead == DefaultTcpTransportMapping.this.messageLengthDecoder.getMinHeaderLength()) {
        messageLength = DefaultTcpTransportMapping.this.messageLengthDecoder.getMessageLength(ByteBuffer.wrap(this.buf));

        if (DefaultTcpTransportMapping.logger.isDebugEnabled()) {
          DefaultTcpTransportMapping.logger.debug("Message length is " + messageLength);
        }
        if ((messageLength.getMessageLength() > DefaultTcpTransportMapping.this.getMaxInboundMessageSize()) || (messageLength.getMessageLength() <= 0))
        {
          DefaultTcpTransportMapping.logger.error("Received message length " + messageLength + " is greater than inboundBufferSize " + DefaultTcpTransportMapping.this.getMaxInboundMessageSize());

          if (entry != null) {
            Socket s = entry.getSocket();
            if (s != null) {
              s.close();
              DefaultTcpTransportMapping.logger.info("Socket to " + entry.getPeerAddress() + " closed due to an error");
            }
          }
        }
        else
        {
          byteBuffer.limit(messageLength.getMessageLength());
          bytesRead += readChannel.read(byteBuffer);
          if (bytesRead == messageLength.getMessageLength()) {
            dispatchMessage(incomingAddress, byteBuffer, bytesRead);
          }
          else {
            byte[] message = new byte[byteBuffer.limit()];
            int buflen = byteBuffer.limit() - byteBuffer.remaining();
            byteBuffer.flip();
            byteBuffer.get(message, 0, buflen);
            ByteBuffer newBuffer = ByteBuffer.wrap(message);
            newBuffer.position(buflen);
            entry.setReadBuffer(newBuffer);
          }
          entry.addRegistration(this.selector, 1);
        }
      }
      else if (bytesRead < 0L) {
        DefaultTcpTransportMapping.logger.debug("Socket closed remotely");
        sk.cancel();
        readChannel.close();
        TransportStateEvent e = new TransportStateEvent(DefaultTcpTransportMapping.this, incomingAddress, 2, null);

        DefaultTcpTransportMapping.this.fireConnectionStateChanged(e);
      }
      else {
        entry.addRegistration(this.selector, 1);
      }
    }

    private void dispatchMessage(TcpAddress incomingAddress, ByteBuffer byteBuffer, long bytesRead)
    {
      byteBuffer.flip();
      if (DefaultTcpTransportMapping.logger.isDebugEnabled())
        DefaultTcpTransportMapping.logger.debug("Received message from " + incomingAddress + " with length " + bytesRead + ": " + new OctetString(byteBuffer.array(), 0, (int)bytesRead).toHexString());
      ByteBuffer bis;
      ByteBuffer bis;
      if (DefaultTcpTransportMapping.this.isAsyncMsgProcessingSupported()) {
        byte[] bytes = new byte[(int)bytesRead];
        System.arraycopy(byteBuffer.array(), 0, bytes, 0, (int)bytesRead);
        bis = ByteBuffer.wrap(bytes);
      }
      else {
        bis = ByteBuffer.wrap(byteBuffer.array(), 0, (int)bytesRead);
      }

      DefaultTcpTransportMapping.this.fireProcessMessage(incomingAddress, bis);
    }

    private void writeMessage(DefaultTcpTransportMapping.SocketEntry entry, SocketChannel sc) throws IOException
    {
      byte[] message = entry.nextMessage();
      if (message != null) {
        ByteBuffer buffer = ByteBuffer.wrap(message);
        sc.write(buffer);
        if (DefaultTcpTransportMapping.logger.isDebugEnabled()) {
          DefaultTcpTransportMapping.logger.debug("Send message with length " + message.length + " to " + entry.getPeerAddress() + ": " + new OctetString(message).toHexString());
        }

        entry.addRegistration(this.selector, 1);
      }
      else {
        entry.removeRegistration(this.selector, 4);

        if ((entry.hasMessage()) && (!entry.isRegistered(4))) {
          entry.addRegistration(this.selector, 4);
          DefaultTcpTransportMapping.logger.debug("Waking up selector");
          this.selector.wakeup();
        }
      }
    }

    public void close() {
      this.stop = true;
      WorkerTask st = DefaultTcpTransportMapping.this.server;
      if (st != null)
        st.terminate();
    }

    public void terminate()
    {
      this.stop = true;
      if (DefaultTcpTransportMapping.logger.isDebugEnabled())
        DefaultTcpTransportMapping.logger.debug("Terminated worker task: " + getClass().getName());
    }

    public void join()
    {
      if (DefaultTcpTransportMapping.logger.isDebugEnabled())
        DefaultTcpTransportMapping.logger.debug("Joining worker task: " + getClass().getName());
    }

    public void interrupt()
    {
      this.stop = true;
      if (DefaultTcpTransportMapping.logger.isDebugEnabled()) {
        DefaultTcpTransportMapping.logger.debug("Interrupting worker task: " + getClass().getName());
      }
      this.selector.wakeup();
    }
  }

  class SocketTimeout extends TimerTask
  {
    private DefaultTcpTransportMapping.SocketEntry entry;

    public SocketTimeout(DefaultTcpTransportMapping.SocketEntry entry)
    {
      this.entry = entry;
    }

    public void run()
    {
      long now = System.currentTimeMillis();
      if ((DefaultTcpTransportMapping.this.socketCleaner == null) || (now - this.entry.getLastUse() >= DefaultTcpTransportMapping.this.connectionTimeout))
      {
        if (DefaultTcpTransportMapping.logger.isDebugEnabled()) {
          DefaultTcpTransportMapping.logger.debug("Socket has not been used for " + (now - this.entry.getLastUse()) + " micro seconds, closing it");
        }

        DefaultTcpTransportMapping.this.sockets.remove(this.entry.getPeerAddress());
        try {
          synchronized (this.entry) {
            this.entry.getSocket().close();
          }
          DefaultTcpTransportMapping.logger.info("Socket to " + this.entry.getPeerAddress() + " closed due to timeout");
        }
        catch (IOException ex)
        {
          DefaultTcpTransportMapping.logger.error(ex);
        }
      }
      else {
        if (DefaultTcpTransportMapping.logger.isDebugEnabled()) {
          DefaultTcpTransportMapping.logger.debug("Scheduling " + (this.entry.getLastUse() + DefaultTcpTransportMapping.this.connectionTimeout - now));
        }

        DefaultTcpTransportMapping.this.socketCleaner.schedule(new SocketTimeout(DefaultTcpTransportMapping.this, this.entry), this.entry.getLastUse() + DefaultTcpTransportMapping.this.connectionTimeout - now);
      }
    }

    public boolean cancel()
    {
      boolean result = super.cancel();

      this.entry = null;
      return result;
    }
  }

  public static class SnmpMesssageLengthDecoder
    implements MessageLengthDecoder
  {
    public int getMinHeaderLength()
    {
      return 6;
    }
    public MessageLength getMessageLength(ByteBuffer buf) throws IOException {
      BER.MutableByte type = new BER.MutableByte();
      BERInputStream is = new BERInputStream(buf);
      int ml = BER.decodeHeader(is, type);
      int hl = (int)is.getPosition();
      MessageLength messageLength = new MessageLength(hl, ml);
      return messageLength;
    }
  }

  class SocketEntry
  {
    private Socket socket;
    private TcpAddress peerAddress;
    private long lastUse;
    private LinkedList message = new LinkedList();
    private ByteBuffer readBuffer = null;
    private volatile int registrations = 0;

    public SocketEntry(TcpAddress address, Socket socket) {
      this.peerAddress = address;
      this.socket = socket;
      this.lastUse = System.currentTimeMillis();
    }

    public synchronized void addRegistration(Selector selector, int opKey)
      throws ClosedChannelException
    {
      if ((this.registrations & opKey) == 0) {
        this.registrations |= opKey;
        if (DefaultTcpTransportMapping.logger.isDebugEnabled()) {
          DefaultTcpTransportMapping.logger.debug("Adding operation " + opKey + " for: " + toString());
        }
        this.socket.getChannel().register(selector, this.registrations, this);
      }
      else if (!this.socket.getChannel().isRegistered()) {
        this.registrations = opKey;
        if (DefaultTcpTransportMapping.logger.isDebugEnabled()) {
          DefaultTcpTransportMapping.logger.debug("Registering new operation " + opKey + " for: " + toString());
        }
        this.socket.getChannel().register(selector, opKey, this);
      }
    }

    public synchronized void removeRegistration(Selector selector, int opKey) throws ClosedChannelException
    {
      if ((this.registrations & opKey) == opKey) {
        this.registrations &= (opKey ^ 0xFFFFFFFF);
        this.socket.getChannel().register(selector, this.registrations, this);
      }
    }

    public synchronized boolean isRegistered(int opKey) {
      return (this.registrations & opKey) == opKey;
    }

    public long getLastUse() {
      return this.lastUse;
    }

    public void used() {
      this.lastUse = System.currentTimeMillis();
    }

    public Socket getSocket() {
      return this.socket;
    }

    public TcpAddress getPeerAddress() {
      return this.peerAddress;
    }

    public synchronized void addMessage(byte[] message) {
      this.message.add(message);
    }

    public synchronized byte[] nextMessage() {
      if (this.message.size() > 0) {
        return (byte[])(byte[])this.message.removeFirst();
      }
      return null;
    }

    public synchronized boolean hasMessage() {
      return !this.message.isEmpty();
    }

    public void setReadBuffer(ByteBuffer byteBuffer) {
      this.readBuffer = byteBuffer;
    }

    public ByteBuffer getReadBuffer() {
      return this.readBuffer;
    }

    public String toString() {
      return "SocketEntry[peerAddress=" + this.peerAddress + ",socket=" + this.socket + ",lastUse=" + new Date(this.lastUse) + "]";
    }
  }
}