package org.snmp4j.transport;

import java.io.IOException;
import java.nio.ByteBuffer;

public abstract interface MessageLengthDecoder
{
  public abstract int getMinHeaderLength();

  public abstract MessageLength getMessageLength(ByteBuffer paramByteBuffer)
    throws IOException;
}