package org.snmp4j.transport;

import java.io.IOException;
import java.util.EventObject;
import org.snmp4j.smi.Address;

public class TransportStateEvent extends EventObject
{
  private static final long serialVersionUID = 6440139076579035559L;
  public static final int STATE_UNKNOWN = 0;
  public static final int STATE_CONNECTED = 1;
  public static final int STATE_DISCONNECTED_REMOTELY = 2;
  public static final int STATE_DISCONNECTED_TIMEOUT = 3;
  public static final int STATE_CLOSED = 4;
  private int newState;
  private Address peerAddress;
  private IOException causingException;
  private boolean cancelled = false;

  public TransportStateEvent(Object source, Address peerAddress, int newState, IOException causingException)
  {
    super(source);
    this.newState = newState;
    this.peerAddress = peerAddress;
    this.causingException = causingException;
  }

  public IOException getCausingException() {
    return this.causingException;
  }

  public int getNewState() {
    return this.newState;
  }

  public Address getPeerAddress() {
    return this.peerAddress;
  }

  public boolean isCancelled()
  {
    return this.cancelled;
  }

  public String toString() {
    return TransportStateEvent.class.getName() + "[source=" + this.source + ",peerAddress=" + this.peerAddress + ",newState=" + this.newState + ",cancelled=" + this.cancelled + ",causingException=" + this.causingException + "]";
  }

  public void setCancelled(boolean cancelled)
  {
    this.cancelled = cancelled;
  }
}