package org.snmp4j.transport;

import java.io.IOException;
import java.util.Vector;
import org.snmp4j.log.LogAdapter;
import org.snmp4j.log.LogFactory;
import org.snmp4j.smi.Address;
import org.snmp4j.smi.TcpAddress;

public abstract class TcpTransportMapping extends AbstractTransportMapping
  implements ConnectionOrientedTransportMapping
{
  private static final LogAdapter logger = LogFactory.getLogger(TcpTransportMapping.class);
  protected TcpAddress tcpAddress;
  private transient Vector transportStateListeners;

  public TcpTransportMapping(TcpAddress tcpAddress)
  {
    this.tcpAddress = tcpAddress;
  }

  public Class getSupportedAddressClass() {
    return TcpAddress.class;
  }

  public TcpAddress getAddress()
  {
    return this.tcpAddress;
  }

  public Address getListenAddress() {
    return this.tcpAddress;
  }

  public abstract void sendMessage(Address paramAddress, byte[] paramArrayOfByte)
    throws IOException;

  public abstract void listen()
    throws IOException;

  public abstract void close()
    throws IOException;

  public abstract MessageLengthDecoder getMessageLengthDecoder();

  public abstract void setMessageLengthDecoder(MessageLengthDecoder paramMessageLengthDecoder);

  public abstract void setConnectionTimeout(long paramLong);

  public synchronized void addTransportStateListener(TransportStateListener l)
  {
    if (this.transportStateListeners == null) {
      this.transportStateListeners = new Vector(2);
    }
    this.transportStateListeners.add(l);
  }

  public synchronized void removeTransportStateListener(TransportStateListener l)
  {
    if (this.transportStateListeners != null)
      this.transportStateListeners.remove(l);
  }

  protected void fireConnectionStateChanged(TransportStateEvent change)
  {
    if (logger.isDebugEnabled()) {
      logger.debug("Firing transport state event: " + change);
    }
    if (this.transportStateListeners != null) {
      Vector listeners = this.transportStateListeners;
      int count = listeners.size();
      for (int i = 0; i < count; i++)
        ((TransportStateListener)listeners.get(i)).connectionStateChanged(change);
    }
  }
}