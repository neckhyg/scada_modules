package org.snmp4j.transport;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;
import org.snmp4j.SNMP4JSettings;
import org.snmp4j.TransportMapping;
import org.snmp4j.log.LogAdapter;
import org.snmp4j.log.LogFactory;
import org.snmp4j.smi.Address;

public class TransportMappings
{
  private static final LogAdapter logger = LogFactory.getLogger(TransportMappings.class);
  public static final String TRANSPORT_MAPPINGS = "org.snmp4j.transportMappings";
  private static final String TRANSPORT_MAPPINGS_DEFAULT = "transports.properties";
  private static TransportMappings instance = null;
  private Hashtable transportMappings = null;

  public static TransportMappings getInstance()
  {
    if (instance == null) {
      instance = new TransportMappings();
    }
    return instance;
  }

  public TransportMapping createTransportMapping(Address transportAddress)
  {
    if (this.transportMappings == null) {
      registerTransportMappings();
    }
    Class c = (Class)this.transportMappings.get(transportAddress.getClass().getName());

    if (c == null) {
      return null;
    }
    Class[] params = new Class[1];
    params[0] = transportAddress.getClass();
    Constructor constructor = null;
    try {
      constructor = c.getConstructor(params);
      return (TransportMapping)constructor.newInstance(new Object[] { transportAddress });
    }
    catch (InvocationTargetException ite)
    {
      if (logger.isDebugEnabled()) {
        ite.printStackTrace();
      }
      logger.error(ite);
      throw new RuntimeException(ite.getTargetException());
    }
    catch (Exception ex) {
      if (logger.isDebugEnabled()) {
        ex.printStackTrace();
      }
      logger.error(ex);
    }return null;
  }

  protected synchronized void registerTransportMappings()
  {
    if (SNMP4JSettings.isExtensibilityEnabled()) {
      String transports = System.getProperty("org.snmp4j.transportMappings", "transports.properties");

      InputStream is = TransportMappings.class.getResourceAsStream(transports);
      if (is == null) {
        throw new InternalError("Could not read '" + transports + "' from classpath!");
      }

      Properties props = new Properties();
      try {
        props.load(is);
        Hashtable t = new Hashtable(props.size());
        for (Enumeration en = props.propertyNames(); en.hasMoreElements(); ) {
          String addressClassName = (String)en.nextElement();
          String className = props.getProperty(addressClassName);
          try {
            Class c = Class.forName(className);
            t.put(addressClassName, c);
          }
          catch (ClassNotFoundException cnfe) {
            logger.error(cnfe);
          }
        }

        this.transportMappings = t;
      }
      catch (IOException iox) {
        String txt = "Could not read '" + transports + "': " + iox.getMessage();

        logger.error(txt);
        throw new InternalError(txt);
      }
      finally {
        try {
          is.close();
        }
        catch (IOException ex) {
          logger.warn(ex);
        }
      }
    }
    else {
      Hashtable t = new Hashtable(2);
      t.put("org.snmp4j.smi.UdpAddress", DefaultUdpTransportMapping.class);
      t.put("org.snmp4j.smi.TcpAddress", DefaultTcpTransportMapping.class);
      this.transportMappings = t;
    }
  }
}