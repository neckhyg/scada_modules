package org.snmp4j.transport;

import java.io.IOException;
import org.snmp4j.TransportMapping;
import org.snmp4j.smi.Address;

public abstract interface ConnectionOrientedTransportMapping extends TransportMapping
{
  public abstract MessageLengthDecoder getMessageLengthDecoder();

  public abstract void setMessageLengthDecoder(MessageLengthDecoder paramMessageLengthDecoder);

  public abstract void setConnectionTimeout(long paramLong);

  public abstract void addTransportStateListener(TransportStateListener paramTransportStateListener);

  public abstract void removeTransportStateListener(TransportStateListener paramTransportStateListener);

  public abstract boolean close(Address paramAddress)
    throws IOException;
}