package org.snmp4j.transport;

import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.PortUnreachableException;
import java.net.SocketAddress;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.nio.ByteBuffer;
import org.snmp4j.SNMP4JSettings;
import org.snmp4j.log.LogAdapter;
import org.snmp4j.log.LogFactory;
import org.snmp4j.smi.Address;
import org.snmp4j.smi.OctetString;
import org.snmp4j.smi.UdpAddress;
import org.snmp4j.util.ThreadFactory;
import org.snmp4j.util.WorkerTask;

public class DefaultUdpTransportMapping extends UdpTransportMapping
{
  private static final LogAdapter logger = LogFactory.getLogger(DefaultUdpTransportMapping.class);

  protected DatagramSocket socket = null;
  protected WorkerTask listener;
  protected ListenThread listenerThread;
  private int socketTimeout = 0;

  private int receiveBufferSize = 0;

  public DefaultUdpTransportMapping()
    throws IOException
  {
    super(new UdpAddress(InetAddress.getLocalHost(), 0));
    this.socket = new DatagramSocket(this.udpAddress.getPort());
  }

  public DefaultUdpTransportMapping(UdpAddress udpAddress, boolean reuseAddress)
    throws IOException
  {
    super(udpAddress);
    this.socket = new DatagramSocket(null);
    this.socket.setReuseAddress(reuseAddress);
    SocketAddress addr = new InetSocketAddress(udpAddress.getInetAddress(), udpAddress.getPort());

    this.socket.bind(addr);
  }

  public DefaultUdpTransportMapping(UdpAddress udpAddress)
    throws IOException
  {
    super(udpAddress);
    this.socket = new DatagramSocket(udpAddress.getPort(), udpAddress.getInetAddress());
  }

  public void sendMessage(Address targetAddress, byte[] message)
    throws IOException
  {
    InetSocketAddress targetSocketAddress = new InetSocketAddress(((UdpAddress)targetAddress).getInetAddress(), ((UdpAddress)targetAddress).getPort());

    if (logger.isDebugEnabled()) {
      logger.debug("Sending message to " + targetAddress + " with length " + message.length + ": " + new OctetString(message).toHexString());
    }

    DatagramSocket s = ensureSocket();
    s.send(new DatagramPacket(message, message.length, targetSocketAddress));
  }

  public void close()
    throws IOException
  {
    boolean interrupted = false;
    WorkerTask l = this.listener;
    if (l != null) {
      l.terminate();
      l.interrupt();
      if (this.socketTimeout > 0) {
        try {
          l.join();
        }
        catch (InterruptedException ex) {
          interrupted = true;
          logger.warn(ex);
        }
      }
      this.listener = null;
    }
    DatagramSocket closingSocket = this.socket;
    if ((closingSocket != null) && (!closingSocket.isClosed())) {
      closingSocket.close();
    }
    this.socket = null;
    if (interrupted)
      Thread.currentThread().interrupt();
  }

  public synchronized void listen()
    throws IOException
  {
    if (this.listener != null) {
      throw new SocketException("Port already listening");
    }
    ensureSocket();
    this.listenerThread = new ListenThread();
    this.listener = SNMP4JSettings.getThreadFactory().createWorkerThread("DefaultUDPTransportMapping_" + getAddress(), this.listenerThread, true);

    this.listener.run();
  }

  private synchronized DatagramSocket ensureSocket() throws SocketException {
    DatagramSocket s = this.socket;
    if (s == null) {
      s = new DatagramSocket(this.udpAddress.getPort());
      s.setSoTimeout(this.socketTimeout);
      this.socket = s;
    }
    return s;
  }

  public void setPriority(int newPriority)
  {
    WorkerTask lt = this.listener;
    if ((lt instanceof Thread))
      ((Thread)lt).setPriority(newPriority);
  }

  public int getPriority()
  {
    WorkerTask lt = this.listener;
    if ((lt instanceof Thread)) {
      return ((Thread)lt).getPriority();
    }

    return 5;
  }

  public void setThreadName(String name)
  {
    WorkerTask lt = this.listener;
    if ((lt instanceof Thread))
      ((Thread)lt).setName(name);
  }

  public String getThreadName()
  {
    WorkerTask lt = this.listener;
    if ((lt instanceof Thread)) {
      return ((Thread)lt).getName();
    }

    return null;
  }

  public void setMaxInboundMessageSize(int maxInboundMessageSize)
  {
    this.maxInboundMessageSize = maxInboundMessageSize;
  }

  public int getSocketTimeout()
  {
    return this.socketTimeout;
  }

  public int getReceiveBufferSize()
  {
    return this.receiveBufferSize;
  }

  public void setReceiveBufferSize(int receiveBufferSize)
  {
    if (receiveBufferSize <= 0) {
      throw new IllegalArgumentException("Receive buffer size must be > 0");
    }
    this.receiveBufferSize = receiveBufferSize;
  }

  public void setSocketTimeout(int socketTimeout)
  {
    this.socketTimeout = socketTimeout;
    if (this.socket != null)
      try {
        this.socket.setSoTimeout(socketTimeout);
      }
      catch (SocketException ex) {
        throw new RuntimeException(ex);
      }
  }

  public boolean isListening()
  {
    return this.listener != null;
  }

  class ListenThread
    implements WorkerTask
  {
    private byte[] buf;
    private volatile boolean stop = false;

    public ListenThread() throws SocketException
    {
      this.buf = new byte[DefaultUdpTransportMapping.this.getMaxInboundMessageSize()];
    }

    public void run() {
      try {
        DefaultUdpTransportMapping.this.socket.setSoTimeout(DefaultUdpTransportMapping.this.getSocketTimeout());
        if (DefaultUdpTransportMapping.this.receiveBufferSize > 0) {
          DefaultUdpTransportMapping.this.socket.setReceiveBufferSize(Math.max(DefaultUdpTransportMapping.this.receiveBufferSize, DefaultUdpTransportMapping.this.maxInboundMessageSize));
        }

        if (DefaultUdpTransportMapping.logger.isDebugEnabled()) {
          DefaultUdpTransportMapping.logger.debug("UDP receive buffer size for socket " + DefaultUdpTransportMapping.this.getAddress() + " is set to: " + DefaultUdpTransportMapping.this.socket.getReceiveBufferSize());
        }

      }
      catch (SocketException ex)
      {
        DefaultUdpTransportMapping.logger.error(ex);
        DefaultUdpTransportMapping.this.setSocketTimeout(0);
      }
      while (!this.stop) {
        DatagramPacket packet = new DatagramPacket(this.buf, this.buf.length, DefaultUdpTransportMapping.this.udpAddress.getInetAddress(), DefaultUdpTransportMapping.this.udpAddress.getPort());
        try
        {
          try
          {
            DatagramSocket socketCopy = DefaultUdpTransportMapping.this.socket;
            if (socketCopy == null) {
              this.stop = true;
              continue;
            }
            socketCopy.receive(packet);
          } catch (InterruptedIOException iiox) {
          }
          if (iiox.bytesTransferred <= 0)
          {
            continue;
          }
          if (DefaultUdpTransportMapping.logger.isDebugEnabled())
            DefaultUdpTransportMapping.logger.debug("Received message from " + packet.getAddress() + "/" + packet.getPort() + " with length " + packet.getLength() + ": " + new OctetString(packet.getData(), 0, packet.getLength()).toHexString());
          ByteBuffer bis;
          ByteBuffer bis;
          if (DefaultUdpTransportMapping.this.isAsyncMsgProcessingSupported()) {
            byte[] bytes = new byte[packet.getLength()];
            System.arraycopy(packet.getData(), 0, bytes, 0, bytes.length);
            bis = ByteBuffer.wrap(bytes);
          }
          else {
            bis = ByteBuffer.wrap(packet.getData());
          }
          DefaultUdpTransportMapping.this.fireProcessMessage(new UdpAddress(packet.getAddress(), packet.getPort()), bis);
        }
        catch (SocketTimeoutException stex)
        {
        }
        catch (PortUnreachableException purex)
        {
          synchronized (DefaultUdpTransportMapping.this) {
            DefaultUdpTransportMapping.this.listener = null;
          }
          DefaultUdpTransportMapping.logger.error(purex);
          if (DefaultUdpTransportMapping.logger.isDebugEnabled()) {
            purex.printStackTrace();
          }
          if (SNMP4JSettings.isFowardRuntimeExceptions()) {
            throw new RuntimeException(purex);
          }
          break;
        }
        catch (SocketException soex) {
          if (!this.stop) {
            DefaultUdpTransportMapping.logger.error("Socket for transport mapping " + toString() + " error: " + soex.getMessage(), soex);
          }

          this.stop = true;
        }
        catch (IOException iox) {
          DefaultUdpTransportMapping.logger.warn(iox);
          if (DefaultUdpTransportMapping.logger.isDebugEnabled()) {
            iox.printStackTrace();
          }
          if (SNMP4JSettings.isFowardRuntimeExceptions()) {
            throw new RuntimeException(iox);
          }
        }
      }
      synchronized (DefaultUdpTransportMapping.this) {
        DefaultUdpTransportMapping.this.listener = null;
        this.stop = true;
        DatagramSocket closingSocket = DefaultUdpTransportMapping.this.socket;
        if ((closingSocket != null) && (!closingSocket.isClosed())) {
          closingSocket.close();
        }
      }
      if (DefaultUdpTransportMapping.logger.isDebugEnabled())
        DefaultUdpTransportMapping.logger.debug("Worker task stopped:" + getClass().getName());
    }

    public void close()
    {
      this.stop = true;
    }

    public void terminate() {
      close();
      if (DefaultUdpTransportMapping.logger.isDebugEnabled())
        DefaultUdpTransportMapping.logger.debug("Terminated worker task: " + getClass().getName());
    }

    public void join() throws InterruptedException
    {
      if (DefaultUdpTransportMapping.logger.isDebugEnabled())
        DefaultUdpTransportMapping.logger.debug("Joining worker task: " + getClass().getName());
    }

    public void interrupt()
    {
      if (DefaultUdpTransportMapping.logger.isDebugEnabled()) {
        DefaultUdpTransportMapping.logger.debug("Interrupting worker task: " + getClass().getName());
      }
      close();
    }
  }
}