package org.snmp4j;

import java.nio.ByteBuffer;
import java.util.Collection;
import org.snmp4j.asn1.BERInputStream;
import org.snmp4j.mp.MessageProcessingModel;
import org.snmp4j.mp.PduHandle;
import org.snmp4j.mp.PduHandleCallback;
import org.snmp4j.mp.StateReference;
import org.snmp4j.mp.StatusInformation;
import org.snmp4j.smi.Address;
import org.snmp4j.transport.TransportListener;

public abstract interface MessageDispatcher extends TransportListener
{
  public abstract int getNextRequestID();

  public abstract void addMessageProcessingModel(MessageProcessingModel paramMessageProcessingModel);

  public abstract void removeMessageProcessingModel(MessageProcessingModel paramMessageProcessingModel);

  public abstract MessageProcessingModel getMessageProcessingModel(int paramInt);

  public abstract void addTransportMapping(TransportMapping paramTransportMapping);

  public abstract TransportMapping removeTransportMapping(TransportMapping paramTransportMapping);

  public abstract Collection getTransportMappings();

  public abstract TransportMapping getTransport(Address paramAddress);

  public abstract void addCommandResponder(CommandResponder paramCommandResponder);

  public abstract void removeCommandResponder(CommandResponder paramCommandResponder);

  public abstract PduHandle sendPdu(TransportMapping paramTransportMapping, Address paramAddress, int paramInt1, int paramInt2, byte[] paramArrayOfByte, int paramInt3, PDU paramPDU, boolean paramBoolean)
    throws MessageException;

  public abstract PduHandle sendPdu(TransportMapping paramTransportMapping, Address paramAddress, int paramInt1, int paramInt2, byte[] paramArrayOfByte, int paramInt3, PDU paramPDU, boolean paramBoolean, PduHandleCallback paramPduHandleCallback)
    throws MessageException;

  public abstract PduHandle sendPdu(Address paramAddress, int paramInt1, int paramInt2, byte[] paramArrayOfByte, int paramInt3, PDU paramPDU, boolean paramBoolean)
    throws MessageException;

  public abstract int returnResponsePdu(int paramInt1, int paramInt2, byte[] paramArrayOfByte, int paramInt3, PDU paramPDU, int paramInt4, StateReference paramStateReference, StatusInformation paramStatusInformation)
    throws MessageException;

  /** @deprecated */
  public abstract void processMessage(TransportMapping paramTransportMapping, Address paramAddress, BERInputStream paramBERInputStream);

  public abstract void processMessage(TransportMapping paramTransportMapping, Address paramAddress, ByteBuffer paramByteBuffer);

  public abstract void releaseStateReference(int paramInt, PduHandle paramPduHandle);
}