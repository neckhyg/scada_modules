package org.snmp4j;

public abstract interface TimeoutModel
{
  public abstract long getRetryTimeout(int paramInt1, int paramInt2, long paramLong);

  public abstract long getRequestTimeout(int paramInt, long paramLong);
}