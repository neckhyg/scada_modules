package org.snmp4j;

import java.io.Serializable;
import org.snmp4j.smi.Address;

public abstract interface Target extends Serializable, Cloneable
{
  public abstract Address getAddress();

  public abstract void setAddress(Address paramAddress);

  public abstract void setVersion(int paramInt);

  public abstract int getVersion();

  public abstract void setRetries(int paramInt);

  public abstract int getRetries();

  public abstract void setTimeout(long paramLong);

  public abstract long getTimeout();

  public abstract int getMaxSizeRequestPDU();

  public abstract void setMaxSizeRequestPDU(int paramInt);

  public abstract Object clone();
}