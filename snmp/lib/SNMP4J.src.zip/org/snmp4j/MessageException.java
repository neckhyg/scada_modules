package org.snmp4j;

import java.io.IOException;
import org.snmp4j.mp.StatusInformation;

public class MessageException extends IOException
{
  private static final long serialVersionUID = 7129156393920783825L;
  private StatusInformation statusInformation;

  public MessageException()
  {
  }

  public MessageException(StatusInformation status)
  {
    super("" + status.getErrorIndication());
    setStatusInformation(status);
  }

  public MessageException(String message) {
    super(message);
  }

  public StatusInformation getStatusInformation() {
    return this.statusInformation;
  }

  public void setStatusInformation(StatusInformation statusInformation) {
    this.statusInformation = statusInformation;
  }
}