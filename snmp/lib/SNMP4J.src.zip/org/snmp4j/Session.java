package org.snmp4j;

import java.io.IOException;
import org.snmp4j.event.ResponseEvent;
import org.snmp4j.event.ResponseListener;

public abstract interface Session
{
  public abstract void close()
    throws IOException;

  public abstract ResponseEvent send(PDU paramPDU, Target paramTarget)
    throws IOException;

  public abstract void send(PDU paramPDU, Target paramTarget, Object paramObject, ResponseListener paramResponseListener)
    throws IOException;

  public abstract ResponseEvent send(PDU paramPDU, Target paramTarget, TransportMapping paramTransportMapping)
    throws IOException;

  public abstract void send(PDU paramPDU, Target paramTarget, TransportMapping paramTransportMapping, Object paramObject, ResponseListener paramResponseListener)
    throws IOException;

  public abstract void cancel(PDU paramPDU, ResponseListener paramResponseListener);
}