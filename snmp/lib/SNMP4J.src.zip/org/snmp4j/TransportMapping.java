package org.snmp4j;

import java.io.IOException;
import org.snmp4j.smi.Address;
import org.snmp4j.transport.TransportListener;

public abstract interface TransportMapping
{
  public abstract Class getSupportedAddressClass();

  public abstract Address getListenAddress();

  public abstract void sendMessage(Address paramAddress, byte[] paramArrayOfByte)
    throws IOException;

  /** @deprecated */
  public abstract void addMessageDispatcher(MessageDispatcher paramMessageDispatcher);

  /** @deprecated */
  public abstract void removeMessageDispatcher(MessageDispatcher paramMessageDispatcher);

  public abstract void addTransportListener(TransportListener paramTransportListener);

  public abstract void removeTransportListener(TransportListener paramTransportListener);

  public abstract void close()
    throws IOException;

  public abstract void listen()
    throws IOException;

  public abstract boolean isListening();

  public abstract int getMaxInboundMessageSize();
}