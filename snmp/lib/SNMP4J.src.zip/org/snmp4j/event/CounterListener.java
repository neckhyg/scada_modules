package org.snmp4j.event;

import java.util.EventListener;

public abstract interface CounterListener extends EventListener
{
  public abstract void incrementCounter(CounterEvent paramCounterEvent);
}