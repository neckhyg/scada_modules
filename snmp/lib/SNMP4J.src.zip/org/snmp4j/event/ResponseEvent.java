package org.snmp4j.event;

import java.util.EventObject;
import org.snmp4j.PDU;
import org.snmp4j.smi.Address;

public class ResponseEvent extends EventObject
{
  private static final long serialVersionUID = 3966730838956160070L;
  private Address peerAddress;
  private PDU request;
  private PDU response;
  private Object userObject;
  private Exception error;

  public ResponseEvent(Object source, Address peerAddress, PDU request, PDU response, Object userObject)
  {
    super(source);
    setPeerAddress(peerAddress);
    setRequest(request);
    setResponse(response);
    setUserObject(userObject);
  }

  public ResponseEvent(Object source, Address peerAddress, PDU request, PDU response, Object userObject, Exception error)
  {
    this(source, peerAddress, request, response, userObject);
    this.error = error;
  }

  public PDU getRequest()
  {
    return this.request;
  }

  protected final void setPeerAddress(Address peerAddress) {
    this.peerAddress = peerAddress;
  }

  protected final void setRequest(PDU request) {
    this.request = request;
  }

  protected final void setResponse(PDU response) {
    this.response = response;
  }

  public PDU getResponse()
  {
    return this.response;
  }

  protected final void setUserObject(Object userObject) {
    this.userObject = userObject;
  }

  public Object getUserObject()
  {
    return this.userObject;
  }

  public Exception getError()
  {
    return this.error;
  }

  public Address getPeerAddress()
  {
    return this.peerAddress;
  }
}