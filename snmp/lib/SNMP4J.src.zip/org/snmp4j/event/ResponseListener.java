package org.snmp4j.event;

import java.util.EventListener;

public abstract interface ResponseListener extends EventListener
{
  public abstract void onResponse(ResponseEvent paramResponseEvent);
}