package org.snmp4j.event;

import java.util.EventObject;
import org.snmp4j.smi.Counter32;
import org.snmp4j.smi.OID;
import org.snmp4j.smi.Variable;

public class CounterEvent extends EventObject
{
  private static final long serialVersionUID = 7916507798848195425L;
  private OID oid;
  private Variable currentValue = new Counter32();

  public CounterEvent(Object source, OID oid)
  {
    super(source);
    this.oid = oid;
  }

  public OID getOid()
  {
    return this.oid;
  }

  public Variable getCurrentValue()
  {
    return this.currentValue;
  }

  public void setCurrentValue(Variable currentValue)
  {
    this.currentValue = currentValue;
  }
}