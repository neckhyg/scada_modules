package org.snmp4j.event;

import java.util.EventListener;

public abstract interface UsmUserListener extends EventListener
{
  public abstract void usmUserChange(UsmUserEvent paramUsmUserEvent);
}