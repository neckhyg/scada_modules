package org.snmp4j.event;

import java.util.EventObject;
import org.snmp4j.smi.Address;
import org.snmp4j.smi.OctetString;

public class SnmpEngineEvent extends EventObject
{
  private static final long serialVersionUID = -7287039511083410591L;
  public static final int ADDED_ENGINE_ID = 1;
  public static final int REMOVED_ENGINE_ID = 2;
  private OctetString engineID;
  private Address engineAddress;
  private int type;

  public SnmpEngineEvent(Object source, int type, OctetString engineID, Address engineAddress)
  {
    super(source);
    this.engineID = engineID;
    this.type = type;
    this.engineAddress = engineAddress;
  }

  public int getType()
  {
    return this.type;
  }

  public OctetString getEngineID()
  {
    return this.engineID;
  }

  public Address getEngineAddress()
  {
    return this.engineAddress;
  }
}