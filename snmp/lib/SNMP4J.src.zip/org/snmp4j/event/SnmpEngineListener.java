package org.snmp4j.event;

import java.util.EventListener;

public abstract interface SnmpEngineListener extends EventListener
{
  public abstract void engineChanged(SnmpEngineEvent paramSnmpEngineEvent);
}