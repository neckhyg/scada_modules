package org.snmp4j.event;

import java.util.EventObject;
import org.snmp4j.TransportMapping;
import org.snmp4j.asn1.BERInputStream;
import org.snmp4j.smi.Address;

public class AuthenticationFailureEvent extends EventObject
{
  private static final long serialVersionUID = -8623553792794471405L;
  private Address address;
  private transient TransportMapping transport;
  private BERInputStream message;
  private int error;

  public AuthenticationFailureEvent(Object source, Address sourceAddress, TransportMapping transport, int error, BERInputStream message)
  {
    super(source);
    this.address = sourceAddress;
    this.transport = transport;
    this.error = error;
    this.message = message;
  }

  public TransportMapping getTransport()
  {
    return this.transport;
  }

  public BERInputStream getMessage()
  {
    return this.message;
  }

  public int getError()
  {
    return this.error;
  }

  public Address getAddress()
  {
    return this.address;
  }
}