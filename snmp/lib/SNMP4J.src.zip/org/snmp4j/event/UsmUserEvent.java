package org.snmp4j.event;

import java.util.EventObject;
import org.snmp4j.security.UsmUserEntry;

public class UsmUserEvent extends EventObject
{
  private static final long serialVersionUID = -2650579887988635391L;
  public static final int USER_ADDED = 1;
  public static final int USER_REMOVED = 2;
  public static final int USER_CHANGED = 3;
  private UsmUserEntry user;
  private int type;

  public UsmUserEvent(Object source, UsmUserEntry changedEntry, int type)
  {
    super(source);
    this.user = changedEntry;
    this.type = type;
  }

  public UsmUserEntry getUser()
  {
    return this.user;
  }

  public int getType()
  {
    return this.type;
  }
}