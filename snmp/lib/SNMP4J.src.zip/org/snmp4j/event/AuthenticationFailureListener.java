package org.snmp4j.event;

import java.util.EventListener;

public abstract interface AuthenticationFailureListener extends EventListener
{
  public abstract void authenticationFailure(AuthenticationFailureEvent paramAuthenticationFailureEvent);
}