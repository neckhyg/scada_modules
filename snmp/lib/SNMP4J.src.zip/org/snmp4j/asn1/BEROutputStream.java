package org.snmp4j.asn1;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;

public class BEROutputStream extends OutputStream
{
  private ByteBuffer buffer;
  private int offset = 0;

  public BEROutputStream()
  {
    this.buffer = null;
  }

  public BEROutputStream(ByteBuffer buffer)
  {
    this.buffer = buffer;
    this.offset = buffer.position();
  }

  public void write(int b) throws IOException {
    this.buffer.put((byte)b);
  }

  public void write(byte[] b) throws IOException {
    this.buffer.put(b);
  }

  public void write(byte[] b, int off, int len) throws IOException {
    this.buffer.put(b, off, len);
  }

  public void close()
    throws IOException
  {
  }

  public void flush()
    throws IOException
  {
  }

  public ByteBuffer rewind()
  {
    return (ByteBuffer)this.buffer.position(this.offset);
  }

  public ByteBuffer getBuffer()
  {
    return this.buffer;
  }

  public void setBuffer(ByteBuffer buffer)
  {
    this.buffer = buffer;
    this.offset = buffer.position();
  }

  public void setFilledBuffer(ByteBuffer buffer)
  {
    this.buffer = buffer;
    this.offset = buffer.position();
    buffer.position(buffer.limit());
  }
}