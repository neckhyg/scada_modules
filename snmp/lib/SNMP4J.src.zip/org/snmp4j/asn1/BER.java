package org.snmp4j.asn1;

import java.io.IOException;
import java.io.OutputStream;

public class BER
{
  public static final byte ASN_BOOLEAN = 1;
  public static final byte ASN_INTEGER = 2;
  public static final byte ASN_BIT_STR = 3;
  public static final byte ASN_OCTET_STR = 4;
  public static final byte ASN_NULL = 5;
  public static final byte ASN_OBJECT_ID = 6;
  public static final byte ASN_SEQUENCE = 16;
  public static final byte ASN_SET = 17;
  public static final byte ASN_UNIVERSAL = 0;
  public static final byte ASN_APPLICATION = 64;
  public static final byte ASN_CONTEXT = -128;
  public static final byte ASN_PRIVATE = -64;
  public static final byte ASN_PRIMITIVE = 0;
  public static final byte ASN_CONSTRUCTOR = 32;
  public static final byte ASN_LONG_LEN = -128;
  public static final byte ASN_EXTENSION_ID = 31;
  public static final byte ASN_BIT8 = -128;
  public static final byte INTEGER = 2;
  public static final byte INTEGER32 = 2;
  public static final byte BITSTRING = 3;
  public static final byte OCTETSTRING = 4;
  public static final byte NULL = 5;
  public static final byte OID = 6;
  public static final byte SEQUENCE = 48;
  public static final byte IPADDRESS = 64;
  public static final byte COUNTER = 65;
  public static final byte COUNTER32 = 65;
  public static final byte GAUGE = 66;
  public static final byte GAUGE32 = 66;
  public static final byte TIMETICKS = 67;
  public static final byte OPAQUE = 68;
  public static final byte COUNTER64 = 70;
  public static final int NOSUCHOBJECT = 128;
  public static final int NOSUCHINSTANCE = 129;
  public static final int ENDOFMIBVIEW = 130;
  private static final int LENMASK = 255;
  public static final int MAX_OID_LENGTH = 127;
  private static boolean checkSequenceLength = true;
  private static boolean checkValueLength = true;

  public static final void encodeHeader(OutputStream os, int type, int length)
    throws IOException
  {
    os.write(type);
    encodeLength(os, length);
  }

  public static final void encodeHeader(OutputStream os, int type, int length, int numBytesLength)
    throws IOException
  {
    os.write(type);
    encodeLength(os, length, numBytesLength);
  }

  public static final int getBERLengthOfLength(int length)
  {
    if (length < 0) {
      return 5;
    }
    if (length < 128) {
      return 1;
    }
    if (length <= 255) {
      return 2;
    }
    if (length <= 65535) {
      return 3;
    }
    if (length <= 16777215) {
      return 4;
    }
    return 5;
  }

  public static final void encodeLength(OutputStream os, int length)
    throws IOException
  {
    if (length < 0) {
      os.write(-124);
      os.write(length >> 24 & 0xFF);
      os.write(length >> 16 & 0xFF);
      os.write(length >> 8 & 0xFF);
      os.write(length & 0xFF);
    }
    else if (length < 128) {
      os.write(length);
    }
    else if (length <= 255) {
      os.write(-127);
      os.write(length);
    }
    else if (length <= 65535) {
      os.write(-126);
      os.write(length >> 8 & 0xFF);
      os.write(length & 0xFF);
    }
    else if (length <= 16777215) {
      os.write(-125);
      os.write(length >> 16 & 0xFF);
      os.write(length >> 8 & 0xFF);
      os.write(length & 0xFF);
    }
    else {
      os.write(-124);
      os.write(length >> 24 & 0xFF);
      os.write(length >> 16 & 0xFF);
      os.write(length >> 8 & 0xFF);
      os.write(length & 0xFF);
    }
  }

  public static final void encodeLength(OutputStream os, int length, int numLengthBytes)
    throws IOException
  {
    os.write(numLengthBytes | 0xFFFFFF80);
    for (int i = (numLengthBytes - 1) * 8; i >= 0; i -= 8)
      os.write(length >> i & 0xFF);
  }

  public static final void encodeInteger(OutputStream os, byte type, int value)
    throws IOException
  {
    int integer = value;

    int intsize = 4;

    int mask = -8388608;

    while ((((integer & mask) == 0) || ((integer & mask) == mask)) && (intsize > 1)) {
      intsize--;
      integer <<= 8;
    }
    encodeHeader(os, type, intsize);
    mask = -16777216;

    while (intsize-- > 0) {
      os.write((integer & mask) >> 24);
      integer <<= 8;
    }
  }

  public static final void encodeUnsignedInteger(OutputStream os, byte type, long value)
    throws IOException
  {
    int len = 1;
    if ((value >> 24 & 0xFF) != 0L) {
      len = 4;
    }
    else if ((value >> 16 & 0xFF) != 0L) {
      len = 3;
    }
    else if ((value >> 8 & 0xFF) != 0L) {
      len = 2;
    }

    if ((value >> 8 * (len - 1) & 0x80) != 0L) {
      len++;
    }

    encodeHeader(os, type, len);

    if (len == 5) {
      os.write(0);
      for (int x = 1; x < len; x++) {
        os.write((int)(value >> (8 * (4 - x) & 0xFF)));
      }
    }
    else
    {
      for (int x = 0; x < len; x++)
        os.write((int)(value >> (8 * (len - 1 - x) & 0xFF)));
    }
  }

  public static final void encodeString(OutputStream os, byte type, byte[] string)
    throws IOException
  {
    encodeHeader(os, type, string.length);

    os.write(string);
  }

  public static final void encodeSequence(OutputStream os, byte type, int length)
    throws IOException
  {
    os.write(type);
    encodeLength(os, length);
  }

  public static final int getOIDLength(int[] value)
  {
    int length = 1;
    for (int i = 2; i < value.length; i++) {
      long v = value[i] & 0xFFFFFFFF;
      if (v < 128L) {
        length++;
      }
      else if (v < 16384L) {
        length += 2;
      }
      else if (v < 2097152L) {
        length += 3;
      }
      else if (v < 268435456L) {
        length += 4;
      }
      else {
        length += 5;
      }
    }
    return length;
  }

  public static final void encodeOID(OutputStream os, byte type, int[] oid)
    throws IOException
  {
    encodeHeader(os, type, getOIDLength(oid));

    int encodedLength = oid.length;
    int rpos = 0;

    if (oid.length < 2) {
      os.write(0);
      encodedLength = 0;
    }
    else {
      os.write(oid[1] + oid[0] * 40 & 0xFF);
      encodedLength -= 2;
      rpos = 2;
    }

    while (encodedLength-- > 0) {
      long subid = oid[(rpos++)] & 0xFFFFFFFF;
      if (subid < 127L) {
        os.write((int)subid & 0xFF);
      }
      else {
        long mask = 127L;
        long bits = 0L;

        long testmask = 127L; for (long testbits = 0L; testmask != 0L; )
        {
          if ((subid & testmask) > 0L) {
            mask = testmask;
            bits = testbits;
          }
          testmask <<= 7; testbits += 7L;
        }

        for (; mask != 127L; bits -= 7L)
        {
          if (mask == 31457280L) {
            mask = 266338304L;
          }
          os.write((int)((subid & mask) >> (int)bits | 0xFFFFFF80));

          mask >>= 7;
        }

        os.write((int)(subid & mask));
      }
    }
  }

  public static final void encodeUnsignedInt64(OutputStream os, byte type, long value)
    throws IOException
  {
    for (int len = 8; (len > 1) && 
      ((value >> 8 * (len - 1) & 0xFF) == 0L); len--);
    if ((value >> 8 * (len - 1) & 0x80) != 0L) {
      len++;
    }
    encodeHeader(os, type, len);
    if (len == 9) {
      os.write(0);
      len--;
    }
    for (int x = 0; x < len; x++)
      os.write((int)(value >> (8 * (len - 1 - x) & 0xFF)));
  }

  public static final int decodeLength(BERInputStream is)
    throws IOException
  {
    return decodeLength(is, true);
  }

  public static final int decodeLength(BERInputStream is, boolean checkLength)
    throws IOException
  {
    int length = 0;
    int lengthbyte = is.read();

    if ((lengthbyte & 0xFFFFFF80) > 0) {
      lengthbyte &= 127;
      if (lengthbyte == 0) {
        throw new IOException("Indefinite lengths are not supported");
      }
      if (lengthbyte > 4) {
        throw new IOException("Data length > 4 bytes are not supported!");
      }
      for (int i = 0; i < lengthbyte; i++) {
        int l = is.read() & 0xFF;
        length |= l << 8 * (lengthbyte - 1 - i);
      }
      if (length < 0)
        throw new IOException("SNMP does not support data lengths > 2^31");
    }
    else
    {
      length = lengthbyte & 0xFF;
    }

    if (checkLength) {
      checkLength(is, length);
    }
    return length;
  }

  public static final int decodeHeader(BERInputStream is, MutableByte type, boolean checkLength)
    throws IOException
  {
    byte t = (byte)is.read();
    if ((t & 0x1F) == 31) {
      throw new IOException("Cannot process extension IDs" + getPositionMessage(is));
    }

    type.setValue(t);
    return decodeLength(is, checkLength);
  }

  public static final int decodeHeader(BERInputStream is, MutableByte type)
    throws IOException
  {
    return decodeHeader(is, type, true);
  }

  public static final int decodeInteger(BERInputStream is, MutableByte type)
    throws IOException
  {
    int value = 0;

    type.setValue((byte)is.read());

    if ((type.value != 2) && (type.value != 67) && (type.value != 65))
    {
      throw new IOException("Wrong ASN.1 type. Not an integer: " + type.value + getPositionMessage(is));
    }

    int length = decodeLength(is);
    if (length > 4) {
      throw new IOException("Length greater than 32bit are not supported  for integers: " + getPositionMessage(is));
    }

    int b = is.read() & 0xFF;
    if ((b & 0x80) > 0) {
      value = -1;
    }
    while (length-- > 0) {
      value = value << 8 | b;
      if (length > 0) {
        b = is.read();
      }
    }
    return value;
  }

  private static String getPositionMessage(BERInputStream is) {
    return " at position " + is.getPosition();
  }

  public static final long decodeUnsignedInteger(BERInputStream is, MutableByte type)
    throws IOException
  {
    long value = 0L;

    type.setValue((byte)is.read());
    if ((type.value != 2) && (type.value != 67) && (type.value != 65) && (type.value != 66) && (type.value != 71))
    {
      throw new IOException("Wrong ASN.1 type. Not an unsigned integer: " + type.value + getPositionMessage(is));
    }

    int length = decodeLength(is);

    int b = is.read();
    if ((length > 5) || ((length > 4) && (b != 0))) {
      throw new IOException("Only 32bit unsigned integers are supported" + getPositionMessage(is));
    }

    if (b == 0) {
      if (length > 1) {
        b = is.read();
      }
      length--;
    }

    for (int i = 0; i < length; i++) {
      value = value << 8 | b & 0xFF;
      if (i + 1 < length) {
        b = is.read();
      }
    }
    return value;
  }

  public static final byte[] decodeString(BERInputStream is, MutableByte type)
    throws IOException
  {
    type.setValue((byte)is.read());
    if ((type.value != 4) && (type.value != 36) && (type.value != 64) && (type.value != 68) && (type.value != 3) && (type.value != 69))
    {
      throw new IOException("Wrong ASN.1 type. Not a string: " + type.value + getPositionMessage(is));
    }

    int length = decodeLength(is);

    byte[] value = new byte[length];
    int pos = 0;

    while ((pos < length) && (is.available() > 0)) {
      int read = is.read(value);
      if (read > 0) {
        pos += read;
      }
      else if (read < 0) {
        throw new IOException("Wrong string length " + read + " < " + length);
      }
    }
    return value;
  }

  public static final int[] decodeOID(BERInputStream is, MutableByte type)
    throws IOException
  {
    type.setValue((byte)is.read());
    if (type.value != 6) {
      throw new IOException("Wrong type. Not an OID: " + type.value + getPositionMessage(is));
    }

    int length = decodeLength(is);

    int[] oid = new int[length + 2];

    if (length == 0)
    {
      int tmp78_77 = 0; oid[1] = tmp78_77; oid[0] = tmp78_77;
    }
    int pos = 1;
    while (length > 0) { int subidentifier = 0;
      int b;
      do { int next = is.read();
        if (next < 0) {
          throw new IOException("Unexpected end of input stream" + getPositionMessage(is));
        }

        b = next & 0xFF;
        subidentifier = (subidentifier << 7) + (b & 0x7F);
        length--; }
      while ((length > 0) && ((b & 0xFFFFFF80) != 0));
      oid[(pos++)] = subidentifier;
    }

    int subidentifier = oid[1];
    if (subidentifier == 43) {
      oid[0] = 1;
      oid[1] = 3;
    }
    else {
      oid[1] = (subidentifier % 40);
      oid[0] = ((subidentifier - oid[1]) / 40);
    }
    if (pos < 2) {
      pos = 2;
    }
    int[] value = new int[pos];
    System.arraycopy(oid, 0, value, 0, pos);
    return value;
  }

  public static final void decodeNull(BERInputStream is, MutableByte type)
    throws IOException
  {
    type.setValue((byte)(is.read() & 0xFF));
    if ((type.value != 5) && (type.value != -128) && (type.value != -127) && (type.value != -126))
    {
      throw new IOException("Wrong ASN.1 type. Is not null: " + type.value + getPositionMessage(is));
    }

    int length = decodeLength(is);
    if (length != 0)
      throw new IOException("Invalid Null encoding, length is not zero: " + length + getPositionMessage(is));
  }

  public static final long decodeUnsignedInt64(BERInputStream is, MutableByte type)
    throws IOException
  {
    type.setValue((byte)is.read());
    if ((type.value != 2) && (type.value != 70)) {
      throw new IOException("Wrong type. Not an integer 64: " + type.value + getPositionMessage(is));
    }

    int length = decodeLength(is);
    int b = is.read() & 0xFF;
    if (length > 9) {
      throw new IOException("Invalid 64bit unsigned integer length: " + length + getPositionMessage(is));
    }

    if (b == 0) {
      if (length > 1) {
        b = is.read();
      }
      length--;
    }
    long value = 0L;

    for (int i = 0; i < length; i++) {
      value = value << 8 | b & 0xFF;
      if (i + 1 < length) {
        b = is.read();
      }
    }
    return value;
  }

  public static boolean isCheckSequenceLength()
  {
    return checkSequenceLength;
  }

  public static void setCheckSequenceLength(boolean checkSequenceLen)
  {
    checkSequenceLength = checkSequenceLen;
  }

  public static void checkSequenceLength(int expectedLength, BERSerializable sequence)
    throws IOException
  {
    if ((isCheckSequenceLength()) && (expectedLength != sequence.getBERPayloadLength()))
    {
      throw new IOException("The actual length of the SEQUENCE object " + sequence.getClass().getName() + " is " + sequence.getBERPayloadLength() + ", but " + expectedLength + " was expected");
    }
  }

  public static void checkSequenceLength(int expectedLength, int actualLength, BERSerializable sequence)
    throws IOException
  {
    if ((isCheckSequenceLength()) && (expectedLength != actualLength))
    {
      throw new IOException("The actual length of the SEQUENCE object " + sequence.getClass().getName() + " is " + actualLength + ", but " + expectedLength + " was expected");
    }
  }

  private static void checkLength(BERInputStream is, int length)
    throws IOException
  {
    if (!checkValueLength) {
      return;
    }
    if ((length < 0) || (length > is.getAvailableBytes()))
      throw new IOException("The encoded length " + length + " exceeds the number of bytes left in input" + getPositionMessage(is) + " which actually is " + is.getAvailableBytes());
  }

  public boolean isCheckValueLength()
  {
    return checkValueLength;
  }

  public void setCheckValueLength(boolean checkValueLength) {
    checkValueLength = checkValueLength;
  }

  public static class MutableByte
  {
    byte value = 0;

    public MutableByte() {
    }
    public MutableByte(byte value) {
      setValue(value);
    }

    public void setValue(byte value) {
      this.value = value;
    }

    public byte getValue() {
      return this.value;
    }
  }
}