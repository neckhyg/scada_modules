package org.snmp4j.asn1;

import java.io.IOException;
import java.io.OutputStream;

public abstract interface BERSerializable
{
  public abstract int getBERLength();

  public abstract int getBERPayloadLength();

  public abstract void decodeBER(BERInputStream paramBERInputStream)
    throws IOException;

  public abstract void encodeBER(OutputStream paramOutputStream)
    throws IOException;
}