package org.snmp4j;

import org.snmp4j.smi.Address;
import org.snmp4j.smi.OctetString;

public class UserTarget extends SecureTarget
{
  private static final long serialVersionUID = -1426511355567423746L;
  private OctetString authoritativeEngineID = new OctetString();

  public UserTarget()
  {
  }

  public UserTarget(Address address, OctetString securityName, byte[] authoritativeEngineID)
  {
    super(address, securityName);
    setAuthoritativeEngineID(authoritativeEngineID);
  }

  public UserTarget(Address address, OctetString securityName, byte[] authoritativeEngineID, int securityLevel)
  {
    super(address, securityName);
    setAuthoritativeEngineID(authoritativeEngineID);
    setSecurityLevel(securityLevel);
  }

  public void setAuthoritativeEngineID(byte[] authoritativeEngineID)
  {
    this.authoritativeEngineID.setValue(authoritativeEngineID);
  }

  public byte[] getAuthoritativeEngineID()
  {
    return this.authoritativeEngineID.getValue();
  }

  public int getSecurityModel()
  {
    return 3;
  }

  public void setSecurityModel(int securityModel)
  {
    if (securityModel != 3)
      throw new IllegalArgumentException("The UserTarget target can only be used with the User Based Security Model (USM)");
  }
}