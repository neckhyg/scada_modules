package org.snmp4j;

import java.io.Serializable;
import org.snmp4j.smi.Address;
import org.snmp4j.smi.OctetString;

public abstract class SecureTarget extends AbstractTarget
  implements Serializable
{
  private static final long serialVersionUID = 3864834593299255038L;
  private int securityLevel = 1;
  private int securityModel = 0;
  private OctetString securityName = new OctetString();

  protected SecureTarget()
  {
  }

  protected SecureTarget(Address address, OctetString securityName)
  {
    super(address);
    setSecurityName(securityName);
  }

  public int getSecurityModel()
  {
    return this.securityModel;
  }

  public final OctetString getSecurityName()
  {
    return this.securityName;
  }

  public int getSecurityLevel()
  {
    return this.securityLevel;
  }

  public void setSecurityLevel(int securityLevel)
  {
    this.securityLevel = securityLevel;
  }

  public void setSecurityModel(int securityModel)
  {
    this.securityModel = securityModel;
  }

  public final void setSecurityName(OctetString securityName)
  {
    this.securityName = securityName;
  }
}