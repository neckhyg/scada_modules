package org.snmp4j.util;

import java.util.EventListener;

public abstract interface TableListener extends EventListener
{
  public abstract boolean next(TableEvent paramTableEvent);

  public abstract void finished(TableEvent paramTableEvent);

  public abstract boolean isFinished();
}