package org.snmp4j.util;

public abstract interface WorkerTask extends Runnable
{
  public abstract void terminate();

  public abstract void join()
    throws InterruptedException;

  public abstract void interrupt();
}