package org.snmp4j.util;

import java.util.LinkedList;
import org.snmp4j.log.LogAdapter;
import org.snmp4j.log.LogFactory;

public class TaskScheduler
  implements Runnable
{
  private LogAdapter logger = LogFactory.getLogger(TaskScheduler.class);
  private static final long DEFAULT_SCHEDULER_TIMEOUT = 5L;
  private LinkedList tasks = new LinkedList();
  private ThreadPool threadPool;
  private boolean stop;
  protected long schedulerTimeout = 5L;

  public TaskScheduler(ThreadPool threadPool)
  {
    this.threadPool = threadPool;
  }

  public synchronized void addTask(SchedulerTask task)
  {
    this.tasks.addLast(task);
    notify();
  }

  public synchronized boolean removeTask(SchedulerTask task)
  {
    return this.tasks.remove(task);
  }

  public synchronized void clear()
  {
    this.tasks.clear();
  }

  public void run()
  {
    while (!this.stop) {
      boolean readyToRun = false;
      synchronized (this) {
        for (int i = 0; i < this.tasks.size(); i++) {
          SchedulerTask task = (SchedulerTask)this.tasks.get(i);
          if (task.isDone()) {
            if (this.logger.isDebugEnabled()) {
              this.logger.debug("Task '" + task + "' is done");
            }
            this.tasks.removeFirst();
          }
          else if (task.isReadyToRun()) {
            readyToRun = true;
            while (true) if (!this.threadPool.tryToExecute(task)) {
                try {
                  synchronized (this.threadPool) {
                    this.threadPool.wait(this.schedulerTimeout);
                  }
                }
                catch (InterruptedException ex) {
                  this.logger.warn("Scheduler interrupted, aborting...");
                  this.stop = true;
                }
              }

            this.tasks.addLast(this.tasks.removeFirst());
            i--;
          }
        }
      }
      if (!readyToRun) {
        try {
          if (this.threadPool.isIdle()) {
            synchronized (this) {
              wait(this.schedulerTimeout);
            }
          }
          else
            synchronized (this.threadPool) {
              this.threadPool.wait(this.schedulerTimeout);
            }
        }
        catch (InterruptedException ex1)
        {
          this.logger.warn("Scheduler interrupted, aborting...");
          this.stop = true;
        }
      }
    }
    this.logger.info("Scheduler stopped.");
  }

  public void setStop(boolean stop)
  {
    this.stop = stop;
  }

  public boolean isStop()
  {
    return this.stop;
  }
}