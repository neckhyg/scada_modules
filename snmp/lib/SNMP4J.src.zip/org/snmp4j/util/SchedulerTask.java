package org.snmp4j.util;

public abstract interface SchedulerTask extends WorkerTask
{
  public abstract boolean isReadyToRun();

  public abstract boolean isDone();
}