package org.snmp4j.util;

import org.snmp4j.PDU;
import org.snmp4j.smi.VariableBinding;

public class TreeEvent extends RetrievalEvent
{
  private static final long serialVersionUID = 5660517240029018420L;

  public TreeEvent(Object source, Object userObject, VariableBinding[] vbs)
  {
    super(source, userObject, vbs);
  }

  public TreeEvent(Object source, Object userObject, int status) {
    super(source, userObject, status);
  }

  public TreeEvent(Object source, Object userObject, PDU report) {
    super(source, userObject, report);
  }

  public TreeEvent(Object source, Object userObject, Exception exception) {
    super(source, userObject, exception);
  }

  public VariableBinding[] getVariableBindings()
  {
    return this.vbs;
  }
}