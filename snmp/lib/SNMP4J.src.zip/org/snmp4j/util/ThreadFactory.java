package org.snmp4j.util;

public abstract interface ThreadFactory
{
  public abstract WorkerTask createWorkerThread(String paramString, WorkerTask paramWorkerTask, boolean paramBoolean);
}