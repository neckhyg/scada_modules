package org.snmp4j.util;

import org.snmp4j.PDU;
import org.snmp4j.Target;

public abstract interface PDUFactory
{
  public abstract PDU createPDU(Target paramTarget);
}