package org.snmp4j.util;

import java.util.EventListener;

public abstract interface TreeListener extends EventListener
{
  public abstract boolean next(TreeEvent paramTreeEvent);

  public abstract void finished(TreeEvent paramTreeEvent);

  public abstract boolean isFinished();
}