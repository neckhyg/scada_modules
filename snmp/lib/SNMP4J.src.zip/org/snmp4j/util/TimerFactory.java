package org.snmp4j.util;

public abstract interface TimerFactory
{
  public abstract CommonTimer createTimer();
}