package org.snmp4j.util;

import org.snmp4j.Session;

public abstract class AbstractSnmpUtility
{
  protected Session session;
  protected PDUFactory pduFactory;

  public AbstractSnmpUtility(Session snmpSession, PDUFactory pduFactory)
  {
    this.session = snmpSession;
    this.pduFactory = pduFactory;
  }
}