package org.snmp4j.util;

import java.text.ParseException;
import org.snmp4j.smi.OID;
import org.snmp4j.smi.Variable;
import org.snmp4j.smi.VariableBinding;

public abstract interface VariableTextFormat
{
  public abstract String format(OID paramOID, Variable paramVariable, boolean paramBoolean);

  public abstract VariableBinding parseVariableBinding(String paramString)
    throws ParseException;

  public abstract Variable parse(OID paramOID, String paramString)
    throws ParseException;

  public abstract Variable parse(int paramInt, String paramString)
    throws ParseException;
}