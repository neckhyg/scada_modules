package org.snmp4j.util;

public abstract interface WorkerPool
{
  public abstract void execute(WorkerTask paramWorkerTask);

  public abstract boolean tryToExecute(WorkerTask paramWorkerTask);

  public abstract void stop();

  public abstract void cancel();

  public abstract boolean isIdle();
}