package org.snmp4j.util;

import java.text.ParseException;

public abstract interface OIDTextFormat
{
  public abstract String format(int[] paramArrayOfInt);

  public abstract int[] parse(String paramString)
    throws ParseException;
}