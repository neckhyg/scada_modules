package org.snmp4j.util;

import org.snmp4j.PDU;
import org.snmp4j.PDUv1;
import org.snmp4j.ScopedPDU;
import org.snmp4j.Target;

public class DefaultPDUFactory
  implements PDUFactory
{
  private int pduType = -96;

  public DefaultPDUFactory()
  {
  }

  public DefaultPDUFactory(int pduType)
  {
    setPduType(pduType);
  }

  public void setPduType(int pduType) {
    this.pduType = pduType;
  }

  public int getPduType() {
    return this.pduType;
  }

  public PDU createPDU(Target target)
  {
    return createPDU(target, this.pduType);
  }

  public static PDU createPDU(Target target, int pduType)
  {
    PDU request = createPDU(target.getVersion());
    request.setType(pduType);
    return request;
  }

  public static PDU createPDU(int targetVersion)
  {
    PDU request;
    switch (targetVersion) {
    case 3:
      request = new ScopedPDU();
      break;
    case 0:
      request = new PDUv1();
      break;
    default:
      request = new PDU();
    }
    return request;
  }
}