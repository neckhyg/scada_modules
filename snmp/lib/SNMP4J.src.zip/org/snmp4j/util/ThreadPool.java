package org.snmp4j.util;

import java.util.List;
import java.util.Vector;

public class ThreadPool
  implements WorkerPool
{
  protected Vector taskManagers;
  protected String name = "ThreadPool";
  protected volatile boolean stop = false;
  protected boolean respawnThreads = false;

  protected String getTaskManagerName(String prefix, int index)
  {
    return prefix + "." + index;
  }

  protected void setup(String name, int size) {
    this.name = name;
    this.taskManagers = new Vector(size);
    for (int i = 0; i < size; i++) {
      TaskManager tm = new TaskManager(getTaskManagerName(name, i));
      this.taskManagers.add(tm);
      tm.start();
    }
  }

  public static ThreadPool create(String name, int size)
  {
    ThreadPool pool = new ThreadPool();
    pool.setup(name, size);
    return pool;
  }

  public synchronized void execute(WorkerTask task)
  {
    while (true)
    {
      for (int i = 0; i < this.taskManagers.size(); i++) {
        TaskManager tm = (TaskManager)this.taskManagers.get(i);
        if ((this.respawnThreads) && (!tm.isAlive())) {
          tm = new TaskManager(getTaskManagerName(this.name, i));
        }
        if (tm.isIdle()) {
          tm.execute(task);
          return;
        }
      }
      try {
        wait();
      }
      catch (InterruptedException ex) {
        Thread.currentThread().interrupt();
      }
    }
  }

  public synchronized boolean tryToExecute(WorkerTask task)
  {
    for (int i = 0; i < this.taskManagers.size(); i++) {
      TaskManager tm = (TaskManager)this.taskManagers.get(i);
      if ((this.respawnThreads) && (!tm.isAlive())) {
        tm = new TaskManager(getTaskManagerName(this.name, i));
      }
      if (tm.isIdle()) {
        tm.execute(task);
        return true;
      }
    }
    return false;
  }

  public boolean isRespawnThreads()
  {
    return this.respawnThreads;
  }

  public void setRespawnThreads(boolean respawnThreads)
  {
    this.respawnThreads = respawnThreads;
  }

  public String getName()
  {
    return this.name;
  }

  public void stop()
  {
    List tms;
    synchronized (this) {
      this.stop = true;
      tms = (List)this.taskManagers.clone();
    }
    for (int i = 0; i < tms.size(); i++) {
      TaskManager tm = (TaskManager)tms.get(i);
      tm.terminate();
      synchronized (tm) {
        tm.notify();
      }
      try {
        tm.join();
      }
      catch (InterruptedException ex) {
        Thread.currentThread().interrupt();
      }
    }
  }

  public synchronized void cancel()
  {
    this.stop = true;
    for (int i = 0; i < this.taskManagers.size(); i++) {
      TaskManager tm = (TaskManager)this.taskManagers.get(i);
      tm.terminate();
      tm.interrupt();
    }
  }

  public synchronized void interrupt()
  {
    for (int i = 0; i < this.taskManagers.size(); i++) {
      TaskManager tm = (TaskManager)this.taskManagers.get(i);
      tm.interrupt();
    }
  }

  public synchronized boolean isIdle()
  {
    for (int i = 0; i < this.taskManagers.size(); i++) {
      TaskManager tm = (TaskManager)this.taskManagers.get(i);
      if (!tm.isIdle()) {
        return false;
      }
    }
    return true;
  }

  class TaskManager extends Thread
  {
    private WorkerTask task = null;
    private volatile boolean run = true;

    public TaskManager(String name) {
      super();
    }

    public synchronized void run() {
      while (true) if ((!ThreadPool.this.stop) && (this.run)) {
          if (this.task != null) {
            this.task.run();
            synchronized (ThreadPool.this) {
              this.task = null;
              ThreadPool.this.notify();
            }continue;
          }
          try
          {
            wait();
          }
          catch (InterruptedException ex) {
            this.run = ThreadPool.this.respawnThreads;
          }
        }
    }

    public boolean isIdle()
    {
      return (this.task == null) && (this.run);
    }

    public boolean isStopped() {
      return ThreadPool.this.stop;
    }

    public void terminate() {
      ThreadPool.this.stop = true;
      WorkerTask t;
      if ((t = this.task) != null)
        t.terminate();
    }

    public synchronized void execute(WorkerTask task)
    {
      if (this.task == null) {
        this.task = task;
        notify();
      }
      else {
        throw new IllegalStateException("TaskManager is not idle");
      }
    }
  }
}