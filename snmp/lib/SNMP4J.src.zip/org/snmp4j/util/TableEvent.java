package org.snmp4j.util;

import java.util.Arrays;
import org.snmp4j.PDU;
import org.snmp4j.smi.OID;
import org.snmp4j.smi.VariableBinding;

public class TableEvent extends RetrievalEvent
{
  private static final long serialVersionUID = 3340523737695933621L;
  private OID index;

  protected TableEvent(Object source, Object userObject)
  {
    super(source, userObject);
    this.userObject = userObject;
  }

  public TableEvent(Object source, Object userObject, int status)
  {
    this(source, userObject);
    this.status = status;
  }

  public TableEvent(Object source, Object userObject, Exception exception)
  {
    this(source, userObject);
    this.exception = exception;
    this.status = -4;
  }

  public TableEvent(Object source, Object userObject, PDU report)
  {
    this(source, userObject);
    this.reportPDU = report;
    this.status = -3;
  }

  public TableEvent(Object source, Object userObject, OID index, VariableBinding[] cols)
  {
    super(source, userObject, cols);
    this.index = index;
  }

  public OID getIndex()
  {
    return this.index;
  }

  public VariableBinding[] getColumns()
  {
    return this.vbs;
  }

  public String toString() {
    return getClass().getName() + "[index=" + this.index + ",vbs=" + (this.vbs == null ? "null" : new StringBuffer().append("").append(Arrays.asList(this.vbs)).toString()) + ",status=" + this.status + ",exception=" + this.exception + ",report=" + this.reportPDU + "]";
  }
}