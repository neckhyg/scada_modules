package org.snmp4j.util;

import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

public class DefaultTimerFactory
  implements TimerFactory
{
  public CommonTimer createTimer()
  {
    return new TimerAdapter();
  }

  class TimerAdapter implements CommonTimer
  {
    private Timer timer = new Timer(true);

    TimerAdapter() {  }

    public void schedule(TimerTask task, long delay) { this.timer.schedule(task, delay); }

    public void cancel()
    {
      this.timer.cancel();
    }

    public void schedule(TimerTask task, Date firstTime, long period) {
      this.timer.schedule(task, firstTime, period);
    }

    public void schedule(TimerTask task, long delay, long period) {
      this.timer.schedule(task, delay, period);
    }
  }
}