package org.snmp4j.util;

import java.util.Date;
import java.util.TimerTask;

public abstract interface CommonTimer
{
  public abstract void schedule(TimerTask paramTimerTask, long paramLong);

  public abstract void schedule(TimerTask paramTimerTask, Date paramDate, long paramLong);

  public abstract void schedule(TimerTask paramTimerTask, long paramLong1, long paramLong2);

  public abstract void cancel();
}