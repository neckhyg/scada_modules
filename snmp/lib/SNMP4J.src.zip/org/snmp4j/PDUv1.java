package org.snmp4j;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Vector;
import org.snmp4j.asn1.BER;
import org.snmp4j.asn1.BER.MutableByte;
import org.snmp4j.asn1.BERInputStream;
import org.snmp4j.smi.Counter64;
import org.snmp4j.smi.Integer32;
import org.snmp4j.smi.IpAddress;
import org.snmp4j.smi.OID;
import org.snmp4j.smi.TimeTicks;
import org.snmp4j.smi.Variable;
import org.snmp4j.smi.VariableBinding;

public class PDUv1 extends PDU
{
  private static final long serialVersionUID = -6478805117911347898L;
  public static final int COLDSTART = 0;
  public static final int WARMSTART = 1;
  public static final int LINKDOWN = 2;
  public static final int LINKUP = 3;
  public static final int AUTHENTICATIONFAILURE = 4;
  public static final int ENTERPRISE_SPECIFIC = 6;
  private static final String OPERATION_NOT_SUPPORTED = "Operation not supported for SNMPv1 PDUs";
  private OID enterprise = new OID();
  private IpAddress agentAddress = new IpAddress("0.0.0.0");
  private Integer32 genericTrap = new Integer32(0);
  private Integer32 specificTrap = new Integer32(0);
  private TimeTicks timestamp = new TimeTicks(0L);

  public PDUv1()
  {
    setType(-92);
  }

  public PDUv1(PDUv1 other)
  {
    super(other);
    this.enterprise = ((OID)other.enterprise.clone());
    this.agentAddress = ((IpAddress)other.agentAddress.clone());
    this.genericTrap = ((Integer32)other.genericTrap.clone());
    this.specificTrap = ((Integer32)other.specificTrap.clone());
    this.timestamp = ((TimeTicks)other.timestamp.clone());
  }

  public Object clone() {
    return new PDUv1(this);
  }

  public void decodeBER(BERInputStream inputStream)
    throws IOException
  {
    BER.MutableByte pduType = new BER.MutableByte();
    int length = BER.decodeHeader(inputStream, pduType);
    int pduStartPos = (int)inputStream.getPosition();

    switch (pduType.getValue()) {
    case -96:
    case -95:
    case -94:
    case -93:
    case -92:
      break;
    default:
      throw new IOException("Unsupported PDU type: " + pduType.getValue());
    }
    setType(pduType.getValue());
    if (getType() == -92) {
      this.enterprise.decodeBER(inputStream);
      this.agentAddress.decodeBER(inputStream);
      this.genericTrap.decodeBER(inputStream);
      this.specificTrap.decodeBER(inputStream);
      this.timestamp.decodeBER(inputStream);
    }
    else {
      this.requestID.decodeBER(inputStream);
      this.errorStatus.decodeBER(inputStream);
      this.errorIndex.decodeBER(inputStream);
    }

    pduType = new BER.MutableByte();
    int vbLength = BER.decodeHeader(inputStream, pduType);
    if (pduType.getValue() != 48) {
      throw new IOException("Encountered invalid tag, SEQUENCE expected: " + pduType.getValue());
    }

    int startPos = (int)inputStream.getPosition();
    this.variableBindings = new Vector();
    while (inputStream.getPosition() - startPos < vbLength) {
      VariableBinding vb = new VariableBinding();
      vb.decodeBER(inputStream);
      if (!isVariableV1(vb.getVariable())) {
        throw new MessageException("Counter64 encountered in SNMPv1 PDU (RFC 2576 §4.1.2.1)");
      }

      this.variableBindings.add(vb);
    }
    if (BER.isCheckSequenceLength()) {
      BER.checkSequenceLength(vbLength, (int)inputStream.getPosition() - startPos, this);

      BER.checkSequenceLength(length, (int)inputStream.getPosition() - pduStartPos, this);
    }
  }

  public void encodeBER(OutputStream outputStream)
    throws IOException
  {
    BER.encodeHeader(outputStream, this.type, getBERPayloadLength());

    if (this.type == -92) {
      this.enterprise.encodeBER(outputStream);
      this.agentAddress.encodeBER(outputStream);
      this.genericTrap.encodeBER(outputStream);
      this.specificTrap.encodeBER(outputStream);
      this.timestamp.encodeBER(outputStream);
    }
    else {
      this.requestID.encodeBER(outputStream);
      this.errorStatus.encodeBER(outputStream);
      this.errorIndex.encodeBER(outputStream);
    }
    int vbLength = 0;
    for (int i = 0; i < this.variableBindings.size(); i++) {
      vbLength += ((VariableBinding)this.variableBindings.get(i)).getBERLength();
    }
    BER.encodeHeader(outputStream, 48, vbLength);
    for (int i = 0; i < this.variableBindings.size(); i++) {
      VariableBinding vb = (VariableBinding)this.variableBindings.get(i);
      if (!isVariableV1(vb.getVariable())) {
        throw new IOException("Cannot encode Counter64 into a SNMPv1 PDU");
      }
      vb.encodeBER(outputStream);
    }
  }

  protected boolean isVariableV1(Variable v)
  {
    return !(v instanceof Counter64);
  }

  protected int getBERPayloadLengthPDU() {
    if (getType() != -92) {
      return super.getBERPayloadLengthPDU();
    }

    int length = 0;

    for (int i = 0; i < this.variableBindings.size(); i++) {
      length += ((VariableBinding)this.variableBindings.get(i)).getBERLength();
    }
    length += BER.getBERLengthOfLength(length) + 1;
    length += this.agentAddress.getBERLength();
    length += this.enterprise.getBERLength();
    length += this.genericTrap.getBERLength();
    length += this.specificTrap.getBERLength();
    length += this.timestamp.getBERLength();
    return length;
  }

  public int getMaxRepetitions()
  {
    throw new UnsupportedOperationException("Operation not supported for SNMPv1 PDUs");
  }

  public void setMaxRepetitions(int maxRepetitions)
  {
    throw new UnsupportedOperationException("Operation not supported for SNMPv1 PDUs");
  }

  public void setMaxSizeScopedPDU(int maxSizeScopedPDU)
  {
    throw new UnsupportedOperationException("Operation not supported for SNMPv1 PDUs");
  }

  public void setNonRepeaters(int nonRepeaters)
  {
    throw new UnsupportedOperationException("Operation not supported for SNMPv1 PDUs");
  }

  private void checkV1TRAP() {
    if (getType() != -92)
      throw new UnsupportedOperationException("Operation is only supported for SNMPv1 trap PDUs (V1TRAP)");
  }

  public OID getEnterprise()
  {
    checkV1TRAP();
    return this.enterprise;
  }

  public void setEnterprise(OID enterprise)
  {
    checkV1TRAP();
    checkNull(enterprise);
    this.enterprise = ((OID)enterprise.clone());
  }

  public IpAddress getAgentAddress()
  {
    checkV1TRAP();
    return this.agentAddress;
  }

  public void setAgentAddress(IpAddress agentAddress)
  {
    checkV1TRAP();
    checkNull(agentAddress);
    this.agentAddress = agentAddress;
  }

  public int getGenericTrap()
  {
    checkV1TRAP();
    return this.genericTrap.getValue();
  }

  public void setGenericTrap(int genericTrap)
  {
    checkV1TRAP();
    this.genericTrap.setValue(genericTrap);
  }

  public int getSpecificTrap()
  {
    checkV1TRAP();
    return this.specificTrap.getValue();
  }

  public void setSpecificTrap(int specificTrap)
  {
    checkV1TRAP();
    this.specificTrap.setValue(specificTrap);
  }

  public long getTimestamp()
  {
    checkV1TRAP();
    return this.timestamp.getValue();
  }

  public void setTimestamp(long timeStamp)
  {
    checkV1TRAP();
    this.timestamp.setValue(timeStamp);
  }

  protected void checkNull(Object parameter)
  {
    if (parameter == null)
      throw new NullPointerException("Members of PDUv1 must not be null");
  }

  public String toString()
  {
    if (this.type == -92) {
      StringBuffer buf = new StringBuffer();
      buf.append(getTypeString(this.type));
      buf.append("[reqestID=");
      buf.append(this.requestID);
      buf.append(",timestamp=");
      buf.append(this.timestamp);
      buf.append(",enterprise=");
      buf.append(this.enterprise);
      buf.append(",genericTrap=");
      buf.append(this.genericTrap);
      buf.append(",specificTrap=");
      buf.append(this.specificTrap);
      buf.append(", VBS[");
      for (int i = 0; i < this.variableBindings.size(); i++) {
        buf.append(this.variableBindings.get(i));
        if (i + 1 < this.variableBindings.size()) {
          buf.append("; ");
        }
      }
      buf.append("]]");
      return buf.toString();
    }
    return super.toString();
  }
}