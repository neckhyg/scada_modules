package org.snmp4j;

import java.io.Serializable;

public abstract interface User extends Serializable
{
}