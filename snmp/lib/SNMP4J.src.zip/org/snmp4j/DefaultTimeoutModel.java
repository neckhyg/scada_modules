package org.snmp4j;

public class DefaultTimeoutModel
  implements TimeoutModel
{
  public long getRetryTimeout(int retryCount, int totalNumberOfRetries, long targetTimeout)
  {
    return targetTimeout;
  }

  public long getRequestTimeout(int totalNumberOfRetries, long targetTimeout) {
    return (totalNumberOfRetries + 1) * targetTimeout;
  }
}