package org.snmp4j;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.TimerTask;
import java.util.Vector;
import org.snmp4j.event.ResponseEvent;
import org.snmp4j.event.ResponseListener;
import org.snmp4j.log.LogAdapter;
import org.snmp4j.log.LogFactory;
import org.snmp4j.mp.MPv1;
import org.snmp4j.mp.MPv2c;
import org.snmp4j.mp.MPv3;
import org.snmp4j.mp.MessageProcessingModel;
import org.snmp4j.mp.PduHandle;
import org.snmp4j.mp.PduHandleCallback;
import org.snmp4j.mp.SnmpConstants;
import org.snmp4j.mp.StatusInformation;
import org.snmp4j.security.SecurityProtocols;
import org.snmp4j.security.USM;
import org.snmp4j.smi.Address;
import org.snmp4j.smi.OID;
import org.snmp4j.smi.OctetString;
import org.snmp4j.smi.VariableBinding;
import org.snmp4j.transport.ConnectionOrientedTransportMapping;
import org.snmp4j.transport.TransportMappings;
import org.snmp4j.util.CommonTimer;
import org.snmp4j.util.TimerFactory;

public class Snmp
  implements Session, CommandResponder
{
  private static final LogAdapter logger = LogFactory.getLogger(Snmp.class);
  private static final int DEFAULT_MAX_REQUEST_STATUS = 2;
  private static final int ENGINE_ID_DISCOVERY_MAX_REQUEST_STATUS = 0;
  private MessageDispatcher messageDispatcher;
  private Map pendingRequests = new Hashtable(50);

  private Map asyncRequests = new Hashtable(50);
  private CommonTimer timer;
  private transient Vector commandResponderListeners;
  private TimeoutModel timeoutModel = new DefaultTimeoutModel();

  private NotificationDispatcher notificationDispatcher = null;

  private ReportHandler reportHandler = new ReportProcessor();

  public Snmp()
  {
    this.messageDispatcher = new MessageDispatcherImpl();
  }

  protected final void initMessageDispatcher()
  {
    this.messageDispatcher.addCommandResponder(this);
    this.messageDispatcher.addMessageProcessingModel(new MPv2c());
    this.messageDispatcher.addMessageProcessingModel(new MPv1());
    this.messageDispatcher.addMessageProcessingModel(new MPv3());
    SecurityProtocols.getInstance().addDefaultProtocols();
  }

  public Snmp(TransportMapping transportMapping)
  {
    this();
    initMessageDispatcher();
    if (transportMapping != null)
      addTransportMapping(transportMapping);
  }

  public Snmp(MessageDispatcher messageDispatcher, TransportMapping transportMapping)
  {
    this.messageDispatcher = messageDispatcher;
    this.messageDispatcher.addCommandResponder(this);
    if (transportMapping != null)
      addTransportMapping(transportMapping);
  }

  public Snmp(MessageDispatcher messageDispatcher)
  {
    this.messageDispatcher = messageDispatcher;
    this.messageDispatcher.addCommandResponder(this);
  }

  public MessageDispatcher getMessageDispatcher()
  {
    return this.messageDispatcher;
  }

  public void addTransportMapping(TransportMapping transportMapping)
  {
    this.messageDispatcher.addTransportMapping(transportMapping);
    transportMapping.addTransportListener(this.messageDispatcher);
  }

  public void removeTransportMapping(TransportMapping transportMapping)
  {
    this.messageDispatcher.removeTransportMapping(transportMapping);
    transportMapping.removeTransportListener(this.messageDispatcher);
  }

  public synchronized boolean addNotificationListener(Address listenAddress, CommandResponder listener)
  {
    TransportMapping tm = TransportMappings.getInstance().createTransportMapping(listenAddress);

    if (tm == null) {
      if (logger.isInfoEnabled()) {
        logger.info("Failed to add notification listener for address: " + listenAddress);
      }

      return false;
    }
    if ((tm instanceof ConnectionOrientedTransportMapping)) {
      ((ConnectionOrientedTransportMapping)tm).setConnectionTimeout(0L);
    }
    tm.addTransportListener(this.messageDispatcher);
    if (this.notificationDispatcher == null) {
      this.notificationDispatcher = new NotificationDispatcher();
      addCommandResponder(this.notificationDispatcher);
    }
    this.notificationDispatcher.addNotificationListener(listenAddress, tm, listener);
    try {
      tm.listen();
      if (logger.isInfoEnabled()) {
        logger.info("Added notification listener for address: " + listenAddress);
      }

      return true;
    }
    catch (IOException ex) {
      logger.warn("Failed to initialize notification listener for address '" + listenAddress + "': " + ex.getMessage());
    }
    return false;
  }

  public synchronized boolean removeNotificationListener(Address listenAddress)
  {
    if (this.notificationDispatcher != null) {
      if (logger.isInfoEnabled()) {
        logger.info("Removing notification listener for address: " + listenAddress);
      }

      return this.notificationDispatcher.removeNotificationListener(listenAddress);
    }

    return false;
  }

  public void listen()
    throws IOException
  {
    Iterator it = this.messageDispatcher.getTransportMappings().iterator();
    while (it.hasNext()) {
      TransportMapping tm = (TransportMapping)it.next();
      if (!tm.isListening())
        tm.listen();
    }
  }

  public int getNextRequestID()
  {
    return this.messageDispatcher.getNextRequestID();
  }

  public void close()
    throws IOException
  {
    Iterator it = this.messageDispatcher.getTransportMappings().iterator();
    while (it.hasNext()) {
      TransportMapping tm = (TransportMapping)it.next();
      if (tm.isListening()) {
        tm.close();
      }
    }
    CommonTimer t = this.timer;
    this.timer = null;
    if (t != null) {
      t.cancel();
    }

    if (this.notificationDispatcher != null)
      this.notificationDispatcher.closeAll();
    List pr;
    synchronized (this.pendingRequests) {
      pr = new ArrayList(this.pendingRequests.values());
    }
    for (Iterator it = pr.iterator(); it.hasNext(); ) {
      PendingRequest pending = (PendingRequest)it.next();
      ResponseEvent e = new ResponseEvent(this, null, pending.pdu, null, pending.userObject, new InterruptedException("Snmp session has been closed"));

      ResponseListener l = pending.listener;
      if (l != null)
        l.onResponse(e);
    }
  }

  public ResponseEvent get(PDU pdu, Target target)
    throws IOException
  {
    pdu.setType(-96);
    return send(pdu, target);
  }

  public void get(PDU pdu, Target target, Object userHandle, ResponseListener listener)
    throws IOException
  {
    pdu.setType(-96);
    send(pdu, target, userHandle, listener);
  }

  public ResponseEvent getNext(PDU pdu, Target target)
    throws IOException
  {
    pdu.setType(-95);
    return send(pdu, target);
  }

  public void getNext(PDU pdu, Target target, Object userHandle, ResponseListener listener)
    throws IOException
  {
    pdu.setType(-95);
    send(pdu, target, userHandle, listener);
  }

  public ResponseEvent getBulk(PDU pdu, Target target)
    throws IOException
  {
    pdu.setType(-91);
    return send(pdu, target);
  }

  public void getBulk(PDU pdu, Target target, Object userHandle, ResponseListener listener)
    throws IOException
  {
    pdu.setType(-91);
    send(pdu, target, userHandle, listener);
  }

  public ResponseEvent inform(PDU pdu, Target target)
    throws IOException
  {
    pdu.setType(-90);
    return send(pdu, target);
  }

  public void inform(PDU pdu, Target target, Object userHandle, ResponseListener listener)
    throws IOException
  {
    pdu.setType(-90);
    send(pdu, target, userHandle, listener);
  }

  public void trap(PDUv1 pdu, Target target)
    throws IOException
  {
    if (target.getVersion() != 0) {
      throw new IllegalArgumentException("SNMPv1 trap PDU must be used with SNMPv1");
    }

    pdu.setType(-92);
    send(pdu, target);
  }

  public void notify(PDU pdu, Target target)
    throws IOException
  {
    if (target.getVersion() == 0) {
      throw new IllegalArgumentException("Notifications PDUs cannot be used with SNMPv1");
    }

    pdu.setType(-89);
    send(pdu, target);
  }

  public ResponseEvent set(PDU pdu, Target target)
    throws IOException
  {
    pdu.setType(-93);
    return send(pdu, target);
  }

  public void set(PDU pdu, Target target, Object userHandle, ResponseListener listener)
    throws IOException
  {
    pdu.setType(-93);
    send(pdu, target, userHandle, listener);
  }

  public ResponseEvent send(PDU pdu, Target target) throws IOException {
    return send(pdu, target, null);
  }

  public ResponseEvent send(PDU pdu, Target target, TransportMapping transport)
    throws IOException
  {
    return send(pdu, target, transport, 2);
  }

  private ResponseEvent send(PDU pdu, Target target, TransportMapping transport, int maxRequestStatus)
    throws IOException
  {
    if (!pdu.isConfirmedPdu()) {
      sendMessage(pdu, target, transport, null);
      return null;
    }
    if (this.timer == null) {
      createPendingTimer();
    }
    SyncResponseListener syncResponse = new SyncResponseListener();
    PendingRequest retryRequest = null;
    synchronized (syncResponse) {
      PduHandle handle = null;
      PendingRequest request = new PendingRequest(syncResponse, target, pdu, target, transport);

      PendingRequest.access$002(request, maxRequestStatus);
      handle = sendMessage(pdu, target, transport, request);
      long totalTimeout = this.timeoutModel.getRequestTimeout(target.getRetries(), target.getTimeout());

      long stopTime = System.currentTimeMillis() + totalTimeout;
      try {
        while ((syncResponse.getResponse() == null) && (System.currentTimeMillis() < stopTime))
        {
          syncResponse.wait(totalTimeout);
        }
        retryRequest = (PendingRequest)this.pendingRequests.remove(handle);
        if (logger.isDebugEnabled()) {
          logger.debug("Removed pending request with handle: " + handle);
        }
        request.setFinished();
        request.cancel();
      }
      catch (InterruptedException iex) {
        logger.warn(iex);

        request.setFinished();
        request.cancel();
        retryRequest = (PendingRequest)this.pendingRequests.remove(handle);
        if (retryRequest != null) {
          retryRequest.setFinished();
          retryRequest.cancel();
        }
        Thread.currentThread().interrupt();
      }
      finally {
        if (!request.finished)
        {
          retryRequest = (PendingRequest)this.pendingRequests.remove(handle);
          if (retryRequest != null) {
            retryRequest.setFinished();
            retryRequest.cancel();
          }
        }
      }
    }
    if (retryRequest != null) {
      retryRequest.setFinished();
      retryRequest.cancel();
    }
    if (syncResponse.getResponse() == null) {
      SyncResponseListener.access$202(syncResponse, new ResponseEvent(this, null, pdu, null, null));
    }

    return syncResponse.response;
  }

  private synchronized void createPendingTimer() {
    if (this.timer == null)
      this.timer = SNMP4JSettings.getTimerFactory().createTimer();
  }

  public void send(PDU pdu, Target target, Object userHandle, ResponseListener listener)
    throws IOException
  {
    send(pdu, target, null, userHandle, listener);
  }

  public void send(PDU pdu, Target target, TransportMapping transport, Object userHandle, ResponseListener listener)
    throws IOException
  {
    if (!pdu.isConfirmedPdu()) {
      sendMessage(pdu, target, transport, null);
      return;
    }
    if (this.timer == null) {
      createPendingTimer();
    }
    PendingRequest request = new AsyncPendingRequest(listener, userHandle, pdu, target, transport);

    sendMessage(pdu, target, transport, request);
  }

  /** @deprecated */
  public PDU sendPDU(PDU pdu, Target target)
    throws IOException
  {
    ResponseEvent e = send(pdu, target);
    if (e != null) {
      return e.getResponse();
    }

    return null;
  }

  /** @deprecated */
  public void sendPDU(PDU pdu, Target target, Object userHandle, ResponseListener listener)
    throws IOException
  {
    send(pdu, target, userHandle, listener);
  }

  protected PduHandle sendMessage(PDU pdu, Target target, TransportMapping transport, PduHandleCallback pduHandleCallback)
    throws IOException
  {
    PduHandle handle = null;
    if ((target instanceof SecureTarget)) {
      SecureTarget secureTarget = (SecureTarget)target;
      handle = this.messageDispatcher.sendPdu(transport, secureTarget.getAddress(), secureTarget.getVersion(), secureTarget.getSecurityModel(), secureTarget.getSecurityName().getValue(), secureTarget.getSecurityLevel(), pdu, true, pduHandleCallback);
    }
    else if ((target instanceof CommunityTarget)) {
      CommunityTarget communityTarget = (CommunityTarget)target;
      int securityModel = 2;
      if (communityTarget.getVersion() == 0) {
        securityModel = 1;
      }
      handle = this.messageDispatcher.sendPdu(transport, communityTarget.getAddress(), communityTarget.getVersion(), securityModel, communityTarget.getCommunity().getValue(), 1, pdu, true, pduHandleCallback);
    }

    return handle;
  }

  public void cancel(PDU request, ResponseListener listener) {
    AsyncRequestKey key = new AsyncRequestKey(request, listener);
    PduHandle pending = (PduHandle)this.asyncRequests.remove(key);
    if (logger.isDebugEnabled()) {
      logger.debug("Cancelling pending request with handle " + pending);
    }
    if (pending != null) {
      PendingRequest pendingRequest = (PendingRequest)this.pendingRequests.remove(pending);

      if (pendingRequest != null)
        synchronized (pendingRequest) {
          pendingRequest.setFinished();
          pendingRequest.cancel();
        }
    }
  }

  public void setLocalEngine(byte[] engineID, int engineBoots, int engineTime)
  {
    MPv3 mpv3 = getMPv3();
    mpv3.setLocalEngineID(engineID);
    USM usm = (USM)mpv3.getSecurityModel(3);
    usm.setLocalEngine(new OctetString(engineID), engineBoots, engineTime);
  }

  public byte[] getLocalEngineID()
  {
    return getMPv3().getLocalEngineID();
  }

  private MPv3 getMPv3() {
    MPv3 mpv3 = (MPv3)getMessageProcessingModel(3);
    if (mpv3 == null) {
      throw new NoSuchElementException("MPv3 not available");
    }
    return mpv3;
  }

  public byte[] discoverAuthoritativeEngineID(Address address, long timeout)
  {
    MPv3 mpv3 = getMPv3();

    OctetString engineID = mpv3.removeEngineID(address);

    if (engineID != null) {
      USM usm = getUSM();
      if (usm != null) {
        usm.removeEngineTime(engineID);
      }
    }
    ScopedPDU scopedPDU = new ScopedPDU();
    scopedPDU.setType(-96);
    SecureTarget target = new UserTarget();
    target.setTimeout(timeout);
    target.setAddress(address);
    target.setSecurityLevel(1);
    try {
      send(scopedPDU, target, null, 0);
      OctetString authoritativeEngineID = mpv3.getEngineID(address);
      if (authoritativeEngineID == null) {
        return null;
      }

      return new OctetString(authoritativeEngineID.getValue()).getValue();
    }
    catch (IOException ex) {
      logger.error("IO error while trying to discover authoritative engine ID: " + ex);
    }

    return null;
  }

  public USM getUSM()
  {
    MPv3 mp = (MPv3)getMessageProcessingModel(3);
    if (mp != null) {
      return (USM)mp.getSecurityModel(3);
    }
    return null;
  }

  public MessageProcessingModel getMessageProcessingModel(int messageProcessingModel)
  {
    return this.messageDispatcher.getMessageProcessingModel(messageProcessingModel);
  }

  public void processPdu(CommandResponderEvent event)
  {
    PduHandle handle = event.getPduHandle();
    PDU pdu = event.getPDU();
    if (pdu.getType() == -94) {
      event.setProcessed(true);

      if (logger.isDebugEnabled())
        logger.debug("Looking up pending request with handle " + handle);
      PendingRequest request;
      synchronized (this.pendingRequests) {
        request = (PendingRequest)this.pendingRequests.get(handle);
        if (request != null) {
          request.responseReceived();
        }
      }
      if (request == null) {
        if (logger.isWarnEnabled()) {
          logger.warn("Received response that cannot be matched to any outstanding request, address=" + event.getPeerAddress() + ", requestID=" + pdu.getRequestID());
        }

      }
      else
      {
        ResponseListener l = request.listener;
        if (l != null) {
          l.onResponse(new ResponseEvent(this, event.getPeerAddress(), request.pdu, pdu, request.userObject));
        }

      }

    }
    else if (pdu.getType() == -88) {
      event.setProcessed(true);
      this.reportHandler.processReport(handle, event);
    }
    else {
      if (logger.isDebugEnabled()) {
        logger.debug("Fire process PDU event: " + event.toString());
      }
      fireProcessPdu(event);
    }
  }

  public synchronized void removeCommandResponder(CommandResponder listener)
  {
    if ((this.commandResponderListeners != null) && (this.commandResponderListeners.contains(listener)))
    {
      Vector v = (Vector)this.commandResponderListeners.clone();
      v.removeElement(listener);
      this.commandResponderListeners = v;
    }
  }

  public synchronized void addCommandResponder(CommandResponder listener)
  {
    Vector v = this.commandResponderListeners == null ? new Vector(2) : (Vector)this.commandResponderListeners.clone();

    if (!v.contains(listener)) {
      v.addElement(listener);
      this.commandResponderListeners = v;
    }
  }

  protected void fireProcessPdu(CommandResponderEvent event)
  {
    if (this.commandResponderListeners != null) {
      Vector listeners = this.commandResponderListeners;
      int count = listeners.size();
      for (int i = 0; i < count; i++) {
        ((CommandResponder)listeners.get(i)).processPdu(event);

        if (event.isProcessed())
          return;
      }
    }
  }

  public TimeoutModel getTimeoutModel()
  {
    return this.timeoutModel;
  }

  public ReportHandler getReportHandler()
  {
    return this.reportHandler;
  }

  public void setTimeoutModel(TimeoutModel timeoutModel)
  {
    if (timeoutModel == null) {
      throw new NullPointerException("Timeout model cannot be null");
    }
    this.timeoutModel = timeoutModel;
  }

  public void setReportHandler(ReportHandler reportHandler)
  {
    if (reportHandler == null) {
      throw new IllegalArgumentException("ReportHandler must not be null");
    }
    this.reportHandler = reportHandler;
  }

  class NotificationDispatcher
    implements CommandResponder
  {
    private Hashtable notificationListeners = new Hashtable(10);
    private Hashtable notificationTransports = new Hashtable(10);

    protected NotificationDispatcher()
    {
    }

    public synchronized void addNotificationListener(Address listenAddress, TransportMapping transport, CommandResponder listener)
    {
      this.notificationListeners.put(listenAddress, transport);
      this.notificationTransports.put(transport, listener);
    }

    public synchronized boolean removeNotificationListener(Address listenAddress)
    {
      TransportMapping tm = (TransportMapping)this.notificationListeners.remove(listenAddress);

      if (tm == null) {
        return false;
      }
      tm.removeTransportListener(Snmp.this.messageDispatcher);
      this.notificationTransports.remove(tm);
      try
      {
        tm.close();
      }
      catch (IOException ex) {
        Snmp.logger.error(ex);
        if (Snmp.logger.isDebugEnabled()) {
          ex.printStackTrace();
        }
      }
      return true;
    }

    public synchronized void closeAll() {
      this.notificationTransports.clear();
      Iterator it = this.notificationListeners.values().iterator();
      while (it.hasNext()) {
        TransportMapping tm = (TransportMapping)it.next();
        try {
          tm.close();
        }
        catch (IOException ex) {
          Snmp.logger.error(ex);
          if (Snmp.logger.isDebugEnabled()) {
            ex.printStackTrace();
          }
        }
      }
      this.notificationListeners.clear();
    }

    public synchronized void processPdu(CommandResponderEvent event) {
      CommandResponder listener = (CommandResponder)this.notificationTransports.get(event.getTransportMapping());

      if ((event.getPDU() != null) && (event.getPDU().getType() == -90))
      {
        try
        {
          sendInformResponse(event);
        }
        catch (MessageException mex) {
          if (Snmp.logger.isWarnEnabled()) {
            Snmp.logger.warn("Failed to send response on INFORM PDU event (" + event + "): " + mex.getMessage());
          }
        }
      }

      if (listener != null)
        listener.processPdu(event);
    }

    protected void sendInformResponse(CommandResponderEvent event)
      throws MessageException
    {
      PDU responsePDU = (PDU)event.getPDU().clone();
      responsePDU.setType(-94);
      responsePDU.setErrorStatus(0);
      responsePDU.setErrorIndex(0);
      Snmp.this.messageDispatcher.returnResponsePdu(event.getMessageProcessingModel(), event.getSecurityModel(), event.getSecurityName(), event.getSecurityLevel(), responsePDU, event.getMaxSizeResponsePDU(), event.getStateReference(), new StatusInformation());
    }
  }

  static class SyncResponseListener
    implements ResponseListener
  {
    private ResponseEvent response = null;

    public synchronized void onResponse(ResponseEvent event) {
      this.response = event;
      notify();
    }

    public ResponseEvent getResponse() {
      return this.response;
    }
  }

  static class AsyncRequestKey
  {
    private PDU request;
    private ResponseListener listener;

    public AsyncRequestKey(PDU request, ResponseListener listener)
    {
      this.request = request;
      this.listener = listener;
    }

    public boolean equals(Object obj)
    {
      if ((obj instanceof AsyncRequestKey)) {
        AsyncRequestKey other = (AsyncRequestKey)obj;
        return (this.request.equals(other.request)) && (this.listener.equals(other.listener));
      }
      return false;
    }

    public int hashCode() {
      return this.request.hashCode();
    }
  }

  class AsyncPendingRequest extends Snmp.PendingRequest
  {
    public AsyncPendingRequest(ResponseListener listener, Object userObject, PDU pdu, Target target, TransportMapping transport)
    {
      super(listener, userObject, pdu, target, transport);
    }

    protected void registerRequest(PduHandle handle) {
      Snmp.AsyncRequestKey key = new Snmp.AsyncRequestKey(this.pdu, this.listener);
      Snmp.this.asyncRequests.put(key, handle);
    }
  }

  class PendingRequest extends TimerTask
    implements PduHandleCallback
  {
    private PduHandle key;
    protected int retryCount;
    protected ResponseListener listener;
    protected Object userObject;
    protected PDU pdu;
    protected Target target;
    protected TransportMapping transport;
    private int requestStatus = 0;

    private int maxRequestStatus = 2;

    private volatile boolean finished = false;
    private volatile boolean responseReceived = false;
    private volatile boolean pendingRetry = false;
    private volatile boolean cancelled = false;

    public PendingRequest(ResponseListener listener, Object userObject, PDU pdu, Target target, TransportMapping transport)
    {
      this.userObject = userObject;
      this.listener = listener;
      this.retryCount = target.getRetries();
      this.pdu = pdu;
      this.target = ((Target)target.clone());
      this.transport = transport;
    }

    private PendingRequest(PendingRequest other) {
      this.userObject = other.userObject;
      this.listener = other.listener;
      other.retryCount -= 1;
      this.pdu = other.pdu;
      this.target = other.target;
      this.requestStatus = other.requestStatus;
      this.responseReceived = other.responseReceived;
      this.transport = other.transport;
    }

    protected void registerRequest(PduHandle handle)
    {
    }

    public void responseReceived() {
      this.responseReceived = true;
    }

    public synchronized void pduHandleAssigned(PduHandle handle, Object pdu) {
      if (this.key == null) {
        this.key = handle;

        Target t = this.target;
        if ((t != null) && (!this.cancelled)) {
          Snmp.this.pendingRequests.put(handle, this);
          registerRequest(handle);
          if (Snmp.logger.isDebugEnabled()) {
            Snmp.logger.debug("Running pending " + ((this.listener instanceof Snmp.SyncResponseListener) ? "sync" : "async") + " request with handle " + handle + " and retry count left " + this.retryCount);
          }

          long delay = Snmp.this.timeoutModel.getRetryTimeout(t.getRetries() - this.retryCount, t.getRetries(), t.getTimeout());

          if ((!this.finished) && (!this.responseReceived) && (!this.cancelled)) {
            try {
              Snmp.this.timer.schedule(this, delay);
            }
            catch (IllegalStateException isex)
            {
            }
          }
          else
            Snmp.this.pendingRequests.remove(handle);
        }
      }
    }

    public synchronized void run()
    {
      PduHandle m_key = this.key;
      PDU m_pdu = this.pdu;
      Target m_target = this.target;
      TransportMapping m_transport = this.transport;
      ResponseListener m_listener = this.listener;
      Object m_userObject = this.userObject;

      if ((m_key == null) || (m_pdu == null) || (m_target == null) || (m_listener == null))
      {
        if (Snmp.logger.isDebugEnabled()) {
          Snmp.logger.debug("PendingRequest canceled key=" + m_key + ", pdu=" + m_pdu + ", target=" + m_target + ", transport=" + m_transport + ", listener=" + m_listener);
        }

        return;
      }
      try
      {
        synchronized (Snmp.this.pendingRequests) {
          this.pendingRetry = ((!this.finished) && (this.retryCount > 0) && (!this.responseReceived));
        }

        if (this.pendingRetry) {
          try {
            PendingRequest nextRetry = new PendingRequest(Snmp.this, this);
            Snmp.this.sendMessage(m_pdu, m_target, m_transport, nextRetry);
            this.pendingRetry = false;
          }
          catch (IOException ex) {
            ResponseListener l = this.listener;
            this.finished = true;
            Snmp.logger.error("Failed to send SNMP message to " + m_target + ": " + ex.getMessage());

            Snmp.this.messageDispatcher.releaseStateReference(m_target.getVersion(), m_key);

            if (l != null) {
              this.listener.onResponse(new ResponseEvent(Snmp.this, null, m_pdu, null, m_userObject, ex));
            }
          }

        }
        else if (!this.finished) {
          this.finished = true;
          Snmp.this.pendingRequests.remove(m_key);
          if (!this.cancelled)
          {
            if (Snmp.logger.isDebugEnabled()) {
              Snmp.logger.debug("Request timed out: " + m_key.getTransactionID());
            }
            Snmp.this.messageDispatcher.releaseStateReference(m_target.getVersion(), m_key);

            m_listener.onResponse(new ResponseEvent(Snmp.this, null, m_pdu, null, m_userObject));
          }

        }
        else
        {
          Snmp.this.pendingRequests.remove(m_key);
        }
      }
      catch (RuntimeException ex) {
        Snmp.logger.error("Failed to process pending request " + m_key + " because " + ex.getMessage(), ex);

        throw ex;
      }
      catch (Error er) {
        Snmp.logger.fatal("Failed to process pending request " + m_key + " because " + er.getMessage(), er);

        throw er;
      }
    }

    public boolean setFinished() {
      boolean currentState = this.finished;
      this.finished = true;
      return currentState;
    }

    public void setMaxRequestStatus(int maxRequestStatus) {
      this.maxRequestStatus = maxRequestStatus;
    }

    public int getMaxRequestStatus() {
      return this.maxRequestStatus;
    }

    public boolean isResponseReceived() {
      return this.responseReceived;
    }

    public boolean cancel()
    {
      this.cancelled = true;
      boolean result = super.cancel();

      if (!this.pendingRetry) {
        this.key = null;
        this.pdu = null;
        this.target = null;
        this.transport = null;
        this.listener = null;
        this.userObject = null;
      }
      return result;
    }
  }

  class ReportProcessor
    implements Snmp.ReportHandler
  {
    ReportProcessor()
    {
    }

    public void processReport(PduHandle handle, CommandResponderEvent e)
    {
      PDU pdu = e.getPDU();
      Snmp.logger.debug("Searching pending request with handle" + handle);
      Snmp.PendingRequest request = (Snmp.PendingRequest)Snmp.this.pendingRequests.get(handle);
      if (request == null) {
        Snmp.logger.warn("Unmatched report PDU received from " + e.getPeerAddress());
        return;
      }
      if (pdu.size() == 0) {
        Snmp.logger.error("Illegal report PDU received from " + e.getPeerAddress() + " missing report variable binding");

        return;
      }
      VariableBinding vb = pdu.get(0);
      if (vb == null) {
        Snmp.logger.error("Received illegal REPORT PDU from " + e.getPeerAddress());
        return;
      }
      OID firstOID = vb.getOid();
      boolean resend = false;
      if (request.requestStatus < request.maxRequestStatus) {
        switch (request.requestStatus) {
        case 0:
          if (SnmpConstants.usmStatsUnknownEngineIDs.equals(firstOID)) {
            resend = true;
          } else {
            if (!SnmpConstants.usmStatsNotInTimeWindows.equals(firstOID)) break;
            Snmp.PendingRequest.access$508(request);
            resend = true; } break;
        case 1:
          if (!SnmpConstants.usmStatsNotInTimeWindows.equals(firstOID)) break;
          resend = true;
        }

      }

      if (resend) {
        Snmp.logger.debug("Send new request after report.");
        Snmp.PendingRequest.access$508(request);
        try
        {
          PduHandle resentHandle = Snmp.this.sendMessage(request.pdu, request.target, e.getTransportMapping(), null);

          Snmp.PendingRequest.access$602(request, resentHandle);
        }
        catch (IOException iox) {
          Snmp.logger.error("Failed to send message to " + request.target + ": " + iox.getMessage());

          return;
        }

      }
      else
      {
        ResponseListener reqListener = request.listener;
        PDU reqPDU = request.pdu;
        Object reqUserObject = request.userObject;
        boolean intime;
        synchronized (request) {
          intime = request.cancel();
        }

        Snmp.this.pendingRequests.remove(handle);
        if ((intime) && (reqListener != null))
        {
          reqListener.onResponse(new ResponseEvent(this, e.getPeerAddress(), reqPDU, pdu, reqUserObject));
        }
        else if (Snmp.logger.isInfoEnabled())
          Snmp.logger.info("Received late report from " + e.getPeerAddress() + " with request ID " + pdu.getRequestID());
      }
    }
  }

  public static abstract interface ReportHandler
  {
    public abstract void processReport(PduHandle paramPduHandle, CommandResponderEvent paramCommandResponderEvent);
  }
}