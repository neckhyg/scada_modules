package org.snmp4j.smi;

import java.net.InetAddress;
import org.snmp4j.log.LogAdapter;
import org.snmp4j.log.LogFactory;

public class TcpAddress extends TransportIpAddress
{
  static final long serialVersionUID = 1165319744164017388L;
  private static final LogAdapter logger = LogFactory.getLogger(TcpAddress.class);

  public TcpAddress()
  {
  }

  public TcpAddress(InetAddress inetAddress, int port) {
    setInetAddress(inetAddress);
    setPort(port);
  }

  public TcpAddress(int port)
  {
    setPort(port);
  }

  public TcpAddress(String address) {
    if (!parseAddress(address))
      throw new IllegalArgumentException(address);
  }

  public static Address parse(String address)
  {
    try {
      TcpAddress a = new TcpAddress();
      if (a.parseAddress(address))
        return a;
    }
    catch (Exception ex)
    {
      logger.error(ex);
    }
    return null;
  }

  public boolean equals(Object o) {
    if ((o instanceof TcpAddress)) {
      return super.equals(o);
    }
    return false;
  }
}