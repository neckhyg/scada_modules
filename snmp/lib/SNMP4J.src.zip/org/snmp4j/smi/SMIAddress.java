package org.snmp4j.smi;

public abstract class SMIAddress extends AbstractVariable
  implements Address
{
}