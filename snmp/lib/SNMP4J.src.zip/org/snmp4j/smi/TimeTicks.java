package org.snmp4j.smi;

import java.io.IOException;
import java.io.OutputStream;
import java.text.MessageFormat;
import org.snmp4j.asn1.BER;
import org.snmp4j.asn1.BER.MutableByte;
import org.snmp4j.asn1.BERInputStream;

public class TimeTicks extends UnsignedInteger32
{
  private static final long serialVersionUID = 8663761323061572311L;
  private static final String FORMAT_PATTERN = "{0,choice,0#|1#1 day, |1<{0,number,integer} days, }{1,number,integer}:{2,number,00}:{3,number,00}.{4,number,00}";

  public TimeTicks()
  {
  }

  public TimeTicks(TimeTicks other)
  {
    this.value = other.value;
  }

  public TimeTicks(long value) {
    super(value);
  }

  public Object clone() {
    return new TimeTicks(this.value);
  }

  public int getSyntax() {
    return 67;
  }

  public void encodeBER(OutputStream os) throws IOException {
    BER.encodeUnsignedInteger(os, 67, super.getValue());
  }

  public void decodeBER(BERInputStream inputStream) throws IOException {
    BER.MutableByte type = new BER.MutableByte();
    long newValue = BER.decodeUnsignedInteger(inputStream, type);
    if (type.getValue() != 67) {
      throw new IOException("Wrong type encountered when decoding TimeTicks: " + type.getValue());
    }
    setValue(newValue);
  }

  public String toString()
  {
    return toString("{0,choice,0#|1#1 day, |1<{0,number,integer} days, }{1,number,integer}:{2,number,00}:{3,number,00}.{4,number,00}");
  }

  public String toString(String pattern)
  {
    long tt = getValue();

    long days = tt / 8640000L;
    tt %= 8640000L;

    long hours = tt / 360000L;
    tt %= 360000L;

    long minutes = tt / 6000L;
    tt %= 6000L;

    long seconds = tt / 100L;
    tt %= 100L;

    long hseconds = tt;

    Long[] values = new Long[5];
    values[0] = new Long(days);
    values[1] = new Long(hours);
    values[2] = new Long(minutes);
    values[3] = new Long(seconds);
    values[4] = new Long(hseconds);

    return MessageFormat.format(pattern, (Object[])values);
  }

  public long toMilliseconds()
  {
    return this.value * 10L;
  }

  public void fromMilliseconds(long millis)
  {
    setValue(millis / 10L);
  }
}