package org.snmp4j.smi;

import java.io.IOException;
import java.io.OutputStream;
import org.snmp4j.asn1.BER;
import org.snmp4j.asn1.BER.MutableByte;
import org.snmp4j.asn1.BERInputStream;

public class Null extends AbstractVariable
{
  private static final long serialVersionUID = 6907924131098190092L;
  private int syntax = 5;

  public static final Null noSuchObject = new Null(128);

  public static final Null noSuchInstance = new Null(129);

  public static final Null endOfMibView = new Null(130);

  public static final Null instance = new Null(5);

  public Null()
  {
  }

  public Null(int exceptionSyntax) {
    setSyntax(exceptionSyntax);
  }

  public void decodeBER(BERInputStream inputStream) throws IOException {
    BER.MutableByte type = new BER.MutableByte();
    BER.decodeNull(inputStream, type);
    this.syntax = (type.getValue() & 0xFF);
  }

  public int getSyntax() {
    return this.syntax;
  }

  public int hashCode() {
    return getSyntax();
  }

  public int getBERLength() {
    return 2;
  }

  public boolean equals(Object o) {
    if ((o instanceof Null)) {
      return ((Null)o).getSyntax() == getSyntax();
    }
    return false;
  }

  public int compareTo(Object o) {
    return getSyntax() - ((Null)o).getSyntax();
  }

  public String toString() {
    switch (getSyntax()) {
    case 128:
      return "noSuchObject";
    case 129:
      return "noSuchInstance";
    case 130:
      return "endOfMibView";
    }
    return "Null";
  }

  public void encodeBER(OutputStream outputStream) throws IOException {
    BER.encodeHeader(outputStream, (byte)getSyntax(), 0);
  }

  public void setSyntax(int syntax) {
    if ((syntax != 5) && (!isExceptionSyntax(syntax))) {
      throw new IllegalArgumentException("Syntax " + syntax + " is incompatible with Null type");
    }

    this.syntax = syntax;
  }

  public Object clone() {
    return new Null(this.syntax);
  }

  public static boolean isExceptionSyntax(int syntax) {
    switch (syntax) {
    case 128:
    case 129:
    case 130:
      return true;
    }
    return false;
  }

  public final int toInt()
  {
    return getSyntax();
  }

  public final long toLong()
  {
    return getSyntax();
  }

  public OID toSubIndex(boolean impliedLength) {
    throw new UnsupportedOperationException();
  }

  public void fromSubIndex(OID subIndex, boolean impliedLength) {
    throw new UnsupportedOperationException();
  }
}