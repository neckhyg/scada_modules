package org.snmp4j.smi;

import java.io.IOException;
import java.io.OutputStream;
import org.snmp4j.asn1.BER;
import org.snmp4j.asn1.BER.MutableByte;
import org.snmp4j.asn1.BERInputStream;

public class Opaque extends OctetString
{
  private static final long serialVersionUID = -17056771587100877L;

  public Opaque()
  {
  }

  public Opaque(byte[] bytes)
  {
    super(bytes);
  }

  public int getSyntax() {
    return 68;
  }

  public void encodeBER(OutputStream outputStream) throws IOException {
    BER.encodeString(outputStream, 68, getValue());
  }

  public void decodeBER(BERInputStream inputStream) throws IOException {
    BER.MutableByte type = new BER.MutableByte();
    byte[] v = BER.decodeString(inputStream, type);
    if (type.getValue() != 68) {
      throw new IOException("Wrong type encountered when decoding OctetString: " + type.getValue());
    }

    setValue(v);
  }

  public void setValue(OctetString value) {
    setValue(new byte[0]);
    append(value);
  }

  public String toString() {
    return super.toHexString();
  }

  public Object clone() {
    return new Opaque(super.getValue());
  }
}