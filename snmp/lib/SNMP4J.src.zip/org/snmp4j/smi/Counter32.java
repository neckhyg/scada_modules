package org.snmp4j.smi;

import java.io.IOException;
import java.io.OutputStream;
import org.snmp4j.asn1.BER;
import org.snmp4j.asn1.BER.MutableByte;
import org.snmp4j.asn1.BERInputStream;

public class Counter32 extends UnsignedInteger32
{
  private static final long serialVersionUID = 6140742767439142144L;

  public Counter32()
  {
  }

  public Counter32(long value)
  {
    super(value);
  }

  public boolean equals(Object o) {
    if ((o instanceof Counter32)) {
      return ((Counter32)o).getValue() == getValue();
    }
    return false;
  }

  public int getSyntax() {
    return 65;
  }

  public void encodeBER(OutputStream outputStream) throws IOException {
    BER.encodeUnsignedInteger(outputStream, 65, getValue());
  }

  public void decodeBER(BERInputStream inputStream) throws IOException {
    BER.MutableByte type = new BER.MutableByte();
    long newValue = BER.decodeUnsignedInteger(inputStream, type);
    if (type.getValue() != 65) {
      throw new IOException("Wrong type encountered when decoding Counter: " + type.getValue());
    }

    setValue(newValue);
  }

  public Object clone() {
    return new Counter32(this.value);
  }

  public void increment()
  {
    if (this.value < 4294967295L) {
      this.value += 1L;
    }
    else
      this.value = 0L;
  }

  public OID toSubIndex(boolean impliedLength)
  {
    throw new UnsupportedOperationException();
  }

  public void fromSubIndex(OID subIndex, boolean impliedLength) {
    throw new UnsupportedOperationException();
  }
}