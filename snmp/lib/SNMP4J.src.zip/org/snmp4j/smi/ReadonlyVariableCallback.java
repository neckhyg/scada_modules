package org.snmp4j.smi;

public abstract class ReadonlyVariableCallback
  implements VariantVariableCallback
{
  public abstract void updateVariable(VariantVariable paramVariantVariable);

  public final void variableUpdated(VariantVariable variable)
  {
  }
}