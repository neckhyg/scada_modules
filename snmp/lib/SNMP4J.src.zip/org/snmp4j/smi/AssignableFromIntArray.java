package org.snmp4j.smi;

public abstract interface AssignableFromIntArray
{
  public abstract void setValue(int[] paramArrayOfInt);

  public abstract int[] toIntArray();
}