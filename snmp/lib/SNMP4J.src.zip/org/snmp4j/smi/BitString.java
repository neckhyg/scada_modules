package org.snmp4j.smi;

import java.io.IOException;
import java.io.OutputStream;
import org.snmp4j.asn1.BER;
import org.snmp4j.asn1.BER.MutableByte;
import org.snmp4j.asn1.BERInputStream;

public class BitString extends OctetString
{
  private static final long serialVersionUID = -8739361280962307248L;

  public int getSyntax()
  {
    return 3;
  }

  public void encodeBER(OutputStream outputStream) throws IOException {
    BER.encodeString(outputStream, 3, getValue());
  }

  public void decodeBER(BERInputStream inputStream) throws IOException {
    BER.MutableByte type = new BER.MutableByte();
    byte[] v = BER.decodeString(inputStream, type);
    if (type.getValue() != 3) {
      throw new IOException("Wrong type encountered when decoding BitString: " + type.getValue());
    }

    setValue(v);
  }

  public Object clone() {
    BitString clone = new BitString();
    clone.setValue(super.getValue());
    return clone;
  }
}