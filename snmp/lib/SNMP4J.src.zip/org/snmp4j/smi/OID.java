package org.snmp4j.smi;

import java.io.IOException;
import java.io.OutputStream;
import java.text.ParseException;
import java.util.Arrays;
import java.util.NoSuchElementException;
import org.snmp4j.SNMP4JSettings;
import org.snmp4j.asn1.BER;
import org.snmp4j.asn1.BER.MutableByte;
import org.snmp4j.asn1.BERInputStream;
import org.snmp4j.util.OIDTextFormat;

public class OID extends AbstractVariable
  implements AssignableFromString, AssignableFromIntArray
{
  private static final long serialVersionUID = 7521667239352941172L;
  public static final int MAX_OID_LEN = 128;
  public static final int MAX_SUBID_VALUE = -1;
  private static final int[] NULL_OID = new int[0];

  private int[] value = NULL_OID;

  public OID()
  {
  }

  public OID(String oid)
  {
    this.value = parseDottedString(oid);
  }

  public OID(int[] rawOID)
  {
    this(rawOID, 0, rawOID.length);
  }

  public OID(int[] prefixOID, int[] suffixOID)
  {
    this.value = new int[prefixOID.length + suffixOID.length];
    System.arraycopy(prefixOID, 0, this.value, 0, prefixOID.length);
    System.arraycopy(suffixOID, 0, this.value, prefixOID.length, suffixOID.length);
  }

  public OID(int[] rawOID, int offset, int length)
  {
    setValue(rawOID, offset, length);
  }

  public OID(OID other)
  {
    this(other.getValue());
  }

  private static int[] parseDottedString(String oid) {
    try {
      return SNMP4JSettings.getOIDTextFormat().parse(oid);
    } catch (ParseException ex) {
    }
    throw new RuntimeException("OID '" + oid + "' cannot be parsed", ex);
  }

  public final int getSyntax()
  {
    return 6;
  }

  public int hashCode() {
    int hash = 0;
    for (int i = 0; i < this.value.length; i++) {
      hash += (this.value[i] * 31 ^ this.value.length - 1 - i);
    }
    return hash;
  }

  public final boolean equals(Object o) {
    if ((o instanceof OID)) {
      OID other = (OID)o;
      if (other.value.length != this.value.length) {
        return false;
      }
      for (int i = 0; i < this.value.length; i++) {
        if (this.value[i] != other.value[i]) {
          return false;
        }
      }
      return true;
    }
    return false;
  }

  public OID mask(OctetString mask)
  {
    int[] masked = new int[this.value.length];
    System.arraycopy(this.value, 0, masked, 0, this.value.length);
    for (int i = 0; (i < mask.length() * 8) && (i < masked.length); i++) {
      byte b = (byte)(128 >> i % 8);
      if ((mask.get(i / 8) & b) == 0) {
        masked[i] = 0;
      }
    }
    return new OID(masked);
  }

  public final int compareTo(Object o) {
    if ((o instanceof OID)) {
      OID other = (OID)o;
      int min = Math.min(this.value.length, other.value.length);
      int result = leftMostCompare(min, other);
      if (result == 0) {
        return this.value.length - other.value.length;
      }
      return result;
    }
    throw new ClassCastException(o.getClass().getName());
  }

  public String toString() {
    return SNMP4JSettings.getOIDTextFormat().format(this.value);
  }

  public byte[] toByteArray()
  {
    byte[] b = new byte[this.value.length];
    for (int i = 0; i < this.value.length; i++) {
      b[i] = (byte)(this.value[i] & 0xFF);
    }
    return b;
  }

  public void encodeBER(OutputStream outputStream) throws IOException {
    BER.encodeOID(outputStream, 6, this.value);
  }

  public int getBERLength() {
    int length = 1;

    for (int i = 2; i < this.value.length; i++)
    {
      long v = this.value[i] & 0xFFFFFFFF;

      if (v < 128L) {
        length++;
      }
      else if (v < 16384L) {
        length += 2;
      }
      else if (v < 2097152L) {
        length += 3;
      }
      else if (v < 268435456L) {
        length += 4;
      }
      else {
        length += 5;
      }
    }
    return length + BER.getBERLengthOfLength(length) + 1;
  }

  public void decodeBER(BERInputStream inputStream) throws IOException {
    BER.MutableByte type = new BER.MutableByte();
    int[] v = BER.decodeOID(inputStream, type);
    if (type.getValue() != 6) {
      throw new IOException("Wrong type encountered when decoding OID: " + type.getValue());
    }

    setValue(v);
  }

  public void setValue(String value) {
    this.value = parseDottedString(value);
  }

  public final void setValue(int[] value)
  {
    if (value == null) {
      throw new IllegalArgumentException("OID value must not be set to null");
    }
    this.value = value;
  }

  private void setValue(int[] rawOID, int offset, int length) {
    this.value = new int[length];
    System.arraycopy(rawOID, offset, this.value, 0, length);
  }

  public final int[] getValue()
  {
    return this.value;
  }

  public final int get(int index)
  {
    return this.value[index];
  }

  public final long getUnsigned(int index)
  {
    return this.value[index] & 0xFFFFFFFF;
  }

  public final void set(int index, int value)
  {
    this.value[index] = value;
  }

  public final OID append(String oid)
  {
    OID suffix = new OID(oid);
    return append(suffix);
  }

  public final OID append(OID oid)
  {
    int[] newValue = new int[this.value.length + oid.value.length];
    System.arraycopy(this.value, 0, newValue, 0, this.value.length);
    System.arraycopy(oid.value, 0, newValue, this.value.length, oid.value.length);
    this.value = newValue;
    return this;
  }

  public final OID append(int subID)
  {
    int[] newValue = new int[this.value.length + 1];
    System.arraycopy(this.value, 0, newValue, 0, this.value.length);
    newValue[this.value.length] = subID;
    this.value = newValue;
    return this;
  }

  public final OID appendUnsigned(long subID)
  {
    return append((int)(subID & 0xFFFFFFFF));
  }

  public boolean isValid()
  {
    return (size() >= 2) && (size() <= 128) && ((this.value[0] & 0xFFFFFFFF) <= 2L) && ((this.value[1] & 0xFFFFFFFF) < 40L);
  }

  public final int size()
  {
    return this.value.length;
  }

  public int leftMostCompare(int n, OID other)
  {
    for (int i = 0; i < n; i++) {
      if (this.value[i] == other.value[i]) {
        continue;
      }
      if ((this.value[i] & 0xFFFFFFFF) < (other.value[i] & 0xFFFFFFFF))
      {
        return -1;
      }

      return 1;
    }

    return 0;
  }

  public int rightMostCompare(int n, OID other)
  {
    int cursorA = this.value.length - 1;
    int cursorB = other.value.length - 1;
    for (int i = n - 1; i >= 0; cursorB--) {
      if (this.value[cursorA] != other.value[cursorB])
      {
        if (this.value[cursorA] < other.value[cursorB]) {
          return -1;
        }

        return 1;
      }
      i--; cursorA--;
    }

    return 0;
  }

  public boolean startsWith(OID other)
  {
    if (other.value.length > this.value.length) {
      return false;
    }
    int min = Math.min(this.value.length, other.value.length);
    return leftMostCompare(min, other) == 0;
  }

  public Object clone() {
    return new OID(this.value);
  }

  public final int last()
  {
    if (this.value.length > 0) {
      return this.value[(this.value.length - 1)];
    }
    throw new NoSuchElementException();
  }

  public final long lastUnsigned()
  {
    if (this.value.length > 0) {
      return this.value[(this.value.length - 1)] & 0xFFFFFFFF;
    }
    throw new NoSuchElementException();
  }

  public int removeLast()
  {
    if (this.value.length == 0) {
      return -1;
    }
    int[] newValue = new int[this.value.length - 1];
    System.arraycopy(this.value, 0, newValue, 0, this.value.length - 1);
    int retValue = this.value[(this.value.length - 1)];
    this.value = newValue;
    return retValue;
  }

  public void trim(int n)
  {
    if (n > 0) {
      if (n > this.value.length) {
        n = this.value.length;
      }
      int[] newValue = new int[this.value.length - n];
      System.arraycopy(this.value, 0, newValue, 0, this.value.length - n);
      this.value = newValue;
    }
  }

  public OID trim()
  {
    return new OID(this.value, 0, Math.max(this.value.length - 1, 0));
  }

  public int toInt() {
    throw new UnsupportedOperationException();
  }

  public long toLong() {
    throw new UnsupportedOperationException();
  }

  public final OID toSubIndex(boolean impliedLength) {
    if (impliedLength) {
      return new OID(this.value);
    }
    OID subIndex = new OID(new int[] { size() });
    subIndex.append(this);
    return subIndex;
  }

  public final void fromSubIndex(OID subIndex, boolean impliedLength) {
    int offset = 1;
    if (impliedLength) {
      offset = 0;
    }
    setValue(subIndex.getValue(), offset, subIndex.size() - offset);
  }

  public final OID successor()
  {
    if (this.value.length == 128) {
      for (int i = 127; i >= 0; i--) {
        if (this.value[i] != -1) {
          int[] succ = new int[i + 1];
          System.arraycopy(this.value, 0, succ, 0, i + 1);
          succ[i] += 1;
          return new OID(succ);
        }
      }
      return new OID();
    }

    int[] succ = new int[this.value.length + 1];
    System.arraycopy(this.value, 0, succ, 0, this.value.length);
    succ[this.value.length] = 0;
    return new OID(succ);
  }

  public final OID predecessor()
  {
    if (last() != 0) {
      int[] pval = new int[''];
      System.arraycopy(this.value, 0, pval, 0, this.value.length);
      Arrays.fill(pval, this.value.length, pval.length, -1);
      OID pred = new OID(pval);
      pred.set(size() - 1, last() - 1);
      return pred;
    }

    OID pred = new OID(this);
    pred.removeLast();
    return pred;
  }

  public final OID nextPeer()
  {
    OID next = new OID(this);
    if ((next.size() > 0) && (last() != -1)) {
      next.set(next.size() - 1, last() + 1);
    }
    else if (next.size() > 1) {
      next.trim(1);
      next = nextPeer();
    }
    return next;
  }

  public static final OID max(OID a, OID b)
  {
    if (a.compareTo(b) >= 0) {
      return a;
    }
    return b;
  }

  public static final OID min(OID a, OID b)
  {
    if (a.compareTo(b) <= 0) {
      return a;
    }
    return b;
  }

  public int[] toIntArray() {
    return this.value;
  }
}