package org.snmp4j.smi;

public final class SMIConstants
{
  public static final int SYNTAX_INTEGER = 2;
  public static final int SYNTAX_OCTET_STRING = 4;
  public static final int SYNTAX_NULL = 5;
  public static final int SYNTAX_OBJECT_IDENTIFIER = 6;
  public static final int SYNTAX_IPADDRESS = 64;
  public static final int SYNTAX_INTEGER32 = 2;
  public static final int SYNTAX_COUNTER32 = 65;
  public static final int SYNTAX_GAUGE32 = 66;
  public static final int SYNTAX_UNSIGNED_INTEGER32 = 66;
  public static final int SYNTAX_TIMETICKS = 67;
  public static final int SYNTAX_OPAQUE = 68;
  public static final int SYNTAX_COUNTER64 = 70;
  public static final int SYNTAX_BITS = 4;
  public static final int EXCEPTION_NO_SUCH_OBJECT = 128;
  public static final int EXCEPTION_NO_SUCH_INSTANCE = 129;
  public static final int EXCEPTION_END_OF_MIB_VIEW = 130;
}