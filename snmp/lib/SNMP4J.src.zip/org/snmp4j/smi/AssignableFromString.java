package org.snmp4j.smi;

public abstract interface AssignableFromString
{
  public abstract void setValue(String paramString);
}