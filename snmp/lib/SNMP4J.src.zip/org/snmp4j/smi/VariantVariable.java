package org.snmp4j.smi;

import java.io.IOException;
import java.io.OutputStream;
import org.snmp4j.asn1.BERInputStream;

public class VariantVariable extends AbstractVariable
  implements AssignableFromInteger, AssignableFromLong, AssignableFromString, AssignableFromByteArray
{
  private static final long serialVersionUID = -3678564678835871188L;
  private Variable variable;
  private VariantVariableCallback callback;

  public VariantVariable(Variable initialVariable)
  {
    if (initialVariable == null) {
      throw new NullPointerException();
    }
    this.variable = initialVariable;
  }

  public VariantVariable(Variable initialVariable, VariantVariableCallback callback)
  {
    this(initialVariable);
    this.callback = callback;
  }

  public synchronized int compareTo(Object o) {
    updateVariable();
    return this.variable.compareTo(o);
  }

  protected void updateVariable() {
    if (this.callback != null)
      this.callback.updateVariable(this);
  }

  protected void variableUpdated()
  {
    if (this.callback != null)
      this.callback.variableUpdated(this);
  }

  public synchronized void decodeBER(BERInputStream inputStream) throws IOException
  {
    this.variable.decodeBER(inputStream);
    variableUpdated();
  }

  public synchronized void encodeBER(OutputStream outputStream) throws IOException {
    updateVariable();
    this.variable.encodeBER(outputStream);
  }

  public synchronized void fromSubIndex(OID subIndex, boolean impliedLength) {
    this.variable.fromSubIndex(subIndex, impliedLength);
    variableUpdated();
  }

  public synchronized int getBERLength() {
    updateVariable();
    return this.variable.getBERLength();
  }

  public int getSyntax() {
    return this.variable.getSyntax();
  }

  public synchronized int toInt() {
    updateVariable();
    return this.variable.toInt();
  }

  public synchronized long toLong() {
    updateVariable();
    return this.variable.toLong();
  }

  public synchronized byte[] toByteArray() {
    updateVariable();
    if ((this.variable instanceof AssignableFromByteArray)) {
      return ((AssignableFromByteArray)this.variable).toByteArray();
    }
    throw new UnsupportedOperationException();
  }

  public synchronized OID toSubIndex(boolean impliedLength) {
    updateVariable();
    return this.variable.toSubIndex(impliedLength);
  }

  public synchronized boolean equals(Object o) {
    updateVariable();
    return this.variable.equals(o);
  }

  public synchronized int hashCode() {
    updateVariable();
    return this.variable.hashCode();
  }

  public synchronized String toString() {
    updateVariable();
    return this.variable.toString();
  }

  public Object clone() {
    updateVariable();
    return new VariantVariable((Variable)this.variable.clone());
  }

  public synchronized void setValue(int value) {
    if ((this.variable instanceof AssignableFromByteArray)) {
      ((AssignableFromByteArray)this.variable).setValue(value);
    }
    else
      throw new ClassCastException("An integer value cannot be assigned to " + this.variable);
  }

  public synchronized void setValue(long value)
  {
    if ((this.variable instanceof AssignableFromLong)) {
      ((AssignableFromLong)this.variable).setValue(value);
    }
    else
      throw new ClassCastException("A long value cannot be assigned to " + this.variable);
  }

  public synchronized void setValue(OctetString value)
  {
    if ((this.variable instanceof AssignableFromByteArray)) {
      ((AssignableFromByteArray)this.variable).setValue(value.getValue());
    }
    else
      throw new ClassCastException("An OctetString value cannot be assigned to " + this.variable);
  }

  public synchronized void setValue(byte[] value)
  {
    if ((this.variable instanceof AssignableFromByteArray)) {
      ((AssignableFromByteArray)this.variable).setValue(value);
    }
    else
      throw new ClassCastException("A byte array value cannot be assigned to " + this.variable);
  }

  public synchronized void setValue(String value)
  {
    if ((this.variable instanceof AssignableFromString)) {
      ((AssignableFromString)this.variable).setValue(value);
    }
    else
      throw new ClassCastException("A string value cannot be assigned to " + this.variable);
  }

  public Variable getVariable()
  {
    return this.variable;
  }

  public boolean isDynamic() {
    return true;
  }
}