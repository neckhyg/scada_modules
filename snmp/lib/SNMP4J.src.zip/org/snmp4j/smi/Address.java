package org.snmp4j.smi;

public abstract interface Address extends Comparable, AssignableFromString
{
  public abstract boolean isValid();

  public abstract boolean parseAddress(String paramString);

  public abstract void setValue(String paramString);
}