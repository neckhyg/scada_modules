package org.snmp4j.smi;

public abstract interface AssignableFromLong
{
  public abstract void setValue(long paramLong);

  public abstract long toLong();
}