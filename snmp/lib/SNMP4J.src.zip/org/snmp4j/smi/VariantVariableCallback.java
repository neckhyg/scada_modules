package org.snmp4j.smi;

public abstract interface VariantVariableCallback
{
  public abstract void variableUpdated(VariantVariable paramVariantVariable);

  public abstract void updateVariable(VariantVariable paramVariantVariable);
}