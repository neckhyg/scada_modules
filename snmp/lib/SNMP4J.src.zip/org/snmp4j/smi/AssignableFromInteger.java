package org.snmp4j.smi;

public abstract interface AssignableFromInteger
{
  public abstract void setValue(int paramInt);

  public abstract int toInt();
}