package org.snmp4j.smi;

public class Gauge32 extends UnsignedInteger32
{
  static final long serialVersionUID = 1469573439175461445L;

  public Gauge32()
  {
  }

  public Gauge32(long value)
  {
    super(value);
  }

  public int getSyntax() {
    return 66;
  }

  public Object clone() {
    return new Gauge32(this.value);
  }
}