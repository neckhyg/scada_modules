package org.snmp4j.smi;

import java.io.IOException;
import java.io.OutputStream;
import org.snmp4j.asn1.BER;
import org.snmp4j.asn1.BER.MutableByte;
import org.snmp4j.asn1.BERInputStream;

public class UnsignedInteger32 extends AbstractVariable
  implements AssignableFromLong, AssignableFromString
{
  private static final long serialVersionUID = -2155365655395258383L;
  protected long value = 0L;

  public UnsignedInteger32()
  {
  }

  public UnsignedInteger32(long value)
  {
    setValue(value);
  }

  public UnsignedInteger32(int signedIntValue)
  {
    setValue(signedIntValue & 0xFFFFFFFF);
  }

  public UnsignedInteger32(byte signedByteValue)
  {
    setValue(signedByteValue & 0xFF);
  }

  public void encodeBER(OutputStream outputStream) throws IOException {
    BER.encodeUnsignedInteger(outputStream, 66, this.value);
  }

  public void decodeBER(BERInputStream inputStream) throws IOException {
    BER.MutableByte type = new BER.MutableByte();
    long newValue = BER.decodeUnsignedInteger(inputStream, type);
    if (type.getValue() != 66) {
      throw new IOException("Wrong type encountered when decoding Gauge: " + type.getValue());
    }

    setValue(newValue);
  }

  public int getSyntax() {
    return 66;
  }

  public int hashCode() {
    return (int)this.value;
  }

  public int getBERLength() {
    if (this.value < 128L) {
      return 3;
    }
    if (this.value < 32768L) {
      return 4;
    }
    if (this.value < 8388608L) {
      return 5;
    }
    if (this.value < 2147483648L) {
      return 6;
    }
    return 7;
  }

  public boolean equals(Object o) {
    if ((o instanceof UnsignedInteger32)) {
      return ((UnsignedInteger32)o).value == this.value;
    }
    return false;
  }

  public int compareTo(Object o) {
    long diff = this.value - ((UnsignedInteger32)o).getValue();
    if (diff < 0L) {
      return -1;
    }
    if (diff > 0L) {
      return 1;
    }
    return 0;
  }

  public String toString() {
    return Long.toString(this.value);
  }

  public final void setValue(String value) {
    setValue(Long.parseLong(value));
  }

  public void setValue(long value) {
    if ((value < 0L) || (value > 4294967295L)) {
      throw new IllegalArgumentException("Argument must be an unsigned 32bit value");
    }

    this.value = value;
  }

  public long getValue() {
    return this.value;
  }

  public Object clone() {
    return new UnsignedInteger32(this.value);
  }

  public final int toInt() {
    return (int)getValue();
  }

  public final long toLong() {
    return getValue();
  }

  public OID toSubIndex(boolean impliedLength) {
    return new OID(new int[] { toInt() });
  }

  public void fromSubIndex(OID subIndex, boolean impliedLength) {
    setValue(subIndex.getUnsigned(0));
  }
}