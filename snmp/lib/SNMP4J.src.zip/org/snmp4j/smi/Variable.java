package org.snmp4j.smi;

import org.snmp4j.asn1.BERSerializable;

public abstract interface Variable extends Cloneable, Comparable, BERSerializable
{
  public static final long serialVersionUID = 1395840752909725320L;

  public abstract boolean equals(Object paramObject);

  public abstract int compareTo(Object paramObject);

  public abstract int hashCode();

  public abstract Object clone();

  public abstract int getSyntax();

  public abstract boolean isException();

  public abstract String toString();

  public abstract int toInt();

  public abstract long toLong();

  public abstract String getSyntaxString();

  public abstract OID toSubIndex(boolean paramBoolean);

  public abstract void fromSubIndex(OID paramOID, boolean paramBoolean);

  public abstract boolean isDynamic();
}