package org.snmp4j.smi;

import java.net.InetAddress;

public class UdpAddress extends TransportIpAddress
{
  static final long serialVersionUID = -4390734262648716203L;

  public UdpAddress()
  {
  }

  public UdpAddress(InetAddress inetAddress, int port)
  {
    setInetAddress(inetAddress);
    setPort(port);
  }

  public UdpAddress(int port) {
    setPort(port);
  }

  public UdpAddress(String address) {
    if (!parseAddress(address))
      throw new IllegalArgumentException(address);
  }

  public static Address parse(String address)
  {
    try {
      UdpAddress a = new UdpAddress();
      if (a.parseAddress(address))
        return a;
    }
    catch (Exception ex)
    {
    }
    return null;
  }

  public boolean equals(Object o) {
    if ((o instanceof UdpAddress)) {
      return super.equals(o);
    }
    return false;
  }
}