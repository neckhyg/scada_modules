package org.snmp4j.smi;

public abstract interface AssignableFromByteArray
{
  public abstract void setValue(byte[] paramArrayOfByte);

  public abstract byte[] toByteArray();
}