package org.snmp4j.smi;

import java.io.IOException;
import java.io.OutputStream;
import java.math.BigInteger;
import org.snmp4j.asn1.BER;
import org.snmp4j.asn1.BER.MutableByte;
import org.snmp4j.asn1.BERInputStream;

public class Counter64 extends AbstractVariable
  implements AssignableFromLong, AssignableFromString
{
  private static final long serialVersionUID = 8741539680564150071L;
  private long value = 0L;

  public Counter64() {
  }

  public Counter64(long value) {
    setValue(value);
  }

  public void encodeBER(OutputStream outputStream) throws IOException {
    BER.encodeUnsignedInt64(outputStream, 70, this.value);
  }

  public void decodeBER(BERInputStream inputStream) throws IOException {
    BER.MutableByte type = new BER.MutableByte();
    long newValue = BER.decodeUnsignedInt64(inputStream, type);
    if (type.getValue() != 70) {
      throw new IOException("Wrong type encountered when decoding Counter64: " + type.getValue());
    }

    setValue(newValue);
  }

  public int getSyntax() {
    return 70;
  }

  public int hashCode() {
    return (int)this.value;
  }

  public int getBERLength() {
    if (this.value < 0L) {
      return 11;
    }
    if (this.value < 2147483648L) {
      if (this.value < 32768L) {
        return this.value < 128L ? 3 : 4;
      }
      return this.value < 8388608L ? 5 : 6;
    }
    if (this.value < 140737488355328L) {
      return this.value < 549755813888L ? 7 : 8;
    }
    return this.value < 36028797018963968L ? 9 : 10;
  }

  public boolean equals(Object o) {
    if ((o instanceof Counter64)) {
      return ((Counter64)o).value == this.value;
    }
    return false;
  }

  public int compareTo(Object o) {
    long other = ((Counter64)o).value;
    for (int i = 63; i >= 0; i--) {
      if ((this.value >> i & 1L) == (other >> i & 1L))
        continue;
      if ((this.value >> i & 1L) != 0L) {
        return 1;
      }

      return -1;
    }

    return 0;
  }

  public String toString() {
    if ((this.value > 0L) && (this.value < 9223372036854775807L)) {
      return Long.toString(this.value);
    }
    byte[] bytes = new byte[8];
    for (int i = 0; i < 8; i++) {
      bytes[i] = (byte)(int)(this.value >> (7 - i) * 8 & 0xFF);
    }
    BigInteger i64 = new BigInteger(1, bytes);
    return i64.toString();
  }

  public void setValue(String value) {
    this.value = Long.parseLong(value);
  }

  public void setValue(long value) {
    this.value = value;
  }

  public long getValue() {
    return this.value;
  }

  public Object clone() {
    return new Counter64(this.value);
  }

  public void increment()
  {
    this.value += 1L;
  }

  public final int toInt() {
    return (int)getValue();
  }

  public final long toLong() {
    return getValue();
  }

  public OID toSubIndex(boolean impliedLength) {
    throw new UnsupportedOperationException();
  }

  public void fromSubIndex(OID subIndex, boolean impliedLength) {
    throw new UnsupportedOperationException();
  }
}