package org.snmp4j;

import org.snmp4j.util.DefaultThreadFactory;
import org.snmp4j.util.DefaultTimerFactory;
import org.snmp4j.util.OIDTextFormat;
import org.snmp4j.util.SimpleOIDTextFormat;
import org.snmp4j.util.SimpleVariableTextFormat;
import org.snmp4j.util.ThreadFactory;
import org.snmp4j.util.TimerFactory;
import org.snmp4j.util.VariableTextFormat;

public final class SNMP4JSettings
{
  private static boolean extensibilityEnabled = false;

  private static volatile boolean forwardRuntimeExceptions = false;

  private static ThreadFactory threadFactory = new DefaultThreadFactory();

  private static TimerFactory timerFactory = new DefaultTimerFactory();

  private static OIDTextFormat oidTextFormat = new SimpleOIDTextFormat();

  private static VariableTextFormat variableTextFormat = new SimpleVariableTextFormat();

  private static long threadJoinTimeout = 60000L;

  public static void setExtensibilityEnabled(boolean enable)
  {
    extensibilityEnabled = enable;
  }

  public static final boolean isExtensibilityEnabled()
  {
    return extensibilityEnabled;
  }

  public static void setForwardRuntimeExceptions(boolean forwardExceptions)
  {
    forwardRuntimeExceptions = forwardExceptions;
  }

  public static final boolean isFowardRuntimeExceptions()
  {
    return forwardRuntimeExceptions;
  }

  public static final ThreadFactory getThreadFactory()
  {
    return threadFactory;
  }

  public static final void setThreadFactory(ThreadFactory newThreadFactory)
  {
    if (newThreadFactory == null) {
      throw new NullPointerException();
    }
    threadFactory = newThreadFactory;
  }

  public static final TimerFactory getTimerFactory()
  {
    return timerFactory;
  }

  public static final void setTimerFactory(TimerFactory newTimerFactory)
  {
    if (newTimerFactory == null) {
      throw new NullPointerException();
    }
    timerFactory = newTimerFactory;
  }

  public static final OIDTextFormat getOIDTextFormat()
  {
    return oidTextFormat;
  }

  public static final void setOIDTextFormat(OIDTextFormat newOidTextFormat)
  {
    if (newOidTextFormat == null) {
      throw new NullPointerException();
    }
    oidTextFormat = newOidTextFormat;
  }

  public static final VariableTextFormat getVariableTextFormat()
  {
    return variableTextFormat;
  }

  public static final void setVariableTextFormat(VariableTextFormat newVariableTextFormat)
  {
    if (newVariableTextFormat == null) {
      throw new NullPointerException();
    }
    variableTextFormat = newVariableTextFormat;
  }

  public static long getThreadJoinTimeout()
  {
    return threadJoinTimeout;
  }

  public static void setThreadJoinTimeout(long millis)
  {
    threadJoinTimeout = millis;
  }
}