package org.snmp4j;

import org.snmp4j.smi.Address;
import org.snmp4j.smi.OctetString;

public class CommunityTarget extends AbstractTarget
{
  static final long serialVersionUID = 147443821594052003L;
  private OctetString community = new OctetString();

  public CommunityTarget()
  {
    setVersion(0);
  }

  public CommunityTarget(Address address, OctetString community)
  {
    super(address);
    setVersion(0);
    setCommunity(community);
  }

  public OctetString getCommunity()
  {
    return this.community;
  }

  public void setCommunity(OctetString community)
  {
    if (community == null) {
      throw new IllegalArgumentException("Community must not be null");
    }
    this.community = community;
  }

  public String toString() {
    return "CommunityTarget[" + toStringAbstractTarget() + ", community=" + this.community + "]";
  }
}