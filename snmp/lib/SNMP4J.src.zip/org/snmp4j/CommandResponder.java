package org.snmp4j;

import java.util.EventListener;

public abstract interface CommandResponder extends EventListener
{
  public abstract void processPdu(CommandResponderEvent paramCommandResponderEvent);
}