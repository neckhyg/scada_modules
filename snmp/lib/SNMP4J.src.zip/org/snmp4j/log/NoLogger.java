package org.snmp4j.log;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class NoLogger
  implements LogAdapter
{
  static final NoLogger instance = new NoLogger();

  public void debug(Object message)
  {
  }

  public void error(Object message)
  {
  }

  public void error(Object message, Throwable t)
  {
  }

  public void info(Object message) {
  }

  public boolean isDebugEnabled() {
    return false;
  }

  public boolean isInfoEnabled() {
    return false;
  }

  public boolean isWarnEnabled() {
    return false;
  }

  public void warn(Object message) {
  }

  public void fatal(Object message) {
  }

  public void fatal(Object message, Throwable throwable) {
  }

  public void setLogLevel(LogLevel level) {
  }

  public String getName() {
    return "";
  }

  public LogLevel getLogLevel() {
    return LogLevel.OFF;
  }

  public LogLevel getEffectiveLogLevel() {
    return LogLevel.OFF;
  }

  public Iterator getLogHandler() {
    return Collections.EMPTY_LIST.iterator();
  }
}