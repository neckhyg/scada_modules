package org.snmp4j.log;

public class ConsoleLogFactory extends LogFactory
{
  protected LogAdapter createLogger(Class c)
  {
    return new ConsoleLogAdapter();
  }

  protected LogAdapter createLogger(String className) {
    return new ConsoleLogAdapter();
  }
}