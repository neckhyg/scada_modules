package org.snmp4j.log;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class JavaLogAdapter
  implements LogAdapter
{
  private final Logger logger;

  public JavaLogAdapter(Logger logger)
  {
    this.logger = logger;
  }

  public boolean isDebugEnabled()
  {
    return isLoggable(LogLevel.DEBUG);
  }

  public boolean isInfoEnabled() {
    return isLoggable(LogLevel.INFO);
  }

  public boolean isWarnEnabled() {
    return isLoggable(LogLevel.WARN);
  }

  public void debug(Object message)
  {
    log(LogLevel.DEBUG, message.toString(), null);
  }

  public void info(Object message) {
    log(LogLevel.INFO, message.toString(), null);
  }

  public void warn(Object message) {
    log(LogLevel.WARN, message.toString(), null);
  }

  public void error(Object message) {
    log(LogLevel.ERROR, message.toString(), null);
  }

  public void error(Object message, Throwable t) {
    log(LogLevel.ERROR, message.toString(), t);
  }

  public void fatal(Object message) {
    log(LogLevel.FATAL, message.toString(), null);
  }

  public void fatal(Object message, Throwable t) {
    log(LogLevel.FATAL, message.toString(), t);
  }

  public LogLevel getEffectiveLogLevel()
  {
    return fromJavaToSnmp4jLevel(this.logger.getLevel());
  }

  public Iterator getLogHandler() {
    return Arrays.asList(this.logger.getHandlers()).iterator();
  }

  public LogLevel getLogLevel() {
    return getEffectiveLogLevel();
  }

  public String getName() {
    return this.logger.getName();
  }

  public void setLogLevel(LogLevel logLevel) {
    this.logger.setLevel(fromSnmp4jToJdk(logLevel));
  }

  private boolean isLoggable(LogLevel logLevel)
  {
    return this.logger.isLoggable(fromSnmp4jToJdk(logLevel));
  }

  private void log(LogLevel logLevel, String msg, Throwable t) {
    this.logger.log(fromSnmp4jToJdk(logLevel), msg, t);
  }

  private static Level fromSnmp4jToJdk(LogLevel logLevel)
  {
    if (logLevel == null) {
      return null;
    }
    switch (logLevel.getLevel()) {
    case 2:
      return Level.ALL;
    case 4:
      return Level.FINE;
    case 3:
      return Level.FINEST;
    case 5:
      return Level.INFO;
    case 6:
      return Level.WARNING;
    case 7:
      return Level.SEVERE;
    case 8:
      return Level.SEVERE;
    case 1:
      return Level.OFF;
    case 0:
      return Level.OFF;
    }
    throw new IllegalArgumentException("Mapping not defined from SNMP4J level " + logLevel + " to Java logging level");
  }

  private static LogLevel fromJavaToSnmp4jLevel(Level level)
  {
    if (level == null) {
      return LogLevel.NONE;
    }
    if (Level.ALL.equals(level)) {
      return LogLevel.ALL;
    }
    if (Level.SEVERE.equals(level)) {
      return LogLevel.FATAL;
    }
    if (Level.WARNING.equals(level)) {
      return LogLevel.WARN;
    }
    if (Level.INFO.equals(level)) {
      return LogLevel.INFO;
    }
    if (Level.CONFIG.equals(level)) {
      return LogLevel.DEBUG;
    }
    if (Level.FINE.equals(level)) {
      return LogLevel.DEBUG;
    }
    if (Level.FINER.equals(level)) {
      return LogLevel.TRACE;
    }
    if (Level.FINEST.equals(level)) {
      return LogLevel.TRACE;
    }
    if (Level.OFF.equals(level)) {
      return LogLevel.DEBUG;
    }

    throw new IllegalArgumentException("Mapping not defined from Java level " + level.getName() + " to SNMP4J logging level");
  }
}