package org.snmp4j.log;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import org.apache.log4j.Logger;
import org.apache.log4j.spi.LoggerRepository;

public class Log4jLogFactory extends LogFactory
{
  protected LogAdapter createLogger(Class c)
  {
    return new Log4jLogAdapter(Logger.getLogger(c));
  }

  protected LogAdapter createLogger(String className) {
    return new Log4jLogAdapter(Logger.getLogger(className));
  }

  public LogAdapter getRootLogger() {
    return new Log4jLogAdapter(Logger.getRootLogger());
  }

  public Iterator loggers() {
    ArrayList l = Collections.list(Logger.getRootLogger().getLoggerRepository().getCurrentLoggers());

    for (int i = 0; i < l.size(); i++) {
      l.set(i, new Log4jLogAdapter((Logger)l.get(i)));
    }
    Collections.sort(l);
    return l.iterator();
  }
}