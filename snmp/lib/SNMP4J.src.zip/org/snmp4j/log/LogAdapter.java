package org.snmp4j.log;

import java.util.Iterator;

public abstract interface LogAdapter
{
  public abstract boolean isDebugEnabled();

  public abstract boolean isInfoEnabled();

  public abstract boolean isWarnEnabled();

  public abstract void debug(Object paramObject);

  public abstract void info(Object paramObject);

  public abstract void warn(Object paramObject);

  public abstract void error(Object paramObject);

  public abstract void error(Object paramObject, Throwable paramThrowable);

  public abstract void fatal(Object paramObject);

  public abstract void fatal(Object paramObject, Throwable paramThrowable);

  public abstract void setLogLevel(LogLevel paramLogLevel);

  public abstract LogLevel getLogLevel();

  public abstract LogLevel getEffectiveLogLevel();

  public abstract String getName();

  public abstract Iterator getLogHandler();
}