package com.aginova.portlets;

import com.aginova.business.Topics;

public abstract class Portlet
{
  public static Portlet[] getListOfPortlets()
  {
    return Topics.getTopics().getListOfPortlets();
  }

  public String getPortletActualName()
  {
    String temp = getClass().getName();
    int pos = temp.lastIndexOf(".");
    return temp.substring(pos + 1);
  }

  public abstract String getPortletName();

  public abstract String getPortletJSP();

  public abstract String getPortletTitle();

  public abstract int getPortletWidth();

  public abstract String getHelpActual();

  public abstract String getHelpDisplay();
}