package com.aginova.portlets;

import com.aginova.app.oilgas.OilgasHelper;

public class MoteHelper extends OilgasHelper
{
}