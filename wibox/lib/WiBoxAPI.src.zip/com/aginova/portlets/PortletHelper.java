package com.aginova.portlets;

import com.aginova.storage.Camp;
import com.aginova.storage.UserGroup;
import java.util.List;

public abstract class PortletHelper
{
  public static final int CONTENT_MODE_MOTE_VIEW = 1;
  public static final int CONTENT_MODE_OVERVIEW = 2;

  public abstract Content getContent(String paramString, Camp paramCamp, List<UserGroup> paramList, int paramInt, boolean paramBoolean);

  public static class Content
  {
    public String later;
    public String names;
    public String scripts;
    public int imageWidth;
    public int imageHeight;
    public String detailsPage;
    public String asset;
    public int assetCounter;
  }
}