package com.aginova.portlets;

import com.aginova.util.DBConnectionProperties;

public class SensorsMapView extends Portlet
{
  String imageName;
  PortletHelper helper;

  public SensorsMapView(String imageName, PortletHelper helper)
  {
    this.imageName = imageName;
    this.helper = helper;
  }

  public String getPortletName()
  {
    return "Map";
  }

  public String getPortletJSP()
  {
    DBConnectionProperties.getDBConnectionProperties(); boolean mapsAvailable = DBConnectionProperties.isGoogleMapSet();
    if (mapsAvailable) {
      return "googleMapsView.jsp" + (this.imageName != null ? "?imageName=" + this.imageName : "");
    }
    return "sensorsMapView.jsp" + (this.imageName != null ? "?imageName=" + this.imageName : "");
  }

  public String getPortletTitle()
  {
    return "Overview";
  }

  public int getPortletWidth()
  {
    return 3;
  }

  public String getHelpActual()
  {
    return "sensorsMapView";
  }

  public String getHelpDisplay()
  {
    return "map";
  }

  public void setHelper(PortletHelper helper) {
    this.helper = helper;
  }

  public PortletHelper getHelper() {
    return this.helper;
  }
}