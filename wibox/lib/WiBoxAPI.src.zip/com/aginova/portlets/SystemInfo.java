package com.aginova.portlets;

public class SystemInfo extends Portlet
{
  public String getPortletName()
  {
    return "System Information portlet";
  }

  public String getPortletJSP()
  {
    return "system_info.jsp";
  }

  public String getPortletTitle()
  {
    return "System Information";
  }

  public int getPortletWidth()
  {
    return 1;
  }

  public String getHelpActual()
  {
    return "systemInformation";
  }

  public String getHelpDisplay()
  {
    return "System information";
  }
}