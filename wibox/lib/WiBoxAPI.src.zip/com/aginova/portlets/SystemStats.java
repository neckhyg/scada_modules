package com.aginova.portlets;

import com.aginova.util.Lang;

public class SystemStats extends Portlet
{
  public String getPortletName()
  {
    return "System Stats portlet";
  }

  public String getPortletJSP()
  {
    return "system_stats.jsp";
  }

  public String getPortletTitle()
  {
    return Lang.getLang().getLang("home_system_stats");
  }

  public int getPortletWidth()
  {
    return 1;
  }

  public String getHelpActual()
  {
    return "systemStats";
  }

  public String getHelpDisplay()
  {
    return "System statistics";
  }

  public String getPortletDescription()
  {
    return "Provides a quick overview of the system current status.";
  }
}