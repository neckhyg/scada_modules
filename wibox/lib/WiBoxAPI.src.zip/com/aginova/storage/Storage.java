package com.aginova.storage;

import com.aginova.data.CommonWrapper;
import com.aginova.exception.FieldException;
import com.aginova.exception.UserException;
import com.aginova.util.ExtMap;
import com.aginova.util.Hibernate;
import com.aginova.util.Tools;
import java.io.Serializable;
import java.util.List;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.Transaction;

public abstract class Storage extends CommonWrapper
{
  protected static final Logger logger = Logger.getLogger(Storage.class);

  protected void checkNotEmpty(String value, String type) throws FieldException {
    if ((value == null) || (value.trim().equals("")))
      throw new FieldException("Field cannot be empty", type);
  }

  protected void checkLength(String value, String type, int maxLength)
    throws FieldException
  {
    if ((value != null) && (value.length() > maxLength))
      throw new FieldException("Field cannot be larger than " + maxLength + " characters: " + type, type);
  }

  protected void checkSmaller(String p1, String p2, String field)
    throws FieldException
  {
    if ((Tools.isNotEmptyNullOrNullString(p1)) && (Tools.isNotEmptyNullOrNullString(p2))) {
      Float f1 = Float.valueOf(Float.parseFloat(p1));
      Float f2 = Float.valueOf(Float.parseFloat(p2));
      if (f2.floatValue() <= f1.floatValue()) throw new FieldException("Upper limit cannot be smaller or equal to lower limit (" + field + ")", field);
    }
  }

  protected void checkSmaller(Float p1, Float p2, String field)
    throws FieldException
  {
    if ((p1 != null) && (p2 != null) && 
      (p2.floatValue() <= p1.floatValue())) throw new FieldException("Upper limit cannot be smaller or equal to lower limit for " + field, field);
  }

  protected void checkLong(String value, String fieldName)
    throws FieldException
  {
    try
    {
      if ((value != null) && (!value.trim().equals(""))) Long.parseLong(value); 
    }
    catch (Exception e) {
      throw new FieldException("The value must be an integer: " + value, fieldName);
    }
  }

  protected void checkFloat(String value, String fieldName)
    throws FieldException
  {
    try
    {
      Float.parseFloat(value);
    } catch (Exception e) {
      throw new FieldException("The value must be a float: " + value, fieldName);
    }
  }

  protected void checkPositive(Integer field, String displayField)
    throws UserException
  {
    if ((field != null) && (field.intValue() < 0)) throw new UserException(displayField + " must be positive!"); 
  }

  public List getAllRows()
  {
    throw new RuntimeException("NOT IMPLEMENTED");
  }

  public Storage save() {
    Session sess = Hibernate.getSafeSession(false);
    Transaction tx = null;
    try {
      tx = sess.beginTransaction();
      Storage obj = (Storage)sess.merge(this);
      logger.debug("Received back " + obj);
      sess.flush();
      Hibernate.safeCommit(tx);
      localStorage1 = obj;
      return localStorage1;
    }
    catch (Exception ee)
    {
      Hibernate.safeRollback(tx);
      logger.error("Error while saving Storage...", ee);
      Tools.recurseException(ee);
      Storage localStorage1 = null;
      return localStorage1; } finally { Hibernate.safeClose(sess); } throw localObject;
  }

  /** @deprecated */
  public static Storage load(Class cl, Serializable id)
  {
    Session sess = Hibernate.getSafeSession();
    Transaction tx = null;
    try {
      tx = sess.beginTransaction();
      Storage obj = (Storage)sess.load(cl, id);
      Hibernate.safeCommit(tx);
      localStorage1 = obj;
      return localStorage1;
    }
    catch (Exception ee)
    {
      Hibernate.safeRollback(tx);
      logger.error("Error while saving Storage...", ee);
      Storage localStorage1 = null;
      return localStorage1; } finally { Hibernate.safeClose(sess); } throw localObject;
  }

  public void preDelete(Session sess)
    throws Exception
  {
  }

  public void postDelete()
    throws Exception
  {
  }

  public void preSave()
    throws Exception
  {
  }

  public void preMerge(Session sess)
    throws Exception
  {
  }

  public void postSave(Session sess)
    throws Exception
  {
  }

  public void postPostSave(Session sess, ExtMap map)
    throws Exception
  {
  }

  public String getStyleClass()
  {
    return null;
  }

  public String getAuditClassDisplay()
  {
    return "N/A (1)";
  }

  public abstract String getAuditDisplayInfo();

  public int getAuditObjectType()
  {
    return 0;
  }

  public void selfDelete(Session session)
  {
    session.delete(this);
  }
}