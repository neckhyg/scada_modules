package com.aginova.storage;

import com.aginova.business.Role;
import com.aginova.engine.DatabaseLoader;
import com.aginova.exception.FieldException;
import com.aginova.exception.UserException;
import com.aginova.util.ExtMap;
import com.aginova.util.Hibernate;
import com.aginova.util.Tools;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import org.apache.log4j.Logger;
import org.hibernate.ObjectNotFoundException;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class Property extends Storage
{
  private String property_id;
  private Map properties = new HashMap();

  public String getProperty_id()
  {
    return this.property_id;
  }

  public void setProperty_id(String property_id) {
    this.property_id = property_id;
  }

  public Map getProperties()
  {
    return this.properties;
  }

  public void setProperties(Map properties) {
    this.properties = properties;
  }

  public String setData(Session sess, ExtMap map) throws FieldException {
    String res = super.setData(sess, map);

    save();

    String toStore = map.getString("propertiesToStore");
    String types = map.getString("propertiesType");
    StringTokenizer st = new StringTokenizer(toStore, ",");
    StringTokenizer stTypes = new StringTokenizer(types, ",");
    while (st.hasMoreTokens()) {
      String key = st.nextToken();
      KeyValue keyValue = new KeyValue();
      keyValue.setProperty_key(key);

      String type = stTypes.nextToken();
      String value = map.getString(key);

      if (!type.equals("String"))
      {
        if (type.equals("float")) {
          try {
            Float.parseFloat(value);
          } catch (Exception e) {
            throw new FieldException("You must enter a float for " + toStore, type);
          }
        }
      }
      keyValue.setProperty_value(value);
      getProperties().put(key, keyValue);
      keyValue.setProperty_id(this);
      keyValue.save();
    }
    return res;
  }

  public String getStringWithoutException(String key) {
    KeyValue val = (KeyValue)this.properties.get(key);
    if (val == null)
      return null;
    return val.getProperty_value();
  }

  public List getList(String key) {
    KeyValue val = (KeyValue)this.properties.get(key);
    List res = new ArrayList();
    if (val != null)
      res.add(val.getProperty_value());
    return res;
  }

  public static boolean getBooleanPropertyByCategoryAndName(String cat, String keyName, boolean defaultValue)
  {
    String temp = getPropertyByCategoryAndName(cat, keyName, "" + defaultValue);

    return (temp != null) && (temp.equals("true"));
  }

  public static void createPropertyIfNotExisting(String category, String keyName, String defaultValue)
  {
    if (getPropertyByCategoryAndName(category, keyName, null) == null)
      setPropertyByCategoryAndName(category, keyName, defaultValue);
  }

  public static void setPropertyByCategoryAndName(String cat, String keyName, String value)
  {
    Session sess = Hibernate.getSafeSession(false);
    Transaction tx = null;
    try {
      tx = sess.beginTransaction();
      Property pt = new Property();
      pt.setProperty_id(cat);
      ExtMap map = new ExtMap();
      map.put(keyName, value);

      map.put("propertiesToStore", keyName);
      map.put("propertiesType", "String");
      map.put("fieldsToStore", "");
      map.put("fieldTypes", "");
      map.put("fieldDisplays", "");
      map.put("fieldImportance", "");

      pt.setData(sess, map);
      sess.merge(pt);
      Hibernate.safeCommit(tx);
    } catch (Exception ee) {
      logger.error("", ee);
      Hibernate.safeRollback(tx);
    } finally {
      Hibernate.safeClose(sess);
    }
  }

  public static String getPropertyByCategoryAndName(String cat, String keyName, String defaultValue)
  {
    Session sess = Hibernate.getSafeSession(false);
    Transaction tx = null;
    try {
      tx = sess.beginTransaction();
      Property prop = (Property)sess.load(Property.class, cat);
      String str1;
      if (prop == null) {
        Hibernate.safeCommit(tx);
        str1 = defaultValue; jsr 123;
      }
      val = prop.getStringWithoutException(keyName);
      Hibernate.safeCommit(tx);
      if (val == null) {
        str2 = defaultValue; jsr 96;
      }str2 = val;
    }
    catch (ObjectNotFoundException onfe)
    {
      String str2;
      Hibernate.safeRollback(tx);

      return defaultValue;
    }
    catch (Exception e)
    {
      String val;
      Hibernate.safeRollback(tx);
      logger.error("", e);
      logger.error("Using default value of " + defaultValue + " instead !");
      return defaultValue;
    } finally {
      Hibernate.safeClose(sess);
    }
  }

  public static void main(String[] args) throws Exception {
    DatabaseLoader.setupTest();
    setPropertyByCategoryAndName("TEST", "T1", "T2");
  }

  public void postSave(Session sess)
    throws Exception
  {
    Role.invalidateSecurityCache();
  }

  public void preMerge(Session sess)
    throws Exception
  {
    logger.debug("TMP - properties " + this.properties);
    String k = getStringWithoutException("pro2");
    if ((Tools.isNotEmptyNullOrNullString(k)) && 
      (Role.getA(k) == 0))
      throw new UserException("Invalid Sentinel Pro II license!");
  }

  public String getAuditDisplayInfo()
  {
    return "/Modified System property: " + (this.property_id != null ? this.property_id.toLowerCase() : "N/A");
  }
}