package com.aginova.business;

import com.aginova.app.oilgas.Topics;
import com.aginova.crossbow.Message;
import com.aginova.exception.DriverException;
import com.aginova.exception.NotImplementedException;
import org.apache.log4j.Logger;

public class ProductDefinitions
{
  private static final Logger logger = Logger.getLogger(ProductDefinitions.class);

  static class OxySensor extends ProductInformation.DefaultComponent
    implements Component
  {
    public int getSensorType()
    {
      return 6;
    }

    public String getSensorCodeDisplay()
    {
      return "oxySensor";
    }

    public void fromRaw(Message data, Object[][] calibrationData)
    {
      Float rawData = data.getFloatValue("rawOxySensor");
      if (Float.isNaN(rawData.floatValue()))
        rawData = null;
      ProductDefinitions.logger.debug("rawData from OxySensor: " + rawData);
      data.setValue("oxySensor", rawData);
    }

    public float fromBytes(int[] bytes)
    {
      throw new NotImplementedException();
    }

    public String getXMLName()
    {
      return "oxy";
    }

    public String getDisplayName()
    {
      return "Oxygen";
    }
  }

  static class DigitalInputSensor extends ProductInformation.DefaultComponent
    implements Component
  {
    public int getSensorType()
    {
      return 7;
    }

    public String getSensorCodeDisplay()
    {
      return Topics.SENSOR_TYPE_DIGITAL_IO;
    }

    public void fromRaw(Message data, Object[][] calibrationData)
    {
      Integer rawData = data.getIntValue("rawDigitalInSensor");
      ProductDefinitions.logger.debug("rawData from digital input: " + rawData);
      data.setValue(ProductInformation.DIGITAL_IN_SENSOR_TEXT, rawData);
    }

    public float fromBytes(int[] bytes)
    {
      throw new NotImplementedException();
    }

    public String getXMLName()
    {
      return "digital";
    }

    public String getDisplayName()
    {
      return "Digital input";
    }
  }

  static class TMAS16Channels extends ProductInformation.DefaultComponent
    implements Component
  {
    int channel;

    TMAS16Channels(int channel)
    {
      this.channel = channel;
    }

    public int getSensorType()
    {
      return 3;
    }

    public String getSensorCodeDisplay()
    {
      return "tmas";
    }

    public void fromRaw(Message data, Object[][] calibrationData)
    {
      Integer[] rawData = (Integer[])(Integer[])data.getObjectValue("rawTMAS");
      ProductDefinitions.logger.debug("Using rawData " + rawData);
      data.setValue("tmas", rawData);
    }

    public float fromBytes(int[] bytes)
    {
      throw new NotImplementedException();
    }

    public String getXMLName()
    {
      return "tmas";
    }

    public String getDisplayName()
    {
      return "TMAS " + this.channel;
    }
  }

  static class RTDSensor extends ProductInformation.VariableSensor
    implements Component
  {
    int channel;
    int numberWires;

    RTDSensor(int channel, String xmlName, String rawName, int numberWires)
    {
      super(rawName);
      this.channel = channel;
      this.numberWires = numberWires;
    }

    public int getSensorType()
    {
      return 1;
    }

    public void fromRaw(Message data, Object[][] calibrationData)
    {
      Integer rawADC1 = data.getIntValue(this.rawName + "1");
      Integer rawADC2 = data.getIntValue(this.rawName + "2");
      Integer rawADC3 = data.getIntValue(this.rawName + "3");
      Integer rawADC4 = data.getIntValue(this.rawName + "4");

      Float resistance = ProductInformation.resistanceFromADC(this.numberWires, rawADC1, rawADC2, rawADC3, rawADC4);
      Float compResistance = ProductInformation.rtdOffsetCompensate(resistance);
      ProductDefinitions.logger.debug("Resistance " + resistance + ", compResistance (uncalibrated, with offset) " + compResistance);

      Float compResistance2 = ProductInformation.calibrateRTD(compResistance, calibrationData);
      Float celciusRTD = ProductInformation.rtdResistanceToTemperatureCelsius(compResistance2);
      ProductDefinitions.logger.debug("CompResistance (calibrated) " + compResistance2 + ", celciusRTD  " + celciusRTD);

      data.setValue(this.xmlName, ProductInformation.celciusToFarenheit(celciusRTD));
      data.setValue(this.xmlName + "Resistance", compResistance);
    }

    public String getDisplayName()
    {
      return "RTD Temperature " + this.channel;
    }

    public boolean isCalibrationAvailable()
    {
      return true;
    }
  }

  static class WetnessSensor extends ProductInformation.VariableSensor
    implements Component
  {
    int channel;

    WetnessSensor(int channel, String xmlName, String rawName)
    {
      super(rawName);
      this.channel = channel;
    }

    public int getSensorType()
    {
      return 2;
    }

    public void fromRaw(Message data, Object[][] calibrationData)
    {
      Integer rawADC = data.getIntValue(this.rawName);

      if (rawADC.intValue() <= 16) {
        ProductDefinitions.logger.debug("ADC value was too low, setting to zero");
        rawADC = Integer.valueOf(0);
      }

      ProductDefinitions.logger.debug("TMP- computing wetness for rawADC=" + rawADC + ", rawName=" + this.rawName);
      Float val = Float.valueOf(ProductInformation.wetnessComputeWLS(ProductInformation.adcOffsetCompensate(rawADC).floatValue()));

      data.setValue(this.xmlName, val);
      ProductDefinitions.logger.debug("TMP- Got value " + val);
    }

    public String getDisplayName()
    {
      return "Wetness " + this.channel;
    }
  }

  static class ICEWetnessSensor extends ProductDefinitions.WetnessSensor
    implements Component
  {
    ICEWetnessSensor(int channel, String xmlName, String rawName)
    {
      super(xmlName, rawName);
    }

    public void fromRaw(Message data, Object[][] calibrationData)
    {
      int rawADC = data.getIntValue(this.rawName).intValue();
      if (ProductDefinitions.logger.isDebugEnabled()) {
        ProductDefinitions.logger.debug("TMP- computing wetness for rawADC=" + rawADC + ", rawName=" + this.rawName);
      }
      Float val = ProductInformation.wetnessComputeICEWetness(new Float(rawADC));
      data.setValue(this.xmlName, val);
      if (ProductDefinitions.logger.isDebugEnabled())
        ProductDefinitions.logger.debug("TMP- Got value " + val);
    }
  }

  static class CorrosivitySensor extends ProductInformation.VariableSensor
    implements Component
  {
    int channel;

    CorrosivitySensor(int channel, String xmlName, String rawName)
    {
      super(rawName);
      this.channel = channel;
    }

    public int getSensorType()
    {
      return 8;
    }

    public void fromRaw(Message data, Object[][] calibrationData)
    {
      Integer rawADC = data.getIntValue(this.rawName);
      if (rawADC.intValue() <= 10) {
        ProductDefinitions.logger.debug("ADC value was too low, setting to null");
        rawADC = Integer.valueOf(10);
      }

      Float val = ProductInformation.wetnessComputeICECorrosivity(new Float(rawADC.intValue()));
      data.setValue(this.xmlName, val);
      ProductDefinitions.logger.debug("TMP- Got value " + val);
    }

    public String getDisplayName()
    {
      return "Corrosivity " + this.channel;
    }
  }

  static class CDS extends ProductInformation.VariableSensor
    implements Component
  {
    int channel;
    boolean real;

    CDS(int channel, String xmlName, String rawName, boolean real)
    {
      super(rawName);
      this.channel = channel;
      this.real = real;
    }

    public int getSensorType()
    {
      return 9;
    }

    public void fromRaw(Message data, Object[][] calibrationData)
    {
      int rawADC = data.getIntValue(this.rawName).intValue();

      Float val = new Float(rawADC);
      data.setValue(this.xmlName, val);
      ProductDefinitions.logger.debug("TMP- Got value " + val);
    }

    public String getDisplayName()
    {
      return "Coating Degr. " + this.channel;
    }
  }

  static class PoleStarRTD extends ProductDefinitions.RawIntegerSensor
  {
    PoleStarRTD()
    {
      super("rawPSRTD", "RTD", 1);
    }

    public void fromRaw(Message data, Object[][] calibrationData)
    {
      Float rawData = data.getFloatValue(this.rawName);
      ProductDefinitions.logger.debug("PoleStarRTD rawData : " + rawData);
      data.setValue(this.xmlName, ProductInformation.celciusToFarenheit(rawData));
    }
  }

  static class BPCUIWetSensor extends ProductDefinitions.RawIntegerSensor
  {
    BPCUIWetSensor()
    {
      super("wetRaw", "Wetness", 2);
    }

    public void fromRaw(Message data, Object[][] calibrationData) {
      int[] rawADC = (int[])(int[])data.getObjectValue(this.rawName);
      Float[] output = new Float[rawADC.length];
      for (int i = 0; i < output.length; i++) {
        output[i] = ProductInformation.computeBPCUI24Wetness(new Float(rawADC[i]), data.getFloatValue("voltage").floatValue());
      }

      data.setValue(this.xmlName, output);
    }
  }

  static class BPCUICorrSensor extends ProductDefinitions.RawIntegerSensor
  {
    BPCUICorrSensor()
    {
      super("corrRaw", "Corrosion", 8);
    }

    public void fromRaw(Message data, Object[][] calibrationData) {
      int[] rawADC = (int[])(int[])data.getObjectValue(this.rawName);
      Float[] output = new Float[rawADC.length];
      for (int i = 0; i < output.length; i++) {
        Float voltage = data.getFloatValue("voltage");
        output[i] = ProductInformation.computeBPCUI24Corrosivity(new Float(rawADC[i]), voltage.floatValue());
      }

      data.setValue(this.xmlName, output);
    }
  }

  static class HighImpedance extends ProductDefinitions.RawIntegerSensor
  {
    HighImpedance()
    {
      super("rawHighImpedance", "High Impedance", 12);
    }

    public void fromRaw(Message data, Object[][] calibrationData) {
      Integer rawADC = data.getIntValue(this.rawName);
      Float output = ProductInformation.computeHighImpedance(rawADC);
      data.setValue(this.xmlName, output);
    }
  }

  static class RawIntegerSensor extends ProductInformation.VariableSensor
  {
    String displayName;
    int sensorType;

    RawIntegerSensor(String xmlName, String rawName, String displayName, int sensorType)
    {
      super(rawName);
      this.displayName = displayName;
      this.sensorType = sensorType;
    }

    public int getSensorType() {
      return this.sensorType;
    }

    public void fromRaw(Message data, Object[][] calibrationData) {
      int rawADC = data.getIntValue(this.rawName).intValue();
      Integer val = new Integer(rawADC);
      data.setValue(this.xmlName, val);
    }

    public String getDisplayName() {
      return this.displayName;
    }
  }

  static class TMAS16ChannelsDirect extends ProductInformation.VariableSensor
  {
    TMAS16ChannelsDirect(String xmlName, String rawCode)
    {
      super(rawCode);
    }

    public int getSensorType()
    {
      return 13;
    }

    public String getDisplayName()
    {
      return "MAS corrosivity";
    }
  }

  static class PowerDirect extends ProductInformation.VariableSensor
  {
    float scalingFactor;
    int type;
    String displayName;

    PowerDirect(int type, String displayName, String xmlName, String rawCode, float scalingFactor)
    {
      super(rawCode);
      this.scalingFactor = scalingFactor;
      this.displayName = displayName;
      this.type = type;
    }

    public int getSensorType()
    {
      return this.type;
    }

    public String getDisplayName()
    {
      return this.displayName;
    }

    public void fromRaw(Message data, Object[][] calibrationData)
    {
      Double rawMeasurement = data.getDoubleValue(this.rawName);
      if (rawMeasurement != null) {
        rawMeasurement = Double.valueOf(rawMeasurement.doubleValue() / this.scalingFactor);
      }
      ProductDefinitions.logger.debug("raw for " + this.displayName + " : " + rawMeasurement + ", xmlName " + this.xmlName + " using scalingFactor " + this.scalingFactor);
      data.setValue(this.xmlName, rawMeasurement);
    }
  }

  static class QT06024CExternalThermistor extends ProductDefinitions.DefaultOnBoardThermistor
  {
    boolean newADC;

    QT06024CExternalThermistor(String rawCode, String displayCode)
    {
      super(displayCode);
    }

    QT06024CExternalThermistor(String rawCode, String displayCode, boolean newADC) {
      super(displayCode);
      this.newADC = newADC;
    }

    public void fromRaw(Message data, Object[][] calibrationData)
      throws DriverException
    {
      Integer rawADC = data.getIntValue(this.rawCode);
      if ((rawADC == null) || ((!this.newADC) && (rawADC.intValue() < 5)) || ((this.newADC) && (rawADC.intValue() < ProductInformation.LOW_ADC_LIMIT_NEW_ADC)))
      {
        ProductDefinitions.logger.debug("ADC value was too low (" + rawADC + "), setting to null");
        rawADC = null;
      }

      Float val = ProductInformation.celciusToFarenheit(ProductInformation.rawQT06024CADCtoCelcius(ProductInformation.adcOffsetCompensate(rawADC, this.newADC), this.newADC));

      ProductDefinitions.logger.debug("Storing val=" + val + " for " + this.displayCode + " for ADC " + rawADC);
      data.setValue(this.displayCode, val);
    }

    public String toString() {
      return "QT06024CExternalThermistor";
    }
  }

  static class BPInternalThermistor extends ProductDefinitions.DefaultOnBoardThermistor
  {
    BPInternalThermistor(String rawCode, String displayCode)
    {
      super(displayCode);
    }

    public void fromRaw(Message data, Object[][] calibrationData)
    {
      Integer rawADC = data.getIntValue(this.rawCode);
      if (rawADC == null) {
        ProductDefinitions.logger.debug("ADC value was too low (" + rawADC + "), setting to null");
        rawADC = null;
      }

      Float val = ProductInformation.convertBPThermistor(rawADC, data.getFloatValue("voltage"));
      ProductDefinitions.logger.debug("Storing val=" + val + " for " + this.displayCode + " for ADC " + rawADC);
      data.setValue(this.displayCode, val);
    }

    public String toString() {
      return "BPInternalThermistor";
    }
  }

  static class PS103J2ExternalThermistor extends ProductDefinitions.DefaultOnBoardThermistor
  {
    boolean newADC;

    PS103J2ExternalThermistor(String rawCode, String displayCode)
    {
      super(displayCode);
    }

    PS103J2ExternalThermistor(String rawCode, String displayCode, boolean newADC) {
      super(displayCode);
      this.newADC = newADC;
    }

    public void fromRaw(Message data, Object[][] calibrationData)
      throws DriverException
    {
      Integer rawADC = data.getIntValue(this.rawCode);
      ProductDefinitions.logger.debug("Using rawADC " + rawADC);
      if ((rawADC == null) || ((!this.newADC) && (rawADC.intValue() < 5)) || ((this.newADC) && (rawADC.intValue() < ProductInformation.LOW_ADC_LIMIT_NEW_ADC)))
      {
        ProductDefinitions.logger.debug("ADC value was too low (" + rawADC + "), setting to null");
        rawADC = null;
      }
      data.setValue(this.displayCode, ProductInformation.celciusToFarenheit(ProductInformation.rawPS103J2ThermistorADCtoCelcius(ProductInformation.adcOffsetCompensate(rawADC, this.newADC), this.newADC)));
    }
  }

  static class Probe12J1H0042ExternalThermistor extends ProductDefinitions.DefaultOnBoardThermistor
  {
    boolean newADC;

    Probe12J1H0042ExternalThermistor(String rawCode, String displayCode)
    {
      super(displayCode);
    }

    Probe12J1H0042ExternalThermistor(String rawCode, String displayCode, boolean newADC) {
      super(displayCode);
      this.newADC = newADC;
    }

    public void fromRaw(Message data, Object[][] calibrationData)
      throws DriverException
    {
      Integer rawADC = data.getIntValue(this.rawCode);
      if ((rawADC == null) || ((!this.newADC) && (rawADC.intValue() < 5)) || ((this.newADC) && (rawADC.intValue() < ProductInformation.LOW_ADC_LIMIT_NEW_ADC)))
      {
        ProductDefinitions.logger.debug("ADC value was too low (" + rawADC + "), setting to null");
        rawADC = null;
      }

      Float val = ProductInformation.celciusToFarenheit(ProductInformation.raw12J1H0042ADCtoCelcius(ProductInformation.adcOffsetCompensate(rawADC, this.newADC), this.newADC));

      ProductDefinitions.logger.debug("Storing val=" + val + " for " + this.displayCode + " for ADC " + rawADC);
      data.setValue(this.displayCode, val);
    }

    public String toString() {
      return "Probe12J1H0042ExternalThermistor";
    }
  }

  static class ConvertFarenheit extends ProductDefinitions.DefaultOnBoardThermistor
  {
    ConvertFarenheit(String rawCode, String displayCode)
    {
      super(displayCode);
    }

    public void fromRaw(Message data, Object[][] calibrationData) {
      Float celciusMeasurement = data.getFloatValue(this.rawCode);
      data.setValue(this.displayCode, ProductInformation.celciusToFarenheit(celciusMeasurement));
      data.setValue(this.displayCode + "Resistance", celciusMeasurement);
    }
  }

  static class ConvertFarenheitRTD extends ProductDefinitions.DefaultOnBoardThermistor
  {
    ConvertFarenheitRTD(String rawCode, String displayCode)
    {
      super(displayCode);
    }

    public void fromRaw(Message data, Object[][] calibrationData) {
      Float celciusMeasurement = data.getFloatValue(this.rawCode);
      data.setValue(this.displayCode, ProductInformation.celciusToFarenheit(celciusMeasurement));
      ProductDefinitions.logger.debug("DEBUG - displayCode for " + this.displayCode + "Resistance appended.");
    }
  }

  static class SHT11Humidity extends ProductInformation.DefaultComponent
    implements Component
  {
    public int getSensorType()
    {
      return 4;
    }

    public String getSensorCodeDisplay()
    {
      return "hum";
    }

    public void fromRaw(Message data, Object[][] calibrationData)
    {
      Integer rawHum = data.getIntValue("rawHum");
      Integer rawTemp = data.getIntValue("rawTempInt");

      if ((rawHum == null) || (rawHum.intValue() >= 65535)) {
        ProductDefinitions.logger.debug("ADC value was too low (" + rawHum + "), setting to null");
        rawHum = null;
      }

      Float[] rh = ProductInformation.computeSHT11Humidity(rawHum, rawTemp);

      data.setValue("hum", rh[0]);
      data.setValue("hum_tcomp", rh[1]);
    }

    public float fromBytes(int[] bytes)
    {
      throw new NotImplementedException();
    }

    public String getXMLName()
    {
      return "hum";
    }

    public String getDisplayName()
    {
      return "On board SHT11 humidity";
    }
  }

  static class SHT11Temperature extends ProductInformation.DefaultComponent
    implements Component
  {
    public int getSensorType()
    {
      return 1;
    }

    public String getSensorCodeDisplay()
    {
      return "tempInt";
    }

    public void fromRaw(Message data, Object[][] calibrationData)
    {
      Integer rawADC = data.getIntValue("rawTempInt");
      if ((rawADC == null) || (rawADC.intValue() >= 65535)) {
        ProductDefinitions.logger.debug("ADC value was too low (" + rawADC + "), setting to null");
        rawADC = null;
      }

      data.setValue("tempInt", ProductInformation.computeSHT11Temperature(rawADC));
    }

    public float fromBytes(int[] bytes)
    {
      throw new NotImplementedException();
    }

    public String getXMLName()
    {
      return "temp";
    }

    public String getDisplayName()
    {
      return "On board SHT11 temperature";
    }
  }

  static class DefaultOnBoardThermistor extends ProductInformation.DefaultComponent
    implements Component
  {
    String rawCode;
    String displayCode;

    DefaultOnBoardThermistor(String rawCode, String displayCode)
    {
      this.rawCode = rawCode;
      this.displayCode = displayCode;
    }

    public int getSensorType()
    {
      return 1;
    }

    public String getSensorCodeDisplay()
    {
      return this.displayCode;
    }

    public void fromRaw(Message data, Object[][] calibrationData)
      throws DriverException
    {
      Integer rawADC = data.getIntValue(this.rawCode);
      if ((rawADC == null) || (rawADC.intValue() < 5)) {
        ProductDefinitions.logger.debug("ADC value was too low, setting to null");
        rawADC = null;
      }
      data.setValue(this.displayCode, ProductInformation.celciusToFarenheit(ProductInformation.rawThermistorADCtoCelcius(ProductInformation.adcOffsetCompensate(rawADC))));
    }

    public float fromBytes(int[] bytes)
    {
      throw new NotImplementedException();
    }

    public String getXMLName()
    {
      return "temp";
    }

    public String getDisplayName()
    {
      return "Default temperature";
    }
  }

  static class CO2Direct extends ProductInformation.VariableSensor
  {
    CO2Direct(String xmlName, String rawCode)
    {
      super(rawCode);
    }

    public int getSensorType()
    {
      return 16;
    }

    public String getDisplayName()
    {
      return "CO2";
    }
  }

  static class PHDirect extends ProductInformation.VariableSensor
  {
    PHDirect(String xmlName, String rawCode)
    {
      super(rawCode);
    }

    public int getSensorType()
    {
      return 15;
    }

    public String getDisplayName()
    {
      return "pH";
    }
  }

  static class HumidityDirect extends ProductInformation.VariableSensor
  {
    HumidityDirect(String xmlName, String rawCode)
    {
      super(rawCode);
    }

    public int getSensorType()
    {
      return 4;
    }

    public String getDisplayName()
    {
      return "Humidity";
    }
  }

  static class ResistanceDirect extends ProductInformation.VariableSensor
  {
    ResistanceDirect(String xmlName, String rawCode)
    {
      super(rawCode);
    }

    public int getSensorType()
    {
      return 17;
    }

    public String getDisplayName()
    {
      return "Resistance";
    }
  }

  static class VoltageDirect extends ProductInformation.VariableSensor
  {
    VoltageDirect(String xmlName, String rawCode)
    {
      super(rawCode);
    }

    public int getSensorType()
    {
      return 12;
    }

    public String getDisplayName()
    {
      return "Voltage";
    }
  }

  static class DirectLightSensor extends ProductInformation.VariableSensor
  {
    DirectLightSensor()
    {
      super("rawLight");
    }

    public int getSensorType()
    {
      return 5;
    }

    public String getDisplayName()
    {
      return "Light";
    }
  }

  static class OnBoardLightSensor extends ProductInformation.DefaultComponent
    implements Component
  {
    public int getSensorType()
    {
      return 5;
    }

    public String getSensorCodeDisplay()
    {
      return "light";
    }

    public void fromRaw(Message data, Object[][] calibrationData)
    {
      Float rawADC = data.getFloatValue("rawLight");
      Float light = null;

      light = Float.valueOf(1.324F * rawADC.floatValue());

      data.setValue("light", light);
    }

    public float fromBytes(int[] bytes)
    {
      throw new NotImplementedException();
    }

    public String getXMLName()
    {
      return "light";
    }

    public String getDisplayName()
    {
      return "On board light";
    }
  }
}