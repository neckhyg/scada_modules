package com.aginova.business;

import com.aginova.crossbow.Message;
import com.aginova.engine.DatabaseLoader;
import com.aginova.exception.DriverException;
import com.aginova.exception.NotImplementedException;
import com.aginova.exception.ProductNotFoundException;
import com.aginova.storage.Property;
import com.aginova.util.ArrayTools;
import com.aginova.util.DBConnectionProperties;
import com.aginova.util.Displayable;
import com.aginova.util.DisplayableImpl;
import com.aginova.util.Tools;
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.log4j.Logger;

public class ProductInformation
{
  private static final Logger logger = Logger.getLogger(ProductInformation.class);

  static int LOW_ADC_LIMIT_NEW_ADC = -32700;
  private static final String LED_FLASH_MESSAGE = "- Check that LED blinks GREEN RED ORANGE during flashing (from 5.4.18)\n";
  private static final String RES_10K_MESSAGE = "- Use 56.2K calibrator on Port 1 and 1K calibrator on Port 2\n";
  private static final String LIGHT_MESSAGE = "- Point a strong light towards light sensor (>100lux)\n";
  private static final String DEBUG_BUTTON_MESSAGE = "- Press the pushbutton at the end and make sure that the LED blinks (pushbutton test)";
  private static final String RTD_CALIBRATION_MESSAGE = "- Fill the exact calibrator values below that will be used\n- Start with the 18.2 Ohm calibrator on RTD's Channel 1 and the 249 Ohm on Channel 2.\n- Do not put Digital IO plug\n- Follow instructions for the calibration process, final temp must be around 32°F";
  public static final int TYPE_TEMPERATURE = 1;
  public static final int TYPE_WETNESS = 2;
  public static final int TYPE_CURRENT = 3;
  public static final int TYPE_HUMIDITY = 4;
  public static final int TYPE_LIGHT = 5;
  public static final int TYPE_OXY = 6;
  public static final int TYPE_DIGITAL_IN = 7;
  public static final int TYPE_CORROSIVITY = 8;
  public static final int TYPE_CDS = 9;
  public static final int TYPE_ACOUSTIC = 10;
  public static final int TYPE_PARTICLES = 11;
  public static final int TYPE_VOLTAGE = 12;
  public static final int TYPE_MAS_CORROSIVITY = 13;
  public static final int TYPE_ACT_POWER = 14;
  public static final int TYPE_PH = 15;
  public static final int TYPE_CO2 = 16;
  public static final int TYPE_RESISTANCE = 17;
  public static final int TYPE_REACT_POWER = 18;
  public static final int TYPE_APPARENT_POWER = 19;
  public static final int TYPE_FREQ_POWER = 20;
  public static final int TYPE_CURRENT_POWER = 21;
  public static final int TYPE_VOLTAGE_POWER = 22;
  public static final int WIRES_3 = 3;
  public static final int WIRES_2 = 2;
  public static final int OID_MESSAGE_TYPE = 1;
  public static final int MOTE_ID = 2;
  public static final String MOTE_ID_TEXT = "mote_id";
  public static final int VOLTAGE = 3;
  public static final String VOLTAGE_TEXT = "voltage";
  public static final String VOLTAGE_RAW_TEXT = "voltageRaw";
  public static final int CLOCK = 4;
  public static final String CLOCK_TEXT = "time";
  public static final int COUNT = 5;
  public static final String COUNT_TEXT = "count";
  public static final int SIGNAL_STRENGTH = 6;
  public static final String SIGNAL_STRENGTH_TEXT = "rssi";
  public static final int HEARTBEAT_PERIOD = 7;
  public static final String HEARTBEAT_PERIOD_TEXT = "heartbeat";
  public static final int SAMPLING_PERIOD = 8;
  public static final String SAMPLING_PERIOD_TEXT = "sampling";
  public static final int UPTIME = 9;
  public static final String UPTIME_TEXT = "upTime";
  public static final int OID_RESETS = 10;
  public static final String OID_RESETS_TEXT = "resets";
  public static final int PRODUCT_NUMBER = 11;
  public static final String PRODUCT_NUMBER_TEXT = "product";
  public static final int TEMP = 12;
  public static final String TEMP_TEXT = "temp";
  public static final String TEMP_RAW_TEXT = "rawTemp";
  public static final String MAS_AVG_TEXT = "masCorrAvg";
  public static final String MAS_AVG_RAW_TEXT = "rawMasCorrAvg";
  public static final String MAS_MAX_TEXT = "masCorrMax";
  public static final String MAS_MAX_RAW_TEXT = "rawMasCorrMax";
  public static final String ACT_POWER1_RAW_TEXT = "actPower1Raw";
  public static final String ACT_POWER2_RAW_TEXT = "actPower2Raw";
  public static final String ACT_POWER3_RAW_TEXT = "actPower3Raw";
  public static final String ACT_POWER_TOT_RAW_TEXT = "actPowerTotRaw";
  public static final String ACT_POWER1_TEXT = com.aginova.app.oilgas.Topics.SENSOR_TYPE_ACT_POWER_CONSUMPTION_1;
  public static final String ACT_POWER2_TEXT = com.aginova.app.oilgas.Topics.SENSOR_TYPE_ACT_POWER_CONSUMPTION_2;
  public static final String ACT_POWER3_TEXT = com.aginova.app.oilgas.Topics.SENSOR_TYPE_ACT_POWER_CONSUMPTION_3;
  public static final String ACT_POWER_TOT_TEXT = com.aginova.app.oilgas.Topics.SENSOR_TYPE_ACT_POWER_CONSUMPTION_TOT;
  public static final String REACT_POWER1_RAW_TEXT = "reactPower1Raw";
  public static final String REACT_POWER2_RAW_TEXT = "reactPower2Raw";
  public static final String REACT_POWER3_RAW_TEXT = "reactPower3Raw";
  public static final String REACT_POWER_TOT_RAW_TEXT = "reactPowerTotRaw";
  public static final String REACT_POWER1_TEXT = com.aginova.app.oilgas.Topics.SENSOR_TYPE_REACT_POWER_CONSUMPTION_1;
  public static final String REACT_POWER2_TEXT = com.aginova.app.oilgas.Topics.SENSOR_TYPE_REACT_POWER_CONSUMPTION_2;
  public static final String REACT_POWER3_TEXT = com.aginova.app.oilgas.Topics.SENSOR_TYPE_REACT_POWER_CONSUMPTION_3;
  public static final String REACT_POWER_TOT_TEXT = com.aginova.app.oilgas.Topics.SENSOR_TYPE_REACT_POWER_CONSUMPTION_TOT;
  public static final String APPARENT_POWER1_RAW_TEXT = "appPower1Raw";
  public static final String APPARENT_POWER2_RAW_TEXT = "appPower2Raw";
  public static final String APPARENT_POWER3_RAW_TEXT = "appPower3Raw";
  public static final String APPARENT_POWER_TOT_RAW_TEXT = "appPowerTotRaw";
  public static final String APPARENT_POWER1_TEXT = com.aginova.app.oilgas.Topics.SENSOR_TYPE_APPARENT_POWER_CONSUMPTION_1;
  public static final String APPARENT_POWER2_TEXT = com.aginova.app.oilgas.Topics.SENSOR_TYPE_APPARENT_POWER_CONSUMPTION_2;
  public static final String APPARENT_POWER3_TEXT = com.aginova.app.oilgas.Topics.SENSOR_TYPE_APPARENT_POWER_CONSUMPTION_3;
  public static final String APPARENT_POWER_TOT_TEXT = com.aginova.app.oilgas.Topics.SENSOR_TYPE_APPARENT_POWER_CONSUMPTION_TOT;
  public static final String FREQ_POWER_RAW_TEXT = "freqPowerRaw";
  public static final String FREQ_POWER_TEXT = com.aginova.app.oilgas.Topics.FREQ_POWER_TEXT;
  public static final String MAX_CURRENT_POWER1_RAW_TEXT = "maxCurPwr1Raw";
  public static final String MAX_CURRENT_POWER2_RAW_TEXT = "maxCurPwr2Raw";
  public static final String MAX_CURRENT_POWER3_RAW_TEXT = "maxCurPwr3Raw";
  public static final String MAX_CURRENT_POWER1_TEXT = com.aginova.app.oilgas.Topics.MAX_CURRENT_POWER1_TEXT;
  public static final String MAX_CURRENT_POWER2_TEXT = com.aginova.app.oilgas.Topics.MAX_CURRENT_POWER2_TEXT;
  public static final String MAX_CURRENT_POWER3_TEXT = com.aginova.app.oilgas.Topics.MAX_CURRENT_POWER3_TEXT;
  public static final String MIN_VOLTAGE_POWER1_RAW_TEXT = "minVoltPwr1Raw";
  public static final String MIN_VOLTAGE_POWER2_RAW_TEXT = "minVoltPwr2Raw";
  public static final String MIN_VOLTAGE_POWER3_RAW_TEXT = "minVoltPwr3Raw";
  public static final String MIN_VOLTAGE_POWER1_TEXT = com.aginova.app.oilgas.Topics.MIN_VOLTAGE_POWER1_TEXT;
  public static final String MIN_VOLTAGE_POWER2_TEXT = com.aginova.app.oilgas.Topics.MIN_VOLTAGE_POWER2_TEXT;
  public static final String MIN_VOLTAGE_POWER3_TEXT = com.aginova.app.oilgas.Topics.MIN_VOLTAGE_POWER3_TEXT;

  public static final String VOLTAGE1_TEXT = com.aginova.app.oilgas.Topics.SENSOR_TYPE_VOLTAGE_1;
  public static final String VOLTAGE2_TEXT = com.aginova.app.oilgas.Topics.SENSOR_TYPE_VOLTAGE_2;
  public static final String VOLTAGE1_RAW_TEXT = "voltage1Raw";
  public static final String VOLTAGE2_RAW_TEXT = "voltage2Raw";
  public static final String PH1_TEXT = com.aginova.app.oilgas.Topics.SENSOR_TYPE_PH_1;
  public static final String PH2_TEXT = com.aginova.app.oilgas.Topics.SENSOR_TYPE_PH_2;
  public static final String PH1_RAW_TEXT = "ph1Raw";
  public static final String PH2_RAW_TEXT = "ph2Raw";
  public static final String CO2A_TEXT = com.aginova.app.oilgas.Topics.SENSOR_TYPE_CO2_A;
  public static final String CO2B_TEXT = com.aginova.app.oilgas.Topics.SENSOR_TYPE_CO2_B;
  public static final String CO2A_RAW_TEXT = "co2ARaw";
  public static final String CO2B_RAW_TEXT = "co2BRaw";
  public static final String RESISTANCE1_TEXT = com.aginova.app.oilgas.Topics.SENSOR_TYPE_RESISTANCE_1;
  public static final String RESISTANCE2_TEXT = com.aginova.app.oilgas.Topics.SENSOR_TYPE_RESISTANCE_2;
  public static final String RESISTANCE1_RAW_TEXT = "resistance1Raw";
  public static final String RESISTANCE2_RAW_TEXT = "resistance2Raw";
  public static final String CO2_TEXT = com.aginova.app.oilgas.Topics.SENSOR_TYPE_CO2;
  public static final String CO2_RAW_TEXT = CO2_TEXT + "Raw";

  public static final String BATT_VOLT_TEXT = com.aginova.app.oilgas.Topics.BATT_VOLT_TEXT;
  public static final String BATT_VOLT_RAW_TEXT = BATT_VOLT_TEXT + "Raw";
  public static final int WARM_BOOTS = 13;
  public static final int LIGHT = 14;
  public static final String LIGHT_TEXT = "light";
  public static final String LIGHT_RAW_TEXT = "rawLight";
  public static final int MAC_ADDRESS = 15;
  public static final String MAC_ADDRESS_TEXT = "mac";
  public static final String SHT11_TEMP_TEXT = "tempInt";
  public static final String SHT11_TEMP_RAW_TEXT = "rawTempInt";
  public static final String SHT11_HUM_TEXT = "hum";
  public static final String SHT11_HUM_RAW_TEXT = "rawHum";
  public static final String WET_1_TEXT = "wetness1";
  public static final String WET_1_TEXT_RAW = "rawWetness1";
  public static final String WET_2_TEXT = "wetness2";
  public static final String WET_2_TEXT_RAW = "rawWetness2";
  public static final String WET_3_TEXT = "wetness3";
  public static final String WET_3_TEXT_RAW = "rawWetness3";
  public static final String WET_4_TEXT = "wetness4";
  public static final String WET_4_TEXT_RAW = "rawWetness4";
  public static final String CORR_1_TEXT = "corr1";
  public static final String CORR_1_TEXT_RAW = "rawCorr1";
  public static final String CORR_2_TEXT = "corr2";
  public static final String CORR_2_TEXT_RAW = "rawCorr2";
  public static final String CORR_3_TEXT = "corr3";
  public static final String CORR_3_TEXT_RAW = "rawCorr3";
  public static final String CORR_4_TEXT = "corr4";
  public static final String CORR_4_TEXT_RAW = "rawCorr4";
  public static final String CDS_1_REAL_TEXT = "CDSReal1";
  public static final String CDS_1_REAL_TEXT_RAW = "rawCDSReal1";
  public static final String CDS_2_REAL_TEXT = "CDSReal2";
  public static final String CDS_2_REAL_TEXT_RAW = "rawCDSReal2";
  public static final String CDS_1_IMAGINARY_TEXT = "CDSImaginary1";
  public static final String CDS_1_IMAGINARY_TEXT_RAW = "rawCDSImaginary1";
  public static final String CDS_2_IMAGINARY_TEXT = "CDSImaginary2";
  public static final String CDS_2_IMAGINARY_TEXT_RAW = "rawCDSImaginary2";
  public static int BROADCASTMODE = 23;
  public static final int LASTACK = 24;
  public static final String LASTACK_TEXT = "lastack";
  public static final int CONFIG_PERIOD = 25;
  public static final String CONFIG_PERIOD_TEXT = "config";
  public static final int TMAS = 26;
  public static final String TMAS_TEXT = "tmas";
  public static final String TMAS_RAW_TEXT = "rawTMAS";
  public static final int STOREFWDENABLED = 27;
  public static final String STOREFWDENABLED_TEXT = "storeFwdEnabled";
  public static final int CODEVERSION = 30;
  public static final String CODEVERSION_TEXT = "codeVersion";
  public static final int AP_MAC_ADDRESS = 31;
  public static final String AP_MAC_ADDRESS_TEXT = "APMAC";
  public static final int SENSOR_TEST_RESULT = 32;
  public static final String SENSOR_TEST_RESULT_TEXT = "sensortest";
  public static final String OXY_SENSOR_TEXT = "oxySensor";
  public static final String OXY_SENSOR_RAW_TEXT = "rawOxySensor";
  public static final String RTD1_SENSOR_TEXT = "temp";
  public static final String RTD1_SENSOR_RAW_TEXT = "rawRTD1Sensor";
  public static final String TEMP2_TEXT = "temp2";
  public static final String TEMP2_RAW_TEXT = "rawTemp2";
  public static final String RTD2_SENSOR_TEXT = "temp2";
  public static final String RTD2_SENSOR_RAW_TEXT = "rawRTD2Sensor";
  public static final String DIGITAL_IN_SENSOR_TEXT = com.aginova.app.oilgas.Topics.SENSOR_TYPE_DIGITAL_IO;
  public static final String DIGITAL_IN_SENSOR_RAW_TEXT = "rawDigitalInSensor";
  public static final String PARTICLES_SENSOR_TEXT = "particlesSensor";
  public static final String PARTICLES_SENSOR_RAW_TEXT = "rawParticlesSensor";
  public static final String ACOUSTIC_SENSOR_TEXT = "acousticSensor";
  public static final String ACOUSTIC_SENSOR_RAW_TEXT = "rawAcousticSensor";
  public static final String HIGH_IMPEDANCE_TEXT = "highImpedance";
  public static final String HIGH_IMPEDANCE_RAW_TEXT = "rawHighImpedance";
  public static final String POLESTAR_RTD_TEXT = "temp2";
  public static final String POLESTAR_RTD_RAW_TEXT = "rawPSRTD";
  public static final int GR1TIMESTAMP = 33;
  public static final String GR1TIMESTAMP_TEXT = "GR1Timestamp";
  public static final int GR2TIMESTAMP = 34;
  public static final String GR2TIMESTAMP_TEXT = "GR2Timestamp";
  public static final int GR3TIMESTAMP = 35;
  public static final String GR3TIMESTAMP_TEXT = "GR3Timestamp";
  public static final int GR4TIMESTAMP = 36;
  public static final String GR4TIMESTAMP_TEXT = "GR4Timestamp";
  public static final int GR1PORTALTIMESTAMP = 40;
  public static final int GR2PORTALTIMESTAMP = 41;
  public static final int GR3PORTALTIMESTAMP = 42;
  public static final int GR4PORTALTIMESTAMP = 43;
  public static final int LASTASSOCPERIOD = 46;
  public static final int COMMUNICATIONMODE = 51;
  public static final int APCHANNEL = 47;
  public static final int RETRYCOUNT = 48;
  public static final String RETRYCOUNT_TEXT = "retryCount";
  public static final int WLAN_WATCHDOG = 38;
  public static final String CORR_RAW_TEXT = "corrRaw";
  public static final String CORR_TEXT = "corr";
  public static final String WET_RAW_TEXT = "wetRaw";
  public static final String WET_TEXT = "wet";
  public static final int PARENT = 160;
  public static final int TIMESTAMP = 161;
  public static final int FLASH_INDEX = 162;
  public static final int DATA = 163;
  public static final int AGINOVA_TYPE = 164;
  public static final int SENTINEL_MICRO_CATEGORY = 1;
  public static final int SENTINEL_NOMAD_CATEGORY = 2;
  public static final int SENTINEL_PRO_CATEGORY = 3;
  public static final int SENTINEL_PRO2_CATEGORY = 4;
  public static final int SENTINEL_RTD_CATEGORY = 5;
  public static final int SENTINEL_POWER_CATEGORY = 6;
  public static final int SENTINEL_PH_CATEGORY = 7;
  public static final int SENTINEL_CO2_CATEGORY = 8;
  public static final int SENTINEL_ICE_CATEGORY = 9;
  public static final int SENTINEL_COR_CATEGORY = 10;
  public static final int SENTINEL_MAS_CATEGORY = 11;
  public static final int OTHER_CATEGORY = 12;
  public static final String SENTINEL_MICRO_GROUP = "XTEMP-1008";
  public static final String SENTINEL_MICRO_11B_GROUP = "XTEMP-1016";
  public static final String SENTINEL_MICRO_11M_GROUP = "XTEMP-1060";
  public static final String SENTINEL_NOMAD_11B_GROUP = "XTEMP-1018";
  public static final String SENTINEL_PRO_GROUP = "XTEMP-1006";
  public static final String SENTINEL_ALARM_GROUP = "XTEMP-1007";
  public static final String SENTINEL_PRO_SHT11_GROUP = "XTEMP-1012";
  public static final String SENTINEL_PRO_RTD_GROUP = "XTEMP-1100";
  public static final String SENTINEL_PRO_RTD_11B_GROUP = "XTEMP-1101";
  public static final String SENTINEL_PRO_RTD_11M_GROUP = "XTEMP-1150";
  public static final String SENTINEL_PRO_II_GROUP = "XTEMP-1013";
  public static final String SENTINEL_PRO_II_11B_GROUP = "XTEMP-1015";
  public static final String SENTINEL_PRO_II_11M_GROUP = "XTEMP-1050";
  public static final String SENTINEL_PRO_II_SHT11_GROUP = "XTEMP-1014";
  public static final String SENTINEL_PRO_II_SHT11_11B_GROUP = "XTEMP-1017";
  public static final String SENTINEL_PRO_II_SHT11_11M_GROUP = "XTEMP-1051";
  public static final String SENTINEL_PRO_II_SHT11_11M_WET_GROUP = "XTEMP-1090";
  public static final String SENTINEL_PRO_II_11M_WET_GROUP = "XTEMP-1091";
  public static final String XCORR_ICE_GROUP = "XCORR-1001";
  public static final String XCORR_PH_GROUP = "XCORR-1006";
  public static final String XPH_GROUP = "XPH-1002";
  public static final String XCORR_MAS_GROUP = "XCORR-1004";
  public static final String XCORR_MAS_V2_REVA_GROUP = "XCORR-1008";
  public static final String XCORR_MAS_V2_REVB_GROUP = "XCORR-1009";
  public static final String XCORR_WLS_GROUP = "XCORR-1000";
  public static final String XCORR_BP_GROUP = "XCORR-BP";
  public static final String XCORR_BP_500_GROUP = "XCORR-BP-500";
  public static final String XCORR_CUI_GROUP = "XCORR-BP-CUI-24";
  public static final String GAINSPAN_ALPS_GROUP = "XTEMP-1002";
  public static final String SENTINEL_POWER_20 = "XPOWER-1200";
  public static final String SENTINEL_POWER_100 = "XPOWER-1300";
  public static final String SENTINEL_POWER_200 = "XPOWER-1400";
  public static final String SENTINEL_POWER_500 = "XPOWER-1500";
  public static final String SENTINEL_POWER_1000 = "XPOWER-1600";
  public static final String SENTINEL_POWER_2000 = "XPOWER-1700";
  public static final String SENTINEL_POWER_5 = "XPOWER-1100";
  public static final String SENTINEL_POWER_50 = "XPOWER-1101";
  public static final String SENTINEL_CO2_V1 = "XCO2-1001";
  public static final String SENTINEL_CO2_V2 = "XCO2-1100";
  public static final String SENTINEL_CO2_V2_SST = "XCO2-1101";
  private static ProductInformation instance = null;

  private Map productNameMap = new HashMap();

  private Map<String, String> groupMap = new HashMap();

  private Map<String, Integer> productNameReverseMap = new HashMap();

  private Map<String, Integer> productNameCategoryMap = new HashMap();

  private Map<Integer, Product> productDescrMap = new HashMap();

  private List displayList = new ArrayList();
  private List<Displayable> productGroupDisplayableList;
  private List flashStationDisplayList = new ArrayList();

  private List displayListDisplay = new ArrayList();

  private List<String> productList = new ArrayList();

  public static String XCORR049 = "XCORR-049";
  public static String XCORR050 = "XCORR-050";
  public static String XCORR068 = "XCORR-068";

  public static String XCORR069 = "XCORR-069";
  public static String XCORR070 = "XCORR-070";

  public static String XCORR004 = "XCORR-004";
  public static String XCORRBP4 = "XCORR-BP-4";
  public static String XCORRBP = "XCORR-BP";
  public static String XCORRBP500 = "XCORR-BP-500";
  public static String XCORR061 = "XCORR-061";
  public static String XAERO = "XAERO";
  public static String XCORR_1002_0001 = "XCORR-1002-0001";

  public static String XCORR_BP = "XCORR-BP";
  public static int XCORR_BP_NUMBER = 6;

  public static String XCORR_BP_500 = "XCORR-BP-500";
  public static int XCORR_BP_500_NUMBER = 7;

  public static String XCORR_1000_0001 = "XCORR-1000-0001";
  public static int XCORR_1000_0001_NUMBER = 10;

  public static String XTEMP_1002_0001 = "XTEMP-1002-0001";
  public static int XTEMP_1002_0001_NUMBER = 12;

  public static String XCORR_1004_0001 = "XCORR-1004-0001";
  public static int XCORR_1004_0001_NUMBER = 15;

  public static String XCORR_1008_0001 = "XCORR-1008-0001";
  public static int XCORR_1008_0001_NUMBER = 121;

  public static String XCORR_1009_0001 = "XCORR-1009-0001";
  public static int XCORR_1009_0001_NUMBER = 122;

  public static String XCORR_1009_0002 = "XCORR-1009-0002";
  public static int XCORR_1009_0002_NUMBER = 162;

  public static String XCORR_1009_0003 = "XCORR-1009-0003";
  public static int XCORR_1009_0003_NUMBER = 159;

  public static String XCORR_1006_0001 = "XCORR-1006-0001";
  public static int XCORR_1006_0001_NUMBER = 75;

  public static String XPH_1002_0001 = "XPH-1002-0001";
  public static int XPH_1002_0001_NUMBER = 137;

  public static String XTEMP_1006_0001 = "XTEMP-1006-0001";
  public static int XTEMP_1006_0001_NUMBER = 17;

  public static String XTEMP_1006_0002 = "XTEMP-1006-0002";

  public static int XTEMP_1006_0002_NUMBER = 18;

  public static String XTEMP_1006_0003 = "XTEMP-1006-0003";

  public static int XTEMP_1006_0003_NUMBER = 27;

  public static String XTEMP_1006_0004 = "XTEMP-1006-0004";

  public static int XTEMP_1006_0004_NUMBER = 30;

  public static String XTEMP_1002_0002 = "XTEMP-1002-0002";

  public static String XTEMP_1007_0001 = "XTEMP-1007-0001";
  public static int XTEMP_1007_0001_NUMBER = 19;

  public static String XTEMP_1008_0001 = "XTEMP-1008-0001";

  public static int XTEMP_1008_0001_NUMBER = 20;

  public static String XTEMP_1016_0001 = "XTEMP-1016-0001";

  public static int XTEMP_1016_0001_NUMBER = 110;

  public static String XTEMP_1060_0001 = "XTEMP-1060-0001";

  public static int XTEMP_1060_0001_NUMBER = 167;

  public static String XTEMP_1060_0002 = "XTEMP-1060-0002";

  public static int XTEMP_1060_0002_NUMBER = 213;

  public static String XTEMP_1060_0003 = "XTEMP-1060-0003";

  public static int XTEMP_1060_0003_NUMBER = 217;

  public static String XTEMP_1018_0001 = "XTEMP-1018-0001";

  public static int XTEMP_1018_0001_NUMBER = 118;

  public static String XTEMP_1012_0001 = "XTEMP-1012-0001";

  public static int XTEMP_1012_0001_NUMBER = 43;

  public static String XTEMP_1012_0002 = "XTEMP-1012-0002";

  public static int XTEMP_1012_0002_NUMBER = 44;

  public static String XTEMP_1012_0003 = "XTEMP-1012-0003";

  public static int XTEMP_1012_0003_NUMBER = 45;

  public static String XTEMP_1012_0004 = "XTEMP-1012-0004";

  public static int XTEMP_1012_0004_NUMBER = 46;

  public static String XTEMP_1100_0001 = "XTEMP-1100-0001";

  public static int XTEMP_1100_0001_NUMBER = 60;

  public static String XTEMP_1100_0002 = "XTEMP-1100-0002";

  public static int XTEMP_1100_0002_NUMBER = 88;

  public static String XTEMP_1101_0001 = "XTEMP-1101-0001";

  public static int XTEMP_1101_0001_NUMBER = 111;

  public static String XTEMP_1101_0002 = "XTEMP-1101-0002";

  public static int XTEMP_1101_0002_NUMBER = 112;

  public static String XTEMP_1150_0001 = "XTEMP-1150-0001";

  public static int XTEMP_1150_0001_NUMBER = 168;

  public static String XTEMP_1150_0002 = "XTEMP-1150-0002";

  public static int XTEMP_1150_0002_NUMBER = 169;

  public static String XTEMP_1013_0001 = "XTEMP-1013-0001";
  public static int XTEMP_1013_0001_NUMBER = 61;

  public static String XCORR_BP_CUI_24 = "XCORR-BP-CUI-24";
  public static int XCORR_BP_CUI_24_NUMBER = 76;

  public static String XTEMP_1013_0002 = "XTEMP-1013-0002";
  public static int XTEMP_1013_0002_NUMBER = 77;

  public static String XTEMP_1013_0004 = "XTEMP-1013-0004";
  public static int XTEMP_1013_0004_NUMBER = 78;

  public static String XTEMP_1013_0005 = "XTEMP-1013-0005";
  public static int XTEMP_1013_0005_NUMBER = 101;

  public static String XTEMP_1014_0001 = "XTEMP-1014-0001";
  public static int XTEMP_1014_0001_NUMBER = 70;

  public static String XTEMP_1014_0002 = "XTEMP-1014-0002";
  public static int XTEMP_1014_0002_NUMBER = 79;

  public static String XTEMP_1014_0004 = "XTEMP-1014-0004";
  public static int XTEMP_1014_0004_NUMBER = 80;

  public static String XPOWER_1100_0001 = "XPOWER-1100-0001";
  public static int XPOWER_1100_0001_NUMBER = 175;

  public static String XPOWER_1101_0001 = "XPOWER-1101-0001";
  public static int XPOWER_1101_0001_NUMBER = 176;

  public static String XPOWER_1200_0001 = "XPOWER-1200-0001";
  public static int XPOWER_1200_0001_NUMBER = 81;

  public static String XPOWER_1200_0002 = "XPOWER-1200-0002";
  public static int XPOWER_1200_0002_NUMBER = 178;

  public static String XPOWER_1200_0003 = "XPOWER-1200-0003";
  public static int XPOWER_1200_0003_NUMBER = 179;

  public static String XPOWER_1200_0004 = "XPOWER-1200-0004";
  public static int XPOWER_1200_0004_NUMBER = 180;

  public static String XPOWER_1200_0005 = "XPOWER-1200-0005";
  public static int XPOWER_1200_0005_NUMBER = 181;

  public static String XPOWER_1300_0001 = "XPOWER-1300-0001";
  public static int XPOWER_1300_0001_NUMBER = 182;

  public static String XPOWER_1300_0002 = "XPOWER-1300-0002";
  public static int XPOWER_1300_0002_NUMBER = 183;

  public static String XPOWER_1300_0003 = "XPOWER-1300-0003";
  public static int XPOWER_1300_0003_NUMBER = 184;

  public static String XPOWER_1300_0004 = "XPOWER-1300-0004";
  public static int XPOWER_1300_0004_NUMBER = 185;

  public static String XPOWER_1300_0005 = "XPOWER-1300-0005";
  public static int XPOWER_1300_0005_NUMBER = 186;

  public static String XPOWER_1300_0006 = "XPOWER-1300-0006";
  public static int XPOWER_1300_0006_NUMBER = 177;

  public static String XPOWER_1400_0001 = "XPOWER-1400-0001";
  public static int XPOWER_1400_0001_NUMBER = 187;

  public static String XPOWER_1400_0002 = "XPOWER-1400-0002";
  public static int XPOWER_1400_0002_NUMBER = 188;

  public static String XPOWER_1400_0003 = "XPOWER-1400-0003";
  public static int XPOWER_1400_0003_NUMBER = 207;

  public static String XPOWER_1500_0001 = "XPOWER-1500-0001";
  public static int XPOWER_1500_0001_NUMBER = 189;

  public static String XPOWER_1500_0002 = "XPOWER-1500-0002";
  public static int XPOWER_1500_0002_NUMBER = 190;

  public static String XPOWER_1500_0003 = "XPOWER-1500-0003";
  public static int XPOWER_1500_0003_NUMBER = 208;

  public static String XPOWER_1600_0001 = "XPOWER-1600-0001";
  public static int XPOWER_1600_0001_NUMBER = 191;

  public static String XPOWER_1600_0002 = "XPOWER-1600-0002";
  public static int XPOWER_1600_0002_NUMBER = 192;

  public static String XPOWER_1600_0003 = "XPOWER-1600-0003";
  public static int XPOWER_1600_0003_NUMBER = 209;

  public static String XPOWER_1700_0001 = "XPOWER-1700-0001";
  public static int XPOWER_1700_0001_NUMBER = 193;

  public static String XPOWER_1700_0002 = "XPOWER-1700-0002";
  public static int XPOWER_1700_0002_NUMBER = 194;

  public static String XPOWER_1700_0003 = "XPOWER-1700-0003";
  public static int XPOWER_1700_0003_NUMBER = 210;

  public static String XCO2_1001_0001 = "XCO2-1001-0001";
  public static int XCO2_1001_0001_NUMBER = 201;

  public static String XCO2_1100_0001 = "XCO2-1100-0001";
  public static int XCO2_1100_0001_NUMBER = 205;

  public static String XCO2_1101_0001 = "XCO2-1101-0001";
  public static int XCO2_1101_0001_NUMBER = 215;

  public static String XTEMP_1014_0005 = "XTEMP-1014-0005";
  public static int XTEMP_1014_0005_NUMBER = 102;

  public static String XTEMP_1015_0001 = "XTEMP-1015-0001";
  public static int XTEMP_1015_0001_NUMBER = 106;

  public static String XTEMP_1015_0002 = "XTEMP-1015-0002";
  public static int XTEMP_1015_0002_NUMBER = 107;

  public static String XTEMP_1015_0004 = "XTEMP-1015-0004";
  public static int XTEMP_1015_0004_NUMBER = 108;

  public static String XTEMP_1015_0005 = "XTEMP-1015-0005";
  public static int XTEMP_1015_0005_NUMBER = 109;

  public static String XTEMP_1050_0001 = "XTEMP-1050-0001";
  public static int XTEMP_1050_0001_NUMBER = 151;

  public static String XTEMP_1050_0002 = "XTEMP-1050-0002";
  public static int XTEMP_1050_0002_NUMBER = 152;

  public static String XTEMP_1050_0004 = "XTEMP-1050-0004";
  public static int XTEMP_1050_0004_NUMBER = 153;

  public static String XTEMP_1050_0005 = "XTEMP-1050-0005";
  public static int XTEMP_1050_0005_NUMBER = 154;

  public static String XTEMP_1050_0006 = "XTEMP-1050-0006";
  public static int XTEMP_1050_0006_NUMBER = 220;

  public static String XTEMP_1051_0001 = "XTEMP-1051-0001";
  public static int XTEMP_1051_0001_NUMBER = 155;

  public static String XTEMP_1051_0002 = "XTEMP-1051-0002";
  public static int XTEMP_1051_0002_NUMBER = 156;

  public static String XTEMP_1051_0004 = "XTEMP-1051-0004";
  public static int XTEMP_1051_0004_NUMBER = 157;

  public static String XTEMP_1051_0005 = "XTEMP-1051-0005";
  public static int XTEMP_1051_0005_NUMBER = 158;

  public static String XTEMP_1051_0006 = "XTEMP-1051-0006";
  public static int XTEMP_1051_0006_NUMBER = 221;

  public static String XTEMP_1090_0001 = "XTEMP-1090-0001";
  public static int XTEMP_1090_0001_NUMBER = 204;

  public static String XTEMP_1091_0001 = "XTEMP-1091-0001";
  public static int XTEMP_1091_0001_NUMBER = 206;

  public static String XTEMP_1017_0001 = "XTEMP-1017-0001";
  public static int XTEMP_1017_0001_NUMBER = 113;

  public static String XTEMP_1017_0002 = "XTEMP-1017-0002";
  public static int XTEMP_1017_0002_NUMBER = 114;

  public static String XTEMP_1017_0004 = "XTEMP-1017-0004";
  public static int XTEMP_1017_0004_NUMBER = 115;

  public static String XTEMP_1017_0005 = "XTEMP-1017-0005";
  public static int XTEMP_1017_0005_NUMBER = 116;

  public static String XCORR_1001_0001 = "XCORR-1001-0001";
  public static int XCORR_1001_0001_NUMBER = 11;

  public static String XGS_1000 = "XGS-1000";
  public static int XGS_1000_NUMBER = 90;

  public static String XGS_1001 = "XGS-1001";
  public static int XGS_1001_NUMBER = 91;

  public static String XGS_1002 = "XGS-1002";
  public static int XGS_1002_NUMBER = 93;

  ComputeRequirements rtdRequirements = new RTDComputeRequirements();
  ComputeRequirements rtdGS1011Requirements = new RTDGS1011ComputeRequirements();
  ComputeRequirements pro2Requirements = new Pro2ComputeRequirements();

  public static synchronized ProductInformation getInstance()
  {
    if (instance == null) {
      try {
        logger.debug("Instance is null, creating new instance of ProductInformation");
        instance = new ProductInformation();
        logger.debug("Instance was null - will now populate...");
        instance.populate();
      } catch (Throwable thr) {
        logger.error("While getting the ProductInformation instance", thr);
      }
    }
    return instance;
  }

  private void populate()
  {
    Product product = null;

    logger.debug("Setting product groups");

    this.groupMap.put("XTEMP-1008", "Sentinel Micro");
    this.groupMap.put("XTEMP-1016", "Sentinel Micro (11Mbps)");
    this.groupMap.put("XTEMP-1060", "Sentinel Micro M (11Mbps)");
    this.groupMap.put("XTEMP-1018", "Sentinel Nomad (11Mbps)");
    this.groupMap.put("XTEMP-1006", "Sentinel Pro");
    this.groupMap.put("XTEMP-1007", "Sentinel Alarm");
    this.groupMap.put("XTEMP-1012", "Sentinel Pro SHT11");
    this.groupMap.put("XTEMP-1100", "Sentinel Pro RTD");
    this.groupMap.put("XTEMP-1101", "Sentinel Pro RTD (11Mbps)");
    this.groupMap.put("XTEMP-1150", "Sentinel Pro RTD M (11Mbps)");
    this.groupMap.put("XTEMP-1013", "Sentinel Pro II");
    this.groupMap.put("XTEMP-1015", "Sentinel Pro II (11Mbps)");
    this.groupMap.put("XTEMP-1050", "Sentinel Pro II M (11Mbps)");
    this.groupMap.put("XTEMP-1091", "Sentinel Pro II M Wetness (11Mbps)");

    this.groupMap.put("XTEMP-1014", "Sentinel Pro II SHT11");
    this.groupMap.put("XTEMP-1017", "Sentinel Pro II SHT11 (11Mbps)");
    this.groupMap.put("XTEMP-1051", "Sentinel Pro II M SHT11 (11Mbps)");
    this.groupMap.put("XTEMP-1090", "Sentinel Pro II M SHT11 Wetness (11Mbps)");

    this.groupMap.put("XCORR-1001", "ICE");
    this.groupMap.put("XCORR-1006", "PH");
    this.groupMap.put("XPH-1002", "Sentinel pH");

    this.groupMap.put("XCORR-1004", "MAS");
    this.groupMap.put("XCORR-1008", "MAS rev A");
    this.groupMap.put("XCORR-1009", "MAS rev B");

    this.groupMap.put("XCORR-1000", "WLS");
    this.groupMap.put("XCORR-BP", "BP board");
    this.groupMap.put("XCORR-BP-500", "BP-500 board");
    this.groupMap.put("XCORR-BP-CUI-24", "CUI-24");
    this.groupMap.put("XTEMP-1002", "ALPS");

    this.groupMap.put("XPOWER-1200", "Sentinel Power 20A");
    this.groupMap.put("XPOWER-1300", "Sentinel Power 100A");
    this.groupMap.put("XPOWER-1400", "Sentinel Power 200A");
    this.groupMap.put("XPOWER-1500", "Sentinel Power 500A");
    this.groupMap.put("XPOWER-1600", "Sentinel Power 1000A");
    this.groupMap.put("XPOWER-1700", "Sentinel Power 2000A");

    this.groupMap.put("XPOWER-1100", "Sentinel Power 5A");
    this.groupMap.put("XPOWER-1101", "Sentinel Power 50A");

    this.groupMap.put("XCO2-1001", "Sentinel CO2 (v1)");
    this.groupMap.put("XCO2-1100", "Sentinel CO2 (v2)");
    this.groupMap.put("XCO2-1101", "Sentinel CO2 (v2, SST)");

    logger.debug("Setting individual products");

    product = new DefaultProduct(1, "XTEMP-1008", "On board thermistor", new String[] { "temp" }, new Component[] { new ProductDefinitions.PS103J2ExternalThermistor("rawTemp", "temp") });

    product.setRequirements(new Requirement[] { new Requirement("temp", Float.valueOf(68.0F), Float.valueOf(86.0F)) });
    product.setInternalTemp("temp");
    product.setNotes("- Flashing must be done at a temperature between 20°C and 28°C (68-86°F) to test internal thermistor");
    registerNewProduct(XTEMP_1008_0001_NUMBER, XTEMP_1008_0001, product);
    logger.debug("Micro registered...");

    product = new DefaultProduct(1, "XTEMP-1016", "On board thermistor", new String[] { "temp" }, new Component[] { new ProductDefinitions.ConvertFarenheit("rawTemp", "temp") });

    product.setRequirements(new Requirement[] { new Requirement("temp", Float.valueOf(68.0F), Float.valueOf(86.0F)) });
    product.setInternalTemp("temp");
    product.setNotes("- Flashing must be done at a temperature between 20°C and 28°C to test internal thermistor");
    registerNewProduct(XTEMP_1016_0001_NUMBER, XTEMP_1016_0001, product);

    product = new DefaultProduct(1, "XTEMP-1060", "On board thermistor", new String[] { "temp" }, new Component[] { new ProductDefinitions.ConvertFarenheit("rawTemp", "temp") });

    product.setRequirements(new Requirement[] { new Requirement("temp", Float.valueOf(68.0F), Float.valueOf(86.0F)) });
    product.setInternalTemp("temp");
    product.setNotes("- Flashing must be done at a temperature between 20°C and 28°C to test internal thermistor");
    registerNewProduct(XTEMP_1060_0001_NUMBER, XTEMP_1060_0001, product);

    product = new DefaultProduct(1, "XTEMP-1060", "External 2.7K probe", new String[] { "temp" }, new Component[] { new ProductDefinitions.ConvertFarenheit("rawTemp", "temp") });

    product.setCalibrationAvailable(true);
    product.setOneCalibrationPoint(true);
    product.setCalibrationTransformer(new CalibrationTransformer()
    {
      public Float transformResistance(Float input) {
        return ProductInformation.celciusToFarenheit(ProductInformation.QT06024CADCtoCelcius(input));
      }
      public Float convertBeforeSending(Float input) {
        return ProductInformation.fahrenheitToCelcius(input);
      }
      public Float convertDeltaBeforeSending(Float input) {
        return ProductInformation.fahrenheitToCelciusDifference(input);
      }
    });
    product.setCalibrationPlugs(new float[] { 56200.0F, 1000.0F, 10000.0F, 10000.0F });
    product.setCalibrationCurves(new int[] { 250, 100, 0, 250, 100, 0 });

    product.setRequirements(new Requirement[] { new Requirement("temp", Float.valueOf(68.0F), Float.valueOf(86.0F)) });
    product.setInternalTemp("temp");
    product.setNotes("- Flashing must be done at a temperature between 20°C and 28°C to test external thermistor");
    registerNewProduct(XTEMP_1060_0002_NUMBER, XTEMP_1060_0002, product);

    product = new DefaultProduct(1, "XTEMP-1060", "External 10K probe", new String[] { "temp" }, new Component[] { new ProductDefinitions.ConvertFarenheit("rawTemp", "temp") });

    product.setCalibrationAvailable(false);
    product.setOneCalibrationPoint(true);
    product.setCalibrationTransformer(new CalibrationTransformer()
    {
      public Float transformResistance(Float input) {
        return ProductInformation.celciusToFarenheit(ProductInformation.QT06024CADCtoCelcius(input));
      }
      public Float convertBeforeSending(Float input) {
        return ProductInformation.fahrenheitToCelcius(input);
      }
      public Float convertDeltaBeforeSending(Float input) {
        return ProductInformation.fahrenheitToCelciusDifference(input);
      }
    });
    product.setCalibrationPlugs(new float[] { 56200.0F, 1000.0F, 10000.0F, 10000.0F });
    product.setCalibrationCurves(new int[] { 250, 100, 0, 250, 100, 0 });

    product.setRequirements(new Requirement[] { new Requirement("temp", Float.valueOf(68.0F), Float.valueOf(86.0F)) });
    product.setInternalTemp("temp");
    product.setNotes("- Flashing must be done at a temperature between 20°C and 28°C to test external thermistor");
    registerNewProduct(XTEMP_1060_0003_NUMBER, XTEMP_1060_0003, product);

    product = new DefaultProduct(2, "XTEMP-1018", "On board thermistor", new String[] { "temp" }, new Component[] { new ProductDefinitions.ConvertFarenheit("rawTemp", "temp") });

    product.setRequirements(new Requirement[] { new Requirement("temp", Float.valueOf(68.0F), Float.valueOf(86.0F)) });
    product.setInternalTemp("temp");
    product.setNotes("- Flashing must be done at a temperature between 20°C and 28°C to test internal thermistor");
    registerNewProduct(XTEMP_1018_0001_NUMBER, XTEMP_1018_0001, product);

    product = new DefaultProduct(3, "XTEMP-1006", "Onboard light sensor only", new String[] { "light" }, new Component[] { new ProductDefinitions.OnBoardLightSensor() });

    product.hideFlashingStation();
    registerNewProduct(XTEMP_1006_0001_NUMBER, XTEMP_1006_0001, product);

    product = new DefaultProduct(3, "XTEMP-1006", "Default ext. probe (0802 - Thermodisc 12J1H0042)", new String[] { "temp", "light" }, new Component[] { new ProductDefinitions.Probe12J1H0042ExternalThermistor("rawTemp", "temp"), new ProductDefinitions.OnBoardLightSensor() });

    product.hideFlashingStation();
    registerNewProduct(XTEMP_1006_0002_NUMBER, XTEMP_1006_0002, product);

    product = new DefaultProduct(3, "XTEMP-1006", "Low temperature -80°C probe", new String[] { "temp", "light" }, new Component[] { new ProductDefinitions.Probe12J1H0042ExternalThermistor("rawTemp", "temp"), new ProductDefinitions.OnBoardLightSensor() });

    product.hideFlashingStation();
    registerNewProduct(XTEMP_1006_0003_NUMBER, XTEMP_1006_0003, product);

    product = new DefaultProduct(3, "XTEMP-1006", "High precision 0.1°C accuracy 0°C-40°C PS103J2", new String[] { "temp", "light" }, new Component[] { new ProductDefinitions.PS103J2ExternalThermistor("rawTemp", "temp"), new ProductDefinitions.OnBoardLightSensor() });

    product.hideFlashingStation();
    registerNewProduct(XTEMP_1006_0004_NUMBER, XTEMP_1006_0004, product);

    product = new DefaultProduct(3, "XTEMP-1007", "Alarm Mote (with buzzer)", new String[0], null);

    product.hideFlashingStation();
    registerNewProduct(XTEMP_1007_0001_NUMBER, XTEMP_1007_0001, product);

    product = new DefaultProduct(3, "XTEMP-1012", "Onboard temp/humidity (SHT11), light", new String[] { "tempInt", "hum", "light" }, new Component[] { new ProductDefinitions.SHT11Temperature(), new ProductDefinitions.SHT11Humidity(), new ProductDefinitions.OnBoardLightSensor() });

    product.hideFlashingStation();
    product.setInternalTemp("tempInt");
    registerNewProduct(XTEMP_1012_0001_NUMBER, XTEMP_1012_0001, product);

    product = new DefaultProduct(3, "XTEMP-1012", " Default ext. probe (0802 - Thermodisc 12J1H0042)", new String[] { "temp", "tempInt", "hum", "light" }, new Component[] { new ProductDefinitions.Probe12J1H0042ExternalThermistor("rawTemp", "temp"), new ProductDefinitions.SHT11Temperature(), new ProductDefinitions.SHT11Humidity(), new ProductDefinitions.OnBoardLightSensor() });

    product.hideFlashingStation();
    product.setInternalTemp("tempInt");
    registerNewProduct(XTEMP_1012_0002_NUMBER, XTEMP_1012_0002, product);

    product = new DefaultProduct(3, "XTEMP-1012", "Low temperature -80°C probe", new String[] { "temp", "tempInt", "hum", "light" }, new Component[] { new ProductDefinitions.Probe12J1H0042ExternalThermistor("rawTemp", "temp"), new ProductDefinitions.SHT11Temperature(), new ProductDefinitions.SHT11Humidity(), new ProductDefinitions.OnBoardLightSensor() });

    product.hideFlashingStation();
    product.setInternalTemp("tempInt");
    registerNewProduct(XTEMP_1012_0003_NUMBER, XTEMP_1012_0003, product);

    product = new DefaultProduct(3, "XTEMP-1012", "High precision 0.1°C accuracy 0°C-40°C PS103J2", new String[] { "temp", "tempInt", "hum", "light" }, new Component[] { new ProductDefinitions.PS103J2ExternalThermistor("rawTemp", "temp"), new ProductDefinitions.SHT11Temperature(), new ProductDefinitions.SHT11Humidity(), new ProductDefinitions.OnBoardLightSensor() });

    product.hideFlashingStation();
    product.setInternalTemp("tempInt");
    registerNewProduct(XTEMP_1012_0004_NUMBER, XTEMP_1012_0004, product);

    product = new DefaultProduct(5, "XTEMP-1100", "DIN/IEC751 2-wires", new ColumnDefinition[] { new ColumnDefinition(com.aginova.app.oilgas.Topics.SENSOR_TYPE_TEMPERATURE, true), new ColumnDefinition(com.aginova.app.oilgas.Topics.SENSOR_TYPE_TEMPERATURE_2, true), new ColumnDefinition(com.aginova.app.oilgas.Topics.SENSOR_TYPE_DIGITAL_IO, false) }, new Component[] { new ProductDefinitions.RTDSensor(1, "temp", "rawRTD1Sensor", 2), new ProductDefinitions.RTDSensor(2, "temp2", "rawRTD2Sensor", 2), new ProductDefinitions.DigitalInputSensor() });

    product.setCalibrationAvailable(true);
    product.setNotes("- Fill the exact calibrator values below that will be used\n- Start with the 18.2 Ohm calibrator on RTD's Channel 1 and the 249 Ohm on Channel 2.\n- Do not put Digital IO plug\n- Follow instructions for the calibration process, final temp must be around 32°F\n- Check that LED blinks GREEN RED ORANGE during flashing (from 5.4.18)\n");
    product.setComputeRequirements(this.rtdRequirements);

    product.setCalibrationPlugs(new float[] { 18.200001F, 249.0F, 100.0F, 100.0F });
    product.setCalibrationCurves(new int[] { 0, 100, 0, 0, 1000, 10000 });

    product.setCalibrationTransformer(new CalibrationTransformer()
    {
      public Float transformResistance(Float input)
      {
        return input;
      }
      public Float transformMeasurement(Float input) {
        return ProductInformation.getRTDResistanceFromTempCelcius(ProductInformation.fahrenheitToCelcius(input));
      }
    });
    registerNewProduct(XTEMP_1100_0001_NUMBER, XTEMP_1100_0001, product);

    product = new DefaultProduct(5, "XTEMP-1100", "DIN/IEC751 3-wires", new ColumnDefinition[] { new ColumnDefinition(com.aginova.app.oilgas.Topics.SENSOR_TYPE_TEMPERATURE, true), new ColumnDefinition(com.aginova.app.oilgas.Topics.SENSOR_TYPE_TEMPERATURE_2, true), new ColumnDefinition(com.aginova.app.oilgas.Topics.SENSOR_TYPE_DIGITAL_IO, false) }, new Component[] { new ProductDefinitions.RTDSensor(1, "temp", "rawRTD1Sensor", 3), new ProductDefinitions.RTDSensor(2, "temp2", "rawRTD2Sensor", 3), new ProductDefinitions.DigitalInputSensor() });

    product.setCalibrationAvailable(true);
    product.hideFlashingStation();
    registerNewProduct(XTEMP_1100_0002_NUMBER, XTEMP_1100_0002, product);

    product = new DefaultProduct(5, "XTEMP-1101", "DIN/IEC751 2-wires", new ColumnDefinition[] { new ColumnDefinition(com.aginova.app.oilgas.Topics.SENSOR_TYPE_TEMPERATURE, true), new ColumnDefinition(com.aginova.app.oilgas.Topics.SENSOR_TYPE_TEMPERATURE_2, true), new ColumnDefinition(com.aginova.app.oilgas.Topics.SENSOR_TYPE_DIGITAL_IO, false) }, new Component[] { new ProductDefinitions.ConvertFarenheitRTD("rawRTD1Sensor", "temp"), new ProductDefinitions.ConvertFarenheitRTD("rawRTD2Sensor", "temp2"), new ProductDefinitions.DigitalInputSensor() });

    product.setCalibrationAvailable(true);
    product.setNotes("- Fill the exact calibrator values below that will be used\n- Start with the 18.2 Ohm calibrator on RTD's Channel 1 and the 249 Ohm on Channel 2.\n- Do not put Digital IO plug\n- Follow instructions for the calibration process, final temp must be around 32°F\n- Check that LED blinks GREEN RED ORANGE during flashing (from 5.4.18)\n");

    product.setComputeRequirements(this.rtdGS1011Requirements);

    product.setCalibrationPlugs(new float[] { 18.200001F, 249.0F, 100.0F, 100.0F });
    product.setCalibrationCurves(new int[] { 0, 100, 0, 0, 1000, 10000 });
    product.setPreciseCalibration();
    product.setCalibrationTransformer(new CalibrationTransformer()
    {
      public Float transformResistance(Float input)
      {
        return input;
      }
      public Float transformMeasurement(Float input) {
        return ProductInformation.getRTDResistanceFromTempCelcius(ProductInformation.fahrenheitToCelcius(input));
      }
    });
    registerNewProduct(XTEMP_1101_0001_NUMBER, XTEMP_1101_0001, product);

    product = new DefaultProduct(5, "XTEMP-1101", "DIN/IEC751 3-wires", new ColumnDefinition[] { new ColumnDefinition(com.aginova.app.oilgas.Topics.SENSOR_TYPE_TEMPERATURE, true), new ColumnDefinition(com.aginova.app.oilgas.Topics.SENSOR_TYPE_TEMPERATURE_2, true), new ColumnDefinition(com.aginova.app.oilgas.Topics.SENSOR_TYPE_DIGITAL_IO, false) }, new Component[] { new ProductDefinitions.ConvertFarenheitRTD("rawRTD1Sensor", "temp"), new ProductDefinitions.ConvertFarenheitRTD("rawRTD2Sensor", "temp2"), new ProductDefinitions.DigitalInputSensor() });

    product.setCalibrationAvailable(true);
    product.hideFlashingStation();
    registerNewProduct(XTEMP_1101_0002_NUMBER, XTEMP_1101_0002, product);

    product = new DefaultProduct(5, "XTEMP-1150", "DIN/IEC751 2-wires", new ColumnDefinition[] { new ColumnDefinition(com.aginova.app.oilgas.Topics.SENSOR_TYPE_TEMPERATURE, true), new ColumnDefinition(com.aginova.app.oilgas.Topics.SENSOR_TYPE_TEMPERATURE_2, true), new ColumnDefinition(com.aginova.app.oilgas.Topics.SENSOR_TYPE_DIGITAL_IO, false) }, new Component[] { new ProductDefinitions.ConvertFarenheitRTD("rawRTD1Sensor", "temp"), new ProductDefinitions.ConvertFarenheitRTD("rawRTD2Sensor", "temp2"), new ProductDefinitions.DigitalInputSensor() });

    product.setCalibrationAvailable(true);
    product.setNotes("- Fill the exact calibrator values below that will be used\n- Start with the 18.2 Ohm calibrator on RTD's Channel 1 and the 249 Ohm on Channel 2.\n- Do not put Digital IO plug\n- Follow instructions for the calibration process, final temp must be around 32°F\n- Check that LED blinks GREEN RED ORANGE during flashing (from 5.4.18)\n");

    product.setComputeRequirements(this.rtdGS1011Requirements);

    product.setCalibrationPlugs(new float[] { 18.200001F, 249.0F, 100.0F, 100.0F });
    product.setCalibrationCurves(new int[] { 0, 100, 0, 0, 1000, 10000 });
    product.setPreciseCalibration();
    product.setCalibrationTransformer(new CalibrationTransformer()
    {
      public Float transformResistance(Float input)
      {
        return input;
      }
      public Float transformMeasurement(Float input) {
        return ProductInformation.getRTDResistanceFromTempCelcius(ProductInformation.fahrenheitToCelcius(input));
      }
    });
    registerNewProduct(XTEMP_1150_0001_NUMBER, XTEMP_1150_0001, product);

    product = new DefaultProduct(5, "XTEMP-1150", "DIN/IEC751 3-wires", new ColumnDefinition[] { new ColumnDefinition(com.aginova.app.oilgas.Topics.SENSOR_TYPE_TEMPERATURE, true), new ColumnDefinition(com.aginova.app.oilgas.Topics.SENSOR_TYPE_TEMPERATURE_2, true), new ColumnDefinition(com.aginova.app.oilgas.Topics.SENSOR_TYPE_DIGITAL_IO, false) }, new Component[] { new ProductDefinitions.ConvertFarenheitRTD("rawRTD1Sensor", "temp"), new ProductDefinitions.ConvertFarenheitRTD("rawRTD2Sensor", "temp2"), new ProductDefinitions.DigitalInputSensor() });

    product.setCalibrationAvailable(true);
    product.hideFlashingStation();
    registerNewProduct(XTEMP_1150_0002_NUMBER, XTEMP_1150_0002, product);

    product = new DefaultProduct(4, "XTEMP-1013", "Onboard light sensor only", new String[] { "light" }, new Component[] { new ProductDefinitions.OnBoardLightSensor() });

    product.hideFlashingStation();
    registerNewProduct(XTEMP_1013_0001_NUMBER, XTEMP_1013_0001, product);

    product = new DefaultProduct(4, "XTEMP-1013", "Default probe -20°C to 10°C ±0.5°C", new String[] { "temp", "temp2", "light" }, new Component[] { new ProductDefinitions.Probe12J1H0042ExternalThermistor("rawTemp", "temp", true), new ProductDefinitions.Probe12J1H0042ExternalThermistor("rawTemp2", "temp2", true), new ProductDefinitions.OnBoardLightSensor() });

    product.setRequirements(new Requirement[] { new Requirement("light", Float.valueOf(100.0F), null), new Requirement("temp", Float.valueOf(27.1F), Float.valueOf(28.0F)), new Requirement("temp2", Float.valueOf(27.1F), Float.valueOf(28.0F)) });

    product.setNotes("- Point a strong light towards light sensor (>100lux)\n- Use 56.2K calibrator on Port 1 and 1K calibrator on Port 2\n- Check that LED blinks GREEN RED ORANGE during flashing (from 5.4.18)\n- Press the pushbutton at the end and make sure that the LED blinks (pushbutton test)");

    registerNewProduct(XTEMP_1013_0002_NUMBER, XTEMP_1013_0002, product);

    product = new DefaultProduct(4, "XTEMP-1013", "High precision probe 0°C to 40°C ±0.1°C", new String[] { "temp", "temp2", "light" }, new Component[] { new ProductDefinitions.PS103J2ExternalThermistor("rawTemp", "temp", true), new ProductDefinitions.PS103J2ExternalThermistor("rawTemp2", "temp2", true), new ProductDefinitions.OnBoardLightSensor() });

    product.hideFlashingStation();
    registerNewProduct(XTEMP_1013_0004_NUMBER, XTEMP_1013_0004, product);

    product = new DefaultProduct(4, "XTEMP-1013", "Large range probe -30°C to 50°C ±0.55°C", new String[] { "temp", "temp2", "light" }, new Component[] { new ProductDefinitions.QT06024CExternalThermistor("rawTemp", "temp", true), new ProductDefinitions.QT06024CExternalThermistor("rawTemp2", "temp2", true), new ProductDefinitions.OnBoardLightSensor() });

    product.hideFlashingStation();
    registerNewProduct(XTEMP_1013_0005_NUMBER, XTEMP_1013_0005, product);

    product = new DefaultProduct(4, "XTEMP-1015", "Onboard light sensor only", new String[] { "light" }, new Component[] { new ProductDefinitions.OnBoardLightSensor() });

    product.hideFlashingStation();
    registerNewProduct(XTEMP_1015_0001_NUMBER, XTEMP_1015_0001, product);

    product = new DefaultProduct(4, "XTEMP-1015", "Default probe -20°C to 10°C ±0.5°C", new ColumnDefinition[] { new ColumnDefinition("temp", true), new ColumnDefinition("temp2", true), new ColumnDefinition("light", false) }, new Component[] { new ProductDefinitions.ConvertFarenheit("rawTemp", "temp"), new ProductDefinitions.ConvertFarenheit("rawTemp2", "temp2"), new ProductDefinitions.DirectLightSensor() });

    enableCalibrationForProII(product);
    product.setCalibrationTransformer(new CalibrationTransformer()
    {
      public Float transformResistance(Float input) {
        return ProductInformation.celciusToFarenheit(ProductInformation.access$000(input));
      }
      public Float convertBeforeSending(Float input) {
        return ProductInformation.fahrenheitToCelcius(input);
      }
      public Float convertDeltaBeforeSending(Float input) {
        return ProductInformation.fahrenheitToCelciusDifference(input);
      }
    });
    registerNewProduct(XTEMP_1015_0002_NUMBER, XTEMP_1015_0002, product);

    product = new DefaultProduct(4, "XTEMP-1015", "High precision probe 0°C to 40°C ±0.1°C", new ColumnDefinition[] { new ColumnDefinition("temp", true), new ColumnDefinition("temp2", true), new ColumnDefinition("light", false) }, new Component[] { new ProductDefinitions.ConvertFarenheit("rawTemp", "temp"), new ProductDefinitions.ConvertFarenheit("rawTemp2", "temp2"), new ProductDefinitions.DirectLightSensor() });

    enableCalibrationForProII(product);
    product.setCalibrationTransformer(new CalibrationTransformer()
    {
      public Float transformResistance(Float input) {
        return ProductInformation.celciusToFarenheit(ProductInformation.resistancePS103J2ThermistorADCtoCelcius(input));
      }
      public Float convertBeforeSending(Float input) {
        return ProductInformation.fahrenheitToCelcius(input);
      }
      public Float convertDeltaBeforeSending(Float input) {
        return ProductInformation.fahrenheitToCelciusDifference(input);
      }
    });
    product.hideFlashingStation();
    registerNewProduct(XTEMP_1015_0004_NUMBER, XTEMP_1015_0004, product);

    product = new DefaultProduct(4, "XTEMP-1015", "Large range probe -30°C to 50°C ±0.55°C", new ColumnDefinition[] { new ColumnDefinition("temp", true), new ColumnDefinition("temp2", true), new ColumnDefinition("light", false) }, new Component[] { new ProductDefinitions.ConvertFarenheit("rawTemp", "temp"), new ProductDefinitions.ConvertFarenheit("rawTemp2", "temp2"), new ProductDefinitions.DirectLightSensor() });

    enableCalibrationForProII(product);
    product.setCalibrationTransformer(new CalibrationTransformer()
    {
      public Float transformResistance(Float input) {
        return ProductInformation.celciusToFarenheit(ProductInformation.QT06024CADCtoCelcius(input));
      }
      public Float convertBeforeSending(Float input) {
        return ProductInformation.fahrenheitToCelcius(input);
      }
      public Float convertDeltaBeforeSending(Float input) {
        return ProductInformation.fahrenheitToCelciusDifference(input);
      }
    });
    product.hideFlashingStation();
    registerNewProduct(XTEMP_1015_0005_NUMBER, XTEMP_1015_0005, product);

    product = new DefaultProduct(4, "XTEMP-1050", "Onboard light sensor only", new String[] { "light" }, new Component[] { new ProductDefinitions.DirectLightSensor() });

    product.hideFlashingStation();
    registerNewProduct(XTEMP_1050_0001_NUMBER, XTEMP_1050_0001, product);

    product = new DefaultProduct(4, "XTEMP-1050", "Default probe -20°C to 10°C ±0.5°C", new ColumnDefinition[] { new ColumnDefinition("temp", true), new ColumnDefinition("temp2", true), new ColumnDefinition("light", false) }, new Component[] { new ProductDefinitions.ConvertFarenheit("rawTemp", "temp"), new ProductDefinitions.ConvertFarenheit("rawTemp2", "temp2"), new ProductDefinitions.DirectLightSensor() });

    enableCalibrationForProII(product);
    product.setCalibrationTransformer(new CalibrationTransformer()
    {
      public Float transformResistance(Float input) {
        return ProductInformation.celciusToFarenheit(ProductInformation.access$000(input));
      }
      public Float convertBeforeSending(Float input) {
        return ProductInformation.fahrenheitToCelcius(input);
      }
      public Float convertDeltaBeforeSending(Float input) {
        return ProductInformation.fahrenheitToCelciusDifference(input);
      }
    });
    registerNewProduct(XTEMP_1050_0002_NUMBER, XTEMP_1050_0002, product);

    product = new DefaultProduct(4, "XTEMP-1050", "High precision probe 0°C to 40°C ±0.1°C", new ColumnDefinition[] { new ColumnDefinition("temp", true), new ColumnDefinition("temp2", true), new ColumnDefinition("light", false) }, new Component[] { new ProductDefinitions.ConvertFarenheit("rawTemp", "temp"), new ProductDefinitions.ConvertFarenheit("rawTemp2", "temp2"), new ProductDefinitions.DirectLightSensor() });

    enableCalibrationForProII(product);
    product.setCalibrationTransformer(new CalibrationTransformer()
    {
      public Float transformResistance(Float input) {
        return ProductInformation.celciusToFarenheit(ProductInformation.resistancePS103J2ThermistorADCtoCelcius(input));
      }
      public Float convertBeforeSending(Float input) {
        return ProductInformation.fahrenheitToCelcius(input);
      }
      public Float convertDeltaBeforeSending(Float input) {
        return ProductInformation.fahrenheitToCelciusDifference(input);
      }
    });
    product.hideFlashingStation();
    registerNewProduct(XTEMP_1050_0004_NUMBER, XTEMP_1050_0004, product);

    product = new DefaultProduct(4, "XTEMP-1050", "Large range probe -30°C to 50°C ±0.55°C", new ColumnDefinition[] { new ColumnDefinition("temp", true), new ColumnDefinition("temp2", true), new ColumnDefinition("light", false) }, new Component[] { new ProductDefinitions.ConvertFarenheit("rawTemp", "temp"), new ProductDefinitions.ConvertFarenheit("rawTemp2", "temp2"), new ProductDefinitions.DirectLightSensor() });

    enableCalibrationForProII(product);
    product.setCalibrationTransformer(new CalibrationTransformer()
    {
      public Float transformResistance(Float input) {
        return ProductInformation.celciusToFarenheit(ProductInformation.QT06024CADCtoCelcius(input));
      }
      public Float convertBeforeSending(Float input) {
        return ProductInformation.fahrenheitToCelcius(input);
      }
      public Float convertDeltaBeforeSending(Float input) {
        return ProductInformation.fahrenheitToCelciusDifference(input);
      }
    });
    product.hideFlashingStation();
    registerNewProduct(XTEMP_1050_0005_NUMBER, XTEMP_1050_0005, product);

    product = new DefaultProduct(4, "XTEMP-1050", "Octsens 10K 0.5% probe", new ColumnDefinition[] { new ColumnDefinition("temp", true), new ColumnDefinition("temp2", true), new ColumnDefinition("light", false) }, new Component[] { new ProductDefinitions.ConvertFarenheit("rawTemp", "temp"), new ProductDefinitions.ConvertFarenheit("rawTemp2", "temp2"), new ProductDefinitions.DirectLightSensor() });

    enableCalibrationForProII(product);
    product.setCalibrationTransformer(new CalibrationTransformer()
    {
      public Float transformResistance(Float input) {
        return ProductInformation.celciusToFarenheit(ProductInformation.Octsens10kADCtoCelcius(input));
      }
      public Float convertBeforeSending(Float input) {
        return ProductInformation.fahrenheitToCelcius(input);
      }
      public Float convertDeltaBeforeSending(Float input) {
        return ProductInformation.fahrenheitToCelciusDifference(input);
      }
    });
    product.hideFlashingStation();
    registerNewProduct(XTEMP_1050_0006_NUMBER, XTEMP_1050_0006, product);

    product = new DefaultProduct(4, "XTEMP-1014", "Onboard temp/humidity (SHT11), light", new String[] { "tempInt", "hum", "light" }, new Component[] { new ProductDefinitions.SHT11Temperature(), new ProductDefinitions.SHT11Humidity(), new ProductDefinitions.OnBoardLightSensor() });

    product.hideFlashingStation();
    product.setInternalTemp("tempInt");
    registerNewProduct(XTEMP_1014_0001_NUMBER, XTEMP_1014_0001, product);

    product = new DefaultProduct(4, "XTEMP-1014", "Default probe -20°C to 10°C ±0.5°C", new ColumnDefinition[] { new ColumnDefinition("temp", true), new ColumnDefinition("temp2", true), new ColumnDefinition("tempInt", false), new ColumnDefinition("hum", false), new ColumnDefinition("light", false) }, new Component[] { new ProductDefinitions.Probe12J1H0042ExternalThermistor("rawTemp", "temp", true), new ProductDefinitions.Probe12J1H0042ExternalThermistor("rawTemp2", "temp2", true), new ProductDefinitions.SHT11Temperature(), new ProductDefinitions.SHT11Humidity(), new ProductDefinitions.OnBoardLightSensor() });

    product.setRequirements(new Requirement[] { new Requirement("light", Float.valueOf(100.0F), null), new Requirement("temp", Float.valueOf(27.1F), Float.valueOf(28.0F)), new Requirement("temp2", Float.valueOf(27.1F), Float.valueOf(28.0F)) });

    product.setInternalTemp("tempInt");

    registerNewProduct(XTEMP_1014_0002_NUMBER, XTEMP_1014_0002, product);

    product = new DefaultProduct(4, "XTEMP-1014", "High precision probe 0°C to 40°C ±0.1°C", new String[] { "temp", "temp2", "tempInt", "hum", "light" }, new Component[] { new ProductDefinitions.PS103J2ExternalThermistor("rawTemp", "temp", true), new ProductDefinitions.PS103J2ExternalThermistor("rawTemp2", "temp2", true), new ProductDefinitions.SHT11Temperature(), new ProductDefinitions.SHT11Humidity(), new ProductDefinitions.OnBoardLightSensor() });

    product.hideFlashingStation();
    product.setInternalTemp("tempInt");
    registerNewProduct(XTEMP_1014_0004_NUMBER, XTEMP_1014_0004, product);

    product = new DefaultProduct(4, "XTEMP-1014", "Large range probe -30°C to 50°C ±0.55°C", new String[] { "temp", "temp2", "tempInt", "hum", "light" }, new Component[] { new ProductDefinitions.QT06024CExternalThermistor("rawTemp", "temp", true), new ProductDefinitions.QT06024CExternalThermistor("rawTemp2", "temp2", true), new ProductDefinitions.SHT11Temperature(), new ProductDefinitions.SHT11Humidity(), new ProductDefinitions.OnBoardLightSensor() });

    product.hideFlashingStation();
    product.setInternalTemp("tempInt");
    registerNewProduct(XTEMP_1014_0005_NUMBER, XTEMP_1014_0005, product);

    product = new DefaultProduct(4, "XTEMP-1017", "Onboard temp/humidity (SHT11), light", new String[] { "tempInt", "hum", "light" }, new Component[] { new ProductDefinitions.ConvertFarenheit("rawTempInt", "tempInt"), new ProductDefinitions.HumidityDirect("hum", "rawHum"), new ProductDefinitions.DirectLightSensor() });

    product.hideFlashingStation();
    product.setInternalTemp("tempInt");
    registerNewProduct(XTEMP_1017_0001_NUMBER, XTEMP_1017_0001, product);

    product = new DefaultProduct(4, "XTEMP-1017", "Default probe -20°C to 10°C ±0.5°C", new ColumnDefinition[] { new ColumnDefinition("tempInt", false), new ColumnDefinition("hum", false), new ColumnDefinition("temp", true), new ColumnDefinition("temp2", true), new ColumnDefinition("light", false) }, new Component[] { new ProductDefinitions.ConvertFarenheit("rawTempInt", "tempInt"), new ProductDefinitions.HumidityDirect("hum", "rawHum"), new ProductDefinitions.ConvertFarenheit("rawTemp", "temp"), new ProductDefinitions.ConvertFarenheit("rawTemp2", "temp2"), new ProductDefinitions.DirectLightSensor() });

    product.setCalibrationAvailable(true);
    enableCalibrationForProII(product);
    product.setCalibrationTransformer(new CalibrationTransformer()
    {
      public Float transformResistance(Float input) {
        return ProductInformation.celciusToFarenheit(ProductInformation.access$000(input));
      }
      public Float convertBeforeSending(Float input) {
        return ProductInformation.fahrenheitToCelcius(input);
      }
      public Float convertDeltaBeforeSending(Float input) {
        return ProductInformation.fahrenheitToCelciusDifference(input);
      }
    });
    product.setInternalTemp("tempInt");

    registerNewProduct(XTEMP_1017_0002_NUMBER, XTEMP_1017_0002, product);

    product = new DefaultProduct(4, "XTEMP-1017", "High precision probe 0°C to 40°C ±0.1°C", new ColumnDefinition[] { new ColumnDefinition("tempInt", false), new ColumnDefinition("hum", false), new ColumnDefinition("temp", true), new ColumnDefinition("temp2", true), new ColumnDefinition("light", false) }, new Component[] { new ProductDefinitions.ConvertFarenheit("rawTempInt", "tempInt"), new ProductDefinitions.HumidityDirect("hum", "rawHum"), new ProductDefinitions.ConvertFarenheit("rawTemp", "temp"), new ProductDefinitions.ConvertFarenheit("rawTemp2", "temp2"), new ProductDefinitions.DirectLightSensor() });

    product.hideFlashingStation();
    enableCalibrationForProII(product);
    product.setCalibrationTransformer(new CalibrationTransformer()
    {
      public Float transformResistance(Float input) {
        return ProductInformation.celciusToFarenheit(ProductInformation.resistancePS103J2ThermistorADCtoCelcius(input));
      }
      public Float convertBeforeSending(Float input) {
        return ProductInformation.fahrenheitToCelcius(input);
      }
      public Float convertDeltaBeforeSending(Float input) {
        return ProductInformation.fahrenheitToCelciusDifference(input);
      }
    });
    product.setInternalTemp("tempInt");
    registerNewProduct(XTEMP_1017_0004_NUMBER, XTEMP_1017_0004, product);

    product = new DefaultProduct(4, "XTEMP-1017", "Large range probe -30°C to 50°C ±0.55°C", new ColumnDefinition[] { new ColumnDefinition("tempInt", false), new ColumnDefinition("hum", false), new ColumnDefinition("temp", true), new ColumnDefinition("temp2", true), new ColumnDefinition("light", false) }, new Component[] { new ProductDefinitions.ConvertFarenheit("rawTempInt", "tempInt"), new ProductDefinitions.HumidityDirect("hum", "rawHum"), new ProductDefinitions.ConvertFarenheit("rawTemp", "temp"), new ProductDefinitions.ConvertFarenheit("rawTemp2", "temp2"), new ProductDefinitions.DirectLightSensor() });

    product.hideFlashingStation();
    enableCalibrationForProII(product);
    product.setCalibrationTransformer(new CalibrationTransformer()
    {
      public Float transformResistance(Float input) {
        return ProductInformation.celciusToFarenheit(ProductInformation.QT06024CADCtoCelcius(input));
      }
      public Float convertBeforeSending(Float input) {
        return ProductInformation.fahrenheitToCelcius(input);
      }
      public Float convertDeltaBeforeSending(Float input) {
        return ProductInformation.fahrenheitToCelciusDifference(input);
      }
    });
    product.setInternalTemp("tempInt");
    registerNewProduct(XTEMP_1017_0005_NUMBER, XTEMP_1017_0005, product);

    product = new DefaultProduct(4, "XTEMP-1051", "Onboard temp/humidity (SHT11), light", new String[] { "tempInt", "hum", "light" }, new Component[] { new ProductDefinitions.ConvertFarenheit("rawTempInt", "tempInt"), new ProductDefinitions.HumidityDirect("hum", "rawHum"), new ProductDefinitions.DirectLightSensor() });

    product.hideFlashingStation();
    product.setInternalTemp("tempInt");
    registerNewProduct(XTEMP_1051_0001_NUMBER, XTEMP_1051_0001, product);

    product = new DefaultProduct(4, "XTEMP-1051", "Default probe -20°C to 10°C ±0.5°C", new ColumnDefinition[] { new ColumnDefinition("tempInt", false), new ColumnDefinition("hum", false), new ColumnDefinition("temp", true), new ColumnDefinition("temp2", true), new ColumnDefinition("light", false) }, new Component[] { new ProductDefinitions.ConvertFarenheit("rawTempInt", "tempInt"), new ProductDefinitions.HumidityDirect("hum", "rawHum"), new ProductDefinitions.ConvertFarenheit("rawTemp", "temp"), new ProductDefinitions.ConvertFarenheit("rawTemp2", "temp2"), new ProductDefinitions.DirectLightSensor() });

    product.setInternalTemp("tempInt");
    enableCalibrationForProII(product);
    product.setCalibrationTransformer(new CalibrationTransformer()
    {
      public Float transformResistance(Float input) {
        return ProductInformation.celciusToFarenheit(ProductInformation.access$000(input));
      }
      public Float convertBeforeSending(Float input) {
        return ProductInformation.fahrenheitToCelcius(input);
      }
      public Float convertDeltaBeforeSending(Float input) {
        return ProductInformation.fahrenheitToCelciusDifference(input);
      }
    });
    registerNewProduct(XTEMP_1051_0002_NUMBER, XTEMP_1051_0002, product);

    product = new DefaultProduct(4, "XTEMP-1051", "High precision probe 0°C to 40°C ±0.1°C", new ColumnDefinition[] { new ColumnDefinition("tempInt", false), new ColumnDefinition("hum", false), new ColumnDefinition("temp", true), new ColumnDefinition("temp2", true), new ColumnDefinition("light", false) }, new Component[] { new ProductDefinitions.ConvertFarenheit("rawTempInt", "tempInt"), new ProductDefinitions.HumidityDirect("hum", "rawHum"), new ProductDefinitions.ConvertFarenheit("rawTemp", "temp"), new ProductDefinitions.ConvertFarenheit("rawTemp2", "temp2"), new ProductDefinitions.DirectLightSensor() });

    product.hideFlashingStation();
    product.setInternalTemp("tempInt");
    enableCalibrationForProII(product);
    product.setCalibrationTransformer(new CalibrationTransformer()
    {
      public Float transformResistance(Float input) {
        return ProductInformation.celciusToFarenheit(ProductInformation.resistancePS103J2ThermistorADCtoCelcius(input));
      }
      public Float convertBeforeSending(Float input) {
        return ProductInformation.fahrenheitToCelcius(input);
      }
      public Float convertDeltaBeforeSending(Float input) {
        return ProductInformation.fahrenheitToCelciusDifference(input);
      }
    });
    registerNewProduct(XTEMP_1051_0004_NUMBER, XTEMP_1051_0004, product);

    product = new DefaultProduct(4, "XTEMP-1051", "Large range probe -30°C to 50°C ±0.55°C", new ColumnDefinition[] { new ColumnDefinition("tempInt", false), new ColumnDefinition("hum", false), new ColumnDefinition("temp", true), new ColumnDefinition("temp2", true), new ColumnDefinition("light", false) }, new Component[] { new ProductDefinitions.ConvertFarenheit("rawTempInt", "tempInt"), new ProductDefinitions.HumidityDirect("hum", "rawHum"), new ProductDefinitions.ConvertFarenheit("rawTemp", "temp"), new ProductDefinitions.ConvertFarenheit("rawTemp2", "temp2"), new ProductDefinitions.DirectLightSensor() });

    product.hideFlashingStation();
    product.setInternalTemp("tempInt");
    enableCalibrationForProII(product);
    product.setCalibrationTransformer(new CalibrationTransformer()
    {
      public Float transformResistance(Float input) {
        return ProductInformation.celciusToFarenheit(ProductInformation.QT06024CADCtoCelcius(input));
      }
      public Float convertBeforeSending(Float input) {
        return ProductInformation.fahrenheitToCelcius(input);
      }
      public Float convertDeltaBeforeSending(Float input) {
        return ProductInformation.fahrenheitToCelciusDifference(input);
      }
    });
    registerNewProduct(XTEMP_1051_0005_NUMBER, XTEMP_1051_0005, product);

    product = new DefaultProduct(4, "XTEMP-1051", "Octsens 10K 0.5% probe", new ColumnDefinition[] { new ColumnDefinition("tempInt", false), new ColumnDefinition("hum", false), new ColumnDefinition("temp", true), new ColumnDefinition("temp2", true), new ColumnDefinition("light", false) }, new Component[] { new ProductDefinitions.ConvertFarenheit("rawTempInt", "tempInt"), new ProductDefinitions.HumidityDirect("hum", "rawHum"), new ProductDefinitions.ConvertFarenheit("rawTemp", "temp"), new ProductDefinitions.ConvertFarenheit("rawTemp2", "temp2"), new ProductDefinitions.DirectLightSensor() });

    product.hideFlashingStation();
    product.setInternalTemp("tempInt");
    enableCalibrationForProII(product);
    product.setCalibrationTransformer(new CalibrationTransformer()
    {
      public Float transformResistance(Float input) {
        return ProductInformation.celciusToFarenheit(ProductInformation.Octsens10kADCtoCelcius(input));
      }
      public Float convertBeforeSending(Float input) {
        return ProductInformation.fahrenheitToCelcius(input);
      }
      public Float convertDeltaBeforeSending(Float input) {
        return ProductInformation.fahrenheitToCelciusDifference(input);
      }
    });
    registerNewProduct(XTEMP_1051_0006_NUMBER, XTEMP_1051_0006, product);

    product = new DefaultProduct(4, "XTEMP-1090", "Wetness Sensor (10K)", new ColumnDefinition[] { new ColumnDefinition("tempInt", false), new ColumnDefinition("hum", false), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M1, RESISTANCE1_TEXT, true), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M2, RESISTANCE2_TEXT, true), new ColumnDefinition("light", false) }, new Component[] { new ProductDefinitions.ConvertFarenheit("rawTempInt", "tempInt"), new ProductDefinitions.HumidityDirect("hum", "rawHum"), new ProductDefinitions.ResistanceDirect(RESISTANCE1_TEXT, "resistance1Raw"), new ProductDefinitions.ResistanceDirect(RESISTANCE2_TEXT, "resistance2Raw"), new ProductDefinitions.DirectLightSensor() });

    product.hideFlashingStation();
    product.setInternalTemp("tempInt");
    enableCalibrationForProII(product);
    product.setCalibrationTransformer(new CalibrationTransformer()
    {
      public Float transformResistance(Float input) {
        return ProductInformation.celciusToFarenheit(ProductInformation.QT06024CADCtoCelcius(input));
      }
      public Float convertBeforeSending(Float input) {
        return ProductInformation.fahrenheitToCelcius(input);
      }
      public Float convertDeltaBeforeSending(Float input) {
        return ProductInformation.fahrenheitToCelciusDifference(input);
      }
    });
    registerNewProduct(XTEMP_1090_0001_NUMBER, XTEMP_1090_0001, product);

    product = new DefaultProduct(4, "XTEMP-1091", "Wetness Sensor (10K)", new ColumnDefinition[] { new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M1, RESISTANCE1_TEXT, true), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M2, RESISTANCE2_TEXT, true), new ColumnDefinition("light", false) }, new Component[] { new ProductDefinitions.ResistanceDirect(RESISTANCE1_TEXT, "resistance1Raw"), new ProductDefinitions.ResistanceDirect(RESISTANCE2_TEXT, "resistance2Raw"), new ProductDefinitions.DirectLightSensor() });

    product.hideFlashingStation();
    product.setInternalTemp("tempInt");
    enableCalibrationForProII(product);
    product.setCalibrationTransformer(new CalibrationTransformer()
    {
      public Float transformResistance(Float input) {
        return ProductInformation.celciusToFarenheit(ProductInformation.QT06024CADCtoCelcius(input));
      }
      public Float convertBeforeSending(Float input) {
        return ProductInformation.fahrenheitToCelcius(input);
      }
      public Float convertDeltaBeforeSending(Float input) {
        return ProductInformation.fahrenheitToCelciusDifference(input);
      }
    });
    registerNewProduct(XTEMP_1091_0001_NUMBER, XTEMP_1091_0001, product);

    product = new DefaultProduct(9, "XCORR-1001", "SHT11, onboard thermistor", new String[] { "temp", "tempInt", "hum", "corr1", "corr2", "corr3", "wetness1", "wetness2", "wetness3", "impedance_real", "impedance_imaginary", com.aginova.app.oilgas.Topics.SENSOR_TYPE_IMPEDANCE_REAL_2, com.aginova.app.oilgas.Topics.SENSOR_TYPE_IMPEDANCE_IMAGINARY_2 }, new Component[] { new ProductDefinitions.PS103J2ExternalThermistor("rawTemp", "temp"), new ProductDefinitions.SHT11Temperature(), new ProductDefinitions.SHT11Humidity(), new ProductDefinitions.CorrosivitySensor(1, "corr1", "rawCorr1"), new ProductDefinitions.CorrosivitySensor(2, "corr2", "rawCorr2"), new ProductDefinitions.CorrosivitySensor(3, "corr3", "rawCorr3"), new ProductDefinitions.ICEWetnessSensor(1, "wetness1", "rawWetness1"), new ProductDefinitions.ICEWetnessSensor(2, "wetness2", "rawWetness2"), new ProductDefinitions.ICEWetnessSensor(3, "wetness3", "rawWetness3"), new ProductDefinitions.ICEWetnessSensor(4, "wetness4", "rawWetness4"), new ProductDefinitions.CDS(1, "CDSReal1", "rawCDSReal1", true), new ProductDefinitions.CDS(1, "CDSImaginary1", "rawCDSImaginary1", false), new ProductDefinitions.CDS(2, "CDSReal2", "rawCDSReal2", true), new ProductDefinitions.CDS(2, "CDSImaginary2", "rawCDSImaginary2", false) });

    product.setNotes("- Plug the external SHT75 Temp/Hum sensor");
    registerNewProduct(XCORR_1001_0001_NUMBER, XCORR_1001_0001, product);

    product = new DefaultProduct(7, "XCORR-1006", "Temperature, High impedance, Oxygen Sensor, RTD", new String[] { "temp", "temp2", com.aginova.app.oilgas.Topics.SENSOR_TYPE_HIGH_IMPEDANCE, "oxy" }, new Component[] { new ProductDefinitions.PS103J2ExternalThermistor("rawTemp", "temp"), new ProductDefinitions.PoleStarRTD(), new ProductDefinitions.HighImpedance(), new ProductDefinitions.OxySensor() });

    registerNewProduct(XCORR_1006_0001_NUMBER, XCORR_1006_0001, product);

    product = new DefaultProduct(7, "XPH-1002", "2 pH probes with thermistors", new ColumnDefinition[] { new ColumnDefinition("temp", false), new ColumnDefinition("temp2", false), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M1, VOLTAGE1_TEXT, false), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M2, VOLTAGE2_TEXT, false), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M3, PH1_TEXT, true), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M4, PH2_TEXT, true) }, new Component[] { new ProductDefinitions.ConvertFarenheit("rawTemp", "temp"), new ProductDefinitions.ConvertFarenheit("rawTemp2", "temp2"), new ProductDefinitions.VoltageDirect(VOLTAGE1_TEXT, "voltage1Raw"), new ProductDefinitions.VoltageDirect(VOLTAGE2_TEXT, "voltage2Raw"), new ProductDefinitions.PHDirect(PH1_TEXT, "ph1Raw"), new ProductDefinitions.PHDirect(PH2_TEXT, "ph2Raw") });

    product.setCalibrationAvailable(true);

    product.setCalibrationPlugs(new float[] { 4.0F, 10.0F, 7.0F, 7.0F });
    product.setCalibrationCurves(new int[] { 5, 1000, 0, 5, 1000, 0 });
    product.setCalibrationpH(true);

    product.setCalibrationTransformer(new CalibrationTransformer()
    {
    });
    registerNewProduct(XPH_1002_0001_NUMBER, XPH_1002_0001, product);

    product = new DefaultProduct(11, "XCORR-1004", "Onboard thermistor,  1 MAS corrosivity", new String[] { "temp", "adcValue0", "adcValue1", "adcValue2", "adcValue3", "adcValue4", "adcValue5", "adcValue6", "adcValue7", "adcValue8", "adcValue9", "adcValue10", "adcValue11", "adcValue12", "adcValue13", "adcValue14", "adcValue15" }, new Component[] { new ProductDefinitions.PS103J2ExternalThermistor("rawTemp", "temp"), new ProductDefinitions.TMAS16Channels(0) });

    product.setNotes("- Use a Druck UPS-III Loop Calibrator & Thierry circuit between Ch. 1 and 2\n- Leave other ports opened");
    registerNewProduct(XCORR_1004_0001_NUMBER, XCORR_1004_0001, product);

    product = new DefaultProduct(11, "XCORR-1008", "Onboard thermistor,  MAS corrosivity - default probe", new String[] { "temp", "masCorrAvg", "masCorrMax" }, new Component[] { new ProductDefinitions.PS103J2ExternalThermistor("rawTemp", "temp"), new ProductDefinitions.TMAS16ChannelsDirect("masCorrAvg", "rawMasCorrAvg"), new ProductDefinitions.TMAS16ChannelsDirect("masCorrMax", "rawMasCorrMax") });

    product.setNotes("- Use a Druck UPS-III Loop Calibrator & Thierry circuit between Ch. 1 and 2\n- Leave other ports opened");
    registerNewProduct(XCORR_1008_0001_NUMBER, XCORR_1008_0001, product);

    product = new DefaultProduct(11, "XCORR-1009", "Onboard thermistor,  MAS corrosivity - SwRI Probe - 16 channels", new String[] { "temp", "masCorrAvg", "masCorrMax" }, new Component[] { new ProductDefinitions.PS103J2ExternalThermistor("rawTemp", "temp"), new ProductDefinitions.TMAS16ChannelsDirect("masCorrAvg", "rawMasCorrAvg"), new ProductDefinitions.TMAS16ChannelsDirect("masCorrMax", "rawMasCorrMax") });

    product.setNotes("- Use a Druck UPS-III Loop Calibrator & Thierry circuit between Ch. 1 and 2\n- Leave other ports opened");
    registerNewProduct(XCORR_1009_0001_NUMBER, XCORR_1009_0001, product);

    product = new DefaultProduct(11, "XCORR-1009", "Onboard thermistor,  MAS corrosivity - DNV Probe - 16 channels", new String[] { "temp", "masCorrAvg", "masCorrMax" }, new Component[] { new ProductDefinitions.PS103J2ExternalThermistor("rawTemp", "temp"), new ProductDefinitions.TMAS16ChannelsDirect("masCorrAvg", "rawMasCorrAvg"), new ProductDefinitions.TMAS16ChannelsDirect("masCorrMax", "rawMasCorrMax") });

    product.setNotes("- Use a Druck UPS-III Loop Calibrator & Thierry circuit between Ch. 1 and 2\n- Leave other ports opened");
    registerNewProduct(XCORR_1009_0002_NUMBER, XCORR_1009_0002, product);

    product = new DefaultProduct(11, "XCORR-1009", "Onboard thermistor,  MAS corrosivity - DNV Probe - 8 channels", new String[] { "temp", "masCorrAvg", "masCorrMax" }, new Component[] { new ProductDefinitions.PS103J2ExternalThermistor("rawTemp", "temp"), new ProductDefinitions.TMAS16ChannelsDirect("masCorrAvg", "rawMasCorrAvg"), new ProductDefinitions.TMAS16ChannelsDirect("masCorrMax", "rawMasCorrMax") });

    product.setNotes("- Use a Druck UPS-III Loop Calibrator & Thierry circuit between Ch. 1 and 2\n- Leave other ports opened");
    registerNewProduct(XCORR_1009_0003_NUMBER, XCORR_1009_0003, product);

    product = new DefaultProduct(11, "XCORR-1000", "4-channel Wetness", new String[] { "wetness1", "wetness2", "wetness3", "wetness4" }, new Component[] { new ProductDefinitions.WetnessSensor(1, "wetness1", "rawWetness1"), new ProductDefinitions.WetnessSensor(2, "wetness2", "rawWetness2"), new ProductDefinitions.WetnessSensor(3, "wetness3", "rawWetness3"), new ProductDefinitions.WetnessSensor(4, "wetness4", "rawWetness4") });

    product.setNotes("- Attach a precise 100K Ohm resistor (built by TJA)");
    registerNewProduct(XCORR_1000_0001_NUMBER, XCORR_1000_0001, product);

    product = new DefaultProduct(10, "XCORR-BP", "", new String[] { "temp" }, new Component[0]);

    product.hideFlashingStation();
    registerNewProduct(XCORR_BP_NUMBER, XCORR_BP, product);

    product = new DefaultProduct(10, "XCORR-BP-500", "", new String[] { "temp" }, new Component[0]);

    product.hideFlashingStation();
    registerNewProduct(XCORR_BP_500_NUMBER, XCORR_BP_500, product);

    if (DBConnectionProperties.isApplication(DBConnectionProperties.APPLICATION_OILGAS)) {
      product = new DefaultProduct(10, "XCORR-BP-CUI-24", "-", new String[] { "temp", "bpWet1", "bpWet2", "bpWet3", "bpWet4", "bpWet5", "bpWet6", "bpWet7", "bpWet8", "bpWet9", "bpWet10", "bpWet11", "bpWet12", "bpWet13", "bpWet14", "bpWet15", "bpWet16", "bpWet17", "bpWet18", "bpWet19", "bpWet20", "bpWet21", "bpWet22", "bpWet23", "bpWet24", "bpCorr1", "bpCorr2", "bpCorr3", "bpCorr4", "bpCorr5", "bpCorr6", "bpCorr7", "bpCorr8", "bpCorr9", "bpCorr10", "bpCorr11", "bpCorr12", "bpCorr13", "bpCorr14", "bpCorr15", "bpCorr16", "bpCorr17", "bpCorr18", "bpCorr19", "bpCorr20", "bpCorr21", "bpCorr22", "bpCorr23", "bpCorr24" }, new Component[] { new ProductDefinitions.BPInternalThermistor("rawTemp", "temp"), new ProductDefinitions.BPCUICorrSensor(), new ProductDefinitions.BPCUIWetSensor() });

      product.hideFlashingStation();
      registerNewProduct(XCORR_BP_CUI_24_NUMBER, XCORR_BP_CUI_24, product);
    }

    product = new DefaultProduct(12, "XTEMP-1002", "1 Thermistor (default thermistor soldered on board)", new String[] { "temp" }, new Component[] { new ProductDefinitions.DefaultOnBoardThermistor("rawTemp", "temp") });

    product.hideFlashingStation();
    registerNewProduct(XTEMP_1002_0001_NUMBER, XTEMP_1002_0001, product);

    product = new DefaultProduct(6, "XPOWER-1100", "W2 - Wye 2 wires", new ColumnDefinition[] { new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D1, ACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D5, REACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D9, APPARENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M1, FREQ_POWER_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M2, MAX_CURRENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M5, MIN_VOLTAGE_POWER1_TEXT) }, new Component[] { new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER1_TEXT, "actPower1Raw", 8.0F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER1_TEXT, "reactPower1Raw", 8.0F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER1_TEXT, "appPower1Raw", 8.0F), new ProductDefinitions.PowerDirect(20, "Frequency", FREQ_POWER_TEXT, "freqPowerRaw", 16.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER1_TEXT, "maxCurPwr1Raw", 1200.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER1_TEXT, "minVoltPwr1Raw", 25.0F) });

    registerNewProduct(XPOWER_1100_0001_NUMBER, XPOWER_1100_0001, product);

    product = new DefaultProduct(6, "XPOWER-1101", "W2 - Wye 2 wires", new ColumnDefinition[] { new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D1, ACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D5, REACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D9, APPARENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M1, FREQ_POWER_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M2, MAX_CURRENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M5, MIN_VOLTAGE_POWER1_TEXT) }, new Component[] { new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER1_TEXT, "actPower1Raw", 0.8F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER1_TEXT, "reactPower1Raw", 0.8F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER1_TEXT, "appPower1Raw", 0.8F), new ProductDefinitions.PowerDirect(20, "Frequency", FREQ_POWER_TEXT, "freqPowerRaw", 16.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER1_TEXT, "maxCurPwr1Raw", 120.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER1_TEXT, "minVoltPwr1Raw", 25.0F) });

    registerNewProduct(XPOWER_1101_0001_NUMBER, XPOWER_1101_0001, product);

    product = new DefaultProduct(6, "XPOWER-1200", "W4 - Wye 4 wires", new ColumnDefinition[] { new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D1, ACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D2, ACT_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D3, ACT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D4, ACT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D5, REACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D6, REACT_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D7, REACT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D8, REACT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D9, APPARENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D10, APPARENT_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D11, APPARENT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D12, APPARENT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M1, FREQ_POWER_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M2, MAX_CURRENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M3, MAX_CURRENT_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M4, MAX_CURRENT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M5, MIN_VOLTAGE_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M6, MIN_VOLTAGE_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M7, MIN_VOLTAGE_POWER3_TEXT) }, new Component[] { new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER1_TEXT, "actPower1Raw", 2.0F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER2_TEXT, "actPower2Raw", 2.0F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER3_TEXT, "actPower3Raw", 2.0F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER_TOT_TEXT, "actPowerTotRaw", 2.0F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER1_TEXT, "reactPower1Raw", 2.0F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER2_TEXT, "reactPower2Raw", 2.0F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER3_TEXT, "reactPower3Raw", 2.0F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER_TOT_TEXT, "reactPowerTotRaw", 2.0F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER1_TEXT, "appPower1Raw", 2.0F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER2_TEXT, "appPower2Raw", 2.0F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER3_TEXT, "appPower3Raw", 2.0F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER_TOT_TEXT, "appPowerTotRaw", 2.0F), new ProductDefinitions.PowerDirect(20, "Frequency", FREQ_POWER_TEXT, "freqPowerRaw", 16.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER1_TEXT, "maxCurPwr1Raw", 300.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER2_TEXT, "maxCurPwr2Raw", 300.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER3_TEXT, "maxCurPwr3Raw", 300.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER1_TEXT, "minVoltPwr1Raw", 25.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER2_TEXT, "minVoltPwr2Raw", 25.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER3_TEXT, "minVoltPwr3Raw", 25.0F) });

    registerNewProduct(XPOWER_1200_0001_NUMBER, XPOWER_1200_0001, product);

    product = new DefaultProduct(6, "XPOWER-1200", "W3 - Wye 3 wires", new ColumnDefinition[] { new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D1, ACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D2, ACT_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D4, ACT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D5, REACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D6, REACT_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D8, REACT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D9, APPARENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D10, APPARENT_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D12, APPARENT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M1, FREQ_POWER_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M2, MAX_CURRENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M3, MAX_CURRENT_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M5, MIN_VOLTAGE_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M6, MIN_VOLTAGE_POWER2_TEXT) }, new Component[] { new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER1_TEXT, "actPower1Raw", 2.0F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER2_TEXT, "actPower2Raw", 2.0F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER_TOT_TEXT, "actPowerTotRaw", 2.0F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER1_TEXT, "reactPower1Raw", 2.0F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER2_TEXT, "reactPower2Raw", 2.0F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER_TOT_TEXT, "reactPowerTotRaw", 2.0F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER1_TEXT, "appPower1Raw", 2.0F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER2_TEXT, "appPower2Raw", 2.0F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER_TOT_TEXT, "appPowerTotRaw", 2.0F), new ProductDefinitions.PowerDirect(20, "Frequency", FREQ_POWER_TEXT, "freqPowerRaw", 16.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER1_TEXT, "maxCurPwr1Raw", 300.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER2_TEXT, "maxCurPwr2Raw", 300.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER1_TEXT, "minVoltPwr1Raw", 25.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER2_TEXT, "minVoltPwr2Raw", 25.0F) });

    registerNewProduct(XPOWER_1200_0002_NUMBER, XPOWER_1200_0002, product);

    product = new DefaultProduct(6, "XPOWER-1200", "W2 - Wye 2 wires", new ColumnDefinition[] { new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D1, ACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D5, REACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D9, APPARENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M1, FREQ_POWER_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M2, MAX_CURRENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M5, MIN_VOLTAGE_POWER1_TEXT) }, new Component[] { new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER1_TEXT, "actPower1Raw", 2.0F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER1_TEXT, "reactPower1Raw", 2.0F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER1_TEXT, "appPower1Raw", 2.0F), new ProductDefinitions.PowerDirect(20, "Frequency", FREQ_POWER_TEXT, "freqPowerRaw", 16.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER1_TEXT, "maxCurPwr1Raw", 300.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER1_TEXT, "minVoltPwr1Raw", 25.0F) });

    registerNewProduct(XPOWER_1200_0003_NUMBER, XPOWER_1200_0003, product);

    product = new DefaultProduct(6, "XPOWER-1200", "W0 - Wye 3x single phase", new ColumnDefinition[] { new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D1, ACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D2, ACT_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D3, ACT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D4, ACT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D5, REACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D6, REACT_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D7, REACT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D8, REACT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D9, APPARENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D10, APPARENT_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D11, APPARENT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D12, APPARENT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M1, FREQ_POWER_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M2, MAX_CURRENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M3, MAX_CURRENT_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M4, MAX_CURRENT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M5, MIN_VOLTAGE_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M6, MIN_VOLTAGE_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M7, MIN_VOLTAGE_POWER3_TEXT) }, new Component[] { new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER1_TEXT, "actPower1Raw", 2.0F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER2_TEXT, "actPower2Raw", 2.0F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER3_TEXT, "actPower3Raw", 2.0F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER_TOT_TEXT, "actPowerTotRaw", 2.0F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER1_TEXT, "reactPower1Raw", 2.0F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER2_TEXT, "reactPower2Raw", 2.0F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER3_TEXT, "reactPower3Raw", 2.0F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER_TOT_TEXT, "reactPowerTotRaw", 2.0F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER1_TEXT, "appPower1Raw", 2.0F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER2_TEXT, "appPower2Raw", 2.0F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER3_TEXT, "appPower3Raw", 2.0F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER_TOT_TEXT, "appPowerTotRaw", 2.0F), new ProductDefinitions.PowerDirect(20, "Frequency", FREQ_POWER_TEXT, "freqPowerRaw", 16.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER1_TEXT, "maxCurPwr1Raw", 300.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER2_TEXT, "maxCurPwr2Raw", 300.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER3_TEXT, "maxCurPwr3Raw", 300.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER1_TEXT, "minVoltPwr1Raw", 25.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER2_TEXT, "minVoltPwr2Raw", 25.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER3_TEXT, "minVoltPwr3Raw", 25.0F) });

    registerNewProduct(XPOWER_1200_0004_NUMBER, XPOWER_1200_0004, product);

    product = new DefaultProduct(6, "XPOWER-1200", "D3 - Delta 3 wires", new ColumnDefinition[] { new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D1, ACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D3, ACT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D4, ACT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D5, REACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D7, REACT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D8, REACT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D9, APPARENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D11, APPARENT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D12, APPARENT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M1, FREQ_POWER_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M2, MAX_CURRENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M4, MAX_CURRENT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M5, MIN_VOLTAGE_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M7, MIN_VOLTAGE_POWER3_TEXT) }, new Component[] { new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER1_TEXT, "actPower1Raw", 2.0F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER3_TEXT, "actPower3Raw", 2.0F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER_TOT_TEXT, "actPowerTotRaw", 2.0F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER1_TEXT, "reactPower1Raw", 2.0F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER3_TEXT, "reactPower3Raw", 2.0F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER_TOT_TEXT, "reactPowerTotRaw", 2.0F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER1_TEXT, "appPower1Raw", 2.0F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER3_TEXT, "appPower3Raw", 2.0F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER_TOT_TEXT, "appPowerTotRaw", 2.0F), new ProductDefinitions.PowerDirect(20, "Frequency", FREQ_POWER_TEXT, "freqPowerRaw", 16.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER1_TEXT, "maxCurPwr1Raw", 300.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER3_TEXT, "maxCurPwr3Raw", 300.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER1_TEXT, "minVoltPwr1Raw", 25.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER3_TEXT, "minVoltPwr3Raw", 25.0F) });

    registerNewProduct(XPOWER_1200_0005_NUMBER, XPOWER_1200_0005, product);

    product = new DefaultProduct(6, "XPOWER-1300", "W4 - Wye 4 wires", new ColumnDefinition[] { new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D1, ACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D2, ACT_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D3, ACT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D4, ACT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D5, REACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D6, REACT_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D7, REACT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D8, REACT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D9, APPARENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D10, APPARENT_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D11, APPARENT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D12, APPARENT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M1, FREQ_POWER_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M2, MAX_CURRENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M3, MAX_CURRENT_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M4, MAX_CURRENT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M5, MIN_VOLTAGE_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M6, MIN_VOLTAGE_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M7, MIN_VOLTAGE_POWER3_TEXT) }, new Component[] { new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER1_TEXT, "actPower1Raw", 0.4F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER2_TEXT, "actPower2Raw", 0.4F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER3_TEXT, "actPower3Raw", 0.4F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER_TOT_TEXT, "actPowerTotRaw", 0.4F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER1_TEXT, "reactPower1Raw", 0.4F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER2_TEXT, "reactPower2Raw", 0.4F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER3_TEXT, "reactPower3Raw", 0.4F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER_TOT_TEXT, "reactPowerTotRaw", 0.4F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER1_TEXT, "appPower1Raw", 0.4F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER2_TEXT, "appPower2Raw", 0.4F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER3_TEXT, "appPower3Raw", 0.4F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER_TOT_TEXT, "appPowerTotRaw", 0.4F), new ProductDefinitions.PowerDirect(20, "Frequency", FREQ_POWER_TEXT, "freqPowerRaw", 16.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER1_TEXT, "maxCurPwr1Raw", 60.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER2_TEXT, "maxCurPwr2Raw", 60.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER3_TEXT, "maxCurPwr3Raw", 60.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER1_TEXT, "minVoltPwr1Raw", 25.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER2_TEXT, "minVoltPwr2Raw", 25.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER3_TEXT, "minVoltPwr3Raw", 25.0F) });

    registerNewProduct(XPOWER_1300_0001_NUMBER, XPOWER_1300_0001, product);

    product = new DefaultProduct(6, "XPOWER-1300", "W3 - Wye 3 wires", new ColumnDefinition[] { new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D1, ACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D2, ACT_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D4, ACT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D5, REACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D6, REACT_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D8, REACT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D9, APPARENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D10, APPARENT_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D12, APPARENT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M1, FREQ_POWER_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M2, MAX_CURRENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M3, MAX_CURRENT_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M5, MIN_VOLTAGE_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M6, MIN_VOLTAGE_POWER2_TEXT) }, new Component[] { new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER1_TEXT, "actPower1Raw", 0.4F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER2_TEXT, "actPower2Raw", 0.4F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER_TOT_TEXT, "actPowerTotRaw", 0.4F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER1_TEXT, "reactPower1Raw", 0.4F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER2_TEXT, "reactPower2Raw", 0.4F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER_TOT_TEXT, "reactPowerTotRaw", 0.4F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER1_TEXT, "appPower1Raw", 0.4F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER2_TEXT, "appPower2Raw", 0.4F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER_TOT_TEXT, "appPowerTotRaw", 0.4F), new ProductDefinitions.PowerDirect(20, "Frequency", FREQ_POWER_TEXT, "freqPowerRaw", 16.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER1_TEXT, "maxCurPwr1Raw", 60.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER2_TEXT, "maxCurPwr2Raw", 60.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER1_TEXT, "minVoltPwr1Raw", 25.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER2_TEXT, "minVoltPwr2Raw", 25.0F) });

    registerNewProduct(XPOWER_1300_0002_NUMBER, XPOWER_1300_0002, product);

    product = new DefaultProduct(6, "XPOWER-1300", "W2 - Wye 2 wires", new ColumnDefinition[] { new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D1, ACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D5, REACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D9, APPARENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M1, FREQ_POWER_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M2, MAX_CURRENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M5, MIN_VOLTAGE_POWER1_TEXT) }, new Component[] { new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER1_TEXT, "actPower1Raw", 0.4F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER1_TEXT, "reactPower1Raw", 0.4F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER1_TEXT, "appPower1Raw", 0.4F), new ProductDefinitions.PowerDirect(20, "Frequency", FREQ_POWER_TEXT, "freqPowerRaw", 16.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER1_TEXT, "maxCurPwr1Raw", 60.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER1_TEXT, "minVoltPwr1Raw", 25.0F) });

    registerNewProduct(XPOWER_1300_0003_NUMBER, XPOWER_1300_0003, product);

    product = new DefaultProduct(6, "XPOWER-1300", "W0 - Wye 3x single phase", new ColumnDefinition[] { new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D1, ACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D2, ACT_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D3, ACT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D4, ACT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D5, REACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D6, REACT_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D7, REACT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D8, REACT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D9, APPARENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D10, APPARENT_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D11, APPARENT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D12, APPARENT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M1, FREQ_POWER_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M2, MAX_CURRENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M3, MAX_CURRENT_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M4, MAX_CURRENT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M5, MIN_VOLTAGE_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M6, MIN_VOLTAGE_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M7, MIN_VOLTAGE_POWER3_TEXT) }, new Component[] { new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER1_TEXT, "actPower1Raw", 0.4F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER2_TEXT, "actPower2Raw", 0.4F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER3_TEXT, "actPower3Raw", 0.4F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER_TOT_TEXT, "actPowerTotRaw", 0.4F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER1_TEXT, "reactPower1Raw", 0.4F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER2_TEXT, "reactPower2Raw", 0.4F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER3_TEXT, "reactPower3Raw", 0.4F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER_TOT_TEXT, "reactPowerTotRaw", 0.4F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER1_TEXT, "appPower1Raw", 0.4F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER2_TEXT, "appPower2Raw", 0.4F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER3_TEXT, "appPower3Raw", 0.4F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER_TOT_TEXT, "appPowerTotRaw", 0.4F), new ProductDefinitions.PowerDirect(20, "Frequency", FREQ_POWER_TEXT, "freqPowerRaw", 16.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER1_TEXT, "maxCurPwr1Raw", 60.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER2_TEXT, "maxCurPwr2Raw", 60.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER3_TEXT, "maxCurPwr3Raw", 60.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER1_TEXT, "minVoltPwr1Raw", 25.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER2_TEXT, "minVoltPwr2Raw", 25.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER3_TEXT, "minVoltPwr3Raw", 25.0F) });

    registerNewProduct(XPOWER_1300_0004_NUMBER, XPOWER_1300_0004, product);

    product = new DefaultProduct(6, "XPOWER-1300", "D3 - Delta 3 wires", new ColumnDefinition[] { new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D1, ACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D3, ACT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D4, ACT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D5, REACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D7, REACT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D8, REACT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D9, APPARENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D11, APPARENT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D12, APPARENT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M1, FREQ_POWER_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M2, MAX_CURRENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M4, MAX_CURRENT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M5, MIN_VOLTAGE_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M7, MIN_VOLTAGE_POWER3_TEXT) }, new Component[] { new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER1_TEXT, "actPower1Raw", 0.4F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER3_TEXT, "actPower3Raw", 0.4F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER_TOT_TEXT, "actPowerTotRaw", 0.4F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER1_TEXT, "reactPower1Raw", 0.4F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER3_TEXT, "reactPower3Raw", 0.4F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER_TOT_TEXT, "reactPowerTotRaw", 0.4F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER1_TEXT, "appPower1Raw", 0.4F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER3_TEXT, "appPower3Raw", 0.4F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER_TOT_TEXT, "appPowerTotRaw", 0.4F), new ProductDefinitions.PowerDirect(20, "Frequency", FREQ_POWER_TEXT, "freqPowerRaw", 16.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER1_TEXT, "maxCurPwr1Raw", 60.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER3_TEXT, "maxCurPwr3Raw", 60.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER1_TEXT, "minVoltPwr1Raw", 25.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER3_TEXT, "minVoltPwr3Raw", 25.0F) });

    registerNewProduct(XPOWER_1300_0005_NUMBER, XPOWER_1300_0005, product);

    product = new DefaultProduct(6, "XPOWER-1300", "D3/SP2 - Delta 3 wires, 24V supply", new ColumnDefinition[] { new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D1, ACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D3, ACT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D4, ACT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D5, REACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D7, REACT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D8, REACT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D9, APPARENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D11, APPARENT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D12, APPARENT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M1, FREQ_POWER_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M2, MAX_CURRENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M4, MAX_CURRENT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M5, MIN_VOLTAGE_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M7, MIN_VOLTAGE_POWER3_TEXT) }, new Component[] { new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER1_TEXT, "actPower1Raw", 0.2F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER3_TEXT, "actPower3Raw", 0.2F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER_TOT_TEXT, "actPowerTotRaw", 0.2F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER1_TEXT, "reactPower1Raw", 0.2F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER3_TEXT, "reactPower3Raw", 0.2F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER_TOT_TEXT, "reactPowerTotRaw", 0.2F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER1_TEXT, "appPower1Raw", 0.2F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER3_TEXT, "appPower3Raw", 0.2F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER_TOT_TEXT, "appPowerTotRaw", 0.2F), new ProductDefinitions.PowerDirect(20, "Frequency", FREQ_POWER_TEXT, "freqPowerRaw", 16.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER1_TEXT, "maxCurPwr1Raw", 60.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER3_TEXT, "maxCurPwr3Raw", 60.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER1_TEXT, "minVoltPwr1Raw", 12.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER3_TEXT, "minVoltPwr3Raw", 12.0F) });

    registerNewProduct(XPOWER_1300_0006_NUMBER, XPOWER_1300_0006, product);

    product = new DefaultProduct(6, "XPOWER-1400", "W4 - Wye 4 wires", new ColumnDefinition[] { new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D1, ACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D2, ACT_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D3, ACT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D4, ACT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D5, REACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D6, REACT_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D7, REACT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D8, REACT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D9, APPARENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D10, APPARENT_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D11, APPARENT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D12, APPARENT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M1, FREQ_POWER_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M2, MAX_CURRENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M3, MAX_CURRENT_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M4, MAX_CURRENT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M5, MIN_VOLTAGE_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M6, MIN_VOLTAGE_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M7, MIN_VOLTAGE_POWER3_TEXT) }, new Component[] { new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER1_TEXT, "actPower1Raw", 0.2F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER2_TEXT, "actPower2Raw", 0.2F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER3_TEXT, "actPower3Raw", 0.2F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER_TOT_TEXT, "actPowerTotRaw", 0.2F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER1_TEXT, "reactPower1Raw", 0.2F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER2_TEXT, "reactPower2Raw", 0.2F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER3_TEXT, "reactPower3Raw", 0.2F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER_TOT_TEXT, "reactPowerTotRaw", 0.2F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER1_TEXT, "appPower1Raw", 0.2F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER2_TEXT, "appPower2Raw", 0.2F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER3_TEXT, "appPower3Raw", 0.2F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER_TOT_TEXT, "appPowerTotRaw", 0.2F), new ProductDefinitions.PowerDirect(20, "Frequency", FREQ_POWER_TEXT, "freqPowerRaw", 16.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER1_TEXT, "maxCurPwr1Raw", 30.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER2_TEXT, "maxCurPwr2Raw", 30.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER3_TEXT, "maxCurPwr3Raw", 30.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER1_TEXT, "minVoltPwr1Raw", 25.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER2_TEXT, "minVoltPwr2Raw", 25.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER3_TEXT, "minVoltPwr3Raw", 25.0F) });

    registerNewProduct(XPOWER_1400_0001_NUMBER, XPOWER_1400_0001, product);

    product = new DefaultProduct(6, "XPOWER-1400", "D3 - Delta 3 wires", new ColumnDefinition[] { new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D1, ACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D3, ACT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D4, ACT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D5, REACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D7, REACT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D8, REACT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D9, APPARENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D11, APPARENT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D12, APPARENT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M1, FREQ_POWER_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M2, MAX_CURRENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M4, MAX_CURRENT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M5, MIN_VOLTAGE_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M7, MIN_VOLTAGE_POWER3_TEXT) }, new Component[] { new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER1_TEXT, "actPower1Raw", 0.2F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER3_TEXT, "actPower3Raw", 0.2F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER_TOT_TEXT, "actPowerTotRaw", 0.2F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER1_TEXT, "reactPower1Raw", 0.2F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER3_TEXT, "reactPower3Raw", 0.2F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER_TOT_TEXT, "reactPowerTotRaw", 0.2F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER1_TEXT, "appPower1Raw", 0.2F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER3_TEXT, "appPower3Raw", 0.2F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER_TOT_TEXT, "appPowerTotRaw", 0.2F), new ProductDefinitions.PowerDirect(20, "Frequency", FREQ_POWER_TEXT, "freqPowerRaw", 16.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER1_TEXT, "maxCurPwr1Raw", 30.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER3_TEXT, "maxCurPwr3Raw", 30.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER1_TEXT, "minVoltPwr1Raw", 25.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER3_TEXT, "minVoltPwr3Raw", 25.0F) });

    registerNewProduct(XPOWER_1400_0002_NUMBER, XPOWER_1400_0002, product);

    product = new DefaultProduct(6, "XPOWER-1400", "D3/SP2 - Delta 3 wires, 24V supply", new ColumnDefinition[] { new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D1, ACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D3, ACT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D4, ACT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D5, REACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D7, REACT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D8, REACT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D9, APPARENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D11, APPARENT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D12, APPARENT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M1, FREQ_POWER_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M2, MAX_CURRENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M4, MAX_CURRENT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M5, MIN_VOLTAGE_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M7, MIN_VOLTAGE_POWER3_TEXT) }, new Component[] { new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER1_TEXT, "actPower1Raw", 0.1F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER3_TEXT, "actPower3Raw", 0.1F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER_TOT_TEXT, "actPowerTotRaw", 0.1F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER1_TEXT, "reactPower1Raw", 0.1F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER3_TEXT, "reactPower3Raw", 0.1F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER_TOT_TEXT, "reactPowerTotRaw", 0.1F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER1_TEXT, "appPower1Raw", 0.1F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER3_TEXT, "appPower3Raw", 0.1F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER_TOT_TEXT, "appPowerTotRaw", 0.1F), new ProductDefinitions.PowerDirect(20, "Frequency", FREQ_POWER_TEXT, "freqPowerRaw", 16.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER1_TEXT, "maxCurPwr1Raw", 30.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER3_TEXT, "maxCurPwr3Raw", 30.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER1_TEXT, "minVoltPwr1Raw", 12.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER3_TEXT, "minVoltPwr3Raw", 12.0F) });

    registerNewProduct(XPOWER_1400_0003_NUMBER, XPOWER_1400_0003, product);

    product = new DefaultProduct(6, "XPOWER-1500", "W4 - Wye 4 wires", new ColumnDefinition[] { new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D1, ACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D2, ACT_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D3, ACT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D4, ACT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D5, REACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D6, REACT_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D7, REACT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D8, REACT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D9, APPARENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D10, APPARENT_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D11, APPARENT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D12, APPARENT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M1, FREQ_POWER_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M2, MAX_CURRENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M3, MAX_CURRENT_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M4, MAX_CURRENT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M5, MIN_VOLTAGE_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M6, MIN_VOLTAGE_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M7, MIN_VOLTAGE_POWER3_TEXT) }, new Component[] { new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER1_TEXT, "actPower1Raw", 0.08F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER2_TEXT, "actPower2Raw", 0.08F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER3_TEXT, "actPower3Raw", 0.08F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER_TOT_TEXT, "actPowerTotRaw", 0.08F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER1_TEXT, "reactPower1Raw", 0.08F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER2_TEXT, "reactPower2Raw", 0.08F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER3_TEXT, "reactPower3Raw", 0.08F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER_TOT_TEXT, "reactPowerTotRaw", 0.08F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER1_TEXT, "appPower1Raw", 0.08F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER2_TEXT, "appPower2Raw", 0.08F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER3_TEXT, "appPower3Raw", 0.08F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER_TOT_TEXT, "appPowerTotRaw", 0.08F), new ProductDefinitions.PowerDirect(20, "Frequency", FREQ_POWER_TEXT, "freqPowerRaw", 16.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER1_TEXT, "maxCurPwr1Raw", 12.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER2_TEXT, "maxCurPwr2Raw", 12.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER3_TEXT, "maxCurPwr3Raw", 12.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER1_TEXT, "minVoltPwr1Raw", 25.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER2_TEXT, "minVoltPwr2Raw", 25.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER3_TEXT, "minVoltPwr3Raw", 25.0F) });

    registerNewProduct(XPOWER_1500_0001_NUMBER, XPOWER_1500_0001, product);

    product = new DefaultProduct(6, "XPOWER-1500", "D3 - Delta 3 wires", new ColumnDefinition[] { new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D1, ACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D3, ACT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D4, ACT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D5, REACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D7, REACT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D8, REACT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D9, APPARENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D11, APPARENT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D12, APPARENT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M1, FREQ_POWER_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M2, MAX_CURRENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M4, MAX_CURRENT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M5, MIN_VOLTAGE_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M7, MIN_VOLTAGE_POWER3_TEXT) }, new Component[] { new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER1_TEXT, "actPower1Raw", 0.08F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER3_TEXT, "actPower3Raw", 0.08F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER_TOT_TEXT, "actPowerTotRaw", 0.08F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER1_TEXT, "reactPower1Raw", 0.08F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER3_TEXT, "reactPower3Raw", 0.08F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER_TOT_TEXT, "reactPowerTotRaw", 0.08F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER1_TEXT, "appPower1Raw", 0.08F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER3_TEXT, "appPower3Raw", 0.08F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER_TOT_TEXT, "appPowerTotRaw", 0.08F), new ProductDefinitions.PowerDirect(20, "Frequency", FREQ_POWER_TEXT, "freqPowerRaw", 16.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER1_TEXT, "maxCurPwr1Raw", 12.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER3_TEXT, "maxCurPwr3Raw", 12.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER1_TEXT, "minVoltPwr1Raw", 25.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER3_TEXT, "minVoltPwr3Raw", 25.0F) });

    registerNewProduct(XPOWER_1500_0002_NUMBER, XPOWER_1500_0002, product);

    product = new DefaultProduct(6, "XPOWER-1500", "D3/SP2 - Delta 3 wires, 24V supply", new ColumnDefinition[] { new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D1, ACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D3, ACT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D4, ACT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D5, REACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D7, REACT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D8, REACT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D9, APPARENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D11, APPARENT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D12, APPARENT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M1, FREQ_POWER_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M2, MAX_CURRENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M4, MAX_CURRENT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M5, MIN_VOLTAGE_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M7, MIN_VOLTAGE_POWER3_TEXT) }, new Component[] { new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER1_TEXT, "actPower1Raw", 0.04F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER3_TEXT, "actPower3Raw", 0.04F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER_TOT_TEXT, "actPowerTotRaw", 0.04F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER1_TEXT, "reactPower1Raw", 0.04F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER3_TEXT, "reactPower3Raw", 0.04F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER_TOT_TEXT, "reactPowerTotRaw", 0.04F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER1_TEXT, "appPower1Raw", 0.04F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER3_TEXT, "appPower3Raw", 0.04F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER_TOT_TEXT, "appPowerTotRaw", 0.04F), new ProductDefinitions.PowerDirect(20, "Frequency", FREQ_POWER_TEXT, "freqPowerRaw", 16.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER1_TEXT, "maxCurPwr1Raw", 12.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER3_TEXT, "maxCurPwr3Raw", 12.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER1_TEXT, "minVoltPwr1Raw", 12.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER3_TEXT, "minVoltPwr3Raw", 12.0F) });

    registerNewProduct(XPOWER_1500_0003_NUMBER, XPOWER_1500_0003, product);

    product = new DefaultProduct(6, "XPOWER-1600", "W4 - Wye 4 wires", new ColumnDefinition[] { new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D1, ACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D2, ACT_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D3, ACT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D4, ACT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D5, REACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D6, REACT_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D7, REACT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D8, REACT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D9, APPARENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D10, APPARENT_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D11, APPARENT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D12, APPARENT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M1, FREQ_POWER_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M2, MAX_CURRENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M3, MAX_CURRENT_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M4, MAX_CURRENT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M5, MIN_VOLTAGE_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M6, MIN_VOLTAGE_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M7, MIN_VOLTAGE_POWER3_TEXT) }, new Component[] { new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER1_TEXT, "actPower1Raw", 0.04F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER2_TEXT, "actPower2Raw", 0.04F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER3_TEXT, "actPower3Raw", 0.04F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER_TOT_TEXT, "actPowerTotRaw", 0.04F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER1_TEXT, "reactPower1Raw", 0.04F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER2_TEXT, "reactPower2Raw", 0.04F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER3_TEXT, "reactPower3Raw", 0.04F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER_TOT_TEXT, "reactPowerTotRaw", 0.04F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER1_TEXT, "appPower1Raw", 0.04F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER2_TEXT, "appPower2Raw", 0.04F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER3_TEXT, "appPower3Raw", 0.04F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER_TOT_TEXT, "appPowerTotRaw", 0.04F), new ProductDefinitions.PowerDirect(20, "Frequency", FREQ_POWER_TEXT, "freqPowerRaw", 16.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER1_TEXT, "maxCurPwr1Raw", 6.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER2_TEXT, "maxCurPwr2Raw", 6.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER3_TEXT, "maxCurPwr3Raw", 6.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER1_TEXT, "minVoltPwr1Raw", 25.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER2_TEXT, "minVoltPwr2Raw", 25.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER3_TEXT, "minVoltPwr3Raw", 25.0F) });

    registerNewProduct(XPOWER_1600_0001_NUMBER, XPOWER_1600_0001, product);

    product = new DefaultProduct(6, "XPOWER-1600", "D3 - Delta 3 wires", new ColumnDefinition[] { new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D1, ACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D3, ACT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D4, ACT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D5, REACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D7, REACT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D8, REACT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D9, APPARENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D11, APPARENT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D12, APPARENT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M1, FREQ_POWER_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M2, MAX_CURRENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M4, MAX_CURRENT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M5, MIN_VOLTAGE_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M7, MIN_VOLTAGE_POWER3_TEXT) }, new Component[] { new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER1_TEXT, "actPower1Raw", 0.04F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER3_TEXT, "actPower3Raw", 0.04F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER_TOT_TEXT, "actPowerTotRaw", 0.04F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER1_TEXT, "reactPower1Raw", 0.04F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER3_TEXT, "reactPower3Raw", 0.04F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER_TOT_TEXT, "reactPowerTotRaw", 0.04F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER1_TEXT, "appPower1Raw", 0.04F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER3_TEXT, "appPower3Raw", 0.04F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER_TOT_TEXT, "appPowerTotRaw", 0.04F), new ProductDefinitions.PowerDirect(20, "Frequency", FREQ_POWER_TEXT, "freqPowerRaw", 16.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER1_TEXT, "maxCurPwr1Raw", 6.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER3_TEXT, "maxCurPwr3Raw", 6.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER1_TEXT, "minVoltPwr1Raw", 25.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER3_TEXT, "minVoltPwr3Raw", 25.0F) });

    registerNewProduct(XPOWER_1600_0002_NUMBER, XPOWER_1600_0002, product);

    product = new DefaultProduct(6, "XPOWER-1600", "D3/SP2 - Delta 3 wires, 24V supply", new ColumnDefinition[] { new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D1, ACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D3, ACT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D4, ACT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D5, REACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D7, REACT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D8, REACT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D9, APPARENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D11, APPARENT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D12, APPARENT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M1, FREQ_POWER_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M2, MAX_CURRENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M4, MAX_CURRENT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M5, MIN_VOLTAGE_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M7, MIN_VOLTAGE_POWER3_TEXT) }, new Component[] { new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER1_TEXT, "actPower1Raw", 0.02F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER3_TEXT, "actPower3Raw", 0.02F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER_TOT_TEXT, "actPowerTotRaw", 0.02F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER1_TEXT, "reactPower1Raw", 0.02F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER3_TEXT, "reactPower3Raw", 0.02F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER_TOT_TEXT, "reactPowerTotRaw", 0.02F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER1_TEXT, "appPower1Raw", 0.02F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER3_TEXT, "appPower3Raw", 0.02F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER_TOT_TEXT, "appPowerTotRaw", 0.02F), new ProductDefinitions.PowerDirect(20, "Frequency", FREQ_POWER_TEXT, "freqPowerRaw", 16.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER1_TEXT, "maxCurPwr1Raw", 6.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER3_TEXT, "maxCurPwr3Raw", 6.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER1_TEXT, "minVoltPwr1Raw", 12.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER3_TEXT, "minVoltPwr3Raw", 12.0F) });

    registerNewProduct(XPOWER_1600_0003_NUMBER, XPOWER_1600_0003, product);

    product = new DefaultProduct(6, "XPOWER-1700", "W4 - Wye 4 wires", new ColumnDefinition[] { new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D1, ACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D2, ACT_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D3, ACT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D4, ACT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D5, REACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D6, REACT_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D7, REACT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D8, REACT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D9, APPARENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D10, APPARENT_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D11, APPARENT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D12, APPARENT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M1, FREQ_POWER_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M2, MAX_CURRENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M3, MAX_CURRENT_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M4, MAX_CURRENT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M5, MIN_VOLTAGE_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M6, MIN_VOLTAGE_POWER2_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M7, MIN_VOLTAGE_POWER3_TEXT) }, new Component[] { new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER1_TEXT, "actPower1Raw", 0.02F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER2_TEXT, "actPower2Raw", 0.02F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER3_TEXT, "actPower3Raw", 0.02F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER_TOT_TEXT, "actPowerTotRaw", 0.02F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER1_TEXT, "reactPower1Raw", 0.02F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER2_TEXT, "reactPower2Raw", 0.02F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER3_TEXT, "reactPower3Raw", 0.02F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER_TOT_TEXT, "reactPowerTotRaw", 0.02F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER1_TEXT, "appPower1Raw", 0.02F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER2_TEXT, "appPower2Raw", 0.02F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER3_TEXT, "appPower3Raw", 0.02F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER_TOT_TEXT, "appPowerTotRaw", 0.02F), new ProductDefinitions.PowerDirect(20, "Frequency", FREQ_POWER_TEXT, "freqPowerRaw", 16.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER1_TEXT, "maxCurPwr1Raw", 3.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER2_TEXT, "maxCurPwr2Raw", 3.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER3_TEXT, "maxCurPwr3Raw", 3.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER1_TEXT, "minVoltPwr1Raw", 25.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER2_TEXT, "minVoltPwr2Raw", 25.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER3_TEXT, "minVoltPwr3Raw", 25.0F) });

    registerNewProduct(XPOWER_1700_0001_NUMBER, XPOWER_1700_0001, product);

    product = new DefaultProduct(6, "XPOWER-1700", "D3 - Delta 3 wires", new ColumnDefinition[] { new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D1, ACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D3, ACT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D4, ACT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D5, REACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D7, REACT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D8, REACT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D9, APPARENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D11, APPARENT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D12, APPARENT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M1, FREQ_POWER_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M2, MAX_CURRENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M4, MAX_CURRENT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M5, MIN_VOLTAGE_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M7, MIN_VOLTAGE_POWER3_TEXT) }, new Component[] { new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER1_TEXT, "actPower1Raw", 0.02F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER3_TEXT, "actPower3Raw", 0.02F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER_TOT_TEXT, "actPowerTotRaw", 0.02F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER1_TEXT, "reactPower1Raw", 0.02F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER3_TEXT, "reactPower3Raw", 0.02F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER_TOT_TEXT, "reactPowerTotRaw", 0.02F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER1_TEXT, "appPower1Raw", 0.02F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER3_TEXT, "appPower3Raw", 0.02F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER_TOT_TEXT, "appPowerTotRaw", 0.02F), new ProductDefinitions.PowerDirect(20, "Frequency", FREQ_POWER_TEXT, "freqPowerRaw", 16.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER1_TEXT, "maxCurPwr1Raw", 3.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER3_TEXT, "maxCurPwr3Raw", 3.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER1_TEXT, "minVoltPwr1Raw", 25.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER3_TEXT, "minVoltPwr3Raw", 25.0F) });

    registerNewProduct(XPOWER_1700_0002_NUMBER, XPOWER_1700_0002, product);

    product = new DefaultProduct(6, "XPOWER-1700", "D3/SP2 - Delta 3 wires, 24V supply", new ColumnDefinition[] { new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D1, ACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D3, ACT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D4, ACT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D5, REACT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D7, REACT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D8, REACT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D9, APPARENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D11, APPARENT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_D12, APPARENT_POWER_TOT_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M1, FREQ_POWER_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M2, MAX_CURRENT_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M4, MAX_CURRENT_POWER3_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M5, MIN_VOLTAGE_POWER1_TEXT), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M7, MIN_VOLTAGE_POWER3_TEXT) }, new Component[] { new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER1_TEXT, "actPower1Raw", 0.01F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER3_TEXT, "actPower3Raw", 0.01F), new ProductDefinitions.PowerDirect(14, "Active Power", ACT_POWER_TOT_TEXT, "actPowerTotRaw", 0.01F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER1_TEXT, "reactPower1Raw", 0.01F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER3_TEXT, "reactPower3Raw", 0.01F), new ProductDefinitions.PowerDirect(18, "Reactive Power", REACT_POWER_TOT_TEXT, "reactPowerTotRaw", 0.01F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER1_TEXT, "appPower1Raw", 0.01F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER3_TEXT, "appPower3Raw", 0.01F), new ProductDefinitions.PowerDirect(19, "Apparent Power", APPARENT_POWER_TOT_TEXT, "appPowerTotRaw", 0.01F), new ProductDefinitions.PowerDirect(20, "Frequency", FREQ_POWER_TEXT, "freqPowerRaw", 16.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER1_TEXT, "maxCurPwr1Raw", 3.0F), new ProductDefinitions.PowerDirect(21, "Max current", MAX_CURRENT_POWER3_TEXT, "maxCurPwr3Raw", 3.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER1_TEXT, "minVoltPwr1Raw", 12.0F), new ProductDefinitions.PowerDirect(22, "Min voltage", MIN_VOLTAGE_POWER3_TEXT, "minVoltPwr3Raw", 12.0F) });

    registerNewProduct(XPOWER_1700_0003_NUMBER, XPOWER_1700_0003, product);

    product = new DefaultProduct(8, "XCO2-1001", "2x CO2 probes with thermistors", new ColumnDefinition[] { new ColumnDefinition("temp", false), new ColumnDefinition("temp2", false), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M1, VOLTAGE1_TEXT, false), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M2, VOLTAGE2_TEXT, false), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M3, CO2A_TEXT, true), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M4, CO2B_TEXT, true) }, new Component[] { new ProductDefinitions.ConvertFarenheit("rawTemp", "temp"), new ProductDefinitions.ConvertFarenheit("rawTemp2", "temp2"), new ProductDefinitions.VoltageDirect(VOLTAGE1_TEXT, "voltage1Raw"), new ProductDefinitions.VoltageDirect(VOLTAGE2_TEXT, "voltage2Raw"), new ProductDefinitions.CO2Direct(CO2A_TEXT, "co2ARaw"), new ProductDefinitions.CO2Direct(CO2B_TEXT, "co2BRaw") });

    product.setCalibrationAvailable(false);
    registerNewProduct(XCO2_1001_0001_NUMBER, XCO2_1001_0001, product);

    product = new DefaultProduct(8, "XCO2-1100", "CO2 probe with SHT11 (Senseair)", new ColumnDefinition[] { new ColumnDefinition("temp", false), new ColumnDefinition("temp2", false), new ColumnDefinition("light", false), new ColumnDefinition("tempInt", false), new ColumnDefinition("hum", false), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M1, CO2_TEXT, false), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M2, BATT_VOLT_TEXT, false) }, new Component[] { new ProductDefinitions.ConvertFarenheit("rawTemp", "temp"), new ProductDefinitions.ConvertFarenheit("rawTemp2", "temp2"), new ProductDefinitions.DirectLightSensor(), new ProductDefinitions.ConvertFarenheit("rawTempInt", "tempInt"), new ProductDefinitions.HumidityDirect("hum", "rawHum"), new ProductDefinitions.CO2Direct(CO2_TEXT, CO2_RAW_TEXT), new ConfigurableSensor(BATT_VOLT_TEXT, BATT_VOLT_RAW_TEXT, 12, "Batterey voltage") });

    product.setCalibrationAvailable(false);
    product.setInternalTemp("tempInt");
    registerNewProduct(XCO2_1100_0001_NUMBER, XCO2_1100_0001, product);

    product = new DefaultProduct(8, "XCO2-1101", "CO2 probe with SHT11 (SST)", new ColumnDefinition[] { new ColumnDefinition("tempInt", false), new ColumnDefinition("hum", false), new ColumnDefinition(com.aginova.app.oilgas.Topics.COLUMN_NAME_M1, CO2_TEXT, false) }, new Component[] { new ProductDefinitions.ConvertFarenheit("rawTempInt", "tempInt"), new ProductDefinitions.HumidityDirect("hum", "rawHum"), new ProductDefinitions.CO2Direct(CO2_TEXT, CO2_RAW_TEXT) });

    product.setCalibrationAvailable(false);
    product.setInternalTemp("tempInt");
    registerNewProduct(XCO2_1101_0001_NUMBER, XCO2_1101_0001, product);

    logger.debug("Populate done");
  }

  public Float getValueForProduct(String product_name, Message data, String column)
    throws Exception
  {
    try
    {
      String sensorType = getSensorTypeFromColumn(column, product_name);
      return data.getFloatValue(sensorType); } catch (ColumnNotFoundException cnfe) {
    }
    return null;
  }

  public Double getDoubleValueForProduct(String product_name, Message data, String column)
    throws Exception
  {
    try
    {
      String sensorType = getSensorTypeFromColumn(column, product_name);
      return data.getDoubleValue(sensorType); } catch (ColumnNotFoundException cnfe) {
    }
    return null;
  }

  public String getSensorTypeFromColumn(String column, String product_name)
    throws Exception
  {
    Product product = getProductDescriptionFromName(product_name);

    String[] columns = product.getAvailableDataColumns();
    String[] sensorTypes = product.getAvailableSensorTypes();

    int index = ArrayTools.indexOf(columns, column);
    if (index == -1) {
      throw new ColumnNotFoundException("Could not find column " + column + " in " + ArrayTools.arrayToStringVisual(columns) + " for product " + product_name);
    }

    return sensorTypes[index];
  }

  public void convertData(String product_number, Message data, Object[][][] calibrationData)
    throws Exception
  {
    if (data == null)
      throw new Exception("Cannot have an empty data message!");
    String data_typeStr = data.getValue("data_type");
    boolean debug = logger.isDebugEnabled();
    if (!Tools.isNotEmptyNullOrNullString(data_typeStr)) {
      throw new RuntimeException("Data without datatype, there is a serious problem.");
    }
    int data_type = Integer.parseInt(data_typeStr);
    if (debug)
      logger.debug("Parsing data of type " + data_type + " with data " + data);
    String dataStr = data.getValue("data");
    Product pr = getProductDescriptionFromName(product_number);

    if (data_type == 1) {
      if ((dataStr == null) || (dataStr.length() < 16)) {
        throw new Exception("Invalid data " + dataStr + ", either null or too short!");
      }

      int raw_temp_ext_adc = Integer.parseInt(dataStr.substring(0, 4), 16);
      int raw_temp_int_adc = Integer.parseInt(dataStr.substring(4, 8), 16);
      int raw_hum_adc = Integer.parseInt(dataStr.substring(8, 12), 16);
      int raw_light_adc = Integer.parseInt(dataStr.substring(12, 16), 16);

      if (debug)
        logger.debug("raw_temp_ext_adc " + raw_temp_ext_adc);
      data.setValue("rawTemp", "" + raw_temp_ext_adc);
      getConverted(pr, "temp", data, calibrationData);

      data.setValue("rawTempInt", "" + raw_temp_int_adc);
      getConverted(pr, "tempInt", data, calibrationData);

      data.setValue("rawHum", "" + raw_hum_adc);
      getConverted(pr, "hum", data, calibrationData);

      data.setValue("rawLight", "" + raw_light_adc);
      getConverted(pr, "light", data, calibrationData);

      if (debug)
        logger.debug("Data map after conversion " + data);
    }
    else if (data_type == 2) {
      int raw_wet_1_adc = Integer.parseInt(dataStr.substring(0, 4), 16);
      int raw_wet_2_adc = Integer.parseInt(dataStr.substring(4, 8), 16);
      int raw_wet_3_adc = Integer.parseInt(dataStr.substring(8, 12), 16);
      int raw_wet_4_adc = Integer.parseInt(dataStr.substring(12, 16), 16);

      if (debug)
        logger.debug("raw_wet_1_adc " + raw_wet_1_adc);
      data.setValue("rawWetness1", "" + raw_wet_1_adc);
      getConverted(pr, "wetness1", data, calibrationData);

      if (debug)
        logger.debug("raw_wet_2_adc " + raw_wet_2_adc);
      data.setValue("rawWetness2", "" + raw_wet_2_adc);
      getConverted(pr, "wetness2", data, calibrationData);

      if (debug)
        logger.debug("raw_wet_3_adc " + raw_wet_3_adc);
      data.setValue("rawWetness3", "" + raw_wet_3_adc);
      getConverted(pr, "wetness3", data, calibrationData);

      if (debug)
        logger.debug("raw_wet_4_adc " + raw_wet_4_adc);
      data.setValue("rawWetness4", "" + raw_wet_4_adc);
      getConverted(pr, "wetness4", data, calibrationData);

      if (debug)
        logger.debug("Type 2: Data map after conversion " + data);
    } else if (data_type == 3)
    {
      int raw_temp_ext_adc = Integer.parseInt(dataStr.substring(0, 4), 16);
      int raw_high_impedance_probe = ArrayTools.convertHexToSignedShort(dataStr.substring(4, 8)).shortValue();

      float raw_oxy_pol = ArrayTools.convertHexToFloat(dataStr.substring(8, 16)).floatValue();
      float raw_temp_pol_rtd = ArrayTools.convertHexToFloat(dataStr.substring(16, 24)).floatValue();

      if (debug) {
        logger.debug("raw_temp_ext_adc " + raw_temp_ext_adc);
        logger.debug("raw_oxy_pol " + raw_oxy_pol);
        logger.debug("raw_temp_pol_rtd " + raw_temp_pol_rtd);
        logger.debug("raw_high_impedance_probe " + raw_high_impedance_probe);
      }

      data.setValue("rawTemp", Integer.valueOf(raw_temp_ext_adc));
      getConverted(pr, "temp", data, calibrationData);

      data.setValue("rawHighImpedance", Integer.valueOf(raw_high_impedance_probe));
      getConverted(pr, "highImpedance", data, calibrationData);

      data.setValue("rawOxySensor", Float.valueOf(raw_oxy_pol));
      getConverted(pr, "oxySensor", data, calibrationData);

      data.setValue("rawPSRTD", Float.valueOf(raw_temp_pol_rtd));
      getConverted(pr, "temp2", data, calibrationData);
    } else if (data_type == 4) {
      Short raw_temp_ext_adc_1 = ArrayTools.convertHexToSignedShort(dataStr.substring(0, 4));

      Short raw_temp_ext_adc_2 = ArrayTools.convertHexToSignedShort(dataStr.substring(4, 8));

      int raw_light_adc = Integer.parseInt(dataStr.substring(12, 16), 16);

      if (raw_temp_ext_adc_1.shortValue() == -32768) {
        raw_temp_ext_adc_1 = null;
      }
      if (raw_temp_ext_adc_2.shortValue() == -32768) {
        raw_temp_ext_adc_2 = null;
      }

      if (debug) {
        logger.debug("Data type 4 raw_temp_ext_adc_1=" + raw_temp_ext_adc_1 + ",raw_temp_ext_adc_2 " + raw_temp_ext_adc_2);
      }

      data.setValue("rawTemp", raw_temp_ext_adc_1);
      data.setValue("rawTemp2", raw_temp_ext_adc_2);
      data.setValue("rawLight", "" + raw_light_adc);

      getConverted(pr, "temp", data, calibrationData);
      getConverted(pr, "temp2", data, calibrationData);
      getConverted(pr, "light", data, calibrationData);

      if (debug) logger.debug("Get converted done");
    }
    else if (data_type == 5)
    {
      int raw_temp_ext_adc_1 = ArrayTools.convertHexToSignedShort(dataStr.substring(0, 4)).shortValue();

      int raw_temp_ext_adc_2 = ArrayTools.convertHexToSignedShort(dataStr.substring(4, 8)).shortValue();

      int raw_temp_int_adc = Integer.parseInt(dataStr.substring(8, 12), 16);
      int raw_hum_adc = Integer.parseInt(dataStr.substring(12, 16), 16);
      int raw_light_adc = Integer.parseInt(dataStr.substring(16, 20), 16);

      if (debug) {
        logger.debug("Data type 5 raw_temp_ext_adc_1=" + raw_temp_ext_adc_1 + ",raw_temp_ext_adc_2 " + raw_temp_ext_adc_2);
      }

      data.setValue("rawTemp", "" + raw_temp_ext_adc_1);
      data.setValue("rawTemp2", "" + raw_temp_ext_adc_2);
      data.setValue("rawTempInt", "" + raw_temp_int_adc);
      data.setValue("rawHum", "" + raw_hum_adc);
      data.setValue("rawLight", "" + raw_light_adc);

      getConverted(pr, "temp", data, calibrationData);
      getConverted(pr, "temp2", data, calibrationData);
      getConverted(pr, "tempInt", data, calibrationData);
      getConverted(pr, "hum", data, calibrationData);
      getConverted(pr, "light", data, calibrationData);
    } else if (data_type == 6)
    {
      Integer[] raw_channels = new Integer[16];
      for (int i = 0; i < 16; i++) {
        raw_channels[i] = ArrayTools.hex32BitsToSignedInteger(dataStr.substring(8 * i, 8 * (i + 1)));
      }

      data.setValue("rawTMAS", raw_channels);
      getConverted(pr, "tmas", data, calibrationData);

      int raw_temp_int = ArrayTools.convertHexToSignedShort(dataStr.substring(128, 136)).shortValue();

      data.setValue("rawTemp", "" + raw_temp_int);
      getConverted(pr, "temp", data, calibrationData);
    }
    else if (data_type == 7)
    {
      int raw_rtd1_adc1 = ArrayTools.convertHexToSignedShort(dataStr.substring(0, 4)).shortValue();
      int raw_rtd1_adc2 = ArrayTools.convertHexToSignedShort(dataStr.substring(4, 8)).shortValue();
      int raw_rtd1_adc3 = ArrayTools.convertHexToSignedShort(dataStr.substring(8, 12)).shortValue();
      int raw_rtd1_adc4 = ArrayTools.convertHexToSignedShort(dataStr.substring(12, 16)).shortValue();

      int raw_rtd2_adc1 = ArrayTools.convertHexToSignedShort(dataStr.substring(16, 20)).shortValue();
      int raw_rtd2_adc2 = ArrayTools.convertHexToSignedShort(dataStr.substring(20, 24)).shortValue();
      int raw_rtd2_adc3 = ArrayTools.convertHexToSignedShort(dataStr.substring(24, 28)).shortValue();
      int raw_rtd2_adc4 = ArrayTools.convertHexToSignedShort(dataStr.substring(28, 32)).shortValue();

      int raw_digital_input_adc = ArrayTools.convertHexToSignedShort(dataStr.substring(32, 36)).shortValue();

      if (debug) {
        logger.debug("raw_rtd1_adc1 " + raw_rtd1_adc1);
        logger.debug("raw_rtd1_adc2 " + raw_rtd1_adc2);
        logger.debug("raw_rtd1_adc3 " + raw_rtd1_adc3);
        logger.debug("raw_rtd1_adc4 " + raw_rtd1_adc4);

        logger.debug("raw_rtd2_adc1 " + raw_rtd2_adc1);
        logger.debug("raw_rtd2_adc2 " + raw_rtd2_adc2);
        logger.debug("raw_rtd2_adc3 " + raw_rtd2_adc3);
        logger.debug("raw_rtd2_adc4 " + raw_rtd2_adc4);
      }

      data.setValue("rawRTD1Sensor1", Integer.valueOf(raw_rtd1_adc1));
      data.setValue("rawRTD1Sensor2", Integer.valueOf(raw_rtd1_adc2));
      data.setValue("rawRTD1Sensor3", Integer.valueOf(raw_rtd1_adc3));
      data.setValue("rawRTD1Sensor4", Integer.valueOf(raw_rtd1_adc4));
      getConverted(pr, "temp", data, calibrationData);

      data.setValue("rawRTD2Sensor1", Integer.valueOf(raw_rtd2_adc1));
      data.setValue("rawRTD2Sensor2", Integer.valueOf(raw_rtd2_adc2));
      data.setValue("rawRTD2Sensor3", Integer.valueOf(raw_rtd2_adc3));
      data.setValue("rawRTD2Sensor4", Integer.valueOf(raw_rtd2_adc4));
      getConverted(pr, "temp2", data, calibrationData);

      if (debug)
        logger.debug("raw_digital_input_adc " + raw_digital_input_adc);
      data.setValue("rawDigitalInSensor", Integer.valueOf(raw_digital_input_adc));
      getConverted(pr, DIGITAL_IN_SENSOR_TEXT, data, calibrationData);
    } else if (data_type == 8)
    {
      int raw_temp_ext_adc = Integer.parseInt(dataStr.substring(0, 4), 16);
      int raw_temp_int_adc = Integer.parseInt(dataStr.substring(4, 8), 16);
      int raw_hum_adc = Integer.parseInt(dataStr.substring(8, 12), 16);
      int raw_corr1 = Integer.parseInt(dataStr.substring(12, 16), 16);
      int raw_corr2 = Integer.parseInt(dataStr.substring(16, 20), 16);
      int raw_corr3 = Integer.parseInt(dataStr.substring(20, 24), 16);
      int raw_wet_1_adc = Integer.parseInt(dataStr.substring(24, 28), 16);
      int raw_wet_2_adc = Integer.parseInt(dataStr.substring(28, 32), 16);
      int raw_wet_3_adc = Integer.parseInt(dataStr.substring(32, 36), 16);

      int raw_cds_real1 = ArrayTools.convertHexToSignedShort(dataStr.substring(36, 40)).shortValue();

      int raw_cds_imaginary1 = ArrayTools.convertHexToSignedShort(dataStr.substring(40, 44)).shortValue();

      int raw_cds_real2 = ArrayTools.convertHexToSignedShort(dataStr.substring(44, 48)).shortValue();
      int raw_cds_imaginary2 = ArrayTools.convertHexToSignedShort(dataStr.substring(48, 52)).shortValue();

      data.setValue("rawTemp", "" + raw_temp_ext_adc);
      data.setValue("rawTempInt", "" + raw_temp_int_adc);
      data.setValue("rawHum", "" + raw_hum_adc);
      data.setValue("rawCorr1", "" + raw_corr1);
      data.setValue("rawCorr2", "" + raw_corr2);
      data.setValue("rawCorr3", "" + raw_corr3);
      data.setValue("rawWetness1", "" + raw_wet_1_adc);
      data.setValue("rawWetness2", "" + raw_wet_2_adc);
      data.setValue("rawWetness3", "" + raw_wet_3_adc);

      data.setValue("rawCDSReal1", "" + raw_cds_real1);
      data.setValue("rawCDSImaginary1", "" + raw_cds_imaginary1);
      data.setValue("rawCDSReal2", "" + raw_cds_real2);
      data.setValue("rawCDSImaginary2", "" + raw_cds_imaginary2);

      if (debug) {
        logger.debug("Data before " + data);
      }
      getConverted(pr, "temp", data, calibrationData);
      getConverted(pr, "tempInt", data, calibrationData);
      getConverted(pr, "hum", data, calibrationData);
      getConverted(pr, "corr1", data, calibrationData);
      getConverted(pr, "corr2", data, calibrationData);
      getConverted(pr, "corr3", data, calibrationData);
      getConverted(pr, "wetness1", data, calibrationData);
      getConverted(pr, "wetness2", data, calibrationData);
      getConverted(pr, "wetness3", data, calibrationData);

      getConverted(pr, "CDSReal1", data, calibrationData);
      getConverted(pr, "CDSImaginary1", data, calibrationData);
      getConverted(pr, "CDSReal2", data, calibrationData);
      getConverted(pr, "CDSImaginary2", data, calibrationData);

      if (debug)
        logger.debug("Data after " + data);
    } else if (data_type == 9) {
      if ((dataStr == null) || (dataStr.length() < 20)) {
        throw new Exception("Invalid data " + dataStr + ", either null or too short!");
      }

      int raw_acoustic_adc = Integer.parseInt(dataStr.substring(0, 4), 16);
      int raw_temp_int_adc = Integer.parseInt(dataStr.substring(4, 8), 16);
      int raw_hum_adc = Integer.parseInt(dataStr.substring(8, 12), 16);
      int raw_light_adc = Integer.parseInt(dataStr.substring(12, 16), 16);
      int raw_particles_adc = Integer.parseInt(dataStr.substring(16, 20), 16);
      int raw_not_used_adc = Integer.parseInt(dataStr.substring(20, 24), 16);

      data.setValue("rawAcousticSensor", "" + raw_acoustic_adc);
      getConverted(pr, "acousticSensor", data, calibrationData);

      data.setValue("rawTempInt", "" + raw_temp_int_adc);
      getConverted(pr, "tempInt", data, calibrationData);

      data.setValue("rawHum", "" + raw_hum_adc);
      getConverted(pr, "hum", data, calibrationData);

      data.setValue("rawLight", "" + raw_light_adc);
      getConverted(pr, "light", data, calibrationData);

      data.setValue("rawParticlesSensor", "" + raw_particles_adc);
      getConverted(pr, "particlesSensor", data, calibrationData);

      data.setValue("rawTemp", "" + raw_not_used_adc);
      getConverted(pr, "temp", data, calibrationData);

      if (debug)
        logger.debug("Data map after conversion " + data);
    } else if (data_type == 10)
    {
      if (debug)
        logger.debug("Data string " + dataStr + ", length " + dataStr.length());
      int pos = 0;
      int rawTemp = ArrayTools.read16BitsLSB(dataStr.substring(pos, 4)).intValue();
      pos += 4;

      int[] rawCorr = new int[48];
      int[] rawWet = new int[48];

      for (int i = 0; i < 24; i++) {
        rawCorr[i] = ArrayTools.read16BitsLSB(dataStr.substring(pos + i * 4, pos + i * 4 + 4)).intValue();

        rawWet[i] = ArrayTools.read16BitsLSB(dataStr.substring(96 + pos + i * 4, 96 + pos + i * 4 + 4)).intValue();

        if (debug) {
          logger.debug("Got rawWet[i] " + rawWet[i] + ", rawCorr[i] " + rawCorr[i]);
        }
      }
      data.setValue("rawTemp", "" + rawTemp);
      data.setValue("corrRaw", rawCorr);
      data.setValue("wetRaw", rawWet);
      getConverted(pr, "temp", data, calibrationData);
      getConverted(pr, "corr", data, calibrationData);
      getConverted(pr, "wet", data, calibrationData);
    }
    else if (data_type == 12)
    {
      Float raw_temp_ext1_adc = getNullableIntegerAsFloat(dataStr.substring(0, 4));
      if (raw_temp_ext1_adc != null) {
        raw_temp_ext1_adc = Float.valueOf(raw_temp_ext1_adc.floatValue() / 100.0F - 250.0F);
      }

      data.setValue("rawTemp", raw_temp_ext1_adc);

      getConverted(pr, "temp", data, calibrationData);
    }
    else if (data_type == 13)
    {
      Float raw_temp_ext1_adc = getNullableIntegerAsFloat(dataStr.substring(0, 4));
      if (raw_temp_ext1_adc != null) {
        raw_temp_ext1_adc = Float.valueOf(raw_temp_ext1_adc.floatValue() / 100.0F - 250.0F);
      }

      Float raw_temp_ext2_adc = getNullableIntegerAsFloat(dataStr.substring(4, 8));
      if (raw_temp_ext2_adc != null) {
        raw_temp_ext2_adc = Float.valueOf(raw_temp_ext2_adc.floatValue() / 100.0F - 250.0F);
      }

      float raw_light_adc = Integer.parseInt(dataStr.substring(12, 16), 16) / 10.0F;

      if (debug) {
        logger.debug("raw_temp_ext1_adc " + raw_temp_ext1_adc + ",raw_temp_ext2_adc " + raw_temp_ext2_adc);
      }

      data.setValue("rawTemp", raw_temp_ext1_adc);
      data.setValue("rawTemp2", raw_temp_ext2_adc);
      data.setValue("rawLight", "" + raw_light_adc);

      getConverted(pr, "temp", data, calibrationData);
      getConverted(pr, "temp2", data, calibrationData);
      getConverted(pr, "light", data, calibrationData);
    } else if (data_type == 14)
    {
      Float raw_temp_ext1_adc = getNullableIntegerAsFloat(dataStr.substring(0, 4));
      if (raw_temp_ext1_adc != null) {
        raw_temp_ext1_adc = Float.valueOf(raw_temp_ext1_adc.floatValue() / 100.0F - 250.0F);
      }

      Float raw_temp_ext2_adc = getNullableIntegerAsFloat(dataStr.substring(4, 8));
      if (raw_temp_ext2_adc != null) {
        raw_temp_ext2_adc = Float.valueOf(raw_temp_ext2_adc.floatValue() / 100.0F - 250.0F);
      }

      float raw_light_adc = Integer.parseInt(dataStr.substring(8, 12), 16) / 10.0F;

      Float internalTemp = getNullableIntegerAsFloat(dataStr.substring(16, 20));
      if (internalTemp != null) {
        internalTemp = Float.valueOf(internalTemp.floatValue() / 100.0F - 250.0F);
      }

      Float internalHum = getNullableIntegerAsFloat(dataStr.substring(20, 24));
      if (internalHum != null) {
        internalHum = Float.valueOf(internalHum.floatValue() / 100.0F);
      }

      if (debug) {
        logger.debug("raw_temp_ext1_adc " + raw_temp_ext1_adc + ",raw_temp_ext2_adc " + raw_temp_ext2_adc + ", internalTemp " + internalTemp + ", internalHum " + internalHum);
      }

      data.setValue("rawTemp", raw_temp_ext1_adc);
      data.setValue("rawTemp2", raw_temp_ext2_adc);
      data.setValue("rawLight", "" + raw_light_adc);
      data.setValue("rawTempInt", internalTemp);
      data.setValue("rawHum", internalHum);

      getConverted(pr, "temp", data, calibrationData);
      getConverted(pr, "temp2", data, calibrationData);
      getConverted(pr, "light", data, calibrationData);
      getConverted(pr, "tempInt", data, calibrationData);
      getConverted(pr, "hum", data, calibrationData);
    } else if (data_type == 15)
    {
      int raw_temp_int = ArrayTools.convertHexToSignedShort(dataStr.substring(0, 4)).shortValue();

      Float rawMasAvgCorr = ArrayTools.convertHexStringToFloat(dataStr.substring(4, 12));
      Float rawMasMaxCorr = ArrayTools.convertHexStringToFloat(dataStr.substring(12, 20));

      data.setValue("rawTemp", Integer.valueOf(raw_temp_int));
      data.setValue("rawMasCorrAvg", rawMasAvgCorr);
      data.setValue("rawMasCorrMax", rawMasMaxCorr);

      getConverted(pr, "temp", data, calibrationData);
      getConverted(pr, "masCorrAvg", data, calibrationData);
      getConverted(pr, "masCorrMax", data, calibrationData);
    } else if (data_type == 16) {
      Float raw_rtd1 = getNullableIntegerAsFloat(dataStr.substring(0, 4));
      Float raw_rtd2 = getNullableIntegerAsFloat(dataStr.substring(4, 8));

      if (raw_rtd1 != null) {
        logger.debug("DEBUG - raw_rtd1 " + raw_rtd1);
        raw_rtd1 = Float.valueOf(raw_rtd1.floatValue() / 100.0F - 220.0F);
      }

      if (raw_rtd2 != null) {
        logger.debug("DEBUG - raw_rtd2 " + raw_rtd2);
        raw_rtd2 = Float.valueOf(raw_rtd2.floatValue() / 100.0F - 220.0F);
      }

      int raw_digital_input_adc = ArrayTools.convertHexToSignedShort(dataStr.substring(12, 16)).shortValue();

      data.setValue("rawRTD1Sensor", raw_rtd1);
      data.setValue("rawRTD2Sensor", raw_rtd2);
      data.setValue("rawDigitalInSensor", Integer.valueOf(raw_digital_input_adc));

      getConverted(pr, "temp", data, calibrationData);
      getConverted(pr, "temp2", data, calibrationData);
      getConverted(pr, DIGITAL_IN_SENSOR_TEXT, data, calibrationData);
    } else if (data_type == 17)
    {
      Double actPow1 = ArrayTools.convertHexStringToDouble(dataStr.substring(0, 8));
      Double actPow2 = ArrayTools.convertHexStringToDouble(dataStr.substring(8, 16));
      Double actPow3 = ArrayTools.convertHexStringToDouble(dataStr.substring(16, 24));
      Double actPowTot = ArrayTools.convertHexStringToDouble(dataStr.substring(24, 32));
      logger.debug("dataStr " + dataStr + ", length " + dataStr.length() + ", actPow1 " + actPow1 + ", actPow2 " + actPow2 + ", actPow 3 " + actPow3);

      data.setValue("actPower1Raw", actPow1);
      data.setValue("actPower2Raw", actPow2);
      data.setValue("actPower3Raw", actPow3);
      data.setValue("actPowerTotRaw", actPowTot);

      getConverted(pr, ACT_POWER1_TEXT, data, calibrationData);
      getConverted(pr, ACT_POWER2_TEXT, data, calibrationData);
      getConverted(pr, ACT_POWER3_TEXT, data, calibrationData);
      getConverted(pr, ACT_POWER_TOT_TEXT, data, calibrationData);
    } else if (data_type == 18) {
      Float raw_temp1 = getNullableIntegerAsFloat(dataStr.substring(0, 4));
      if (raw_temp1 != null) {
        raw_temp1 = Float.valueOf(raw_temp1.floatValue() / 100.0F - 250.0F);
      }

      Float raw_temp2 = getNullableIntegerAsFloat(dataStr.substring(4, 8));
      if (raw_temp2 != null) {
        raw_temp2 = Float.valueOf(raw_temp2.floatValue() / 100.0F - 250.0F);
      }

      Float raw_volt1 = getNullableIntegerAsFloat(dataStr.substring(8, 12));
      if (raw_volt1 != null) {
        raw_volt1 = Float.valueOf(raw_volt1.floatValue() / 10.0F - 1000.0F);
      }

      Float raw_volt2 = getNullableIntegerAsFloat(dataStr.substring(12, 16));
      if (raw_volt2 != null) {
        raw_volt2 = Float.valueOf(raw_volt2.floatValue() / 10.0F - 1000.0F);
      }

      Float raw_ph1 = getNullableIntegerAsFloat(dataStr.substring(16, 20));
      if (raw_ph1 != null) {
        raw_ph1 = Float.valueOf(raw_ph1.floatValue() / 1000.0F - 5.0F);
      }

      Float raw_ph2 = getNullableIntegerAsFloat(dataStr.substring(20, 24));
      if (raw_ph2 != null) {
        raw_ph2 = Float.valueOf(raw_ph2.floatValue() / 1000.0F - 5.0F);
      }

      data.setValue("rawTemp", raw_temp1);
      data.setValue("rawTemp2", raw_temp2);

      data.setValue("voltage1Raw", raw_volt1);
      data.setValue("voltage2Raw", raw_volt2);

      data.setValue("ph1Raw", raw_ph1);
      data.setValue("ph2Raw", raw_ph2);

      getConverted(pr, "temp", data, calibrationData);
      getConverted(pr, "temp2", data, calibrationData);
      getConverted(pr, VOLTAGE1_TEXT, data, calibrationData);
      getConverted(pr, VOLTAGE2_TEXT, data, calibrationData);
      getConverted(pr, PH1_TEXT, data, calibrationData);
      getConverted(pr, PH2_TEXT, data, calibrationData);
    }
    else if (data_type == 19)
    {
      Double reactPow1 = ArrayTools.convertHexStringToDouble(dataStr.substring(0, 8));
      Double reactPow2 = ArrayTools.convertHexStringToDouble(dataStr.substring(8, 16));
      Double reactPow3 = ArrayTools.convertHexStringToDouble(dataStr.substring(16, 24));
      Double reactPowTot = ArrayTools.convertHexStringToDouble(dataStr.substring(24, 32));
      logger.debug("reactPow1 " + reactPow1 + ", reactPow2" + reactPow2 + ",reactPow3 " + reactPow3 + ",reactPowTot " + reactPowTot);

      Double apparentPow1 = ArrayTools.convertHexStringToDouble(dataStr.substring(32, 40));
      Double apparentPow2 = ArrayTools.convertHexStringToDouble(dataStr.substring(40, 48));
      Double apparentPow3 = ArrayTools.convertHexStringToDouble(dataStr.substring(48, 56));
      Double apparentPowTot = ArrayTools.convertHexStringToDouble(dataStr.substring(56, 64));
      logger.debug("apparentPow1 " + apparentPow1 + ", apparentPow2" + apparentPow2 + ",apparentPow3 " + apparentPow3 + ",apparentPowTot " + apparentPowTot);

      String measurementTimestamp = dataStr.substring(64, 76);
      logger.debug("EMN Timestamp " + measurementTimestamp);

      Integer freq = ArrayTools.read16Bits(dataStr.substring(76, 80));
      logger.debug("Frequency " + freq + ", unparsed: " + dataStr.substring(76, 80));

      Integer maxCurrentPhase1 = ArrayTools.read16Bits(dataStr.substring(80, 84));
      Integer maxCurrentPhase2 = ArrayTools.read16Bits(dataStr.substring(84, 88));
      Integer maxCurrentPhase3 = ArrayTools.read16Bits(dataStr.substring(88, 92));
      logger.debug("maxCurrentPhase1 " + maxCurrentPhase1 + ", maxCurrentPhase2 " + maxCurrentPhase2 + ", maxCurrentPhase3 " + maxCurrentPhase3);

      Integer minVoltagePhase1 = ArrayTools.read16Bits(dataStr.substring(92, 96));
      Integer minVoltagePhase2 = ArrayTools.read16Bits(dataStr.substring(96, 100));
      Integer minVoltagePhase3 = ArrayTools.read16Bits(dataStr.substring(100, 104));
      logger.debug("minVoltagePhase1 " + minVoltagePhase1 + ", minVoltagePhase2 " + minVoltagePhase2 + ", minVoltagePhase3 " + minVoltagePhase3);

      Integer lemProductID = ArrayTools.read16Bits(dataStr.substring(104, 108));
      Integer schema = Integer.valueOf(lemProductID.intValue() & 0x7);
      Integer calibre = Integer.valueOf((lemProductID.intValue() & 0x78) >> 3);
      Integer final_prod_id = Integer.valueOf((lemProductID.intValue() & 0x780) >> 6);
      Integer volt_type = Integer.valueOf((lemProductID.intValue() & 0x6000) >> 11);

      Integer lemGlobalSoftVersion = ArrayTools.read16Bits(dataStr.substring(108, 112));
      Integer lemSoftVersion = Integer.valueOf((lemGlobalSoftVersion.intValue() & 0xFF00) >> 8);
      Integer lemSoftRevision1 = Integer.valueOf((lemGlobalSoftVersion.intValue() & 0xF0) >> 4);
      Integer lemSoftRevision2 = Integer.valueOf(lemGlobalSoftVersion.intValue() & 0xF);

      Integer lemStatusWord = ArrayTools.read16Bits(dataStr.substring(112, 116));
      logger.debug("lemProductID " + lemProductID + ",lemGlobalSoftVersion " + lemGlobalSoftVersion + ", lemSoftVersion " + lemSoftVersion + ",lemSoftRevision1 " + lemSoftRevision1 + ",lemSoftRevision2 " + lemSoftRevision2 + ", lemStatusWord " + lemStatusWord + ",schema " + schema + ", calibre " + calibre + ", final_prod_id " + final_prod_id + ", volt_type " + volt_type);

      Integer lemRecordInterval = ArrayTools.read16Bits(dataStr.substring(116, 120));
      Integer lemVoltageRMS = ArrayTools.read16Bits(dataStr.substring(120, 124));
      Integer lemErrorStatus = ArrayTools.read16Bits(dataStr.substring(124, 128));
      logger.debug("lemRecordInterval " + lemRecordInterval + ", lemVoltageRMS " + lemVoltageRMS + ", lemErrorStatus " + lemErrorStatus);

      Integer lemSerialErrorCounter = ArrayTools.read16Bits(dataStr.substring(128, 132));
      Integer lemMeterErrorCounter = ArrayTools.read16Bits(dataStr.substring(132, 136));
      Integer lemLSBZeroPowerDetect = ArrayTools.read16Bits(dataStr.substring(136, 140));
      logger.debug("lemSerialErrorCounter " + lemSerialErrorCounter + ", lemMeterErrorCounter " + lemMeterErrorCounter + ", lemLSBZeroPowerDetect " + lemLSBZeroPowerDetect);

      data.setValue("reactPower1Raw", reactPow1);
      data.setValue("reactPower2Raw", reactPow2);
      data.setValue("reactPower3Raw", reactPow3);
      data.setValue("reactPowerTotRaw", reactPowTot);

      data.setValue("appPower1Raw", apparentPow1);
      data.setValue("appPower2Raw", apparentPow2);
      data.setValue("appPower3Raw", apparentPow3);
      data.setValue("appPowerTotRaw", apparentPowTot);

      data.setValue("freqPowerRaw", freq);

      data.setValue("maxCurPwr1Raw", maxCurrentPhase1);
      data.setValue("maxCurPwr2Raw", maxCurrentPhase2);
      data.setValue("maxCurPwr3Raw", maxCurrentPhase3);

      data.setValue("minVoltPwr1Raw", minVoltagePhase1);
      data.setValue("minVoltPwr2Raw", minVoltagePhase2);
      data.setValue("minVoltPwr3Raw", minVoltagePhase3);

      getConverted(pr, REACT_POWER1_TEXT, data, calibrationData);
      getConverted(pr, REACT_POWER2_TEXT, data, calibrationData);
      getConverted(pr, REACT_POWER3_TEXT, data, calibrationData);
      getConverted(pr, REACT_POWER_TOT_TEXT, data, calibrationData);

      getConverted(pr, APPARENT_POWER1_TEXT, data, calibrationData);
      getConverted(pr, APPARENT_POWER2_TEXT, data, calibrationData);
      getConverted(pr, APPARENT_POWER3_TEXT, data, calibrationData);
      getConverted(pr, APPARENT_POWER_TOT_TEXT, data, calibrationData);

      getConverted(pr, FREQ_POWER_TEXT, data, calibrationData);

      getConverted(pr, MAX_CURRENT_POWER1_TEXT, data, calibrationData);
      getConverted(pr, MAX_CURRENT_POWER2_TEXT, data, calibrationData);
      getConverted(pr, MAX_CURRENT_POWER3_TEXT, data, calibrationData);

      getConverted(pr, MIN_VOLTAGE_POWER1_TEXT, data, calibrationData);
      getConverted(pr, MIN_VOLTAGE_POWER2_TEXT, data, calibrationData);
      getConverted(pr, MIN_VOLTAGE_POWER3_TEXT, data, calibrationData);

      data.setValue("createPacket", "false");
    }
    else if (data_type == 20) {
      Float raw_temp1 = getNullableIntegerAsFloat(dataStr.substring(0, 4));
      if (raw_temp1 != null) {
        raw_temp1 = Float.valueOf(raw_temp1.floatValue() / 100.0F - 250.0F);
      }

      Float raw_temp2 = getNullableIntegerAsFloat(dataStr.substring(4, 8));
      if (raw_temp2 != null) {
        raw_temp2 = Float.valueOf(raw_temp2.floatValue() / 100.0F - 250.0F);
      }

      Float raw_volt1 = getNullableIntegerAsFloat(dataStr.substring(8, 12));
      if (raw_volt1 != null) {
        raw_volt1 = Float.valueOf(raw_volt1.floatValue() / 10.0F - 1000.0F);
      }

      Float raw_volt2 = getNullableIntegerAsFloat(dataStr.substring(12, 16));
      if (raw_volt2 != null) {
        raw_volt2 = Float.valueOf(raw_volt2.floatValue() / 10.0F - 1000.0F);
      }

      Float raw_co2a = getNullableIntegerAsFloat(dataStr.substring(16, 20));
      Float raw_co2b = getNullableIntegerAsFloat(dataStr.substring(20, 24));

      data.setValue("rawTemp", raw_temp1);
      data.setValue("rawTemp2", raw_temp2);

      data.setValue("voltage1Raw", raw_volt1);
      data.setValue("voltage2Raw", raw_volt2);

      data.setValue("co2ARaw", raw_co2a);
      data.setValue("co2BRaw", raw_co2b);

      getConverted(pr, "temp", data, calibrationData);
      getConverted(pr, "temp2", data, calibrationData);
      getConverted(pr, VOLTAGE1_TEXT, data, calibrationData);
      getConverted(pr, VOLTAGE2_TEXT, data, calibrationData);
      getConverted(pr, CO2A_TEXT, data, calibrationData);
      getConverted(pr, CO2B_TEXT, data, calibrationData);
    } else if (data_type == 21)
    {
      Float raw_resistance_ext1_adc = getNullableIntegerAsFloat(dataStr.substring(0, 4));
      if (raw_resistance_ext1_adc != null) {
        raw_resistance_ext1_adc = Float.valueOf(raw_resistance_ext1_adc.floatValue() * 100.0F);
      }

      Float raw_resistance_ext2_adc = getNullableIntegerAsFloat(dataStr.substring(4, 8));
      if (raw_resistance_ext2_adc != null) {
        raw_resistance_ext2_adc = Float.valueOf(raw_resistance_ext2_adc.floatValue() * 100.0F);
      }

      Float raw_light_adc = getNullableIntegerAsFloat(dataStr.substring(8, 12));
      if (raw_light_adc != null) {
        raw_light_adc = Float.valueOf(raw_light_adc.floatValue() / 10.0F);
      }

      Float internalTemp = getNullableIntegerAsFloat(dataStr.substring(16, 20));
      if (internalTemp != null) {
        internalTemp = Float.valueOf(internalTemp.floatValue() / 100.0F - 250.0F);
      }

      Float internalHum = getNullableIntegerAsFloat(dataStr.substring(20, 24));
      if (internalHum != null) {
        internalHum = Float.valueOf(internalHum.floatValue() / 100.0F);
      }

      if (debug) {
        logger.debug("raw_resistance_ext1_adc " + raw_resistance_ext1_adc + ",raw_resistance_ext2_adc " + raw_resistance_ext2_adc + ", internalTemp " + internalTemp + ", internalHum " + internalHum);
      }

      data.setValue("resistance1Raw", raw_resistance_ext1_adc);
      data.setValue("resistance2Raw", raw_resistance_ext2_adc);
      data.setValue("rawLight", raw_light_adc);
      data.setValue("rawTempInt", "" + internalTemp);
      data.setValue("rawHum", "" + internalHum);

      getConverted(pr, RESISTANCE1_TEXT, data, calibrationData);
      getConverted(pr, RESISTANCE2_TEXT, data, calibrationData);
      getConverted(pr, "light", data, calibrationData);
      getConverted(pr, "tempInt", data, calibrationData);
      getConverted(pr, "hum", data, calibrationData);
    } else if (data_type == 22) {
      Float raw_temp1 = getNullableIntegerAsFloat(dataStr.substring(0, 4));
      if (raw_temp1 != null) {
        raw_temp1 = Float.valueOf(raw_temp1.floatValue() / 100.0F - 250.0F);
      }

      Float raw_temp2 = getNullableIntegerAsFloat(dataStr.substring(4, 8));
      if (raw_temp2 != null) {
        raw_temp2 = Float.valueOf(raw_temp2.floatValue() / 100.0F - 250.0F);
      }

      Float raw_light_adc = getNullableIntegerAsFloat(dataStr.substring(8, 12));
      if (raw_light_adc != null) {
        raw_light_adc = Float.valueOf(raw_light_adc.floatValue() / 10.0F);
      }

      Float raw_co2 = getNullableIntegerAsFloat(dataStr.substring(12, 16));

      Float internalTemp = getNullableIntegerAsFloat(dataStr.substring(16, 20));
      if (internalTemp != null) {
        internalTemp = Float.valueOf(internalTemp.floatValue() / 100.0F - 250.0F);
      }

      Float internalHum = getNullableIntegerAsFloat(dataStr.substring(20, 24));
      if (internalHum != null) {
        internalHum = Float.valueOf(internalHum.floatValue() / 100.0F);
      }

      Float battVolt = getNullableIntegerAsFloat(dataStr.substring(24, 28));
      if (battVolt != null) {
        battVolt = Float.valueOf(battVolt.floatValue() / 1000.0F);
      }

      data.setValue("rawTemp", raw_temp1);
      data.setValue("rawTemp2", raw_temp2);
      data.setValue("rawLight", raw_light_adc);
      data.setValue(CO2_RAW_TEXT, raw_co2);
      data.setValue("rawTempInt", internalTemp);
      data.setValue("rawHum", internalHum);
      data.setValue(BATT_VOLT_RAW_TEXT, battVolt);

      getConverted(pr, "temp", data, calibrationData);
      getConverted(pr, "temp2", data, calibrationData);
      getConverted(pr, "light", data, calibrationData);
      getConverted(pr, CO2_TEXT, data, calibrationData);
      getConverted(pr, "tempInt", data, calibrationData);
      getConverted(pr, "hum", data, calibrationData);
      getConverted(pr, BATT_VOLT_TEXT, data, calibrationData);
    }
    else if (data_type == 23)
    {
      Float raw_resistance_ext1_adc = getNullableIntegerAsFloat(dataStr.substring(0, 4));
      if (raw_resistance_ext1_adc != null) {
        raw_resistance_ext1_adc = Float.valueOf(raw_resistance_ext1_adc.floatValue() * 100.0F);
      }

      Float raw_resistance_ext2_adc = getNullableIntegerAsFloat(dataStr.substring(4, 8));
      if (raw_resistance_ext2_adc != null) {
        raw_resistance_ext2_adc = Float.valueOf(raw_resistance_ext2_adc.floatValue() * 100.0F);
      }

      Float raw_light_adc = getNullableIntegerAsFloat(dataStr.substring(12, 16));
      logger.debug("raw_light_adc " + raw_light_adc);
      if (raw_light_adc != null) {
        raw_light_adc = Float.valueOf(raw_light_adc.floatValue() / 10.0F);
      }

      if (debug) {
        logger.debug("raw_resistance_ext1_adc " + raw_resistance_ext1_adc + ",raw_resistance_ext2_adc " + raw_resistance_ext2_adc);
      }

      data.setValue("resistance1Raw", raw_resistance_ext1_adc);
      data.setValue("resistance2Raw", raw_resistance_ext2_adc);
      data.setValue("rawLight", raw_light_adc);

      getConverted(pr, RESISTANCE1_TEXT, data, calibrationData);
      getConverted(pr, RESISTANCE2_TEXT, data, calibrationData);
      getConverted(pr, "light", data, calibrationData);
    }
    else if (data_type == 24)
    {
      Float raw_co2 = getNullableIntegerAsFloat(dataStr.substring(0, 4));

      Float internalTemp = getNullableIntegerAsFloat(dataStr.substring(4, 8));
      if (internalTemp != null) {
        internalTemp = Float.valueOf(internalTemp.floatValue() / 100.0F - 250.0F);
      }

      Float internalHum = getNullableIntegerAsFloat(dataStr.substring(8, 12));
      if (internalHum != null) {
        internalHum = Float.valueOf(internalHum.floatValue() / 100.0F);
      }

      data.setValue(CO2_RAW_TEXT, raw_co2);
      data.setValue("rawTempInt", internalTemp);
      data.setValue("rawHum", internalHum);

      getConverted(pr, CO2_TEXT, data, calibrationData);
      getConverted(pr, "tempInt", data, calibrationData);
      getConverted(pr, "hum", data, calibrationData);
    } else {
      throw new RuntimeException("Not implemented data type " + data_type);
    }
  }

  public static final Float getNullableIntegerAsFloat(String s)
  {
    if (s == null)
      return null;
    int tt = Integer.parseInt(s, 16);
    if (tt == 65535)
      return null;
    return Float.valueOf(tt);
  }

  public List<String> getSensorTypesFromProductNumber(String product_number)
    throws ProductNotFoundException
  {
    List res = new ArrayList();

    Product ps = getProductDescriptionFromNumber(getProductNumberFromName(product_number));
    String[] data = ps.getAvailableSensorTypes();
    for (int u = 0; u < data.length; u++) {
      String pp = data[u];
      if ((Property.getBooleanPropertyByCategoryAndName("PARAMETERS", "hide_light_info", false)) && (pp != null) && (pp.equals("light")))
      {
        continue;
      }
      res.add(pp);
    }

    return res;
  }

  public List<String> getDBColumnNamesFromProductNumber(String product_number)
    throws ProductNotFoundException
  {
    List res = new ArrayList();

    Product ps = getProductDescriptionFromNumber(getProductNumberFromName(product_number));
    String[] data = ps.getAvailableDataColumns();
    for (int u = 0; u < data.length; u++) {
      String pp = data[u];
      res.add(pp);
    }

    return res;
  }

  public List<String> getCalibrationColumns(String product_number)
  {
    List res = new ArrayList();
    try {
      Product ps = getProductDescriptionFromNumber(getProductNumberFromName(product_number));
      String[] data = ps.getAvailableDataColumnsForCalibration();
      for (int u = 0; u < data.length; u++) {
        String pp = data[u];
        res.add(pp);
      }
    } catch (Exception ee) {
      logger.error("", ee);
    }
    return res;
  }

  public List<String> getDBColumnNamesFromProductList(List product_names)
  {
    List res = new ArrayList();
    if (product_names != null) {
      for (int i = 0; i < product_names.size(); i++) {
        String product_name = (String)product_names.get(i);
        if (!Tools.isNotEmptyNullOrNullString(product_name))
        {
          logger.debug("Found a product 'null', will ignore it and continue normal operation");
        }
        else
          try {
            Product ps = getProductDescriptionFromNumber(getProductNumberFromName(product_name));

            String[] data = ps.getAvailableDataColumns();
            for (int u = 0; u < data.length; u++) {
              String pp = data[u];
              if (res.indexOf(pp) == -1)
                res.add(pp);
            }
          }
          catch (Exception ee) {
            logger.error("", ee);
          }
      }
    }
    return res;
  }

  public List<String> getSensorTypesFromProductList(List product_names)
  {
    List res = new ArrayList();
    if (product_names != null) {
      for (int i = 0; i < product_names.size(); i++) {
        String product_name = (String)product_names.get(i);
        if (!Tools.isNotEmptyNullOrNullString(product_name))
        {
          logger.debug("Found a product 'null', will ignore it and continue normal operation");
        }
        else
          try {
            Product ps = getProductDescriptionFromNumber(getProductNumberFromName(product_name));

            String[] data = ps.getAvailableSensorTypes();
            for (int u = 0; u < data.length; u++) {
              String pp = data[u];
              if (res.indexOf(pp) == -1)
                res.add(pp);
            }
          }
          catch (Exception ee) {
            logger.error("", ee);
          }
      }
    }
    return res;
  }

  private void registerNewProduct(int prod_number, String prod_name, Product productDescription)
  {
    if (prod_name.indexOf(productDescription.getProductInternalGroup()) != 0) {
      throw new RuntimeException("Cannot register product " + prod_name + " because it is not a superset of " + productDescription.getProductInternalGroup());
    }

    logger.debug("Registering product number " + prod_number + ", name " + prod_name);

    this.productNameMap.put(new Integer(prod_number), prod_name);
    this.productNameReverseMap.put(prod_name, new Integer(prod_number));
    this.productNameCategoryMap.put(prod_name, Integer.valueOf(productDescription.productCategory));
    this.productDescrMap.put(new Integer(prod_number), productDescription);
    this.productList.add(prod_name);

    this.displayList.add(new DisplayableImpl("" + prod_number, prod_name + " - " + productDescription.getProductDescription()));

    if (productDescription.isFlashStationVisible()) {
      this.flashStationDisplayList.add(new DisplayableImpl("" + prod_number, prod_name + " - " + productDescription.getProductDescription()));
    }

    this.displayListDisplay.add(new DisplayableImpl(prod_name, prod_name + " - " + productDescription.getProductDescription())); } 
  public String[] getProductDescriptiveInformation(String long_prod_number) { // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: aload_1
    //   3: invokevirtual 871	com/aginova/business/ProductInformation:getProductNumberFromName	(Ljava/lang/String;)I
    //   6: invokevirtual 872	com/aginova/business/ProductInformation:getProductDescriptionFromNumber	(I)Lcom/aginova/business/ProductInformation$Product;
    //   9: astore_2
    //   10: iconst_2
    //   11: anewarray 121	java/lang/String
    //   14: dup
    //   15: iconst_0
    //   16: aload_2
    //   17: invokevirtual 896	com/aginova/business/ProductInformation$Product:getProductGroup	()Ljava/lang/String;
    //   20: aastore
    //   21: dup
    //   22: iconst_1
    //   23: aload_2
    //   24: invokevirtual 897	com/aginova/business/ProductInformation$Product:getProductionDescriptiveInformation	()Ljava/lang/String;
    //   27: aastore
    //   28: areturn
    //   29: astore_2
    //   30: iconst_2
    //   31: anewarray 121	java/lang/String
    //   34: dup
    //   35: iconst_0
    //   36: ldc_w 898
    //   39: aastore
    //   40: dup
    //   41: iconst_1
    //   42: ldc_w 898
    //   45: aastore
    //   46: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   0	28	29	java/lang/Exception } 
  public String[] getProductDescriptiveInformation(int prod_number) { // Byte code:
    //   0: aload_0
    //   1: iload_1
    //   2: invokevirtual 872	com/aginova/business/ProductInformation:getProductDescriptionFromNumber	(I)Lcom/aginova/business/ProductInformation$Product;
    //   5: astore_2
    //   6: iconst_2
    //   7: anewarray 121	java/lang/String
    //   10: dup
    //   11: iconst_0
    //   12: aload_2
    //   13: invokevirtual 896	com/aginova/business/ProductInformation$Product:getProductGroup	()Ljava/lang/String;
    //   16: aastore
    //   17: dup
    //   18: iconst_1
    //   19: aload_2
    //   20: invokevirtual 897	com/aginova/business/ProductInformation$Product:getProductionDescriptiveInformation	()Ljava/lang/String;
    //   23: aastore
    //   24: areturn
    //   25: astore_2
    //   26: iconst_2
    //   27: anewarray 121	java/lang/String
    //   30: dup
    //   31: iconst_0
    //   32: ldc_w 898
    //   35: aastore
    //   36: dup
    //   37: iconst_1
    //   38: ldc_w 898
    //   41: aastore
    //   42: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   0	24	25	java/lang/Exception } 
  public String getProductNameFromNumber(int prod_number) { return (String)this.productNameMap.get(new Integer(prod_number));
  }

  public int getProductNumberFromName(String product_name)
    throws ProductNotFoundException
  {
    if (!Tools.isNotEmptyNullOrNullString(product_name)) {
      throw new ProductNotFoundException("Product number is not set");
    }

    Integer val = (Integer)this.productNameReverseMap.get(product_name);
    if (val == null) {
      throw new ProductNotFoundException("Unknown product " + product_name + ", list of known products " + this.productNameReverseMap);
    }

    return val.intValue();
  }

  public int getProductCategoryFromName(String product_name)
  {
    if (!Tools.isNotEmptyNullOrNullString(product_name)) {
      throw new ProductNotFoundException("Product number is not set");
    }

    Integer val = (Integer)this.productNameCategoryMap.get(product_name);
    if (val == null) {
      throw new ProductNotFoundException("Unknown product " + product_name + ", list of known products " + this.productNameCategoryMap);
    }

    return val.intValue();
  }

  public Product getProductDescriptionFromNumber(int prod_number)
    throws ProductNotFoundException
  {
    Product pn = (Product)this.productDescrMap.get(new Integer(prod_number));
    if (pn == null) {
      throw new ProductNotFoundException("Product not found: " + prod_number + ", please reconfigure the sensor!");
    }
    return pn;
  }

  public Product getProductDescriptionFromName(String product_name)
    throws Exception
  {
    return getProductDescriptionFromNumber(getProductNumberFromName(product_name));
  }

  public List getDisplayableProductList()
  {
    return this.displayList;
  }

  public List getFlashStationProductList()
  {
    return this.flashStationDisplayList;
  }

  public List getDisplayablePortalProductList()
  {
    return this.displayListDisplay;
  }

  public static void getConverted(String prod_number_name, String displayCode, Message data, Object[][][] calibrationData)
    throws Exception
  {
    getConverted(getInstance().getProductNumberFromName(prod_number_name), displayCode, data, calibrationData);
  }

  public static void getConverted(int prod_number, String displayCode, Message data, Object[][][] calibrationData)
    throws Exception
  {
    ProductInformation pi = getInstance();
    Product pr = pi.getProductDescriptionFromNumber(prod_number);
    getConverted(pr, displayCode, data, calibrationData);
  }

  public static void getConverted(Product pr, String displayCode, Message data, Object[][][] calibrationData)
    throws Exception
  {
    if (!pr.isCalibrationAvailable())
      calibrationData = (Object[][][])null;
    Object[] component = pr.getComponentFromDisplayCode(displayCode);
    boolean debug = logger.isDebugEnabled();
    if (debug) {
      logger.debug("Using component " + component + " for product " + pr + ", displayCode " + displayCode);
    }
    if (component == null)
    {
      if (debug) {
        logger.debug("Did not find any converter for that product: " + pr + " - will just ignore. DisplayCode " + displayCode + " for list of components: " + ArrayTools.objectToStringVisual(component));
      }
      return;
    }

    Object[][] calData = (Object[][])null;
    if ((calibrationData != null) && (((Component)component[0]).isCalibrationAvailable())) {
      calData = calibrationData[((Integer)component[1]).intValue()];
    }

    ((Component)component[0]).fromRaw(data, calData);
  }

  public List getProductList()
  {
    return this.productList;
  }

  public static String optionalConvertUnit(String unitText, String temperatureUnit)
  {
    if (unitText == null)
      return null;
    if (temperatureUnit == null)
      throw new RuntimeException("Temperature unit cannot be null!");
    if (unitText.equals("°F")) {
      if (temperatureUnit.equals("C"))
        return "°C";
    } else if ((unitText.equals("°C")) && 
      (temperatureUnit.equals("F"))) {
      return "°F";
    }
    return unitText;
  }

  public static String optionalConvertFahrenheitInText(String fahrenheitText, String temperatureUnit)
  {
    String output = fahrenheitText;
    try {
      if ((temperatureUnit != null) && (temperatureUnit.equals("C")))
        output = convertFahrenheitInText(fahrenheitText);
    }
    catch (Exception e) {
      logger.error("Error while doing conversion for String " + fahrenheitText + " will not convert...", e);
    }
    return output;
  }

  public static String convertFahrenheitInText(String fahrenheitText) {
    return convertFahrenheitInText(fahrenheitText, false);
  }

  public static String convertFahrenheitInText(String fahrenheitText, boolean showBoth)
  {
    try
    {
      Pattern pattern = Pattern.compile("(\\-)?[0-9]*(\\.)?[0-9]*(\\s)?°F");
      Matcher matcher = null;
      while ((matcher = pattern.matcher(fahrenheitText)).find())
      {
        String extracted = fahrenheitText.substring(matcher.start(), matcher.end());
        String p1 = fahrenheitText.substring(0, matcher.start());
        String p2 = fahrenheitText.substring(matcher.end());
        System.out.println("Extracted: " + extracted + ",p1 " + p1 + ",p2 " + p2);
        String value = extracted.substring(0, extracted.length() - 2);
        String middle = "-°C";
        if (!value.equals("-")) {
          float fahrenheitValue = Float.parseFloat(value);

          middle = Tools.round(fahrenheitToCelcius(Float.valueOf(fahrenheitValue)), 1) + "°C";

          if (showBoth) {
            middle = extracted + "(" + Tools.round(fahrenheitToCelcius(Float.valueOf(fahrenheitValue)), 1) + "°C)";
          }

        }

        fahrenheitText = p1 + middle + p2;
      }
      return fahrenheitText;
    } catch (Exception e) {
      logger.error("", e);
    }return fahrenheitText;
  }

  public static String roundAndDisplayTemperature(Float input, int decimalPlace, String temperatureUnit)
  {
    return roundAndDisplayTemperature(input, decimalPlace, temperatureUnit, false);
  }

  public static String roundAndDisplayTemperatureDifference(Float input, int decimalPlace, String temperatureUnit)
  {
    return roundAndDisplayTemperatureDifference(input, decimalPlace, temperatureUnit, false);
  }

  public static String roundAndDisplayTemperature(Float input, int decimalPlace, String temperatureUnit, boolean noUnit)
  {
    if (input == null) {
      return "-" + (noUnit ? "" : new StringBuilder().append("°").append(temperatureUnit).toString());
    }

    if ((temperatureUnit != null) && (temperatureUnit.equals("C"))) {
      input = fahrenheitToCelcius(input);
    }

    Float conv = Tools.round(input, decimalPlace);
    String rep = conv != null ? "" + conv : "-";
    if (decimalPlace == 0) {
      int c = rep.indexOf(".");
      if (c != -1) {
        rep = rep.substring(0, c);
      }
    }
    return rep + (noUnit ? "" : new StringBuilder().append("°").append(temperatureUnit).toString());
  }

  public static String roundAndDisplayTemperatureDifference(Float input, int decimalPlace, String temperatureUnit, boolean noUnit)
  {
    if ((temperatureUnit != null) && (temperatureUnit.equals("C"))) {
      input = fahrenheitToCelciusDifference(input);
    }

    float conv = Tools.round(input, decimalPlace).floatValue();
    String rep = "" + conv;
    if (decimalPlace == 0) {
      int c = rep.indexOf(".");
      if (c != -1) {
        rep = rep.substring(0, c);
      }
    }
    return rep + (noUnit ? "" : new StringBuilder().append("°").append(temperatureUnit).toString());
  }

  public static float optionalConvertToFarenheit(float value, String unit)
  {
    if (unit.equals("C")) {
      value = celciusToFarenheit(Float.valueOf(value)).floatValue();
    }
    return value;
  }

  public static float truncate(float input, int decimalPlace)
  {
    String str = "" + input;
    int c = str.indexOf(".");
    if (c == -1)
      return input;
    int end = c + decimalPlace + 1;
    if (decimalPlace == 0)
      end--;
    if (end > str.length())
      return input;
    return Float.parseFloat(str.substring(0, end));
  }

  public static Float optionalConvert(Float fahrenheit, String temperatureUnit)
  {
    Float output = fahrenheit;
    if ((temperatureUnit != null) && (temperatureUnit.equals("C"))) {
      output = fahrenheitToCelcius(fahrenheit);
    }
    return output;
  }

  public static Float celciusToFarenheit(Float c)
  {
    if (c == null) {
      return null;
    }
    float MINIMUM_CELCIUS = -273.16F;

    if (c.floatValue() < -273.16F)
      throw new IllegalArgumentException("Argument " + c + " is too small.");
    return Float.valueOf(1.8F * c.floatValue() + 32.0F);
  }

  public static Float fahrenheitToCelcius(Float c)
  {
    if (c == null)
      return null;
    return Float.valueOf((c.floatValue() - 32.0F) / 1.8F);
  }

  public static Float fahrenheitToCelciusDifference(Float c)
  {
    if (c == null) return null;
    return Float.valueOf(c.floatValue() / 1.8F);
  }

  public static double fahrenheitToCelciusDifference(double c)
  {
    return c / 1.799999952316284D;
  }

  public static Float rawThermistorADCtoCelcius(Float unprocessedTemp)
  {
    if (unprocessedTemp == null)
      return null;
    float tempC = 3890.0F / ((float)Math.log(1024.0F / unprocessedTemp.floatValue() - 1.0F) + 13.05F) - 273.14999F;
    return Float.valueOf(tempC);
  }

  public static float computeResistance(Float unprocessedTemp, boolean newAdc)
    throws DriverException
  {
    if (newAdc) {
      if (unprocessedTemp.floatValue() > 32768.0F) {
        throw new DriverException("New ADC does not support value of " + unprocessedTemp + " ( cannot be greater than " + 32768 + ")");
      }
      if (unprocessedTemp.floatValue() < -32768.0F) {
        throw new DriverException("New ADC does not support value of " + unprocessedTemp + " ( cannot be lower than -" + 32768 + ")");
      }
      float R13 = 10000.0F;
      float ADC_gain = 1.0F;
      float ADC_offset = 0.5F;
      float OSR = 256.0F;
      return R13 * (ADC_gain / (unprocessedTemp.floatValue() / (float)Math.pow(2.0D, 16.0D) * (OSR / (OSR + 1.0F)) + ADC_offset) - 1.0F);
    }

    if (unprocessedTemp.floatValue() > 1023.0F) {
      throw new DriverException("Old ADC does not support value of " + unprocessedTemp + " ( cannot be greater than " + 1023 + ")");
    }
    float R8 = 10000.0F;
    return R8 * (1023.0F / unprocessedTemp.floatValue() - 1.0F);
  }

  public static Float rawQT06024CADCtoCelcius(Float unprocessedTemp, boolean newAdc)
    throws DriverException
  {
    if (unprocessedTemp == null) {
      return null;
    }

    float R = computeResistance(unprocessedTemp, newAdc);
    float tempC = QT06024CADCtoCelcius(Float.valueOf(R)).floatValue();
    logger.debug("R " + R + " tempC " + tempC);
    return Float.valueOf(tempC);
  }

  public static Float QT06024CADCtoCelcius(Float resistance) {
    if (resistance == null) return null;

    float a = 0.001425091F;
    float b = 0.000237986F;
    float c = 9.865725E-008F;
    float tempC = (float)(1.0D / (a + b * Math.log(resistance.floatValue()) + c * Math.pow(Math.log(resistance.floatValue()), 3.0D))) - 273.14999F;
    return Float.valueOf(tempC);
  }

  public static Float rawOctsens10kADCtoCelcius(Float unprocessedTemp, boolean newAdc)
    throws DriverException
  {
    if (unprocessedTemp == null) {
      return null;
    }

    float R = computeResistance(unprocessedTemp, newAdc);
    float tempC = Octsens10kADCtoCelcius(Float.valueOf(R)).floatValue();
    logger.debug("R " + R + " tempC " + tempC);
    return Float.valueOf(tempC);
  }

  public static Float Octsens10kADCtoCelcius(Float resistance) {
    if (resistance == null) return null;
    float a = 0.001425091F;
    float b = 0.000237986F;
    float c = 9.865725E-008F;
    if (resistance.floatValue() <= 32820.0D) {
      a = 0.001151F;
      b = 0.0002312F;
      c = 9.3803E-008F;
    } else {
      a = 0.001202F;
      b = 0.0002249F;
      c = 1.0721E-007F;
    }
    float tempC = (float)(1.0D / (a + b * Math.log(resistance.floatValue()) + c * Math.pow(Math.log(resistance.floatValue()), 3.0D))) - 273.14999F;
    return Float.valueOf(tempC);
  }

  public static Float raw12J1H0042ADCtoCelcius(Float unprocessedTemp, boolean newAdc)
    throws DriverException
  {
    if (unprocessedTemp == null) {
      return null;
    }
    float R = computeResistance(unprocessedTemp, newAdc);
    return resistance12J1H0042ADCtoCelcius(Float.valueOf(R));
  }

  private static Float resistance12J1H0042ADCtoCelcius(Float resistance)
  {
    if (resistance == null) {
      return null;
    }
    float a = 0.0014295F;
    float b = 0.00023718F;
    float c = 1.03E-007F;
    float tempC = (float)(1.0D / (a + b * Math.log(resistance.floatValue()) + c * Math.pow(Math.log(resistance.floatValue()), 3.0D))) - 273.14999F;

    logger.debug("Resistance " + resistance + " tempC " + tempC);
    return Float.valueOf(tempC);
  }

  public static Float rawPS103J2ThermistorADCtoCelcius(Float unprocessedTemp, boolean newAdc)
    throws DriverException
  {
    if (unprocessedTemp == null) {
      return null;
    }

    float R = computeResistance(unprocessedTemp, newAdc);
    float tempC = resistancePS103J2ThermistorADCtoCelcius(Float.valueOf(R)).floatValue();

    return Float.valueOf(tempC);
  }

  public static Float resistancePS103J2ThermistorADCtoCelcius(Float resistance) {
    if (resistance == null) return null;
    float a = 0.0011393F;
    float b = 0.0002319495F;
    float c = 1.059925E-007F;
    float d = -6.67899E-011F;
    float tempC = (float)(1.0D / (a + b * Math.log(resistance.floatValue()) + c * Math.pow(Math.log(resistance.floatValue()), 3.0D) + d * Math.pow(Math.log(resistance.floatValue()), 5.0D))) - 273.14999F;

    return Float.valueOf(tempC);
  }

  public static Float[] computeSHT11Humidity(Integer rh, Integer t)
  {
    if (rh == null) {
      return new Float[] { null, null };
    }
    float C1 = -4.0F;
    float C2 = 0.0405F;
    float C3 = -2.8E-006F;
    float T1 = 0.01F;
    float T2 = 8.0E-005F;

    float t_C = t.intValue() * 0.01F - 39.580002F;

    float rh_lin = -2.8E-006F * rh.intValue() * rh.intValue() + 0.0405F * rh.intValue() + -4.0F;
    float rh_true = (t_C - 25.0F) * (0.01F + 8.0E-005F * rh.intValue()) + rh_lin;

    if (rh_true > 100.0F)
      rh_true = 100.0F;
    if (rh_true < 0.1D) {
      rh_true = 0.1F;
    }
    return new Float[] { Float.valueOf(rh_lin), Float.valueOf(rh_true) };
  }

  public static Float computeSHT11Temperature(Integer raw_temp)
  {
    if (raw_temp == null) {
      return null;
    }
    float D1 = -39.243999F;
    float D2 = 0.018F;

    float conv_temp = -39.243999F + 0.018F * raw_temp.intValue();
    return Float.valueOf(conv_temp);
  }

  static Float adcOffsetCompensate(Integer raw_temp)
  {
    return adcOffsetCompensate(raw_temp, false);
  }

  public static Float adcOffsetCompensate(Integer raw_temp, boolean newADC)
  {
    Float result = null;

    if (raw_temp == null) {
      return null;
    }
    if (newADC) {
      result = Float.valueOf(raw_temp.intValue() - (0.0050581F * raw_temp.intValue() + 140.76811F));
      return result;
    }

    if (raw_temp.intValue() > 68)
      result = Float.valueOf(raw_temp.intValue() - (15.2F * raw_temp.intValue() - 1024.5F) / 1000.0F);
    else {
      result = Float.valueOf(raw_temp.intValue());
    }

    return result;
  }

  static float wetnessComputeWLS(float adcValue)
  {
    float RA = 10000.0F;
    float WLS_REFERENCE_VOLTAGE = 2.048F;
    float ADC_REFERENCE_VOLTAGE = 1.22F;
    float K = 1.2048F;
    Float val = Float.valueOf(wetnessCompute0(adcValue, RA, WLS_REFERENCE_VOLTAGE, K, ADC_REFERENCE_VOLTAGE));
    float WLS_UPPER_LIMIT = 1000000.0F;
    if ((val != null) && (val.floatValue() > WLS_UPPER_LIMIT)) {
      val = Float.valueOf(WLS_UPPER_LIMIT);
    }
    return val.floatValue();
  }

  static Float wetnessComputeICEWetness(Float adcValue)
  {
    if (adcValue == null)
      return null;
    float RA = 20000.0F;
    float WLS_REFERENCE_VOLTAGE = 1.0F;
    float ADC_REFERENCE_VOLTAGE = 1.22F;
    float K = 1.2048F;
    return Float.valueOf(wetnessCompute0(adcValue.floatValue(), RA, WLS_REFERENCE_VOLTAGE, K, ADC_REFERENCE_VOLTAGE));
  }

  static Float wetnessComputeICECorrosivity(Float adcValue)
  {
    if (adcValue == null)
      return null;
    float RA = 2000.0F;
    float WLS_REFERENCE_VOLTAGE = 1.0F;
    float ADC_REFERENCE_VOLTAGE = 1.22F;
    float K = 1.2048F;

    return Float.valueOf(wetnessCompute0(adcValue.floatValue(), RA, WLS_REFERENCE_VOLTAGE, K, ADC_REFERENCE_VOLTAGE));
  }

  public static Float computeBPCUI24Wetness(Float adcValue, float moteVoltage)
  {
    if (adcValue == null)
      return null;
    float RA = 10000.0F;
    float WLS_REFERENCE_VOLTAGE = 2.048F;
    float ADC_REFERENCE_VOLTAGE = moteVoltage;
    float K = 3.0F;
    return Float.valueOf(wetnessCompute0(adcValue.floatValue(), RA, WLS_REFERENCE_VOLTAGE, K, ADC_REFERENCE_VOLTAGE));
  }

  public static Float computeBPCUI24Corrosivity(Float adcValue, float moteVoltage)
  {
    if (adcValue == null)
      return null;
    float RA = 1000.0F;
    float WLS_REFERENCE_VOLTAGE = 2.048F;
    float ADC_REFERENCE_VOLTAGE = moteVoltage;
    float K = 3.0F;

    return Float.valueOf(wetnessCompute0(adcValue.floatValue(), RA, WLS_REFERENCE_VOLTAGE, K, ADC_REFERENCE_VOLTAGE));
  }

  private static float wetnessCompute0(float adcValue, float RA, float WLS_REFERENCE_VOLTAGE, float K, float ADC_REFERENCE_VOLTAGE)
  {
    float ADC_RESOLUTION_MINUS_ONE = 1023.0F;

    float rload = ADC_RESOLUTION_MINUS_ONE * RA * WLS_REFERENCE_VOLTAGE * K / (adcValue * ADC_REFERENCE_VOLTAGE);

    if ((Float.isNaN(rload)) || (Float.isInfinite(rload)) || (rload > 100.0F * RA * Tools.round(Float.valueOf(WLS_REFERENCE_VOLTAGE), 0).floatValue()))
    {
      rload = 100.0F * RA * Tools.round(Float.valueOf(WLS_REFERENCE_VOLTAGE), 0).floatValue();
    }

    if (rload < RA * Tools.round(Float.valueOf(WLS_REFERENCE_VOLTAGE), 0).floatValue()) {
      rload = RA * Tools.round(Float.valueOf(WLS_REFERENCE_VOLTAGE), 0).floatValue();
    }

    return rload;
  }

  public static Float rtdResistanceToTemperatureCelsius(Float resistance)
  {
    if (resistance == null)
      return null;
    float A = 0.0039083F;
    float B = -5.775E-007F;
    float C = -4.1831E-012F;
    float R0 = 100.0F;

    float temperature = 0.0F;

    if (resistance.floatValue() < 100.0F) {
      float t1 = (resistance.floatValue() / R0 - 1.0F) / (A + 100.0F * B);
      float t2 = (float)(t1 - (1.0F + A * t1 + B * Math.pow(t1, 2.0D) + C * Math.pow(t1, 3.0D) * (t1 - 100.0F) - resistance.floatValue() / R0) / (A + 2.0F * B * t1 - 300.0F * C * Math.pow(t1, 2.0D) + 4.0F * C * Math.pow(t1, 3.0D)));

      temperature = (float)(t2 - (1.0F + A * t2 + B * Math.pow(t2, 2.0D) + C * Math.pow(t2, 3.0D) * (t2 - 100.0F) - resistance.floatValue() / R0) / (A + 2.0F * B * t2 - 300.0F * C * Math.pow(t2, 2.0D) + 4.0F * C * Math.pow(t2, 3.0D)));
    }
    else
    {
      temperature = (float)((-A + Math.sqrt(Math.pow(A, 2.0D) - 4.0F * B * (1.0F - resistance.floatValue() / R0))) / (2.0F * B));
    }

    return Float.valueOf(temperature);
  }

  static Float rtdOffsetCompensate(Float resistance)
  {
    if (resistance == null)
      return null;
    Float resistanceOffset = Float.valueOf(-0.00342652F * resistance.floatValue() + 0.2413268F);
    Float resistanceCorrected = Float.valueOf(resistance.floatValue() - resistanceOffset.floatValue());

    return resistanceCorrected;
  }

  static Float resistanceFromADC(int numberWires, Integer rawADC1, Integer rawADC2, Integer rawADC3, Integer rawADC4)
  {
    if ((rawADC1 == null) || (rawADC1.intValue() < -32000))
    {
      return null;
    }

    Float Oversampling_ratio = Float.valueOf(512.0F);
    Float V_reference = Float.valueOf(1.22F);
    Float Reference_resistor = Float.valueOf(1000.0F);
    Float PGA3_gain = Float.valueOf(1.0F);
    Float PGA3_gain_4 = Float.valueOf(4.0F);
    Float PGA3_offset = Float.valueOf(0.5F);

    Float SV4 = Float.valueOf((float)(V_reference.floatValue() / PGA3_gain.floatValue() * (Oversampling_ratio.floatValue() / (Oversampling_ratio.floatValue() + 1.0F) * rawADC1.intValue() / Math.pow(2.0D, 16.0D) + PGA3_offset.floatValue())));

    Float SV2 = Float.valueOf((float)(V_reference.floatValue() / PGA3_gain_4.floatValue() * (Oversampling_ratio.floatValue() / (Oversampling_ratio.floatValue() + 1.0F) * rawADC3.intValue() / Math.pow(2.0D, 16.0D) + PGA3_offset.floatValue())));

    Float SV1 = Float.valueOf((float)(V_reference.floatValue() / PGA3_gain_4.floatValue() * (Oversampling_ratio.floatValue() / (Oversampling_ratio.floatValue() + 1.0F) * rawADC4.intValue() / Math.pow(2.0D, 16.0D) + PGA3_offset.floatValue())));

    logger.debug("SV1 " + SV1 + ", SV2 " + SV2 + ", SV4 " + SV4 + ", rawADC1 " + rawADC1 + ", rawADC2 " + rawADC2 + ", rawADC3 " + rawADC3 + ", rawADC4 " + rawADC4);

    Float RTDCurrent = Float.valueOf(SV4.floatValue() / Reference_resistor.floatValue());

    Float RTDResistance = null;
    if (numberWires == 2)
      RTDResistance = Float.valueOf(SV1.floatValue() / RTDCurrent.floatValue());
    else if (numberWires == 3)
      RTDResistance = Float.valueOf((SV2.floatValue() - (SV1.floatValue() - SV2.floatValue())) / RTDCurrent.floatValue());
    else {
      logger.error("Unknown number of wires " + numberWires);
    }
    return RTDResistance;
  }

  public static Float computeHighImpedance(Integer rawADC)
  {
    if (rawADC == null)
      return null;
    float V_REF = 1.22F;
    float OSR = 256.0F;
    Float vSensor = Float.valueOf(rawADC.intValue() / (float)Math.pow(2.0D, 16.0D) * 2.0F * V_REF * OSR / (OSR + 1.0F));
    return vSensor;
  }

  static final Float calibrateRTD(Float value, Object[][] calibrationData)
  {
    if ((value == null) || (calibrationData == null)) {
      return value;
    }

    logger.debug("Calibration " + ArrayTools.arrayToStringVisual(calibrationData));

    for (int i = 0; i < calibrationData.length; i++) {
      Object[] row = calibrationData[i];
      if ((row == null) || (((Integer)row[0]).intValue() == 0))
        continue;
      if (value.floatValue() > ((Integer)row[0]).intValue() / 100) {
        if ((i == calibrationData.length - 1) || (calibrationData[(i + 1)] == null) || (calibrationData[(i + 1)][0] == null) || (((Integer)calibrationData[(i + 1)][0]).intValue() == 0))
        {
          return Float.valueOf(value.floatValue() + (((Integer)row[1]).intValue() - 10000.0F) / 1000.0F);
        }
      }
      else
      {
        if (i == 0)
        {
          return Float.valueOf(value.floatValue() + (((Integer)row[1]).intValue() - 10000.0F) / 1000.0F);
        }

        Object[] prevRow = calibrationData[(i - 1)];
        float A = value.floatValue() - ((Integer)prevRow[0]).intValue() / 100.0F;
        float C = ((Integer)row[0]).intValue() / 100 - ((Integer)prevRow[0]).intValue() / 100.0F;
        float D = ((Integer)row[1]).intValue() - ((Integer)prevRow[1]).intValue();
        float corr = A * D / C + ((Integer)prevRow[1]).intValue();

        return Float.valueOf(value.floatValue() + (corr - 10000.0F) / 1000.0F);
      }

    }

    return value;
  }

  static Float convertBPThermistor(Integer rawValue, Float batteryVoltage)
  {
    float R28 = 49900.0F;
    float REFERENCE_VOLTAGE = 2.048F;

    float resistance = rawValue.intValue() / 1023.0F * batteryVoltage.floatValue() * R28 / (REFERENCE_VOLTAGE - rawValue.intValue() / 1023.0F * batteryVoltage.floatValue());

    float A = 0.0F;
    float B = 0.0F;

    if (resistance >= 11188530.0F) {
      A = 3547.8999F;
      B = -0.2037F;
    } else if (resistance >= 6701660.0F) {
      A = 1646.9F;
      B = -0.1563F;
    } else if (resistance >= 2948480.0F) {
      A = 1808.9F;
      B = -0.1614F;
    } else if (resistance >= 25790.0F) {
      A = 1638.8F;
      B = -0.1544F;
    } else {
      A = 1646.9F;
      B = -0.1563F;
    }

    logger.debug("resistance " + resistance + ",A " + A + ",B " + B + ",rawValue " + rawValue);

    Float conv_temp = Float.valueOf((float)(A * Math.pow(resistance, B)) - 200.0F);

    logger.debug("conv_temp " + conv_temp);
    if ((conv_temp != null) && ((Float.isInfinite(conv_temp.floatValue())) || (Float.isNaN(conv_temp.floatValue())))) {
      logger.error("Temperature is NAN or Infinite, storing as null instead.");
      conv_temp = null;
    }
    return conv_temp;
  }

  public static void main(String[] args)
    throws Exception
  {
    args = null;

    DatabaseLoader.setupTest();

    String product_number = XTEMP_1014_0002;
    HashMap map = new HashMap();
    map.put("data_type", "5");
    int temp = 26000;
    map.put("data", "10001000100010001000");
    Message data = new Message("Data", map);
    getInstance().convertData(product_number, data, (Object[][][])null);
    logger.debug("Res " + data.getFloatValue("temp"));

    product_number = XTEMP_1051_0002;

    map = new HashMap();
    map.put("data_type", "14");

    map.put("data", "100010001000100010001000");
    data = new Message("Data", map);
    getInstance().convertData(product_number, data, (Object[][][])null);
    logger.debug("Res " + data.getFloatValue("temp"));
  }

  public String getProductGroupDescriptionFromCode(String productGroupCode)
  {
    if (productGroupCode == null)
      return "Unknown";
    String result = (String)this.groupMap.get(productGroupCode);
    if (result == null)
      return "Unknown";
    return result;
  }

  public boolean isGroupCodeValid(String productGroupCode)
  {
    return this.groupMap.get(productGroupCode) != null;
  }

  public synchronized List<Displayable> getProductGroupDisplayableList()
  {
    if (this.productGroupDisplayableList == null) {
      this.productGroupDisplayableList = new ArrayList();
      Set set = this.groupMap.keySet();
      Iterator it = set.iterator();
      while (it.hasNext()) {
        String key = (String)it.next();
        String value = (String)this.groupMap.get(key);
        Displayable disp = new DisplayableImpl(key, value);
        this.productGroupDisplayableList.add(disp);
      }

      Comparator comp = new Comparator() {
        public int compare(Displayable o1, Displayable o2) {
          if ((o1 == null) || (o2 == null) || (o2.getDisplayValue() == null))
            return -1;
          return o2.getDisplayValue().compareTo(o1.getDisplayValue());
        }
      };
      Collections.sort(this.productGroupDisplayableList, comp);
    }
    return this.productGroupDisplayableList;
  }

  public static Float getRTDResistanceFromTempCelcius(Float tempCelcius)
  {
    if (tempCelcius == null) {
      return null;
    }
    float A = 0.0039083F;
    float B = -5.775E-007F;
    float C = -4.1831E-012F;
    float R0 = 100.0F;

    if (tempCelcius.floatValue() >= 0.0F) {
      C = 0.0F;
    }
    float R = (float)(R0 * (1.0F + A * tempCelcius.floatValue() + B * Math.pow(tempCelcius.floatValue(), 2.0D) + (tempCelcius.floatValue() - 100.0F) * C * Math.pow(tempCelcius.floatValue(), 3.0D)));

    return Float.valueOf(R);
  }

  private final void enableCalibrationForProII(Product product)
  {
    product.setComputeRequirements(this.pro2Requirements);

    product.setCalibrationAvailable(true);
    product.setCalibrationPlugs(new float[] { 56200.0F, 1000.0F, 10000.0F, 10000.0F });
    product.setCalibrationCurves(new int[] { 250, 100, 0, 250, 100, 0 });
    product.setNotes("- Point a strong light towards light sensor (>100lux)\n- Use 56.2K calibrator on Port 1 and 1K calibrator on Port 2\n- Check that LED blinks GREEN RED ORANGE during flashing (from 5.4.18)\n- Press the pushbutton at the end and make sure that the LED blinks (pushbutton test)");
  }

  private void writeProductsToFile(String fileName)
    throws Exception
  {
    PrintWriter pw = new PrintWriter(new OutputStreamWriter(new BufferedOutputStream(new FileOutputStream(fileName))));
    pw.println("Product Code\tProduct number\tDescription");
    for (String prodName : this.productList) {
      pw.print(prodName);
      pw.print("\t");

      Integer prod_num = (Integer)this.productNameReverseMap.get(prodName);
      pw.print(prod_num);
      pw.print("\t");

      Product product = (Product)this.productDescrMap.get(prod_num);
      pw.println(product.getProductDescription());
    }

    pw.flush();
    pw.close();
  }

  class Pro2ComputeRequirements extends ProductInformation.ComputeRequirements
  {
    Pro2ComputeRequirements()
    {
      super();
    }

    public void computeRequirements(ProductInformation.Product product, Float expectedMeasurementChannel1, Float expectedMeasurementChannel2)
    {
      float maxTolerance = 0.36F;

      float tempCh1Min = expectedMeasurementChannel1.floatValue() - maxTolerance;
      float tempCh1Max = expectedMeasurementChannel1.floatValue() + maxTolerance;

      float tempCh2Min = expectedMeasurementChannel2.floatValue() - maxTolerance;
      float tempCh2Max = expectedMeasurementChannel2.floatValue() + maxTolerance;

      ProductInformation.logger.debug("Using tempCh1Min=" + tempCh1Min + ", tempCh1Max " + tempCh1Max + ", tempCh2Min " + tempCh2Min + ", tempCh2Max " + tempCh2Max + " for expectedMeasurementChannel1 " + expectedMeasurementChannel1 + ", expectedMeasurementChannel2 " + expectedMeasurementChannel2);

      product.setRequirements(new ProductInformation.Requirement[] { new ProductInformation.Requirement("light", Float.valueOf(100.0F), null), new ProductInformation.Requirement("temp", Float.valueOf(tempCh1Min), Float.valueOf(tempCh1Max)), new ProductInformation.Requirement("temp2", Float.valueOf(tempCh2Min), Float.valueOf(tempCh2Max)) });
    }
  }

  class RTDComputeRequirements extends ProductInformation.ComputeRequirements
  {
    RTDComputeRequirements()
    {
      super();
    }

    public void computeRequirements(ProductInformation.Product product, Float expectedMeasurementChannel1, Float expectedMeasurementChannel2) {
      float maxTolerance = 0.2F;

      float tempCh1Min = expectedMeasurementChannel1.floatValue() - maxTolerance;
      float tempCh1Max = expectedMeasurementChannel1.floatValue() + maxTolerance;

      float tempCh2Min = expectedMeasurementChannel2.floatValue() - maxTolerance;
      float tempCh2Max = expectedMeasurementChannel2.floatValue() + maxTolerance;

      ProductInformation.logger.debug("Using tempCh1Min=" + tempCh1Min + ", tempCh1Max " + tempCh1Max + ", tempCh2Min " + tempCh2Min + ", tempCh2Max " + tempCh2Max);

      product.setRequirements(new ProductInformation.Requirement[] { new ProductInformation.Requirement("temp", Float.valueOf(tempCh1Min), Float.valueOf(tempCh1Max)), new ProductInformation.Requirement("temp2", Float.valueOf(tempCh2Min), Float.valueOf(tempCh2Max)) });
    }
  }

  class RTDGS1011ComputeRequirements extends ProductInformation.ComputeRequirements
  {
    RTDGS1011ComputeRequirements()
    {
      super();
    }

    public void computeRequirements(ProductInformation.Product product, Float expectedMeasurementChannel1, Float expectedMeasurementChannel2) {
      float maxTolerance = 0.2F;

      expectedMeasurementChannel1 = ProductInformation.rtdResistanceToTemperatureCelsius(expectedMeasurementChannel1);
      expectedMeasurementChannel2 = ProductInformation.rtdResistanceToTemperatureCelsius(expectedMeasurementChannel2);

      float tempCh1Min = ProductInformation.celciusToFarenheit(Float.valueOf(expectedMeasurementChannel1.floatValue() - maxTolerance)).floatValue();
      float tempCh1Max = ProductInformation.celciusToFarenheit(Float.valueOf(expectedMeasurementChannel1.floatValue() + maxTolerance)).floatValue();

      float tempCh2Min = ProductInformation.celciusToFarenheit(Float.valueOf(expectedMeasurementChannel2.floatValue() - maxTolerance)).floatValue();
      float tempCh2Max = ProductInformation.celciusToFarenheit(Float.valueOf(expectedMeasurementChannel2.floatValue() + maxTolerance)).floatValue();

      ProductInformation.logger.debug("Using tempCh1Min=" + tempCh1Min + ", tempCh1Max " + tempCh1Max + ", tempCh2Min " + tempCh2Min + ", tempCh2Max " + tempCh2Max);

      product.setRequirements(new ProductInformation.Requirement[] { new ProductInformation.Requirement("temp", Float.valueOf(tempCh1Min), Float.valueOf(tempCh1Max)), new ProductInformation.Requirement("temp2", Float.valueOf(tempCh2Min), Float.valueOf(tempCh2Max)) });
    }
  }

  public class ComputeRequirements
  {
    public ComputeRequirements()
    {
    }

    public void computeRequirements(ProductInformation.Product product, Float expectedMeasurementChannel1, Float expectedMeasurementChannel2)
    {
      ProductInformation.logger.warn("No requirements was set for this product! " + product + ", " + expectedMeasurementChannel1 + ", " + expectedMeasurementChannel2);
    }
  }

  public static class CalibrationTransformer
  {
    public Float transformResistance(Float input)
    {
      return input;
    }

    public Float transformMeasurement(Float input) {
      return input;
    }
    public Float convertBeforeSending(Float input) {
      return input;
    }
    public Float convertDeltaBeforeSending(Float input) {
      return input;
    }
  }

  public static class Requirement
  {
    private String rawCode;
    private Float minVal;
    private Float maxVal;
    private boolean preTest;

    public Requirement(String rawCode, Float minVal, Float maxVal, boolean preTest)
    {
      this.rawCode = rawCode;
      this.minVal = minVal;
      this.maxVal = maxVal;
      this.preTest = preTest;
    }

    public Requirement(String rawCode, Float minVal, Float maxVal)
    {
      this.rawCode = rawCode;
      this.minVal = minVal;
      this.maxVal = maxVal;
    }

    public String getRawCode() {
      return this.rawCode;
    }

    public Float getMinVal() {
      return this.minVal;
    }

    public Float getMaxVal() {
      return this.maxVal;
    }

    public boolean isPreTest() {
      return this.preTest;
    }
  }

  public class ColumnDefinition
  {
    String columnName;
    String sensorType;
    boolean calibrable;

    ColumnDefinition(String columnName, String sensorType)
    {
      this(columnName, sensorType, false);
    }

    ColumnDefinition(String columnName, String sensorType, boolean calibrable)
    {
      this.sensorType = sensorType;
      this.columnName = columnName;
      this.calibrable = calibrable;
    }

    ColumnDefinition(String sensorType, boolean calibrable) {
      this.sensorType = sensorType;
      this.columnName = sensorType;
      this.calibrable = calibrable;
    }

    private String getColumnName() {
      return this.columnName;
    }

    private boolean isCalibrable() {
      return this.calibrable;
    }

    private String getSensorType() {
      return this.sensorType;
    }
  }

  class ConfigurableSensor extends ProductInformation.VariableSensor
  {
    int sensorType;
    String displayName;

    ConfigurableSensor(String xmlName, String rawCode, int sensorType, String displayName)
    {
      super(rawCode);
      this.sensorType = sensorType;
      this.displayName = displayName;
    }

    public int getSensorType()
    {
      return this.sensorType;
    }

    public String getDisplayName()
    {
      return this.displayName;
    }
  }

  public static abstract class VariableSensor extends ProductInformation.DefaultComponent
    implements Component
  {
    String xmlName;
    String rawName;

    VariableSensor(String xmlName, String rawName)
    {
      this.xmlName = xmlName;
      this.rawName = rawName;
    }

    public String getSensorCodeDisplay()
    {
      return this.xmlName;
    }

    public float fromBytes(int[] bytes)
    {
      throw new NotImplementedException();
    }

    public String getXMLName()
    {
      return this.xmlName;
    }

    public void fromRaw(Message data, Object[][] calibrationData)
    {
      Float rawMeasurement = data.getFloatValue(this.rawName);
      data.setValue(this.xmlName, rawMeasurement);
    }
  }

  public static abstract class DefaultComponent
    implements Component
  {
    public boolean isCalibrationAvailable()
    {
      return false;
    }
  }

  public class DefaultProduct extends ProductInformation.Product
  {
    Component[] comps;
    String[] availableDataColumns;
    String[] availableSensorTypes;
    String[] availableDataColumnsForCalibration;

    DefaultProduct(int productCategory, String productGroup, String productDescription, Object[] availableColumns, Component[] comps)
    {
      super(productCategory, productGroup, productDescription);
      this.comps = comps;
      ProductInformation.ColumnDefinition[] cds;
      if ((availableColumns instanceof String[])) {
        this.availableDataColumns = ((String[])(String[])availableColumns);
        this.availableSensorTypes = ((String[])(String[])availableColumns);
        this.availableDataColumnsForCalibration = ((String[])(String[])availableColumns);
      }
      else {
        cds = (ProductInformation.ColumnDefinition[])(ProductInformation.ColumnDefinition[])availableColumns;
        List av1 = new ArrayList();
        List av2 = new ArrayList();
        List av3 = new ArrayList();
        for (ProductInformation.ColumnDefinition cd : cds) {
          av1.add(cd.getColumnName());
          av3.add(cd.getSensorType());
          if (cd.isCalibrable()) {
            av2.add(cd.getSensorType());
          }
        }
        this.availableDataColumns = ArrayTools.listToStringArray(av1);
        this.availableSensorTypes = ArrayTools.listToStringArray(av3);
        this.availableDataColumnsForCalibration = ArrayTools.listToStringArray(av2);
      }

      for (String sensorType : this.availableSensorTypes)
        if (!com.aginova.app.oilgas.Topics.getTopics().isSensorAvailable(sensorType))
          throw new RuntimeException("Sensor type: " + sensorType + " is not defined in Topics! " + com.aginova.app.oilgas.Topics.getTopics().getSensorsDescriptors());
    }

    public Component[] getComponents()
    {
      return this.comps;
    }

    public String[] getAvailableSensorTypes() {
      return this.availableSensorTypes;
    }

    public String[] getAvailableDataColumns() {
      return this.availableDataColumns;
    }

    public String[] getAvailableDataColumnsForCalibration() {
      return this.availableDataColumnsForCalibration;
    }

    public int getColumnPositionByName(String name)
    {
      if (this.availableDataColumns != null) {
        for (int i = 0; i < this.availableDataColumns.length; i++) {
          if (this.availableDataColumns[i].equals(name)) {
            return i;
          }
        }
      }
      else if (ProductInformation.logger.isDebugEnabled()) {
        ProductInformation.logger.debug("list of components was null for code " + name + " for product " + this.productInternalGroup + "," + this.productDescriptiveInformation);
      }

      return -1;
    }
  }

  public abstract class Product
  {
    String productDescriptiveInformation;
    String productInternalGroup;
    int productCategory;
    boolean calibrationAvailable;
    boolean preciseCalibration;
    boolean onCalibrationPoint = false;

    boolean pHcalibration = false;

    ProductInformation.CalibrationTransformer calibrationTransformer = new ProductInformation.CalibrationTransformer();
    int[] calibrationCurves;
    float[] calibrationPlugs;
    ProductInformation.Requirement[] requirements;
    String notes;
    boolean flashStation = true;
    String internalTemp;
    ProductInformation.ComputeRequirements computeRequirements = new ProductInformation.ComputeRequirements(ProductInformation.this);

    private Map<String, Object[]> codeDisplayToComponentMap = null;

    public Product(int productCategory, String productInternalGroup, String productDescriptiveInformation) {
      this.productDescriptiveInformation = productDescriptiveInformation;
      this.productInternalGroup = productInternalGroup;
      this.productCategory = productCategory;
    }

    public void setOneCalibrationPoint(boolean value) {
      this.onCalibrationPoint = value;
    }

    public boolean getOneCalibrationPoint()
    {
      return this.onCalibrationPoint;
    }

    public void setCalibrationpH(boolean value)
    {
      this.pHcalibration = value;
    }

    public boolean getCalibrationpH()
    {
      return this.pHcalibration;
    }

    public void hideFlashingStation()
    {
      this.flashStation = false;
    }

    public boolean isFlashStationVisible()
    {
      return this.flashStation;
    }

    public String getNotes()
    {
      return this.notes;
    }

    public void setNotes(String notes)
    {
      this.notes = notes;
    }

    public Component[] getComponents() {
      throw new NotImplementedException();
    }

    public Object[] getComponentFromDisplayCode(String displayCode)
    {
      if (this.codeDisplayToComponentMap == null) {
        this.codeDisplayToComponentMap = new HashMap();
        Component[] comps = getComponents();
        if (comps != null) {
          for (int i = 0; i < comps.length; i++) {
            this.codeDisplayToComponentMap.put(comps[i].getSensorCodeDisplay(), new Object[] { comps[i], Integer.valueOf(i) });
          }
        }

      }

      Object[] temp = (Object[])this.codeDisplayToComponentMap.get(displayCode);
      if (ProductInformation.logger.isDebugEnabled()) {
        ProductInformation.logger.debug("getComponentFromDisplayCode map: " + this.codeDisplayToComponentMap + ", for displayCode " + displayCode + ", temp " + ArrayTools.arrayToStringVisual(temp));
      }

      return temp;
    }

    public String getProductDescription()
    {
      return (String)ProductInformation.this.groupMap.get(this.productInternalGroup) + " - " + this.productDescriptiveInformation;
    }

    public String getProductionDescriptiveInformation() {
      return this.productDescriptiveInformation;
    }

    public String toString() {
      return "Product: " + getProductDescription();
    }

    public String getProductGroup()
    {
      return (String)ProductInformation.this.groupMap.get(this.productInternalGroup);
    }

    public String getProductInternalGroup() {
      return this.productInternalGroup; } 
    public abstract String[] getAvailableDataColumns();

    public abstract String[] getAvailableSensorTypes();

    public abstract String[] getAvailableDataColumnsForCalibration();

    public boolean isCalibrationAvailable() { return this.calibrationAvailable; }

    public void setCalibrationAvailable(boolean calibrationAvailable)
    {
      this.calibrationAvailable = calibrationAvailable;
    }

    public void setRequirements(ProductInformation.Requirement[] requirements) {
      this.requirements = requirements;
    }

    public ProductInformation.Requirement[] getRequirements() {
      return this.requirements;
    }

    public void setInternalTemp(String sensorType) {
      this.internalTemp = sensorType;
    }

    public String getInternalTemp() {
      return this.internalTemp;
    }

    public float[] getCalibrationPlugs() {
      return this.calibrationPlugs;
    }

    public void setCalibrationPlugs(float[] f) {
      this.calibrationPlugs = f;
    }

    public int[] getCalibrationCurves() {
      return this.calibrationCurves;
    }

    public void setCalibrationCurves(int[] f) {
      this.calibrationCurves = f;
    }

    public void setCalibrationTransformer(ProductInformation.CalibrationTransformer c) {
      this.calibrationTransformer = c;
    }

    public ProductInformation.CalibrationTransformer getCalibrationTransformer() {
      return this.calibrationTransformer;
    }

    public boolean isPreciseCalibration() {
      return this.preciseCalibration;
    }
    public void setPreciseCalibration() {
      this.preciseCalibration = true;
    }

    public void setComputeRequirements(ProductInformation.ComputeRequirements computeRequirements)
    {
      this.computeRequirements = computeRequirements;
    }

    public ProductInformation.ComputeRequirements getComputeRequirements() {
      return this.computeRequirements;
    }
  }

  class ColumnNotFoundException extends Exception
  {
    ColumnNotFoundException(String s)
    {
      super();
    }
  }
}