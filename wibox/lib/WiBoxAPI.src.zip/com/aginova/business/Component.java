package com.aginova.business;

import com.aginova.crossbow.Message;
import com.aginova.exception.DriverException;

public abstract interface Component
{
  public abstract int getSensorType();

  public abstract String getSensorCodeDisplay();

  public abstract void fromRaw(Message paramMessage, Object[][] paramArrayOfObject)
    throws DriverException;

  public abstract float fromBytes(int[] paramArrayOfInt);

  public abstract String getDisplayName();

  public abstract boolean isCalibrationAvailable();
}