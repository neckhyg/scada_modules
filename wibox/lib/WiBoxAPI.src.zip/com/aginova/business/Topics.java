package com.aginova.business;

import com.aginova.crossbow.DefaultSensorDescriptor;
import com.aginova.portlets.Portlet;
import com.aginova.storage.User;
import com.aginova.util.Lang;
import com.aginova.util.Listener;
import com.aginova.util.UserProperties;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;

public abstract class Topics
{
  private static final Logger logger = Logger.getLogger(Topics.class);
  private static Topics topics;
  private static Map<String, String> jspMap;
  private static Map<String, String> oppositeMap;
  private static Map<String, Descriptor> descriptorMap;
  private static boolean registered = false;

  public static int PRECISION_0_DIGIT = 0;
  public static int PRECISION_1_DIGIT = 1;
  public static int PRECISION_2_DIGIT = 2;
  public static int PRECISION_3_DIGIT = 3;
  private List<Descriptor> descriptorList;
  List sensorsDescriptors = null;
  private Map sensorsDescriptorsMap = null;

  public static String COLUMN_NAME_M1 = "m1";
  public static String COLUMN_NAME_M2 = "m2";
  public static String COLUMN_NAME_M3 = "m3";
  public static String COLUMN_NAME_M4 = "m4";
  public static String COLUMN_NAME_M5 = "m5";
  public static String COLUMN_NAME_M6 = "m6";
  public static String COLUMN_NAME_M7 = "m7";

  public static String COLUMN_NAME_D1 = "d1";
  public static String COLUMN_NAME_D2 = "d2";
  public static String COLUMN_NAME_D3 = "d3";
  public static String COLUMN_NAME_D4 = "d4";
  public static String COLUMN_NAME_D5 = "d5";
  public static String COLUMN_NAME_D6 = "d6";
  public static String COLUMN_NAME_D7 = "d7";
  public static String COLUMN_NAME_D8 = "d8";
  public static String COLUMN_NAME_D9 = "d9";
  public static String COLUMN_NAME_D10 = "d10";
  public static String COLUMN_NAME_D11 = "d11";
  public static String COLUMN_NAME_D12 = "d12";

  public static String SENSOR_TYPE_ACT_POWER_CONSUMPTION_1 = "actPower1";
  public static String SENSOR_TYPE_ACT_POWER_CONSUMPTION_2 = "actPower2";
  public static String SENSOR_TYPE_ACT_POWER_CONSUMPTION_3 = "actPower3";
  public static String SENSOR_TYPE_ACT_POWER_CONSUMPTION_TOT = "actPowerTot";

  public static String SENSOR_TYPE_REACT_POWER_CONSUMPTION_1 = "reactPower1";
  public static String SENSOR_TYPE_REACT_POWER_CONSUMPTION_2 = "reactPower2";
  public static String SENSOR_TYPE_REACT_POWER_CONSUMPTION_3 = "reactPower3";
  public static String SENSOR_TYPE_REACT_POWER_CONSUMPTION_TOT = "reactPowerTot";

  public static String SENSOR_TYPE_APPARENT_POWER_CONSUMPTION_1 = "appPower1";
  public static String SENSOR_TYPE_APPARENT_POWER_CONSUMPTION_2 = "appPower2";
  public static String SENSOR_TYPE_APPARENT_POWER_CONSUMPTION_3 = "appPower3";
  public static String SENSOR_TYPE_APPARENT_POWER_CONSUMPTION_TOT = "appPowerTot";

  public static String FREQ_POWER_TEXT = "freqPower";

  public static String MAX_CURRENT_POWER1_TEXT = "maxCurPwr1";
  public static String MAX_CURRENT_POWER2_TEXT = "maxCurPwr2";
  public static String MAX_CURRENT_POWER3_TEXT = "maxCurPwr3";

  public static String MIN_VOLTAGE_POWER1_TEXT = "minVoltPwr1";
  public static String MIN_VOLTAGE_POWER2_TEXT = "minVoltPwr2";
  public static String MIN_VOLTAGE_POWER3_TEXT = "minVoltPwr3";

  public static String SENSOR_TYPE_VOLTAGE_1 = "voltage1";
  public static String SENSOR_TYPE_VOLTAGE_2 = "voltage2";

  public static String SENSOR_TYPE_RESISTANCE_1 = "resistance1";
  public static String SENSOR_TYPE_RESISTANCE_2 = "resistance2";

  public static String SENSOR_TYPE_PH_1 = "ph1";
  public static String SENSOR_TYPE_PH_2 = "ph2";

  public static String SENSOR_TYPE_CO2_A = "co2a";
  public static String SENSOR_TYPE_CO2_B = "co2b";

  public static String SENSOR_TYPE_CO2 = "co2";
  public static String BATT_VOLT_TEXT = "batVolt";

  public static String SENSOR_TYPE_TEMPERATURE = "temp";
  public static String SENSOR_TYPE_TEMPERATURE_INT = "tempInt";

  public static String SENSOR_TYPE_TEMPERATURE_2 = "temp2";
  public static String SENSOR_TYPE_HUMIDITY = "hum";
  public static String SENSOR_TYPE_LIGHT = "light";
  public static String SENSOR_TYPE_OXY = "oxy";
  public static String SENSOR_TYPE_WETNESS1 = "wetness1";
  public static String SENSOR_TYPE_WETNESS2 = "wetness2";
  public static String SENSOR_TYPE_WETNESS3 = "wetness3";
  public static String SENSOR_TYPE_WETNESS4 = "wetness4";

  public static String SENSOR_TYPE_CORR1 = "corr1";
  public static String SENSOR_TYPE_CORR2 = "corr2";
  public static String SENSOR_TYPE_CORR3 = "corr3";
  public static String SENSOR_TYPE_CORR4 = "corr4";

  public static String SENSOR_TYPE_MASCORR_AVG = "masCorrAvg";
  public static String SENSOR_TYPE_MASCORR_MAX = "masCorrMax";

  public static String SENSOR_TYPE_DIGITAL_IO = "digitalIO";
  public static String SENSOR_TYPE_ACOUSTIC = "acoustic";
  public static String SENSOR_TYPE_HIGH_IMPEDANCE = "highImpedance";
  public static String SENSOR_TYPE_PARTICLES = "particles";

  public static String SENSOR_TYPE_CORROSION = "corr";
  public static String SENSOR_TYPE_PRESSURE = "press";
  public static String SENSOR_TYPE_IMPEDANCE_REAL = "impedance_real";
  public static String SENSOR_TYPE_IMPEDANCE_IMAGINARY = "impedance_imaginary";

  public static String SENSOR_TYPE_IMPEDANCE_REAL_2 = "impedance2_real";
  public static String SENSOR_TYPE_IMPEDANCE_IMAGINARY_2 = "impedance2_imaginary";

  public static String SENSOR_TYPE_IMPEDANCE_MAGNITUDE = "impedance_magnitude";
  public static String SENSOR_TYPE_IMPEDANCE_ANGLE = "impedance_angle";

  public static String SENSOR_TYPE_RLOAD0 = "rload0";
  public static String SENSOR_TYPE_RLOAD1 = "rload1";
  public static String SENSOR_TYPE_RLOAD2 = "rload2";
  public static String SENSOR_TYPE_RLOAD3 = "rload3";
  public static String SENSOR_TYPE_RLOAD4 = "rload4";
  public static String SENSOR_TYPE_RLOAD5 = "rload5";
  public static String SENSOR_TYPE_RLOAD6 = "rload6";
  public static String SENSOR_TYPE_RLOAD7 = "rload7";
  public static String SENSOR_TYPE_RLOAD8 = "rload8";
  public static String SENSOR_TYPE_RLOAD9 = "rload9";
  public static String SENSOR_TYPE_RLOAD10 = "rload10";
  public static String SENSOR_TYPE_RLOAD11 = "rload11";
  public static String SENSOR_TYPE_RLOAD12 = "rload12";
  public static String SENSOR_TYPE_RLOAD13 = "rload13";
  public static String SENSOR_TYPE_RLOAD14 = "rload14";
  public static String SENSOR_TYPE_RLOAD15 = "rload15";
  public static String SENSOR_TYPE_RLOAD16 = "rload16";
  public static String SENSOR_TYPE_RLOAD17 = "rload17";
  public static String SENSOR_TYPE_RLOAD18 = "rload18";
  public static String SENSOR_TYPE_RLOAD19 = "rload19";

  public static String SENSOR_TYPE_ADC0 = "adcValue0";
  public static String SENSOR_TYPE_ADC1 = "adcValue1";
  public static String SENSOR_TYPE_ADC2 = "adcValue2";
  public static String SENSOR_TYPE_ADC3 = "adcValue3";
  public static String SENSOR_TYPE_ADC4 = "adcValue4";
  public static String SENSOR_TYPE_ADC5 = "adcValue5";
  public static String SENSOR_TYPE_ADC6 = "adcValue6";
  public static String SENSOR_TYPE_ADC7 = "adcValue7";
  public static String SENSOR_TYPE_ADC8 = "adcValue8";
  public static String SENSOR_TYPE_ADC9 = "adcValue9";
  public static String SENSOR_TYPE_ADC10 = "adcValue10";
  public static String SENSOR_TYPE_ADC11 = "adcValue11";
  public static String SENSOR_TYPE_ADC12 = "adcValue12";
  public static String SENSOR_TYPE_ADC13 = "adcValue13";
  public static String SENSOR_TYPE_ADC14 = "adcValue14";
  public static String SENSOR_TYPE_ADC15 = "adcValue15";
  public static String SENSOR_TYPE_ADC16 = "adcValue16";
  public static String SENSOR_TYPE_ADC17 = "adcValue17";
  public static String SENSOR_TYPE_ADC18 = "adcValue18";
  public static String SENSOR_TYPE_ADC19 = "adcValue19";
  public static String SENSOR_TYPE_ADC20 = "adcValue20";

  public static int SENSOR_VIEW_DEGRADATION = 1;
  public static int SENSOR_VIEW_COLORMAP = 2;

  public static int AXIS_TYPE_LINEAR = 1;
  public static int AXIS_TYPE_LOGARITHMIC = 2;

  public static int VISUAL_TYPE_STANDARD = 1;
  public static int VISUAL_TYPE_CUMULATED = 2;

  public static int AXIS_GROUP_TEMPERATURE = 1;
  public static int AXIS_GROUP_HUMIDITY = 2;
  public static int AXIS_GROUP_IMPEDANCE_AMPLITUDE = 3;
  public static int AXIS_GROUP_IMPEDANCE_ANGLE = 4;
  public static int AXIS_GROUP_RESISTANCE = 5;
  public static int AXIS_GROUP_PRESSURE = 6;
  public static int AXIS_GROUP_CORROSION = 7;
  public static int AXIS_GROUP_IMPEDANCE_REAL = 8;
  public static int AXIS_GROUP_IMPEDANCE_IMAGINARY = 9;
  public static int AXIS_GROUP_IMPEDANCE_MAGNITUDE = 10;
  public static int AXIS_GROUP_LIGHT = 11;
  public static int AXIS_GROUP_ADC = 12;
  public static int AXIS_GROUP_WETNESS = 13;
  public static int AXIS_GROUP_OXY = 14;
  public static int AXIS_GROUP_CORROSIVITY = 15;
  public static int AXIS_GROUP_DIGITAL_IO = 16;
  public static int AXIS_GROUP_ACOUSTIC = 17;
  public static int AXIS_GROUP_PARTICLES = 18;
  public static int AXIS_GROUP_HIGHIMPEDANCE = 19;
  public static int AXIS_GROUP_MAS_CORROSIVITY = 20;
  public static int AXIS_GROUP_POWER_CONSUMPTION = 21;
  public static int AXIS_GROUP_VOLTAGE = 22;
  public static int AXIS_GROUP_PH = 23;
  public static int AXIS_GROUP_CO2 = 24;
  public static int AXIS_GROUP_FREQUENCY = 25;
  public static int AXIS_GROUP_CURRENT = 26;

  public static synchronized Topics getTopics()
  {
    if (!registered) {
      Lang.register(new Listener() {
        public void notifyChange() {
          Topics.access$002(null);
        }
      });
      registered = true;
    }

    if (topics == null) {
      topics = (Topics)UserProperties.initiateAppropriateClass("com.aginova.business.Topics");

      jspMap = new HashMap(50);
      oppositeMap = new HashMap(50);
      descriptorMap = new HashMap(50);

      populate(jspMap, oppositeMap, topics.getDescriptorList());
      if (logger.isDebugEnabled())
        logger.debug("Map " + jspMap);
    }
    return topics;
  }

  private static void populate(Map<String, String> jspMaps, Map<String, String> oppositeMap, List topics)
  {
    for (int i = 0; i < topics.size(); i++) {
      Descriptor t = (Descriptor)topics.get(i);
      if (descriptorMap.get(t.getTargetJSP()) != null)
      {
        logger.error("A JSP definition was entered twice: " + t.getTargetJSP() + ", please developer, change Topics.java to avoid this!");
      }

      descriptorMap.put(t.getTargetJSP(), t);
      jspMaps.put(t.getActualName(), t.getTargetJSP());
      oppositeMap.put(t.getTargetJSP(), t.getActualName());
      List list = t.getDescrList();
      if (list != null)
        for (int j = 0; j < list.size(); j++) {
          Descriptor sub = (Descriptor)list.get(j);
          descriptorMap.put(sub.getTargetJSP(), sub);
          jspMaps.put(t.getActualName() + "_" + sub.getActualName(), sub.getTargetJSP());

          logger.debug("Putting in oppositeMap1 " + sub.getTargetJSP() + ", " + t.getActualName() + "_" + sub.getActualName());

          oppositeMap.put(sub.getTargetJSP(), t.getActualName() + "_" + sub.getActualName());

          String[] aliases = sub.getSecurityAliases();
          if (aliases != null) {
            for (int w = 0; w < aliases.length; w++) {
              oppositeMap.put(aliases[w], t.getActualName() + "_" + sub.getActualName());
            }

          }

          List list2 = sub.getDescrList();
          if (list2 != null)
            for (int k = 0; k < list2.size(); k++) {
              Descriptor sub2 = (Descriptor)list2.get(k);
              descriptorMap.put(sub2.getTargetJSP(), sub2);
              jspMaps.put(t.getActualName() + "_" + sub2.getActualName(), sub2.getTargetJSP());

              logger.debug("Putting in oppositeMap2 " + sub2.getTargetJSP() + ", " + t.getActualName() + "_" + sub2.getActualName());

              oppositeMap.put(sub2.getTargetJSP(), t.getActualName() + "_" + sub2.getActualName());

              aliases = sub2.getSecurityAliases();
              if (aliases != null) {
                for (int w = 0; w < aliases.length; w++) {
                  oppositeMap.put(aliases[w], t.getActualName() + "_" + sub2.getActualName());
                }

              }

              List list3 = sub2.getDescrList();
              if (list3 != null)
                for (int k3 = 0; k3 < list3.size(); k3++) {
                  Descriptor sub3 = (Descriptor)list3.get(k3);
                  descriptorMap.put(sub3.getTargetJSP(), sub3);
                  jspMaps.put(t.getActualName() + "_" + sub3.getActualName(), sub3.getTargetJSP());

                  logger.debug("Putting in oppositeMap3 " + sub3.getTargetJSP() + ", " + t.getActualName() + "_" + sub3.getActualName());

                  oppositeMap.put(sub3.getTargetJSP(), t.getActualName() + "_" + sub3.getActualName());

                  aliases = sub3.getSecurityAliases();
                  if (aliases != null)
                    for (int w = 0; w < aliases.length; w++)
                      oppositeMap.put(aliases[w], t.getActualName() + "_" + sub3.getActualName());
                }
            }
        }
    }
  }

  public static String getJSPForPage(String category, String subPage)
  {
    if (topics == null)
      throw new RuntimeException("Topics not initialized yet!");
    return (String)jspMap.get(category + "_" + subPage);
  }

  public static String getPageForJSP(String jspName) {
    if (topics == null)
      throw new RuntimeException("Topics not initialized yet!");
    return (String)oppositeMap.get(jspName);
  }

  public static Descriptor getDescriptorForJSP(String jspPage) {
    return (Descriptor)descriptorMap.get(jspPage);
  }

  public String getChoiceScreen(String jspPage, User user)
  {
    StringBuffer result = new StringBuffer(100);
    Descriptor descr = getDescriptorForJSP(jspPage);
    List list = descr.getDescrList();
    if (list != null) {
      for (int j = 0; j < list.size(); j++) {
        Descriptor sub = (Descriptor)list.get(j);
        if (sub.isVisible()) {
          int access = Role.getAccessForUserJSP(user, sub.getTargetJSP());
          if (access != Role.HIDDEN) {
            result.append("<a href=\"main.jsp?targetPage=" + sub.getTargetJSP() + "\">" + sub.getDisplayName() + "</a><br>");
          }
        }
      }
    }

    return result.toString();
  }

  public synchronized List<Descriptor> getDescriptorList()
  {
    if (this.descriptorList == null) {
      this.descriptorList = new ArrayList();

      this.descriptorList.add(new Descriptor("home", Lang.getLang().getLang("topics_marines_home"), null, "home.jsp"));

      Descriptor dd = getMonitoringDescriptor();
      if (dd != null) {
        this.descriptorList.add(dd);
      }
      dd = getInfrastructureDescriptor();
      if (dd != null) {
        this.descriptorList.add(dd);
      }
      dd = getAdminDescriptor();
      if (dd != null)
        this.descriptorList.add(dd);
    }
    return this.descriptorList;
  }

  protected Descriptor getMonitoringDescriptor()
  {
    List descrList = new ArrayList();

    addSensorsOverview(descrList);
    addSimpleListofMotes(descrList);
    addNotifications(descrList);

    descrList.add(new Descriptor("graphs", Lang.getLang().getLang("topics_marines_report_graph"), null, "report_graphs.jsp"));

    descrList.add(new Descriptor("data", Lang.getLang().getLang("topics_marines_report_data"), null, "report_data.jsp"));

    descrList.add(new Descriptor("reports", Lang.getLang().getLang("topics_marines_report_report"), null, "report_report.jsp"));

    descrList.add(new Descriptor("signing", Lang.getLang().getLang("topics_sensor_signing"), null, "sensor_signing.jsp"));

    return new Descriptor("livedata", Lang.getLang().getLang("topics_marines_vehicules_corrosion"), descrList, "livedata_summary.jsp");
  }

  protected void addSensorsOverview(List descrList)
  {
    descrList.add(new Descriptor("sensorsOverview", Lang.getLang().getLang("topics_menu_sensor_overview"), null, "sensors_overview.jsp", true, false, new String[] { "sensors_overview_details.jsp" }));
  }

  protected void addSimpleListofMotes(List descrList)
  {
    descrList.add(new Descriptor("sensorList", Lang.getLang().getLang("topics_menu_sensor_list"), null, "motes_list.jsp", true, false, new String[] { "status_motes_history.jsp", "createMote.jsp" }));
  }

  protected void addNotifications(List descrList)
  {
    descrList.add(new Descriptor("history", Lang.getLang().getLang("topics_marines_notifications_history"), null, "notifications_history.jsp", true, false, new String[] { "createNotification.jsp" }));
  }

  protected Descriptor getInfrastructureDescriptor()
  {
    List descrList = new ArrayList();

    descrList.add(new Descriptor("energy", Lang.getLang().getLang("topics_energy_graph"), null, "energy_graph.jsp"));

    List subList1 = new ArrayList();
    subList1.add(new Descriptor("logs", Lang.getLang().getLang("topics_marines_administration_logs"), subList1, "admin_logs.jsp"));

    subList1.add(new Descriptor("sysinfo", Lang.getLang().getLang("topics_system_info"), null, "system_info.jsp"));

    descrList.add(new Descriptor("alllogs", Lang.getLang().getLang("topics_marines_administration_logs_category"), subList1, "status_summary.jsp"));

    return new Descriptor("status", Lang.getLang().getLang("topics_marines_wireless_network"), descrList, "status_summary.jsp");
  }

  protected Descriptor getReportDescriptor()
  {
    List descrList = new ArrayList();
    descrList.add(new Descriptor("graphs", Lang.getLang().getLang("topics_marines_report_graph"), null, "report_graphs.jsp"));

    descrList.add(new Descriptor("data", Lang.getLang().getLang("topics_marines_report_data"), null, "report_data.jsp"));

    return new Descriptor("report", Lang.getLang().getLang("topics_marines_report"), descrList, "report_summary.jsp");
  }

  protected Descriptor getAdminDescriptor()
  {
    List descrList = new ArrayList();

    descrList.add(new Descriptor("user", Lang.getLang().getLang("topics_marines_administration_users"), null, "admin_user.jsp", true, false, new String[] { "createLogin.jsp" }));

    descrList.add(new Descriptor("group", Lang.getLang().getLang("topics_administration_groups"), null, "admin_user_group.jsp", true, false, new String[] { "createUserGroup.jsp" }));

    descrList.add(new Descriptor("groupReport", Lang.getLang().getLang("topics_administration_group_reports"), null, "admin_user_group_report.jsp", true, false, new String[0]));

    descrList.add(new Descriptor("userAudit", Lang.getLang().getLang("topics_administration_user_audit"), null, "admin_user_audit.jsp", true, false, new String[0]));

    descrList.add(new Descriptor("role", Lang.getLang().getLang("topics_marines_administration_role"), null, "admin_role.jsp", true, false, new String[] { "createRole.jsp" }));

    addProfilesItems(descrList);

    addVehiclesItem(descrList);

    descrList.add(new Descriptor("category", Lang.getLang().getLang("topics_administration_categories"), null, "admin_categories.jsp", true, false, new String[] { "createCategory.jsp" }));

    descrList.add(new Descriptor("camps", Lang.getLang().getLang("topics_administration_camps"), null, "admin_camps.jsp", true, false, new String[] { "createCamp.jsp" }));

    descrList.add(new Descriptor("locations", Lang.getLang().getLang("topics_administration_locations"), null, "admin_locations.jsp", true, false, new String[] { "createLocation.jsp" }));

    descrList.add(new Descriptor("imagegallery", Lang.getLang().getLang("topics_image_gallery"), null, "image_gallery.jsp"));

    descrList.add(new Descriptor("lang", Lang.getLang().getLang("topics_marines_administration_lang"), null, "admin_lang.jsp", true, false, new String[] { "createLanguage.jsp" }));

    descrList.add(new Descriptor("gateways", Lang.getLang().getLang("topics_administration_gateways"), null, "admin_gateways.jsp", true, false, new String[] { "createGateway.jsp" }));

    addImport(descrList);

    descrList.add(new Descriptor("schedules", Lang.getLang().getLang("topics_schedules_setup"), null, "admin_schedules.jsp", true, false, new String[] { "createSchedule.jsp" }));

    descrList.add(new Descriptor("notifications", Lang.getLang().getLang("topics_marines_notifications_setup"), null, "notifications_setup.jsp"));

    descrList.add(new Descriptor("setup", Lang.getLang().getLang("topics_marines_administration_setup"), null, "admin_setup.jsp"));

    descrList.add(new Descriptor("setup2", Lang.getLang().getLang("topics_properties_setup"), null, "system_parameters.jsp"));

    addFlashItem(descrList);

    return new Descriptor("admin", Lang.getLang().getLang("topics_marines_administration"), descrList, "admin_summary.jsp");
  }

  protected void addFlashItem(List descrList)
  {
    descrList.add(new Descriptor("flashmote", Lang.getLang().getLang("topics_flash_motes"), null, "admin_flashmotes.jsp"));
  }

  protected void addVehiclesItem(List descrList)
  {
    descrList.add(new Descriptor("vehicles", Lang.getLang().getLang("topics_administration_assets"), null, "admin_vehicles.jsp", true, false, new String[] { "createVehicle.jsp" }));
  }

  protected void addProfileItem(List subList)
  {
    subList.add(new Descriptor("profile", Lang.getLang().getLang("topics_marines_mote_profiles"), null, "status_profile.jsp"));
  }

  protected void addSensorTypeItem(List subList)
  {
    subList.add(new Descriptor("sensortype", Lang.getLang().getLang("topics_marines_mote_sensortype"), null, "status_sensortype.jsp", true, false, new String[] { "createSensorType.jsp" }));
  }

  private void addCoatingItem(List subList)
  {
    subList.add(new Descriptor("coating", Lang.getLang().getLang("topics_marines_administration_coating"), null, "admin_coating.jsp", true, false, new String[] { "createCoating.jsp" }));
  }

  protected void addImport(List descrList)
  {
    descrList.add(new Descriptor("import", "Import", null, "importData.jsp"));
  }

  public static String getHelpFromJSP(String jspPage)
  {
    int c = jspPage.indexOf(".");
    if (c == -1) {
      logger.error("jspPage has no jsp extension!");
      return null;
    }
    return jspPage.substring(0, c);
  }

  private Map getSensorsDescriptorsMap()
  {
    if (this.sensorsDescriptorsMap == null)
      getSensorsDescriptors();
    return this.sensorsDescriptorsMap;
  }

  public void addSensors(List sensorsDescriptors)
  {
    sensorsDescriptors.add(new DefaultSensorDescriptor("Temperature (internal)", "(int)", SENSOR_TYPE_TEMPERATURE_INT, SENSOR_TYPE_TEMPERATURE_INT, "°F", Float.valueOf(-100.0F), Float.valueOf(100.0F), 60, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_TEMPERATURE, "Internal Temperature", PRECISION_1_DIGIT));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Humidity", "(hum)", SENSOR_TYPE_HUMIDITY, SENSOR_TYPE_HUMIDITY, "%", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_HUMIDITY, "Humidity", PRECISION_1_DIGIT));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Light", "(light)", SENSOR_TYPE_LIGHT, SENSOR_TYPE_LIGHT, "Lux", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_LIGHT, "Light", PRECISION_0_DIGIT));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Resistance (1)", "(Res. 1)", SENSOR_TYPE_RESISTANCE_1, COLUMN_NAME_M1, "Ohm", Float.valueOf(-100.0F), Float.valueOf(100.0F), 60, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_RESISTANCE, "Resistance", PRECISION_1_DIGIT));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Resistance (2)", "(Res. 2)", SENSOR_TYPE_RESISTANCE_2, COLUMN_NAME_M2, "Ohm", Float.valueOf(-100.0F), Float.valueOf(100.0F), 60, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_RESISTANCE, "Resistance", PRECISION_1_DIGIT));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Voltage (1)", "(Volt. 1)", SENSOR_TYPE_VOLTAGE_1, COLUMN_NAME_M1, "mV", Float.valueOf(-100.0F), Float.valueOf(100.0F), 60, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_VOLTAGE, "Voltage", PRECISION_2_DIGIT));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Voltage (2)", "(Volt. 2)", SENSOR_TYPE_VOLTAGE_2, COLUMN_NAME_M2, "mV", Float.valueOf(-100.0F), Float.valueOf(100.0F), 60, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_VOLTAGE, "Voltage", PRECISION_2_DIGIT));

    sensorsDescriptors.add(new DefaultSensorDescriptor("pH (1)", "(pH 1)", SENSOR_TYPE_PH_1, COLUMN_NAME_M3, "-", Float.valueOf(-100.0F), Float.valueOf(100.0F), 60, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_PH, "pH", PRECISION_2_DIGIT));

    sensorsDescriptors.add(new DefaultSensorDescriptor("pH (2)", "(pH 2)", SENSOR_TYPE_PH_2, COLUMN_NAME_M4, "-", Float.valueOf(-100.0F), Float.valueOf(100.0F), 60, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_PH, "pH", PRECISION_2_DIGIT));

    sensorsDescriptors.add(new DefaultSensorDescriptor("CO2 (1)", "(CO2 1)", SENSOR_TYPE_CO2_A, COLUMN_NAME_M3, "ppm", Float.valueOf(-100.0F), Float.valueOf(100.0F), 60, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_CO2, "CO2", PRECISION_0_DIGIT));

    sensorsDescriptors.add(new DefaultSensorDescriptor("CO2 (2)", "(CO2 2)", SENSOR_TYPE_CO2_B, COLUMN_NAME_M4, "ppm", Float.valueOf(-100.0F), Float.valueOf(100.0F), 60, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_CO2, "CO2", PRECISION_0_DIGIT));

    sensorsDescriptors.add(new DefaultSensorDescriptor("CO2", "(CO2)", SENSOR_TYPE_CO2, COLUMN_NAME_M1, "ppm", Float.valueOf(-100.0F), Float.valueOf(100.0F), 60, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_CO2, "CO2", PRECISION_0_DIGIT));

    sensorsDescriptors.add(new DefaultSensorDescriptor("CO2 batt. volt.", "(CO2 bt vlt)", BATT_VOLT_TEXT, COLUMN_NAME_M2, "V", Float.valueOf(-100.0F), Float.valueOf(100.0F), 60, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_VOLTAGE, "Voltage", PRECISION_1_DIGIT));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Act. Energy (1)", "(act 1)", SENSOR_TYPE_ACT_POWER_CONSUMPTION_1, COLUMN_NAME_D1, "Wh", Float.valueOf(-100.0F), Float.valueOf(100.0F), 60, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_CUMULATED, AXIS_GROUP_POWER_CONSUMPTION, "Active Energy", PRECISION_1_DIGIT));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Act. Energy (2)", "(act 2)", SENSOR_TYPE_ACT_POWER_CONSUMPTION_2, COLUMN_NAME_D2, "Wh", Float.valueOf(-100.0F), Float.valueOf(100.0F), 60, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_CUMULATED, AXIS_GROUP_POWER_CONSUMPTION, "Active Energy", PRECISION_1_DIGIT));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Act. Energy (3)", "(act 3)", SENSOR_TYPE_ACT_POWER_CONSUMPTION_3, COLUMN_NAME_D3, "Wh", Float.valueOf(-100.0F), Float.valueOf(100.0F), 60, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_CUMULATED, AXIS_GROUP_POWER_CONSUMPTION, "Active Energy", PRECISION_1_DIGIT));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Act. Energy (Sum)", "(act sum)", SENSOR_TYPE_ACT_POWER_CONSUMPTION_TOT, COLUMN_NAME_D4, "Wh", Float.valueOf(-100.0F), Float.valueOf(100.0F), 60, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_CUMULATED, AXIS_GROUP_POWER_CONSUMPTION, "Active Energy", PRECISION_1_DIGIT));

    sensorsDescriptors.add(new DefaultSensorDescriptor("React. Energy (1)", "(react 1)", SENSOR_TYPE_REACT_POWER_CONSUMPTION_1, COLUMN_NAME_D5, "VARh", Float.valueOf(-100.0F), Float.valueOf(100.0F), 60, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_CUMULATED, AXIS_GROUP_POWER_CONSUMPTION, "Reactive Energy", PRECISION_1_DIGIT));

    sensorsDescriptors.add(new DefaultSensorDescriptor("React. Energy (2)", "(react 2)", SENSOR_TYPE_REACT_POWER_CONSUMPTION_2, COLUMN_NAME_D6, "VARh", Float.valueOf(-100.0F), Float.valueOf(100.0F), 60, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_CUMULATED, AXIS_GROUP_POWER_CONSUMPTION, "Reactive Energy", PRECISION_1_DIGIT));

    sensorsDescriptors.add(new DefaultSensorDescriptor("React. Energy (3)", "(react 3)", SENSOR_TYPE_REACT_POWER_CONSUMPTION_3, COLUMN_NAME_D7, "VARh", Float.valueOf(-100.0F), Float.valueOf(100.0F), 60, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_CUMULATED, AXIS_GROUP_POWER_CONSUMPTION, "Reactive Energy", PRECISION_1_DIGIT));

    sensorsDescriptors.add(new DefaultSensorDescriptor("React. Energy (Sum)", "(react sum)", SENSOR_TYPE_REACT_POWER_CONSUMPTION_TOT, COLUMN_NAME_D8, "VARh", Float.valueOf(-100.0F), Float.valueOf(100.0F), 60, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_CUMULATED, AXIS_GROUP_POWER_CONSUMPTION, "Reactive Energy", PRECISION_1_DIGIT));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Appar. Energy (1)", "(appar 1)", SENSOR_TYPE_APPARENT_POWER_CONSUMPTION_1, COLUMN_NAME_D9, "VAh", Float.valueOf(-100.0F), Float.valueOf(100.0F), 60, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_CUMULATED, AXIS_GROUP_POWER_CONSUMPTION, "Apparent Energy", PRECISION_1_DIGIT));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Appar. Energy (2)", "(appar 2)", SENSOR_TYPE_APPARENT_POWER_CONSUMPTION_2, COLUMN_NAME_D10, "VAh", Float.valueOf(-100.0F), Float.valueOf(100.0F), 60, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_CUMULATED, AXIS_GROUP_POWER_CONSUMPTION, "Apparent Energy", PRECISION_1_DIGIT));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Appar. Energy (3)", "(appar 3)", SENSOR_TYPE_APPARENT_POWER_CONSUMPTION_3, COLUMN_NAME_D11, "VAh", Float.valueOf(-100.0F), Float.valueOf(100.0F), 60, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_CUMULATED, AXIS_GROUP_POWER_CONSUMPTION, "Apparent Energy", PRECISION_1_DIGIT));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Appar. Energy (Sum)", "(appar sum)", SENSOR_TYPE_APPARENT_POWER_CONSUMPTION_TOT, COLUMN_NAME_D12, "VAh", Float.valueOf(-100.0F), Float.valueOf(100.0F), 60, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_CUMULATED, AXIS_GROUP_POWER_CONSUMPTION, "Apparent Energy", PRECISION_1_DIGIT));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Frequency", "(freq)", FREQ_POWER_TEXT, COLUMN_NAME_M1, "Hz", Float.valueOf(-100.0F), Float.valueOf(100.0F), 60, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_FREQUENCY, "Frequency", PRECISION_1_DIGIT));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Max current (1)", "(max curr 1)", MAX_CURRENT_POWER1_TEXT, COLUMN_NAME_M2, "A", Float.valueOf(-100.0F), Float.valueOf(100.0F), 60, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_CURRENT, "Max current", PRECISION_1_DIGIT));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Max current (2)", "(max curr 2)", MAX_CURRENT_POWER2_TEXT, COLUMN_NAME_M3, "A", Float.valueOf(-100.0F), Float.valueOf(100.0F), 60, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_CURRENT, "Max current", PRECISION_1_DIGIT));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Max current (3)", "(max curr 3)", MAX_CURRENT_POWER3_TEXT, COLUMN_NAME_M4, "A", Float.valueOf(-100.0F), Float.valueOf(100.0F), 60, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_CURRENT, "Max current", PRECISION_1_DIGIT));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Min voltage (1)", "(min volt 1)", MIN_VOLTAGE_POWER1_TEXT, COLUMN_NAME_M5, "V", Float.valueOf(-100.0F), Float.valueOf(100.0F), 60, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_VOLTAGE, "Min voltage", PRECISION_1_DIGIT));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Min voltage (2)", "(min volt 2)", MIN_VOLTAGE_POWER2_TEXT, COLUMN_NAME_M6, "V", Float.valueOf(-100.0F), Float.valueOf(100.0F), 60, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_VOLTAGE, "Min voltage", PRECISION_1_DIGIT));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Min voltage (3)", "(min volt 3)", MIN_VOLTAGE_POWER3_TEXT, COLUMN_NAME_M7, "V", Float.valueOf(-100.0F), Float.valueOf(100.0F), 60, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_VOLTAGE, "Min voltage", PRECISION_1_DIGIT));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Oxygen", "(oxy", SENSOR_TYPE_OXY, SENSOR_TYPE_OXY, "mmHg", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_OXY, "Oxygen", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Temperature (1)", "(ext 1)", SENSOR_TYPE_TEMPERATURE, SENSOR_TYPE_TEMPERATURE, "°F", Float.valueOf(-100.0F), Float.valueOf(100.0F), 60, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_TEMPERATURE, "Temperature", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Temperature (2)", "(ext 2)", SENSOR_TYPE_TEMPERATURE_2, SENSOR_TYPE_TEMPERATURE_2, "°F", Float.valueOf(-100.0F), Float.valueOf(100.0F), 60, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_TEMPERATURE, "Temperature", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Wetness (1)", "(wet 1)", SENSOR_TYPE_WETNESS1, SENSOR_TYPE_WETNESS1, "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_WETNESS, "Wetness", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Wetness (2)", "(wet 2)", SENSOR_TYPE_WETNESS2, SENSOR_TYPE_WETNESS2, "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_WETNESS, "Wetness", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Wetness (3)", "(wet 3)", SENSOR_TYPE_WETNESS3, SENSOR_TYPE_WETNESS3, "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_WETNESS, "Wetness", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Wetness (4)", "(wet 4)", SENSOR_TYPE_WETNESS4, SENSOR_TYPE_WETNESS4, "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_WETNESS, "Wetness", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Corr. rate (avg)", null, SENSOR_TYPE_MASCORR_AVG, SENSOR_TYPE_MASCORR_AVG, "µm/year", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_MAS_CORROSIVITY, "Corrosion rate", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Corr. rate (max)", null, SENSOR_TYPE_MASCORR_MAX, SENSOR_TYPE_MASCORR_MAX, "µm/year", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_MAS_CORROSIVITY, "Corrosion rate", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Corrosivity (1)", "(corr 1)", SENSOR_TYPE_CORR1, SENSOR_TYPE_CORR1, "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_CORROSIVITY, "Corrosivity", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Corrosivity (2)", "(corr 2)", SENSOR_TYPE_CORR2, SENSOR_TYPE_CORR2, "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_CORROSIVITY, "Corrosivity", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Corrosivity (3)", "(corr 3)", SENSOR_TYPE_CORR3, SENSOR_TYPE_CORR3, "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_CORROSIVITY, "Corrosivity", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Corrosivity (4)", "(corr 4)", SENSOR_TYPE_CORR4, SENSOR_TYPE_CORR4, "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_CORROSIVITY, "Corrosivity", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Digital Input", "(D.I.)", SENSOR_TYPE_DIGITAL_IO, SENSOR_TYPE_DIGITAL_IO, "-", Float.valueOf(-1.0F), Float.valueOf(2.0F), 0, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_DIGITAL_IO, "Digital Input", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Acoustic", null, SENSOR_TYPE_ACOUSTIC, SENSOR_TYPE_ACOUSTIC, "dB", Float.valueOf(-1.0F), Float.valueOf(2.0F), 0, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_ACOUSTIC, "Acoustic", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Corrosion Potential", null, SENSOR_TYPE_HIGH_IMPEDANCE, SENSOR_TYPE_HIGH_IMPEDANCE, "Volts vs. Reference electrode", Float.valueOf(-1.0F), Float.valueOf(2.0F), 0, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_HIGHIMPEDANCE, "Corrosion Potential", PRECISION_3_DIGIT));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Particles", null, SENSOR_TYPE_PARTICLES, SENSOR_TYPE_PARTICLES, "-", Float.valueOf(-1.0F), Float.valueOf(2.0F), 0, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_PARTICLES, "Particles", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Pressure", null, SENSOR_TYPE_PRESSURE, SENSOR_TYPE_PRESSURE, "Bar", Float.valueOf(-100.0F), Float.valueOf(100.0F), 80, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_PRESSURE, "Pressure", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Corrosion", null, SENSOR_TYPE_CORROSION, SENSOR_TYPE_CORROSION, "", Float.valueOf(10000.0F), Float.valueOf(100000.0F), 95000, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_CORROSION, "Corrosion", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Impedance Real (1)", null, SENSOR_TYPE_IMPEDANCE_REAL, SENSOR_TYPE_IMPEDANCE_REAL, "Ohm", Float.valueOf(10000.0F), Float.valueOf(100000.0F), 95000, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_IMPEDANCE_REAL, "Impedance (Real)", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Impedance Imaginary (1)", null, SENSOR_TYPE_IMPEDANCE_IMAGINARY, SENSOR_TYPE_IMPEDANCE_IMAGINARY, "Ohm", Float.valueOf(10000.0F), Float.valueOf(100000.0F), 95000, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_IMPEDANCE_IMAGINARY, "Impedance (Imaginary)", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Impedance Real (2)", null, SENSOR_TYPE_IMPEDANCE_REAL_2, SENSOR_TYPE_IMPEDANCE_REAL_2, "Ohm", Float.valueOf(10000.0F), Float.valueOf(100000.0F), 95000, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_IMPEDANCE_REAL, "Impedance (Real)", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Impedance Imaginary (2)", null, SENSOR_TYPE_IMPEDANCE_IMAGINARY_2, SENSOR_TYPE_IMPEDANCE_IMAGINARY_2, "Ohm", Float.valueOf(10000.0F), Float.valueOf(100000.0F), 95000, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_IMPEDANCE_IMAGINARY, "Impedance (Imaginary)", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Percent degradation", null, SENSOR_TYPE_IMPEDANCE_MAGNITUDE, SENSOR_TYPE_IMPEDANCE_MAGNITUDE, "Ohm", Float.valueOf(10000.0F), Float.valueOf(100000.0F), 95000, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LOGARITHMIC, VISUAL_TYPE_STANDARD, AXIS_GROUP_IMPEDANCE_MAGNITUDE, "Impedance", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Sensor output", null, SENSOR_TYPE_IMPEDANCE_ANGLE, SENSOR_TYPE_IMPEDANCE_ANGLE, "°", Float.valueOf(10000.0F), Float.valueOf(100000.0F), 95000, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_IMPEDANCE_ANGLE, "Sensor Output", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Resistance (0)", null, SENSOR_TYPE_RLOAD0, SENSOR_TYPE_RLOAD0, "Ohm", Float.valueOf(0.0F), Float.valueOf(1000000.0F), -1, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_RESISTANCE, "Resistance", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Resistance (1)", null, SENSOR_TYPE_RLOAD1, SENSOR_TYPE_RLOAD1, "Ohm", Float.valueOf(0.0F), Float.valueOf(1000000.0F), -1, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_RESISTANCE, "Resistance", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Resistance (2)", null, SENSOR_TYPE_RLOAD2, SENSOR_TYPE_RLOAD2, "Ohm", Float.valueOf(0.0F), Float.valueOf(1000000.0F), -1, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_RESISTANCE, "Resistance", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Resistance (3)", null, SENSOR_TYPE_RLOAD3, SENSOR_TYPE_RLOAD3, "Ohm", Float.valueOf(0.0F), Float.valueOf(1000000.0F), -1, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_RESISTANCE, "Resistance", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Resistance (4)", null, SENSOR_TYPE_RLOAD4, SENSOR_TYPE_RLOAD4, "Ohm", Float.valueOf(0.0F), Float.valueOf(1000000.0F), -1, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_RESISTANCE, "Resistance", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Resistance (5)", null, SENSOR_TYPE_RLOAD5, SENSOR_TYPE_RLOAD5, "Ohm", Float.valueOf(0.0F), Float.valueOf(1000000.0F), -1, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_RESISTANCE, "Resistance", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Resistance (6)", null, SENSOR_TYPE_RLOAD6, SENSOR_TYPE_RLOAD6, "Ohm", Float.valueOf(0.0F), Float.valueOf(1000000.0F), -1, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_RESISTANCE, "Resistance", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Resistance (7)", null, SENSOR_TYPE_RLOAD7, SENSOR_TYPE_RLOAD7, "Ohm", Float.valueOf(0.0F), Float.valueOf(1000000.0F), -1, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_RESISTANCE, "Resistance", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Resistance (8)", null, SENSOR_TYPE_RLOAD8, SENSOR_TYPE_RLOAD8, "Ohm", Float.valueOf(0.0F), Float.valueOf(1000000.0F), -1, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_RESISTANCE, "Resistance", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Resistance (9)", null, SENSOR_TYPE_RLOAD9, SENSOR_TYPE_RLOAD9, "Ohm", Float.valueOf(0.0F), Float.valueOf(1000000.0F), -1, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_RESISTANCE, "Resistance", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Resistance (10)", null, SENSOR_TYPE_RLOAD10, SENSOR_TYPE_RLOAD10, "Ohm", Float.valueOf(0.0F), Float.valueOf(1000000.0F), -1, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_RESISTANCE, "Resistance", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Resistance (11)", null, SENSOR_TYPE_RLOAD11, SENSOR_TYPE_RLOAD11, "Ohm", Float.valueOf(0.0F), Float.valueOf(1000000.0F), -1, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_RESISTANCE, "Resistance", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Resistance (12)", null, SENSOR_TYPE_RLOAD12, SENSOR_TYPE_RLOAD12, "Ohm", Float.valueOf(0.0F), Float.valueOf(1000000.0F), -1, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_RESISTANCE, "Resistance", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Resistance (13)", null, SENSOR_TYPE_RLOAD13, SENSOR_TYPE_RLOAD13, "Ohm", Float.valueOf(0.0F), Float.valueOf(1000000.0F), -1, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_RESISTANCE, "Resistance", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Resistance (14)", null, SENSOR_TYPE_RLOAD14, SENSOR_TYPE_RLOAD14, "Ohm", Float.valueOf(0.0F), Float.valueOf(1000000.0F), -1, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_RESISTANCE, "Resistance", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Resistance (15)", null, SENSOR_TYPE_RLOAD15, SENSOR_TYPE_RLOAD15, "Ohm", Float.valueOf(0.0F), Float.valueOf(1000000.0F), -1, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_RESISTANCE, "Resistance", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Resistance (16)", null, SENSOR_TYPE_RLOAD16, SENSOR_TYPE_RLOAD16, "Ohm", Float.valueOf(0.0F), Float.valueOf(1000000.0F), -1, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_RESISTANCE, "Resistance", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Resistance (17)", null, SENSOR_TYPE_RLOAD17, SENSOR_TYPE_RLOAD17, "Ohm", Float.valueOf(0.0F), Float.valueOf(1000000.0F), -1, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_RESISTANCE, "Resistance", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Resistance (18)", null, SENSOR_TYPE_RLOAD18, SENSOR_TYPE_RLOAD18, "Ohm", Float.valueOf(0.0F), Float.valueOf(1000000.0F), -1, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_RESISTANCE, "Resistance", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Resistance (19)", null, SENSOR_TYPE_RLOAD19, SENSOR_TYPE_RLOAD19, "Ohm", Float.valueOf(0.0F), Float.valueOf(1000000.0F), -1, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_RESISTANCE, "Resistance", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("ADC (0)", null, SENSOR_TYPE_ADC0, SENSOR_TYPE_ADC0, "-", Float.valueOf(0.0F), Float.valueOf(1000000.0F), -1, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_ADC, "ADC", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("ADC (1)", null, SENSOR_TYPE_ADC1, SENSOR_TYPE_ADC1, "-", Float.valueOf(0.0F), Float.valueOf(1000000.0F), -1, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_ADC, "ADC", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("ADC (2)", null, SENSOR_TYPE_ADC2, SENSOR_TYPE_ADC2, "-", Float.valueOf(0.0F), Float.valueOf(1000000.0F), -1, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_ADC, "ADC", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("ADC (3)", null, SENSOR_TYPE_ADC3, SENSOR_TYPE_ADC3, "-", Float.valueOf(0.0F), Float.valueOf(1000000.0F), -1, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_ADC, "ADC", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("ADC (4)", null, SENSOR_TYPE_ADC4, SENSOR_TYPE_ADC4, "-", Float.valueOf(0.0F), Float.valueOf(1000000.0F), -1, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_ADC, "ADC", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("ADC (5)", null, SENSOR_TYPE_ADC5, SENSOR_TYPE_ADC5, "-", Float.valueOf(0.0F), Float.valueOf(1000000.0F), -1, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_ADC, "ADC", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("ADC (6)", null, SENSOR_TYPE_ADC6, SENSOR_TYPE_ADC6, "-", Float.valueOf(0.0F), Float.valueOf(1000000.0F), -1, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_ADC, "ADC", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("ADC (7)", null, SENSOR_TYPE_ADC7, SENSOR_TYPE_ADC7, "-", Float.valueOf(0.0F), Float.valueOf(1000000.0F), -1, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_ADC, "ADC", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("ADC (8)", null, SENSOR_TYPE_ADC8, SENSOR_TYPE_ADC8, "-", Float.valueOf(0.0F), Float.valueOf(1000000.0F), -1, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_ADC, "ADC", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("ADC (9)", null, SENSOR_TYPE_ADC9, SENSOR_TYPE_ADC9, "-", Float.valueOf(0.0F), Float.valueOf(1000000.0F), -1, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_ADC, "ADC", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("ADC (10)", null, SENSOR_TYPE_ADC10, SENSOR_TYPE_ADC10, "-", Float.valueOf(0.0F), Float.valueOf(1000000.0F), -1, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_ADC, "ADC", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("ADC (11)", null, SENSOR_TYPE_ADC11, SENSOR_TYPE_ADC11, "-", Float.valueOf(0.0F), Float.valueOf(1000000.0F), -1, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_ADC, "ADC", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("ADC (12)", null, SENSOR_TYPE_ADC12, SENSOR_TYPE_ADC12, "-", Float.valueOf(0.0F), Float.valueOf(1000000.0F), -1, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_ADC, "ADC", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("ADC (13)", null, SENSOR_TYPE_ADC13, SENSOR_TYPE_ADC13, "-", Float.valueOf(0.0F), Float.valueOf(1000000.0F), -1, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_ADC, "ADC", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("ADC (14)", null, SENSOR_TYPE_ADC14, SENSOR_TYPE_ADC14, "-", Float.valueOf(0.0F), Float.valueOf(1000000.0F), -1, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_ADC, "ADC", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("ADC (15)", null, SENSOR_TYPE_ADC15, SENSOR_TYPE_ADC15, "-", Float.valueOf(0.0F), Float.valueOf(1000000.0F), -1, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_ADC, "ADC", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("ADC (16)", null, SENSOR_TYPE_ADC16, SENSOR_TYPE_ADC16, "-", Float.valueOf(0.0F), Float.valueOf(1000000.0F), -1, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_ADC, "ADC", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("ADC (17)", null, SENSOR_TYPE_ADC17, SENSOR_TYPE_ADC17, "-", Float.valueOf(0.0F), Float.valueOf(1000000.0F), -1, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_ADC, "ADC", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("ADC (18)", null, SENSOR_TYPE_ADC18, SENSOR_TYPE_ADC18, "-", Float.valueOf(0.0F), Float.valueOf(1000000.0F), -1, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_ADC, "ADC", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("ADC (19)", null, SENSOR_TYPE_ADC19, SENSOR_TYPE_ADC19, "-", Float.valueOf(0.0F), Float.valueOf(1000000.0F), -1, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_ADC, "ADC", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("ADC (20)", null, SENSOR_TYPE_ADC20, SENSOR_TYPE_ADC20, "-", Float.valueOf(0.0F), Float.valueOf(1000000.0F), -1, SENSOR_VIEW_DEGRADATION, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_ADC, "ADC", 1));
  }

  public final synchronized List getSensorsDescriptors()
  {
    if (this.sensorsDescriptors == null) {
      this.sensorsDescriptors = new ArrayList();

      addSensors(this.sensorsDescriptors);

      this.sensorsDescriptorsMap = new HashMap();
      for (int i = 0; i < this.sensorsDescriptors.size(); i++) {
        DefaultSensorDescriptor sds = (DefaultSensorDescriptor)this.sensorsDescriptors.get(i);
        this.sensorsDescriptorsMap.put(sds.getActual(), sds);
      }
    }
    return this.sensorsDescriptors;
  }

  public final List<DefaultSensorDescriptor> getSensorsDescriptorsForTypes(List sensorTypes)
  {
    List res = new ArrayList();
    Map map = getSensorsDescriptorsMap();
    logger.debug("getSensorsDescriptorsMap " + map);

    boolean expiredProII = Role.isLimitExpired();

    for (int i = 0; i < sensorTypes.size(); i++) {
      String type = (String)sensorTypes.get(i);
      DefaultSensorDescriptor sds = (DefaultSensorDescriptor)map.get(type);
      logger.debug("sds " + sds + " for type " + type);
      if (sds == null) {
        sds = new DefaultSensorDescriptor(type, type);
      }
      if ((!expiredProII) || (!"temp2".equals(type)))
        res.add(sds);
      else {
        logger.warn("Sentinel Pro II license problems, removing second probe from lists.");
      }

    }

    Collections.sort(res);
    return res;
  }

  public synchronized DefaultSensorDescriptor getDefaultSensorDescriptorFromType(String sensorType)
  {
    return (DefaultSensorDescriptor)getSensorsDescriptorsMap().get(sensorType);
  }

  public synchronized boolean isSensorAvailable(String sensorType) {
    return getDefaultSensorDescriptorFromType(sensorType) != null;
  }
  public abstract Portlet[] getListOfPortlets();

  public Portlet getPortletByName(String fullName) {
    Portlet[] portlets = getListOfPortlets();
    for (int i = 0; i < portlets.length; i++) {
      if (portlets[i].getClass().getName().equals(fullName)) {
        return portlets[i];
      }
    }
    throw new RuntimeException("Portlet " + fullName + " not in list of portlets");
  }

  public List getDefaultImages()
  {
    return new ArrayList();
  }

  public abstract boolean isDirectMoteView();

  public abstract boolean isWiFiProductOnly();

  protected void addProfilesItems(List descrList)
  {
    List subList = new ArrayList();
    addProfileItem(subList);
    addSensorTypeItem(subList);
    addCoatingItem(subList);

    descrList.add(new Descriptor("profiles", Lang.getLang().getLang("topics_marines_administration_profiles"), subList, "profiles_summary.jsp", true, false, new String[] { "createProfile.jsp" }));
  }
}