package com.aginova.business;

import java.util.List;

public class Descriptor
{
  private String actualName;
  private String displayName;
  private List descrList;
  private String targetJSP;
  private boolean visible = true;
  private boolean googleMap = false;
  private String[] securityAliases;

  public Descriptor(String actualName, String displayName, List descrList, String targetJSP, boolean visible, boolean googleMap, String[] securityAliases)
  {
    this.actualName = actualName;
    this.displayName = displayName;
    this.descrList = descrList;
    this.targetJSP = targetJSP;
    this.visible = visible;
    this.googleMap = googleMap;
    this.securityAliases = securityAliases;
  }

  public Descriptor(String actualName, String displayName, List descrList, String targetJSP, boolean visible, boolean googleMap)
  {
    this.actualName = actualName;
    this.displayName = displayName;
    this.descrList = descrList;
    this.targetJSP = targetJSP;
    this.visible = visible;
    this.googleMap = googleMap;
  }

  public Descriptor(String actualName, String displayName, List descrList, String targetJSP, boolean visible)
  {
    this.actualName = actualName;
    this.displayName = displayName;
    this.descrList = descrList;
    this.targetJSP = targetJSP;
    this.visible = visible;
  }

  public Descriptor(String actualName, String displayName, List descrList, String targetJSP) {
    this.actualName = actualName;
    this.displayName = displayName;
    this.descrList = descrList;
    this.targetJSP = targetJSP;
  }

  public Descriptor(String actualName, String displayName, List descrList) {
    this.actualName = actualName;
    this.displayName = displayName;
    this.descrList = descrList;
  }

  public void setActualName(String actualName)
  {
    this.actualName = actualName;
  }

  public String getActualName()
  {
    return this.actualName;
  }

  public void setDisplayName(String displayName)
  {
    this.displayName = displayName;
  }

  public String getDisplayName()
  {
    return this.displayName;
  }

  public void setDescrList(List descrList)
  {
    this.descrList = descrList;
  }

  public List getDescrList()
  {
    return this.descrList;
  }

  public void setTargetJSP(String targetJSP) {
    this.targetJSP = targetJSP;
  }

  public String getTargetJSP() {
    return this.targetJSP;
  }

  public void setVisible(boolean visible) {
    this.visible = visible;
  }

  public boolean isVisible() {
    return this.visible;
  }

  public void setGoogleMap(boolean googleMap) {
    this.googleMap = googleMap;
  }

  public boolean isGoogleMap() {
    return this.googleMap;
  }

  public void setSecurityAliases(String[] securityAliases) {
    this.securityAliases = securityAliases;
  }

  public String[] getSecurityAliases() {
    return this.securityAliases;
  }
}