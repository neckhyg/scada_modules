package com.aginova.wifi.api;

import com.aginova.crossbow.Message;

public abstract interface WiBoxListener
{
  public abstract void dataReceived(Message paramMessage);

  public abstract void healthReceived(Message paramMessage);

  public abstract void heartbeatReceived(Message paramMessage);

  public abstract void scanInfoReceived(Message paramMessage);

  public abstract void notificationReceived(int paramInt, long paramLong, String paramString1, String paramString2);

  public abstract void updateReceived(int paramInt, long paramLong, String paramString);

  public abstract void errorReceived(Message paramMessage);

  public abstract void wiboxResetReceived(Message paramMessage);

  public abstract void processingError(Message paramMessage, Exception paramException);
}