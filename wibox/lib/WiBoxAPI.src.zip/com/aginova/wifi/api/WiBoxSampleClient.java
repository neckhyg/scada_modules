package com.aginova.wifi.api;

import com.aginova.crossbow.Message;
import com.aginova.util.WarningRemover;
import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class WiBoxSampleClient
  implements WiBoxListener
{
  private static final Logger logger = Logger.getLogger(WiBoxSampleClient.class);
  private static final boolean debug = true;
  WiBoxCommunication wb;

  private WiBoxSampleClient()
    throws Exception
  {
    quickConfigure();

    String host = "localhost";
    String password = "ws79013";
    this.wb = new WiBoxCommunication(host, 8088, password);

    this.wb.registerListener(this);

    this.wb.start();

    long unique = 1L;
  }

  public static void main(String[] args)
    throws Exception
  {
    WarningRemover.removeWarning(args);
    new WiBoxSampleClient();
  }

  public void dataReceived(Message data)
  {
    logger.debug("dataReceived " + data);
    int mote_id = data.getIntValue("mote_id").intValue();
    Float tempExt1 = data.getFloatValue("temp");
    Float tempExt2 = data.getFloatValue("temp2");
    Float tempInt = data.getFloatValue("tempInt");
    Float hum = data.getFloatValue("hum");
    Float light = data.getFloatValue("light");

    logger.debug("** Temp. ext (1): " + tempExt1 + "°F, ext (2):" + tempExt2 + ", int: " + tempInt + ", humidity: " + hum + "%, light: " + light + " from sensor " + mote_id);

    int data_id = Integer.parseInt(data.getValue("data_id"));
    this.wb.ack(data_id);
  }

  public void healthReceived(Message data)
  {
    logger.debug("Health " + data);
  }

  public void heartbeatReceived(Message data)
  {
    logger.debug("Heartbeat " + data);
    try
    {
      Integer[] dd = this.wb.getConfiguration(data.getIntValue("mote_id").intValue(), 1L);
      logger.debug("Received configuration hb=" + dd[0] + ", sa=" + dd[1] + ", config=" + dd[2]);
    } catch (Exception e) {
      logger.error("", e);
    }
  }

  public void scanInfoReceived(Message data)
  {
    logger.debug("Scan info " + data);
  }

  public void notificationReceived(int mote_id, long unique_id, String message, String code)
  {
    logger.debug("notificationReceived  mote_id=" + mote_id + ", unique_id=" + unique_id + ",message=" + message + ",code= " + code);
  }

  public void updateReceived(int mote_id, long unique_id, String message)
  {
    logger.debug("updateReceived  mote_id=" + mote_id + ", unique_id=" + unique_id + ",message=" + message);
  }

  public void errorReceived(Message data)
  {
    logger.debug("errorReceived " + data);
  }

  public void wiboxResetReceived(Message data)
  {
    logger.debug("wiboxResetReceived " + data);
  }

  public static void quickConfigure()
  {
    Properties props = new Properties();
    props.put("log4j.rootLogger", "debug, stdout, logfile");

    props.put("log4j.appender.stdout", "org.apache.log4j.ConsoleAppender");
    props.put("log4j.appender.stdout.layout", "org.apache.log4j.PatternLayout");
    props.put("log4j.appender.stdout.layout.ConversionPattern", "%d{yyyy-MM-dd HH:mm:ss,SSS} %5p [%t] (%F:%L) - %m%n");

    props.put("log4j.appender.stdout.threshold", "debug");

    props.put("log4j.appender.logfile", "org.apache.log4j.RollingFileAppender");
    props.put("log4j.appender.logfile.layout", "org.apache.log4j.PatternLayout");
    props.put("log4j.appender.logfile.layout.ConversionPattern", "%d{yyyy-MM-dd HH:mm:ss,SSS} %5p [%t] (%F:%L) - %m%n");

    props.put("log4j.appender.logfile.File", "log/WiBoxAPIClient.log");
    props.put("log4j.appender.logfile.MaxFileSize", "5MB");
    props.put("log4j.appender.logfile.MaxBackupIndex", "2");

    props.put("log4j.logger.org.apache.jasper", "warn");

    props.put("log4j.logger.httpclient.wire", "warn");
    props.put("log4j.logger.org.apache.commons.httpclient", "warn");
    props.put("log4j.logger.httpclient.wire.header", "warn");
    props.put("log4j.logger.httpclient.wire.content", "warn");

    props.put("log4j.logger.org.snmp4j.agent", "debug");

    props.put("log4j.logger.com.aginova.wifi.api.WiBoxCommunication", "debug");
    props.put("log4j.logger.com.aginova.business", "debug");

    PropertyConfigurator.configure(props);
  }

  public void processingError(Message data, Exception e)
  {
  }

  public static byte[] readFromFile(File f)
    throws IOException
  {
    ByteArrayOutputStream bo = new ByteArrayOutputStream();
    InputStream in = new BufferedInputStream(new FileInputStream(f));
    byte[] temp = new byte[1024];
    int c = 0;
    while ((c = in.read(temp)) != -1) {
      bo.write(temp, 0, c);
    }
    byte[] res = bo.toByteArray();
    in.close();
    return res;
  }
}