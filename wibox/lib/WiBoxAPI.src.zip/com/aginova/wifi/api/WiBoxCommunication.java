package com.aginova.wifi.api;

import com.aginova.business.ProductInformation;
import com.aginova.crossbow.Message;
import com.aginova.util.DBConnectionProperties;
import com.aginova.util.Lang;
import com.aginova.util.Tools;
import com.bea.xml.stream.MXParserFactory;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.Authenticator;
import java.net.ConnectException;
import java.net.PasswordAuthentication;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Stack;
import java.util.Vector;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import org.apache.commons.httpclient.DefaultHttpMethodRetryHandler;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.HttpState;
import org.apache.commons.httpclient.UsernamePasswordCredentials;
import org.apache.commons.httpclient.auth.AuthScope;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.params.HttpClientParams;
import org.apache.commons.httpclient.params.HttpMethodParams;
import org.apache.log4j.Logger;
import org.apache.xmlrpc.client.XmlRpcClient;
import org.apache.xmlrpc.client.XmlRpcClientConfigImpl;

public class WiBoxCommunication
{
  private static final Logger logger = Logger.getLogger(WiBoxCommunication.class);

  public static long HEART_BEAT_MAX_INTERVAL = 20000L;

  Vector<WiBoxListener> listeners = new Vector();
  String host;
  int port;
  String url_base = null;
  String wsPassword;
  boolean connectionChanged = false;
  Thread internalThread;
  Thread monitorThread;
  boolean stopThread = false;
  XmlRpcClient client;
  Stack ackQueue;
  boolean connected = false;

  Map<Integer, String> productMap = new HashMap();

  Map<Integer, Object[][][]> calibrationMap = new HashMap();

  private long last_data_received = -1L;

  private HttpMethod httpMethod = null;

  private Map moteStatusMap = new HashMap();

  private long activeStartTime = System.currentTimeMillis();

  public boolean isConnected()
  {
    return this.connected;
  }

  protected void setConnected(boolean s) {
    this.connected = s;
  }

  public WiBoxCommunication(String host, int port, String wsPassword)
    throws Exception
  {
    this.host = host;
    this.port = port;
    this.wsPassword = wsPassword;
    this.url_base = ("http://" + host + ":" + port + "/");

    Lang.LOAD_FROM_DB = false;
    Lang.init(getClass().getResourceAsStream("/languages.property"));
    DBConnectionProperties.getDBConnectionProperties().setProperty(DBConnectionProperties.INSTALL_APPLICATION, "hospital");

    ProductInformation.getInstance();

    resetXMLRPCClient();
  }

  private void resetXMLRPCClient() throws Exception
  {
    Authenticator.setDefault(new SimpleAuthenticator("ws", this.wsPassword));
    XmlRpcClientConfigImpl config = new XmlRpcClientConfigImpl();
    config.setServerURL(new URL("http://" + this.host + ":" + this.port + "/webservices"));
    config.setBasicUserName("ws");
    config.setBasicPassword(this.wsPassword);
    config.setReplyTimeout(10000);

    config.setEnabledForExtensions(true);
    this.client = new XmlRpcClient();
    this.client.setConfig(config);
  }

  public void ack(int data_id)
  {
    prepareQueue();
    this.ackQueue.push(new Integer(data_id));
  }

  private void prepareQueue()
  {
    if (this.ackQueue == null) {
      this.ackQueue = new Stack();
      Thread ackThread = new Thread("Acknowledgment queue for gateway ")
      {
        public void run()
        {
          while (true) {
            try {
              List listOfIds = new ArrayList();
              try {
                if (WiBoxCommunication.this.ackQueue.size() != 0) continue;
                try {
                  sleep(200L);
                } catch (Exception e) {
                  WiBoxCommunication.logger.error("", e);
                }continue;

                if ((WiBoxCommunication.this.ackQueue.size() > 0) && (listOfIds.size() < 20)) {
                  Integer ackId = (Integer)WiBoxCommunication.this.ackQueue.pop();
                  listOfIds.add(ackId);
                  continue;
                }

                WiBoxCommunication.logger.debug("Sending WS ACK..." + WiBoxCommunication.this.host + ", port " + WiBoxCommunication.this.port + " (" + WiBoxCommunication.this.ackQueue.size() + " acks in queue needs to be sent) listOfIds " + listOfIds);

                String result = (String)WiBoxCommunication.this.xmlRPCExecute("Appliance.ack", listOfIds.toArray());

                WiBoxCommunication.logger.debug("Sending WS ACK...received " + result);
                if (!"OK".equals(result)) {
                  throw new Exception("ACK failed, result was " + result);
                }

              }
              catch (Exception e)
              {
                WiBoxCommunication.logger.warn("Could not ACK a given DB data message (data_id=" + listOfIds + "), the message will be sent again by the appliance..." + e.getMessage());
              }
            }
            catch (Throwable e)
            {
              WiBoxCommunication.logger.error("", e);
            }
            if (WiBoxCommunication.this.stopThread)
              break;
          }
        }
      };
      ackThread.setPriority(10);
      ackThread.start();
    }
  }

  public synchronized void start()
  {
    logger.debug("Starting internal thread");
    System.setProperty("sun.net.client.defaultReadTimeout", "20000");
    System.setProperty("sun.net.client.defaultConnectTimeout", "20000");
    System.setProperty("http.defaultSocketTimeout", "20000");

    if (this.internalThread != null) {
      logger.warn("Internal thread already started, dropping start() request...");
      return;
    }

    this.internalThread = new Thread("WiBox thread")
    {
      public void run()
      {
        WiBoxCommunication.logger.debug("Running WiBoxCommunication listening for data (from data)");
        do
        {
          try
          {
            try
            {
              String version = WiBoxCommunication.this.getGatewayVersion();
              String subversion = version.substring(3);

              WiBoxCommunication.logger.debug("Got version from gateway " + subversion);
            }
            catch (Exception e)
            {
              WiBoxCommunication.logger.error("Could not start gateway " + getName() + ", the error was " + e.getMessage() + "(class " + e.getClass() + ")");

              throw new ConnectException(e.getMessage());
            }

            WiBoxCommunication.this.startCounting();

            URL url = new URL(WiBoxCommunication.this.url_base + "data");

            HttpClient client = new HttpClient();

            client.getParams().setAuthenticationPreemptive(true);

            client.getState().setCredentials(new AuthScope(url.getHost(), url.getPort()), new UsernamePasswordCredentials("ws", WiBoxCommunication.this.wsPassword));

            WiBoxCommunication.access$302(WiBoxCommunication.this, new GetMethod(url.toExternalForm()));

            WiBoxCommunication.this.httpMethod.getParams().setParameter("http.method.retry-handler", new DefaultHttpMethodRetryHandler(3, false));

            WiBoxCommunication.this.httpMethod.setDoAuthentication(true);

            int statusCode = client.executeMethod(WiBoxCommunication.this.httpMethod);

            if (statusCode != 200) {
              throw new Exception("Method failed: " + WiBoxCommunication.this.httpMethod.getStatusLine());
            }

            WiBoxCommunication.logger.warn("URL opened...");

            WiBoxCommunication.logger.debug("Getting input stream");
            InputStream inputStream = WiBoxCommunication.this.httpMethod.getResponseBodyAsStream();
            WiBoxCommunication.logger.debug("Input stream received...");

            WiBoxCommunication.this.setConnected(true);

            WiBoxCommunication.logger.debug("Starting reader");

            XMLStreamReader reader = new MXParserFactory().createXMLStreamReader(new InputStreamReader(inputStream));
            do
            {
              if (!reader.hasNext()) {
                WiBoxCommunication.logger.warn("No data found, breaking...");
                throw new ConnectException("No data was received, is the WiBox configured to send XML/HTTP?");
              }

              WiBoxCommunication.logger.debug("Waiting for next packet");
              reader.next();
              WiBoxCommunication.access$402(WiBoxCommunication.this, System.currentTimeMillis());

              WiBoxCommunication.logger.debug("Received element <" + reader.getLocalName() + ">, isStartElement? " + reader.isStartElement());

              if (reader.isStartElement()) {
                WiBoxCommunication.this.processElement(reader);
              }

            }

            while (!WiBoxCommunication.this.stopThread);

            WiBoxCommunication.logger.warn("Received a stopThread or break signal, exiting loop...");
          }
          catch (ConnectException e)
          {
            WiBoxCommunication.logger.warn("Cannot establish connection (long-running thread), will retry in 10s..." + (e != null ? "" + e.getMessage() : "N/A"));
            try
            {
              Thread.sleep(10000L);
            } catch (Exception e2) {
              WiBoxCommunication.logger.error("Cannot sleep...", e2);

              jsr 128;
            }
          }
          catch (XMLStreamException e4) {
            WiBoxCommunication.logger.error("XML corrupted (long-running thread), will retry in 5s..." + (e4 != null ? e4.getMessage() : "N/A"));
            try
            {
              Thread.sleep(5000L);
            } catch (Exception e2) {
              WiBoxCommunication.logger.debug("Cannot sleep..." + e2);

              jsr 49;
            }
          } catch (Throwable e3) {
            WiBoxCommunication.logger.error("Cannot establish connection (long-running thread), will retry in 20s but this is a fatal error...", e3);
            try
            {
              Thread.sleep(20000L);
            } catch (Exception e2) {
              WiBoxCommunication.logger.error("Cannot sleep...", e2);

              jsr 14;
            } } finally {
            try {
              if (WiBoxCommunication.this.httpMethod != null) {
                WiBoxCommunication.logger.warn("Disconnecting current " + WiBoxCommunication.this.httpMethod + " (2)");

                WiBoxCommunication.this.httpMethod.releaseConnection();
              }
            } catch (Exception eee) {
              WiBoxCommunication.logger.error("", eee);
            }
            WiBoxCommunication.this.setConnected(false);
            WiBoxCommunication.access$402(WiBoxCommunication.this, -1L);
            try
            {
              WiBoxCommunication.logger.warn("Sleeping 5 sec to let things settle down...");
              Thread.sleep(5000L);
            }
            catch (InterruptedException e2) {
              WiBoxCommunication.logger.debug("Cannot sleep..." + e2);
            }
          }
        }
        while (!WiBoxCommunication.this.stopThread);
        WiBoxCommunication.logger.debug("Thread terminated naturally...");
        WiBoxCommunication.this.setConnected(false);
      }
    };
    this.internalThread.setDaemon(true);
    this.internalThread.setPriority(5);
    this.internalThread.start();

    this.monitorThread = new Thread("Monitoring thread") {
      public void run() {
        while (!WiBoxCommunication.this.stopThread)
        {
          try
          {
            if ((WiBoxCommunication.this.isConnected()) && (WiBoxCommunication.this.last_data_received != -1L)) {
              boolean random = Math.random() < 0.1D;
              if (System.currentTimeMillis() - WiBoxCommunication.this.last_data_received > WiBoxCommunication.HEART_BEAT_MAX_INTERVAL)
              {
                WiBoxCommunication.logger.warn("No data was received for a long time, resetting the connection: last_data_received " + WiBoxCommunication.this.last_data_received + ", diff " + (System.currentTimeMillis() - WiBoxCommunication.this.last_data_received) + ", random " + random);

                WiBoxCommunication.this.connectionChanged = true;
                WiBoxCommunication.access$402(WiBoxCommunication.this, -1L);
                try
                {
                  WiBoxCommunication.logger.warn("Interupting the thread...");
                  WiBoxCommunication.this.internalThread.interrupt();
                  WiBoxCommunication.logger.warn("Interupting the thread...done");
                } catch (Exception e) {
                  WiBoxCommunication.logger.error("", e);
                }
                try {
                  WiBoxCommunication.logger.warn("Aborting the HttpMethod...");
                  if (WiBoxCommunication.this.httpMethod != null)
                    WiBoxCommunication.this.httpMethod.abort();
                  WiBoxCommunication.logger.warn("Aborting the HttpMethod...done");
                } catch (Exception e) {
                  WiBoxCommunication.logger.error("", e);
                }
                WiBoxCommunication.logger.warn("Monitoring thread attempted a connection reset.");
                try
                {
                  sleep(30000L);
                }
                catch (Exception e) {
                  WiBoxCommunication.logger.error("", e);
                }
              }
            }
            try {
              sleep(5000L);
            }
            catch (Exception e) {
              WiBoxCommunication.logger.error("", e);
            }
          } catch (Throwable e) {
            WiBoxCommunication.logger.error("", e);
          }
        }
      }
    };
    this.monitorThread.start();
  }

  private void processElement(XMLStreamReader reader) throws XMLStreamException {
    StringBuffer atts = new StringBuffer(50);
    for (int i = 0; i < reader.getAttributeCount(); i++) {
      atts.append(" " + reader.getAttributeLocalName(i) + "=\"" + reader.getAttributeValue(i) + "\"");
    }

    logger.debug("Received element <" + reader.getLocalName() + atts + ">");

    String localName = reader.getLocalName();
    if (!localName.equals("Messages"))
    {
      Map map = new HashMap();
      for (int i = 0; i < reader.getAttributeCount(); i++) {
        map.put(reader.getAttributeLocalName(i), reader.getAttributeValue(i));
      }

      map.put("received", "" + System.currentTimeMillis());
      String messageType = null;

      if (localName.equals("Data"))
      {
        logger.debug("FOUND data message from mote_id= " + reader.getAttributeValue("", "mote_id"));

        MoteStatus moteStatus = getMoteStatus(Integer.parseInt((String)map.get("mote_id")));

        moteStatus.lastData = System.currentTimeMillis();
        moteStatus.count -= 1;

        messageType = "Data";
      }
      else if (localName.equals("HaveData"))
      {
        logger.debug("HaveData received... (almost ignored)");

        int count = 0;
        try {
          count = Integer.parseInt(reader.getAttributeValue("", "count"));
          if (count > 0) {
            logger.debug("Havedata count is " + count);
          }

        }
        catch (Exception e)
        {
          logger.debug("Count is null");
        }

        MoteStatus moteStatus = getMoteStatus(Integer.parseInt((String)map.get("mote_id")));

        moteStatus.lastHaveData = System.currentTimeMillis();
        moteStatus.count = count;
        messageType = "HaveData";
      } else if (localName.equals("Health")) {
        logger.debug("Health received... ");
        messageType = "Health";
      } else if (localName.equals("LinkUp")) {
        logger.debug("Linkup received... ");
        messageType = "LinkUp";
      } else if (localName.equals("WiboxReset")) {
        logger.debug("WiBox Reset received... ");
        messageType = "WiboxReset";
      } else if (localName.equals("Notification")) {
        logger.debug("Notification received... ");
        messageType = "Notification";
      } else if (localName.equals("Update")) {
        logger.debug("Update received... ");
        messageType = "Update";
      } else if (localName.equals("ScanInfo"))
      {
        messageType = "ScanInfo";
      } else if (localName.equals("Error"))
      {
        messageType = "Error";
      }
      else
      {
        logger.error("Unexpected response: " + localName);
        throw new XMLStreamException("Unexpected response: " + localName);
      }
      Message dataObj = new Message(messageType, map);
      broadcastEvent(dataObj);
      logger.debug("Broadcast done...");
    }
  }

  public void stop()
  {
    logger.debug("Someone stopped the gateway!");
    this.stopThread = true;
  }

  private MoteStatus getMoteStatus(int mote_id)
  {
    MoteStatus mm = (MoteStatus)this.moteStatusMap.get(new Integer(mote_id));
    if (mm == null) {
      mm = new MoteStatus(null);
      this.moteStatusMap.put(new Integer(mote_id), mm);
    }
    return mm;
  }

  public String getGatewayVersion()
    throws Exception
  {
    logger.debug("Getting gateway information for gateway " + this);
    String result = (String)xmlRPCExecute("Appliance.getversion", new Object[0]);
    if ((result == null) || (!result.startsWith("OK"))) {
      throw new Exception("Getting gateway version failed, result was " + result);
    }
    return result;
  }

  public void reconfig(int mote_id, Integer heartbeatPeriod, Integer samplingPeriod, Integer configPeriod, Integer samplingSendingRate, long uniqueId)
    throws Exception
  {
    logger.debug("Reconfiguring mote " + mote_id + " through gateway " + this);

    String result = (String)xmlRPCExecute("Appliance.reconfig", new Object[] { new Integer(mote_id), heartbeatPeriod, samplingPeriod, configPeriod, new Long(uniqueId), samplingSendingRate });

    if (!"OK".equals(result))
      throw new Exception("Reconfiguration failed, result was " + result);
  }

  public void reconfigProduct(int mote_id, Integer productNumber, long uniqueId)
    throws Exception
  {
    logger.debug("Reconfiguring mote " + mote_id + " through gateway " + this);
    String result = (String)xmlRPCExecute("Appliance.reconfigProduct", new Object[] { new Integer(mote_id), productNumber, new Long(uniqueId) });

    if (!"OK".equals(result))
      throw new Exception("Reconfiguration failed, result was " + result);
  }

  public void reconfigWiFi(int mote_id, String[] ssids, Integer[] channels, String[] psks, String[] keys, String[] keyIDs, Boolean dhcp, String moteIP, String moteSubnet, String moteGateway, String wiboxIP, long uniqueId, Integer wiBoxDataPort, Integer wiBoxReceivePort, Integer wiBoxFirmwarePort)
    throws Exception
  {
    logger.debug("Reconfiguring mote  " + mote_id + " WiFi through gateway " + this);
    String result = (String)xmlRPCExecute("Appliance.reconfigWiFi", new Object[] { new Integer(mote_id), ssids != null ? ssids[0] : null, ssids != null ? ssids[1] : null, ssids != null ? ssids[2] : null, channels != null ? channels[0] : null, channels != null ? channels[1] : null, channels != null ? channels[2] : null, psks != null ? psks[0] : null, psks != null ? psks[1] : null, psks != null ? psks[2] : null, keys != null ? keys[0] : null, keys != null ? keys[1] : null, keys != null ? keys[2] : null, keyIDs != null ? keyIDs[0] : null, keyIDs != null ? keyIDs[1] : null, keyIDs != null ? keyIDs[2] : null, dhcp != null ? Integer.valueOf(dhcp.booleanValue() ? 1 : 0) : null, moteIP, moteSubnet, moteGateway, wiboxIP, Long.valueOf(uniqueId), wiBoxDataPort, wiBoxReceivePort, wiBoxFirmwarePort });

    if (!"OK".equals(result))
      throw new Exception("Reconfiguration of WiFi failed, result was " + result);
  }

  public Integer[] getConfiguration(int mote_id, long uniqueId)
    throws Exception
  {
    logger.debug("getConfiguration mote " + mote_id + " through gateway " + this);
    Integer[] result = Tools.convertToIntegerArray((Object[])(Object[])xmlRPCExecute("Appliance.getConfiguration", new Object[] { new Integer(mote_id), new Long(uniqueId) }));

    return result;
  }

  private Object xmlRPCExecute(String command, Object[] data)
    throws Exception
  {
    synchronized (this.client) {
      try {
        Object result = this.client.execute(command, data);
        return result;
      } catch (Exception e) {
        String message = e != null ? e.getMessage() : null;
        if ((e != null) && (message != null) && (message.contains("Broken pipe"))) {
          logger.warn("Broken pipe, will reset the client..." + message);
          try {
            resetXMLRPCClient();
          } catch (Exception e1) {
            logger.error("", e1);
          }
        } else if ((e != null) && (message != null) && ((message.contains("Connection refused")) || (message.contains("Connection reset")) || (message.contains("Not found"))))
        {
          logger.warn("Connection refused, is the WiBox running at that address?" + message);
        }
        else {
          logger.warn("Other error, is the WiBox running at that address?" + message);
          logger.error("Message was '" + message + "'", e);
        }
        throw e;
      }
    }
  }

  public void reflash(int mote_id, byte[] wlan, byte[] app1, byte[] app2, int group_id, long uniqueId)
    throws Exception
  {
    logger.debug("Reflashing sensor " + mote_id + " through gateway " + this);

    String result = (String)xmlRPCExecute("Appliance.reprogram", new Object[] { new Integer(mote_id), wlan, app1, app2, new Integer(group_id), new Long(uniqueId) });

    if (!"OK".equals(result))
      throw new Exception("Reprogram failed, result was " + result);
  }

  public void reflashZIP(int mote_id, byte[] wlan, byte[] app1, byte[] app2, byte[] zipBytes, int group_id, long uniqueId)
    throws Exception
  {
    logger.debug("Reflashing sensor " + mote_id + " through gateway " + this);

    String result = (String)xmlRPCExecute("Appliance.reprogramZIP", new Object[] { new Integer(mote_id), wlan, app1, app2, zipBytes, new Integer(group_id), new Long(uniqueId) });

    if (!"OK".equals(result))
      throw new Exception("Reprogram failed, result was " + result);
  }

  /** @deprecated */
  public void setClock(int mote_id, int moteClock, long currentTimeMS, long uniqueId)
    throws Exception
  {
    logger.debug("Setting mote clock " + mote_id + " through gateway " + this);

    String result = (String)xmlRPCExecute("Appliance.setclock", new Object[] { new Integer(mote_id), new Integer(moteClock), new Long(currentTimeMS), new Long(uniqueId) });

    if (!"OK".equals(result))
      throw new Exception("Set clock failed, result was " + result);
  }

  public void setBuzzer(int mote_id, boolean active, long uniqueId)
    throws Exception
  {
    logger.debug("Setting buzzer " + mote_id + " through gateway " + this);

    String result = (String)xmlRPCExecute("Appliance.setbuzzer", new Object[] { new Integer(mote_id), new Integer(active ? 1 : 0), new Long(uniqueId) });

    if (!"OK".equals(result))
      throw new Exception("Set buzzer failed, result was " + result);
  }

  public void resetMote(int mote_id, long uniqueId)
    throws Exception
  {
    logger.debug("Resetting mote  " + mote_id + " through gateway " + this);

    String result = (String)xmlRPCExecute("Appliance.reset", new Object[] { new Integer(mote_id), new Long(uniqueId) });

    if (!"OK".equals(result))
      throw new Exception("Reset mote failed, result was " + result);
  }

  public void getReading(int mote_id, long uniqueId)
    throws Exception
  {
    logger.debug("Get reading from mote  " + mote_id + " through gateway " + this);

    String result = (String)xmlRPCExecute("Appliance.getreading", new Object[] { new Integer(mote_id), new Long(uniqueId) });

    if (!"OK".equals(result))
      throw new Exception("Get reading from mote failed, result was " + result);
  }

  private void startCounting()
  {
    this.activeStartTime = System.currentTimeMillis();
  }

  private synchronized void broadcastEvent(Message data)
  {
    try
    {
      for (WiBoxListener listener : this.listeners)
        try {
          if (data.getMessageType().equals("Data")) {
            int mote_id = data.getIntValue("mote_id").intValue();
            String product_number = (String)this.productMap.get(Integer.valueOf(mote_id));
            if (product_number == null) {
              logger.debug("Receiving data packets from unknown sensor with ID " + mote_id + ", waiting for heartbeats to send them again. " + this.productMap);

              continue;
            }
            Object[][][] calibrationData = (Object[][][])this.calibrationMap.get(Integer.valueOf(mote_id));
            logger.debug("calibrationData from map " + calibrationData);

            boolean requiresCalibration = (data.getValue("clbr") != null) && (data.getValue("clbr").equals("true"));

            if ((requiresCalibration) && 
              (calibrationData == null))
            {
              calibrationData = getCalibration(mote_id, System.currentTimeMillis());

              this.calibrationMap.put(Integer.valueOf(mote_id), calibrationData);

              logger.debug("Waiting for calibration data for mote " + mote_id);
              continue;
            }

            ProductInformation.getInstance().convertData(product_number, data, calibrationData);

            listener.dataReceived(data);
          } else if (data.getMessageType().equals("Health"))
          {
            listener.healthReceived(data);
          } else if (data.getMessageType().equals("HaveData"))
          {
            String product_number = data.getValue("product");
            int mote_id = data.getIntValue("mote_id").intValue();
            logger.debug("Storing product_number " + product_number + " for " + mote_id);

            this.productMap.put(Integer.valueOf(mote_id), product_number);

            listener.heartbeatReceived(data);
          } else if (data.getMessageType().equals("ScanInfo"))
          {
            listener.scanInfoReceived(data);
          } else if (data.getMessageType().equals("Error"))
          {
            listener.errorReceived(data);
          } else if (data.getMessageType().equals("Update"))
          {
            int mote_id = Integer.parseInt(data.getValue("mote_id"));
            long unique_id = Long.parseLong(data.getValue("unique_id"));
            String message = data.getValue("msg");
            listener.updateReceived(mote_id, unique_id, message);
          } else if (data.getMessageType().equals("WiboxReset"))
          {
            listener.wiboxResetReceived(data);
          } else if (data.getMessageType().equals("Notification"))
          {
            int mote_id = Integer.parseInt(data.getValue("mote_id"));
            long unique_id = Long.parseLong(data.getValue("unique_id"));
            String message = data.getValue("msg");
            String code = data.getValue("code");
            listener.notificationReceived(mote_id, unique_id, message, code);
          } else if (data.getMessageType().equals("LinkUp"))
          {
            logger.debug("Received linkup message");
          } else {
            logger.warn("Unrecognized message " + data);
          }
        }
        catch (Exception e) {
          listener.processingError(data, e);
        }
    }
    catch (Throwable thr) {
      logger.error("Error for message " + data, thr);
    }
  }

  private Object[][][] getCalibration(int mote_id, long uniqueId)
    throws Exception
  {
    logger.debug("Get calibration from mote  " + mote_id);

    Object[][][] result = Tools.expandObjectArray((Object[])(Object[])xmlRPCExecute("Appliance.getCalibration", new Object[] { new Integer(mote_id), new Long(uniqueId) }));

    logger.debug("Received result " + result);
    return result;
  }

  public void setCalibration(int mote_id, Object[][][] calibrationData, long uniqueId)
    throws Exception
  {
    logger.debug("Reconfiguring mote  " + mote_id + " calibration through gateway " + this);
    String result = (String)xmlRPCExecute("Appliance.reconfigCalibration", new Object[] { new Integer(mote_id), calibrationData, new Long(uniqueId) });

    if (!"OK".equals(result))
      throw new Exception("Reconfiguration of calibration failed, result was " + result);
  }

  public void registerListener(WiBoxListener listener)
  {
    if (!this.listeners.contains(listener))
      this.listeners.add(listener);
  }

  private class MoteStatus
  {
    public long lastData;
    public long lastHaveData;
    public long lastReconfig;
    public int count;
    public int sleepTime;
    public long sleepStart;

    private MoteStatus()
    {
    }

    public long getLastMessage()
    {
      return Math.max(this.lastHaveData, this.lastData);
    }
  }

  public class SimpleAuthenticator extends Authenticator
  {
    private String username;
    private String password;

    public SimpleAuthenticator(String username, String password)
    {
      this.username = username;
      this.password = password;
    }

    protected PasswordAuthentication getPasswordAuthentication() {
      return new PasswordAuthentication(this.username, this.password.toCharArray());
    }
  }
}