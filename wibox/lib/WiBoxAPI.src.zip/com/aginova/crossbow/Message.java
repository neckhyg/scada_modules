package com.aginova.crossbow;

import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import org.apache.log4j.Logger;

public class Message
{
  private static final Logger logger = Logger.getLogger(Message.class);
  String messageType;
  String creationDate = "" + new Date();
  Map messageMap;
  Message.FailureListener failureListener;
  public static final String ERROR_MESSAGE = "Error";
  public static final String HAVE_DATA_MESSAGE = "HaveData";
  public static final String HEALTH_MESSAGE = "Health";
  public static final String DATA_MESSAGE = "Data";
  public static final String LINKUP_MESSAGE = "LinkUp";
  public static final String PING_MESSAGE = "Ping";
  public static final String SLEEP_MESSAGE = "Sleep";
  public static final String MOTE_CONFIG_MESSAGE = "MoteConfig";
  public static final String SENSOR_CONFIG_MESSAGE = "SensorConfig";
  public static final String CACHE_CONFIG_MESSAGE = "CacheConfig";
  public static final String RADIO_CONFIG_MESSAGE = "RadioConfig";
  public static final String NOTIFICATION_MESSAGE = "Notification";
  public static final String UPDATE_MESSAGE = "Update";
  public static final String SCAN_INFO_MESSAGE = "ScanInfo";
  public static final String WIBOX_RESET_MESSAGE = "WiboxReset";

  public Message(String messageType, Map map)
  {
    this.messageType = messageType;
    this.messageMap = map;
  }

  public String getValue(String key)
  {
    return "" + this.messageMap.get(key);
  }

  public Object getObjectValue(String key)
  {
    return this.messageMap.get(key);
  }

  public void setValue(String key, Object value)
  {
    this.messageMap.put(key, value);
  }

  public boolean getBooleanValue(String key)
  {
    String val = (String)this.messageMap.get(key);
    if (val == null)
      throw new RuntimeException("nullPointerException");
    if (val.trim().equalsIgnoreCase("true"))
      return true;
    if (val.trim().equalsIgnoreCase("false")) {
      return false;
    }
    throw new RuntimeException("Unexpected here " + val + " is not true nor false!");
  }

  public Integer getIntValue(String key)
  {
    Object obj = this.messageMap.get(key);
    if (obj == null)
      return null;
    if ((obj instanceof Short))
      return Integer.valueOf(((Short)obj).intValue());
    if ((obj instanceof Integer))
      return (Integer)obj;
    return Integer.valueOf(Integer.parseInt((String)obj));
  }

  public Float getFloatValue(String key)
  {
    Object obj = null;
    try {
      obj = this.messageMap.get(key);
      if ((obj instanceof Float))
        return (Float)obj;
      if ((obj instanceof Integer))
        return new Float(((Integer)obj).intValue());
      if ((obj instanceof Double))
        return new Float(((Double)obj).doubleValue());
      if ((obj instanceof Short))
        return new Float(((Short)obj).shortValue());
      if ((obj instanceof String)) {
        return new Float((String)obj);
      }
      return (Float)obj;
    }
    catch (Exception e) {
      logger.error("With key " + key + ", obj " + obj + ", class " + (obj != null ? "" + obj.getClass() : "N/A"));
    }
    throw new RuntimeException(e);
  }

  public Double getDoubleValue(String key)
  {
    Object obj = null;
    try {
      obj = this.messageMap.get(key);
      if ((obj instanceof Float))
        return (Double)obj;
      if ((obj instanceof Integer))
        return new Double(((Integer)obj).intValue());
      if ((obj instanceof String)) {
        return new Double((String)obj);
      }
      return (Double)obj;
    }
    catch (Exception e) {
      logger.error("With key " + key + ", obj " + obj + ", class " + (obj != null ? "" + obj.getClass() : "N/A"));
    }
    throw new RuntimeException(e);
  }

  public Long getLongValue(String key)
  {
    Object obj = null;
    try {
      obj = this.messageMap.get(key);
      if ((obj instanceof Long))
        return (Long)obj;
      if ((obj instanceof Integer))
        return new Long(((Integer)obj).intValue());
      if ((obj instanceof String)) {
        return new Long((String)obj);
      }
      return (Long)obj;
    }
    catch (Exception e) {
      logger.error("With key " + key + ", obj " + obj + ", class " + (obj != null ? "" + obj.getClass() : "N/A"));
    }
    throw new RuntimeException(e);
  }

  public boolean isValueValid(String key)
  {
    return this.messageMap.get(key) != null;
  }

  public String getMessageType()
  {
    return this.messageType;
  }

  /** @deprecated */
  public void addAttribute(String att, String attValue)
  {
    this.messageMap.put(att, attValue);
  }

  public String toString()
  {
    return "Message of type " + this.messageType + " map " + this.messageMap;
  }

  public String getAttributes()
  {
    StringBuffer st = new StringBuffer();
    Iterator it = this.messageMap.keySet().iterator();
    while (it.hasNext()) {
      String key = "" + it.next();
      String value = "" + this.messageMap.get(key);
      st.append(" ").append(key).append("=").append(value);
    }
    return st.toString();
  }

  public boolean isError()
  {
    return this.messageType.equals("Error");
  }

  public boolean isHaveData()
  {
    return this.messageType.equals("HaveData");
  }

  public boolean isLinkup()
  {
    return this.messageType.equals("LinkUp");
  }

  public boolean isNotification()
  {
    return this.messageType.equals("Notification");
  }

  public boolean isWiboxReset()
  {
    return this.messageType.equals("WiboxReset");
  }

  public boolean isUpdate()
  {
    return this.messageType.equals("Update");
  }

  public boolean isHealth()
  {
    return this.messageType.equals("Health");
  }

  public boolean isData()
  {
    return this.messageType.equals("Data");
  }

  public boolean isNotInitialized()
  {
    if (!isHaveData())
      return false;
    String flag = "" + getValue("initialized");

    return (flag != null) && (flag.equals("0"));
  }

  public void setFailureListener(Message.FailureListener failureListener)
  {
    this.failureListener = failureListener;
  }

  public Message.FailureListener getFailureListener() {
    return this.failureListener;
  }
}