package com.aginova.crossbow;

import com.aginova.util.Displayable;
import com.aginova.util.Tools;

public class DefaultSensorDescriptor
  implements Displayable, Comparable
{
  String display;
  String shortDisplay;
  String actual;
  String columnName;
  Float minChart;
  Float maxChart;
  String unitDisplay;
  int alertLimit;
  int viewType;
  int axisType;
  int visualType;
  int precisionDigits;
  int axisGroup;
  String axisGroupName;

  public DefaultSensorDescriptor(String display, String actual)
  {
    this.display = display;
    this.actual = actual;
  }

  public DefaultSensorDescriptor(String display, String shortDisplay, String actual, String columnName, String unitDisplay, Float minChart, Float maxChart, int alertLimit, int viewType, int axisType, int visualType, int axisGroup, String axisGroupName, int precisionDigits)
  {
    this.display = display;
    this.shortDisplay = shortDisplay;
    this.actual = actual;
    this.columnName = columnName;
    this.unitDisplay = unitDisplay;
    this.minChart = minChart;
    this.maxChart = maxChart;
    this.alertLimit = alertLimit;
    this.viewType = viewType;
    this.axisType = axisType;
    this.axisGroup = axisGroup;
    this.axisGroupName = axisGroupName;
    this.precisionDigits = precisionDigits;
    this.visualType = visualType;
  }

  public String getDisplay() {
    return this.display;
  }

  public void setDisplay(String display) {
    this.display = display;
  }

  public String getActual() {
    return this.actual;
  }

  public void setActual(String actual) {
    this.actual = actual;
  }

  public Float getMinChart() {
    return this.minChart;
  }

  public void setMinChart(Float minChart) {
    this.minChart = minChart;
  }

  public Float getMaxChart() {
    return this.maxChart;
  }

  public void setMaxChart(Float maxChart) {
    this.maxChart = maxChart;
  }

  public String getUnitDisplay() {
    return this.unitDisplay;
  }

  public void setUnitDisplay(String unitDisplay) {
    this.unitDisplay = unitDisplay;
  }

  public int getAlertLimit() {
    return this.alertLimit;
  }

  public void setAlertLimit(int alertLimit) {
    this.alertLimit = alertLimit;
  }

  public int getViewType() {
    return this.viewType;
  }

  public void setViewType(int viewType) {
    this.viewType = viewType;
  }

  public void setAxisType(int axisType) {
    this.axisType = axisType;
  }

  public int getAxisType() {
    return this.axisType;
  }

  public void setAxisGroup(int axisGroup) {
    this.axisGroup = axisGroup;
  }

  public int getAxisGroup() {
    return this.axisGroup;
  }

  public void setAxisGroupName(String axisGroupName) {
    this.axisGroupName = axisGroupName;
  }

  public String getAxisGroupName() {
    return this.axisGroupName;
  }

  public String getDisplayValue() {
    return this.display;
  }

  public String getActualValue() {
    return this.actual;
  }

  public String toString() {
    return getDisplayValue();
  }

  public int compareTo(Object o) {
    if ((o instanceof DefaultSensorDescriptor)) {
      DefaultSensorDescriptor dd = (DefaultSensorDescriptor)o;
      return Tools.smartCompare(getDisplayValue(), dd.getDisplayValue());
    }
    return -1;
  }

  public static void main(String[] args)
  {
  }

  public int getPrecisionDigits()
  {
    return this.precisionDigits;
  }

  public String getStyleClass()
  {
    return null;
  }

  public void setShortDisplay(String shortDisplay) {
    this.shortDisplay = shortDisplay;
  }

  public String getShortDisplay() {
    return this.shortDisplay;
  }

  public void setColumnName(String columnName) {
    this.columnName = columnName;
  }

  public String getColumnName() {
    return this.columnName;
  }

  public String getShortDisplayNoBrackets()
  {
    String res = this.shortDisplay;
    if (res == null) return null;
    if (res.startsWith("(")) res = res.substring(1);
    if (res.endsWith(")")) res = res.substring(0, res.length() - 1);
    return res;
  }

  public void setVisualType(int visualType) {
    this.visualType = visualType;
  }

  public int getVisualType() {
    return this.visualType;
  }
}