package com.aginova.exception;

public class EmptyQueueException extends RuntimeException
{
}