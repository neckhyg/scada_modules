package com.aginova.exception;

import java.util.HashMap;
import java.util.Map;
import org.apache.log4j.Logger;

public class ErrorManager
{
  private static final Logger logger = Logger.getLogger(ErrorManager.class);

  public static int ONCE = 0;

  public static int TEN_MINUTES = 1;
  private static ErrorManager instance;
  Map errorMap = new HashMap();

  public static int MAPS_NOT_SET = 0;

  public static int ENGINE_OVERFLOW = 1;

  public static synchronized ErrorManager getErrorManager()
  {
    if (instance == null) {
      instance = new ErrorManager();
    }
    return instance;
  }

  public static boolean verifyError(int errorNumber, int quantity)
  {
    boolean result = false;
    ErrorManager em = getErrorManager();
    Object[] dd = (Object[])(Object[])em.errorMap.get(new Integer(errorNumber));

    if (dd == null) {
      em.errorMap.put(new Integer(errorNumber), new Object[] { new Integer(1), new Long(System.currentTimeMillis()) });

      result = true;
    }
    else {
      Integer count = (Integer)dd[0];
      long ts = ((Long)dd[1]).longValue();

      if (ONCE == quantity)
        result = false;
      else if (TEN_MINUTES == quantity) {
        if (System.currentTimeMillis() - ts > 600000L)
          result = true;
        else
          result = false;
      }
      else {
        logger.error("Unknown type " + quantity);
      }

      em.errorMap.put(new Integer(errorNumber), new Object[] { new Integer(count.intValue() + 1), new Long(System.currentTimeMillis()) });
    }

    return result;
  }
}