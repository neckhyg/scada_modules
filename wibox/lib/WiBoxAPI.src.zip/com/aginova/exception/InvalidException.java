package com.aginova.exception;

public class InvalidException extends Exception
{
  public InvalidException(String t)
  {
    super(t);
  }
}