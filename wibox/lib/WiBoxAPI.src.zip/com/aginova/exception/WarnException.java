package com.aginova.exception;

public class WarnException extends Exception
{
  public WarnException(String p0)
  {
    super(p0);
  }
}