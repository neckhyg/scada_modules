package com.aginova.exception;

public class InexistentGatewayException extends Exception
{
  public InexistentGatewayException(int gateway_id)
  {
    super("Gateway do not exist " + gateway_id);
  }
}