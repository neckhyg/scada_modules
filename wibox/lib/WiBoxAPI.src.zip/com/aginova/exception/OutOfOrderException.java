package com.aginova.exception;

public class OutOfOrderException extends Exception
{
  public OutOfOrderException(String s)
  {
    super(s);
  }
}