package com.aginova.exception;

public class UserException extends Exception
{
  public UserException(String s)
  {
    super(s);
  }
}