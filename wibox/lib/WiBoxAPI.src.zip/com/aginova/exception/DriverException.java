package com.aginova.exception;

public class DriverException extends Exception
{
  public DriverException()
  {
  }

  public DriverException(String s)
  {
    super(s);
  }
}