package com.aginova.exception;

public class FieldException extends Exception
{
  String field = null;

  public FieldException(String t, String field) {
    super(t);
    this.field = field;
  }

  public String getField() {
    return this.field;
  }
}