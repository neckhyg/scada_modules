package com.aginova.exception;

public class NotImplementedException extends RuntimeException
{
}