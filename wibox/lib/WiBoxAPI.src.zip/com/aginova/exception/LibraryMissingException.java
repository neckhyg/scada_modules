package com.aginova.exception;

import java.util.ArrayList;
import java.util.List;

public class LibraryMissingException extends Exception
{
  List list = new ArrayList();

  private LibraryMissingException()
  {
  }

  public LibraryMissingException(List list)
  {
    super("");
    this.list = list;
  }

  public String getMessage() {
    return "This is a list of the missing libraries: " + this.list.toString();
  }
}