package com.aginova.exception;

public class NoRowFoundException extends Exception
{
  public NoRowFoundException(String t)
  {
    super(t);
  }
}