package com.aginova.exception;

public class SensorNotFoundException extends RuntimeException
{
  public SensorNotFoundException(String s)
  {
    super(s);
  }
}