package com.aginova.exception;

public class IncompleteLogException extends Exception
{
}