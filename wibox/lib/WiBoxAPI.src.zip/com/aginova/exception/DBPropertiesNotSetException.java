package com.aginova.exception;

public class DBPropertiesNotSetException extends Exception
{
  public DBPropertiesNotSetException(String t)
  {
    super(t);
  }
}