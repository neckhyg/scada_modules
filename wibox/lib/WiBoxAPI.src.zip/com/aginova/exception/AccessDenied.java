package com.aginova.exception;

public class AccessDenied extends Exception
{
  public AccessDenied()
  {
  }

  public AccessDenied(String s)
  {
    super(s);
  }
}