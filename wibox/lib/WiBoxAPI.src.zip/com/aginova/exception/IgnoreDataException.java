package com.aginova.exception;

public class IgnoreDataException extends Exception
{
}