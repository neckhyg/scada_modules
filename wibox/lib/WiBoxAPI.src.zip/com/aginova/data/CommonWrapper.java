package com.aginova.data;

import com.aginova.exception.FieldException;
import com.aginova.util.ArrayTools;
import com.aginova.util.Displayable;
import com.aginova.util.ExtMap;
import com.aginova.util.Hibernate;
import com.aginova.util.Tools;
import com.aginova.util.UserProperties;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.Transaction;

public abstract class CommonWrapper extends Common
{
  private static final Logger logger = Logger.getLogger(CommonWrapper.class);

  public String setData(Session sess, ExtMap map)
    throws FieldException
  {
    StringBuffer sb = new StringBuffer(64);
    this.map = map;
    setNew(false);

    String fieldsToStore = map.getString("fieldsToStore");
    String fieldTypes = map.getString("fieldTypes");
    String fieldDisplays = map.getString("fieldDisplays");
    String fieldImportances = map.getString("fieldImportance");
    StringTokenizer st = new StringTokenizer(fieldsToStore, ",");
    StringTokenizer stTypes = new StringTokenizer(fieldTypes, ",");
    StringTokenizer stDisplays = new StringTokenizer(fieldDisplays, ",");
    StringTokenizer stImportance = new StringTokenizer(fieldImportances, ",");

    while (st.hasMoreElements()) {
      String key = ((String)st.nextElement()).trim();
      String fieldType = ((String)stTypes.nextElement()).trim();
      String fieldDisplay = ((String)stDisplays.nextElement()).trim();
      String fieldImportance = ((String)stImportance.nextElement()).trim();
      try
      {
        Object value = map.get(key);
        logger.debug("Value " + value + " for key " + key + " for field type " + fieldType);

        if ((map.getString(key) == null) || (map.getString(key).equals("")) || (map.getString(key).equals("...")))
        {
          if (fieldImportance.equals("mand"))
            throw new FieldException("Cannot be empty", key);
          if (!fieldImportance.equals("opt")) {
            throw new RuntimeException("Wrong attribute for field fieldImportance!");
          }
        }

        if ((value instanceof String))
        {
          logger.debug("Setting " + value + " for key " + key);
          String res = setString(key, value, fieldType, fieldDisplay);
          if (res != null) {
            if (sb.length() == 0)
              sb.append("Modified ");
            else {
              sb.append(", ");
            }
            sb.append(res);
          }
        } else if (((value instanceof List)) && (((List)value).size() >= 0))
        {
          logger.debug("Setting " + value + " for key " + key);
          String res = setString(key, (List)value, fieldType, fieldDisplay);
          if (res != null) {
            if (sb.length() == 0)
              sb.append("Modified ");
            else {
              sb.append(", ");
            }
            sb.append(res);
          }
        }
        else if (value != null) {
          logger.error("Not supported yet " + value.getClass());
        } else {
          logger.debug("WARN - Value = null for key " + key + ", object of type " + getClass());

          String res = setString(key, null, fieldType, fieldDisplay);
          if (res != null) {
            if (sb.length() == 0)
              sb.append("Modified ");
            else {
              sb.append(", ");
            }
            sb.append(res);
          }
        }
      }
      catch (FieldException e)
      {
        throw new FieldException("Please provide a <i>" + fieldType + "</i> for field <i>" + fieldDisplay + "</i>", key);
      }
    }

    if (sb.length() == 0)
      return null;
    return sb.toString();
  }

  public String getRepresentation()
  {
    return toString();
  }

  public String getStringWithoutException(String key) {
    try {
      return getStringWithException(key);
    } catch (Exception e) {
      logger.error("", e);
    }return null;
  }

  public String getStringWithException(String key)
    throws Exception
  {
    Method method = null;
    try {
      method = getClass().getMethod(convertToMethod(key, "get"), new Class[0]);
    } catch (NoSuchMethodException nsme) {
      method = getClass().getMethod(convertToMethod(key, "is"), new Class[0]);
    }

    Object obj = method.invoke(this, null);
    String result = null;
    if ((obj instanceof String)) {
      result = (String)obj;
    } else if ((obj instanceof Displayable)) {
      result = ((Displayable)obj).getActualValue();
    } else if ((obj instanceof CommonWrapper))
    {
      result = ((CommonWrapper)obj).getRepresentation(); } else {
      if (obj == null)
        return null;
      if (((obj instanceof List)) || ((obj instanceof Set)))
      {
        result = ArrayTools.objectToStringVisual(obj);
      }
      else result = "" + obj;
    }
    logger.debug("getString for key " + key + " returning " + result);
    return result;
  }

  public List getList(String key)
  {
    try
    {
      Method method = null;
      try {
        method = getClass().getMethod(convertToMethod(key, "get"), new Class[0]);
      } catch (NoSuchMethodException nsme) {
        method = getClass().getMethod(convertToMethod(key, "is"), new Class[0]);
      }
      List result = null;
      Object obj = method.invoke(this, null);

      if ((obj instanceof Boolean)) {
        obj = ((Boolean)obj).booleanValue() ? "true" : "false";
      }
      if ((obj instanceof List)) {
        result = (List)obj;
      } else if ((obj instanceof Set)) {
        result = new ArrayList((Set)obj);
      } else {
        result = new ArrayList();
        result.add(obj);
      }

      logger.debug("getList for key " + key + " returning " + result);
      return result;
    } catch (Exception e) {
      logger.error("Error for key " + key, e);
    }return null;
  }

  public String setString(String key, Object value, String fieldType, String fieldDisplay)
    throws FieldException
  {
    String result = null;
    Class typeClass = null;
    try {
      Object finalValue = null;

      String fieldTypeDetails = null;

      int p1 = fieldType.indexOf("+");
      if (p1 != -1) {
        fieldTypeDetails = fieldType.substring(p1 + 1);
        fieldType = fieldType.substring(0, p1);
        logger.debug("fieldType " + fieldType + ", fieldTypeDetails " + fieldTypeDetails);
      }

      if (fieldType.equals("String")) {
        typeClass = String.class;

        if ((value instanceof List))
          finalValue = ((List)value).get(0);
        else
          finalValue = value;
      }
      else if (fieldType.equals("int")) {
        typeClass = Integer.TYPE;
        if ((value instanceof List)) {
          String val2 = (String)((List)value).get(0);
          if (!val2.trim().equals(""))
            finalValue = new Integer(val2);
        }
        else {
          finalValue = new Integer((String)value);
        }
      }
      else if (fieldType.equals("Integer")) {
        typeClass = Integer.class;
        if ((value instanceof List)) {
          String val2 = (String)((List)value).get(0);
          if ((!val2.trim().equals("")) && (!val2.trim().equals("...")))
            finalValue = new Integer(val2);
          else {
            finalValue = null;
          }
        }
        else if (value != null) {
          finalValue = new Integer((String)value);
        }

      }
      else if (fieldType.equals("long")) {
        typeClass = Long.TYPE;
        if ((value instanceof List)) {
          String val2 = (String)((List)value).get(0);
          if (!val2.trim().equals(""))
            finalValue = new Long(val2);
        }
        else {
          finalValue = new Long((String)value);
        }
      }
      else if (fieldType.equals("Long")) {
        typeClass = Long.class;
        if ((value instanceof List)) {
          String val2 = (String)((List)value).get(0);
          if ((!val2.trim().equals("")) && (!val2.trim().equals("...")))
            finalValue = new Long(val2);
          else {
            finalValue = null;
          }
        }
        else if (value != null) {
          finalValue = new Long((String)value);
        }

      }
      else if (fieldType.equals("float")) {
        typeClass = Float.TYPE;
        if ((value instanceof List)) {
          String val2 = (String)((List)value).get(0);
          if (!val2.trim().equals(""))
            try {
              finalValue = new Float(val2);
            } catch (NumberFormatException nfe) {
              throw new FieldException("", "");
            }
        }
        else {
          finalValue = new Float((String)value);
        }
      }
      else if (fieldType.equals("boolean")) {
        typeClass = Boolean.TYPE;
        if ((value instanceof List)) {
          String val2 = (String)((List)value).get(0);
          if (!val2.trim().equals(""))
            finalValue = Boolean.valueOf(val2.trim().equals("true"));
        }
        else {
          finalValue = Boolean.valueOf(((String)value).trim().equals("true"));
        }
      }
      else if (fieldType.equals("List")) {
        typeClass = List.class;
        finalValue = value;
      } else if (fieldType.equals("Set")) {
        typeClass = Set.class;
        if ((fieldTypeDetails != null) && (value != null))
        {
          Class cl = UserProperties.getAppropriateClass("com.aginova.storage." + fieldTypeDetails);

          finalValue = new HashSet();
          Session sess = Hibernate.getSafeSession();
          Transaction tx = null;
          try {
            tx = Hibernate.beginSafeTransaction(sess);
            List list = (List)value;
            for (int i = 0; i < list.size(); i++) {
              String usedValue = (String)list.get(i);
              Object toStore = sess.get(cl.getName(), new Integer(usedValue));

              ((HashSet)finalValue).add(toStore);
            }
            Hibernate.safeCommit(tx);
          }
          catch (Exception e)
          {
            throw e;
          } finally {
            Hibernate.safeClose(sess);
          }
        }
        else if (value != null) {
          finalValue = new HashSet((List)value);
        } else {
          finalValue = new HashSet();
        }
      }
      else
      {
        try
        {
          Class cl = UserProperties.getAppropriateClass("com.aginova.storage." + fieldType, true);

          logger.debug("Using special class " + cl.getName());
          typeClass = cl;
          Object usedValue = null;
          if ((value instanceof List))
            usedValue = ((List)value).get(0);
          else {
            usedValue = value;
          }
          Session sess = Hibernate.getSafeSession();
          Transaction tx = null;
          try {
            tx = Hibernate.beginSafeTransaction(sess);
            if ((usedValue == null) || (((String)usedValue).equals("...")) || (((String)usedValue).trim().equals("")))
            {
              finalValue = null;
            }
            else finalValue = sess.get(typeClass, new Integer((String)usedValue));

            logger.debug("Using object " + finalValue);
            Hibernate.safeCommit(tx);
          }
          catch (Exception e)
          {
            throw e;
          } finally {
            Hibernate.safeClose(sess);
          }
        } catch (Exception e) {
          e.printStackTrace();
          throw new RuntimeException("Unknown field type " + fieldType + " for key " + key + " with value " + value);
        }

      }

      if (((!fieldType.equals("int")) && (!fieldType.equals("long"))) || (finalValue != null))
      {
        Method method = null;
        try
        {
          Object res = getStringWithException(key);

          String prevValue = ArrayTools.objectToStringVisual(res);

          String newValue = ArrayTools.objectToStringVisual(finalValue);

          logger.debug("Previous value: " + prevValue + ", new value: " + newValue);

          prevValue = Tools.isNotEmptyNullOrNullString(prevValue) ? prevValue : "(empty)";

          newValue = Tools.isNotEmptyNullOrNullString(newValue) ? newValue : "(empty)";

          if (!("" + newValue).trim().equals(("" + prevValue).trim()))
          {
            if (fieldDisplay.equalsIgnoreCase("password"))
              result = fieldDisplay + " (not shown)";
            else
              result = fieldDisplay + " from '" + prevValue + "' to '" + newValue + "'";
          }
        }
        catch (Exception e)
        {
          logger.warn("Not fatal: Could not compute old/new value", e);
        }
        try
        {
          method = getClass().getMethod(convertToMethod(key, "set"), new Class[] { typeClass });

          method.invoke(this, new Object[] { finalValue });
        }
        catch (NoSuchMethodException snme) {
          logger.debug("Ignorable exception " + snme.getMessage());
          method = getClass().getMethod(convertToMethod(key, "set"), new Class[] { typeClass.getSuperclass() });

          method.invoke(this, new Object[] { finalValue });
        }
      } else {
        logger.debug("Skipping field  for key " + key + ", fieldType " + fieldType + ", value " + value + ", typeClass " + typeClass);
      }
    }
    catch (InvocationTargetException ite) {
      Throwable target = ite.getTargetException();
      if ((target instanceof FieldException)) {
        FieldException fe = (FieldException)target;
        throw fe;
      }
      logger.error("When trying for key " + key + ", fieldType " + fieldType + ", value " + value + ",typeClass " + typeClass, ite.getTargetException());

      throw new RuntimeException(ite.getTargetException().getMessage());
    }
    catch (FieldException fe) {
      throw fe;
    } catch (Exception e) {
      logger.error("When trying for key " + key + ", fieldType " + fieldType + ", value " + value, e);

      throw new FieldException("Please provide a <i>" + fieldType + "</i> for field <i>" + fieldDisplay + "</i>", key);
    }

    return result;
  }

  public String toString() {
    return this.map.toString();
  }

  public static String convertToMethod(String field, String methodType) {
    return methodType + field.substring(0, 1).toUpperCase() + field.substring(1);
  }
}