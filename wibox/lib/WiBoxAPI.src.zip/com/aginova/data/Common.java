package com.aginova.data;

import com.aginova.exception.FieldException;
import com.aginova.util.ExtMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import org.apache.log4j.Logger;
import org.hibernate.Session;

public abstract class Common
{
  private static final Logger logger = Logger.getLogger(Common.class);

  public ExtMap map = new ExtMap();
  private boolean isNew = true;

  public abstract List getAllRows() throws Exception;

  public void put(Object key, String value) { this.map.put(key, value);
  }

  protected void setNew(boolean status)
  {
    this.isNew = status;
  }

  public boolean isNew()
  {
    return this.isNew;
  }

  public String setData(Session sess, ExtMap map) throws FieldException {
    this.map = map;
    setNew(false);
    return null;
  }

  public void addData(ExtMap newMap)
  {
    for (Iterator i = newMap.entrySet().iterator(); i.hasNext(); ) {
      Map.Entry e = (Map.Entry)i.next();
      this.map.put((String)e.getKey(), (List)e.getValue());
    }
  }

  public String getStringWithoutException(String key)
  {
    return this.map.getString(key);
  }

  public List getList(String key) {
    logger.debug("getList in Common");
    return this.map.getList(key);
  }

  public String toString() {
    return this.map.toString();
  }
}