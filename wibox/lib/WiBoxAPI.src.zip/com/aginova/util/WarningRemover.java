package com.aginova.util;

public class WarningRemover
{
  public static final void removeWarning()
  {
  }

  public static final void removeWarning(Object obj1)
  {
  }

  public static final void removeWarning(Object obj1, Object obj2)
  {
  }
}