package com.aginova.util;

import com.aginova.storage.Language;
import com.aginova.storage.LanguageLine;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.Vector;
import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class Lang
{
  private static final Logger logger = Logger.getLogger(Lang.class);
  private static Lang lang;
  public static boolean LOAD_FROM_DB = true;

  static Vector listeners = new Vector();

  private Map allProperties = new HashMap();
  private String language = "default";
  static final String numbers = "0123456789";

  public static synchronized void init()
    throws Exception
  {
    if (lang == null)
      lang = new Lang(null);
  }

  public static synchronized void reset()
  {
    lang = null;
  }

  public static synchronized void init(InputStream in) throws Exception
  {
    if (lang == null)
      lang = new Lang(in);
  }

  public static void register(Listener l)
  {
    listeners.add(l);
  }

  public static void notifyChange() {
    for (int i = 0; i < listeners.size(); i++)
      try {
        Listener ll = (Listener)listeners.get(i);
        ll.notifyChange();
      }
      catch (Exception e) {
        logger.error("", e);
      }
  }

  public static Lang getLang()
  {
    if (lang == null) {
      throw new RuntimeException("Language not initialized yet !");
    }
    return lang;
  }

  private Lang(InputStream in) throws Exception {
    InputStream is = null;
    String path = "/languages.property";
    if (in == null)
    {
      logger.info("Using path " + path);
      is = getClass().getClassLoader().getResourceAsStream(path);
    } else {
      is = in;
    }

    if (is == null) throw new Exception("Could not load the languages.property file. Make sure that WiBox.jar is in the classpath.");

    Properties properties = new Properties();
    properties.load(is);

    String installedApplication = DBConnectionProperties.getDBConnectionProperties().getProperty(DBConnectionProperties.INSTALL_APPLICATION);
    try
    {
      path = "/languages-" + installedApplication + ".property";
      logger.debug("Using path 2  " + path);
      is = getClass().getClassLoader().getResourceAsStream(path);
      Properties p2 = new Properties();
      if (is != null)
        p2.load(is);
      else {
        logger.warn("No extension found for " + installedApplication + " (INFO)");
      }

      properties.putAll(p2);
    } catch (Exception e) {
      logger.error("", e);
    }

    try
    {
      path = "/extensions.property";
      logger.debug("Using path 2  " + path);
      is = getClass().getClassLoader().getResourceAsStream(path);
      Properties p2 = new Properties();
      if (is != null) {
        p2.load(is);
      }

      properties.putAll(p2);
    } catch (Exception e) {
      logger.error("", e);
    }

    this.allProperties.put("default", properties);

    if (LOAD_FROM_DB)
      loadFromDB();
  }

  public void setLanguage(String lang)
  {
    logger.debug("Setting language '" + lang + "'");
    this.language = lang;
  }

  public void loadFromDB()
  {
    Session sess = Hibernate.getSafeSession();
    Transaction tx = null;
    try {
      tx = sess.beginTransaction();
      List list = sess.createQuery("from LanguageLine as LanguageLine").list();
      for (int i = 0; i < list.size(); i++) {
        LanguageLine ln = (LanguageLine)list.get(i);
        Properties map = (Properties)this.allProperties.get(ln.getLanguage_key().getLanguage_key());
        if (map == null) {
          map = new Properties();
          this.allProperties.put(ln.getLanguage_key().getLanguage_key(), map);
        }

        if (ln.getString_value() != null) {
          map.put(ln.getString_key(), ln.getString_value());
        }
      }
      logger.debug("Loaded " + list.size() + " languages entries for a total of " + this.allProperties.keySet().size() + " languages");
    }
    finally {
      Hibernate.safeCommit(tx);
      Hibernate.safeClose(sess);
    }
  }

  public Properties getPropertiesForDefaultLanguage() {
    Properties props = (Properties)this.allProperties.get("default");
    return props;
  }

  public String getNonEscLang(String key) {
    return getLang(key, this.language);
  }

  public String getLang(String key)
  {
    return Web.escapeHTML(getLang(key, this.language), false);
  }

  public String getLang(String key, String lang)
  {
    Properties props = (Properties)this.allProperties.get(lang);
    String value = null;
    if (props == null)
    {
      props = (Properties)this.allProperties.get("default");
      value = (String)props.get(key);
    } else {
      value = (String)props.get(key);
      if ((value == null) || (value.trim().equals("")))
      {
        props = (Properties)this.allProperties.get("default");
        value = (String)props.get(key);
      } else {
        logger.debug("Language " + lang + " found for a key " + key + ", using value " + value);
      }
    }
    return value;
  }

  public static String convert(String text, String[] placements)
  {
    try
    {
      StringBuffer sb = new StringBuffer(text.length());
      char prev = ' ';
      for (int i = 0; i < text.length(); i++) {
        char curr = text.charAt(i);

        if (("0123456789".indexOf("" + curr) != -1) && (prev == ':'))
        {
          int num = Integer.parseInt("" + curr);

          sb.append(placements[(num - 1)]);
        } else if (curr != ':')
        {
          if (prev == ':') {
            sb.append(prev);
          }
          sb.append(curr);
        }
        prev = curr;
      }
      return sb.toString();
    } catch (Exception e) {
      logger.error("", e);
    }return text;
  }

  public static void main(String[] args)
  {
    System.out.println(convert(":1 Reshad est un :0 ", new String[] { "gros con", "petit" }));
  }
}