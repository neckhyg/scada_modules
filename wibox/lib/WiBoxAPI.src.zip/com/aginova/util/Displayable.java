package com.aginova.util;

public abstract interface Displayable
{
  public abstract String getDisplayValue();

  public abstract String getActualValue();

  public abstract String getStyleClass();
}