package com.aginova.util;

import com.aginova.engine.DatabaseLoader;
import com.aginova.exception.FieldException;
import com.meterware.httpunit.WebForm;
import com.sun.image.codec.jpeg.JPEGImageEncoder;
import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.io.PrintStream;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.net.BindException;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.URL;
import java.net.UnknownHostException;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Enumeration;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.swing.SwingUtilities;
import org.apache.log4j.Logger;
import org.hibernate.JDBCException;

public class Tools
{
  private static final Logger logger = Logger.getLogger(Tools.class);
  public static final int REQUIRED = 1;
  public static final int IMPLIED = 2;
  private static final String ALL_VALS = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  static final DateFormat dateFormatter = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");

  public static String generateID()
  {
    StringBuffer st = new StringBuffer(16);
    for (int i = 0; i < 15; i++) {
      int rand = (int)Math.round(Math.random() * 35.0D);

      st.append("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ".charAt(rand));
    }
    return st.toString();
  }

  public static void sortActualDisplays(List list)
  {
    if (list == null)
      return;
    Comparator comp = new Comparator() {
      public int compare(Object o1, Object o2) {
        List l1 = (List)o1;
        List l2 = (List)o2;

        return String.valueOf(l1.get(1)).compareTo(String.valueOf(l2.get(1)));
      }
    };
    Collections.sort(list, comp);
  }

  public static String[] extractColumns(String[] cols, String[] displayCols, int[] validation, ExtMap map)
    throws Exception
  {
    String[] result = new String[cols.length];

    for (int i = 0; i < cols.length; i++) {
      result[i] = map.getString(cols[i]);

      if ((validation[i] != 1) || ((result[i] != null) && (!result[i].trim().equals("")) && (!result[i].trim().equals("..."))))
        continue;
      throw new FieldException("Please provide a " + displayCols[i], cols[i]);
    }

    return result;
  }

  public static String getTimeStamp()
  {
    return dateFormatter.format(new Date());
  }

  public static String getTime(long time) {
    return dateFormatter.format(new Date(time));
  }

  public static String replaceFirst(String text, String match, String replace)
  {
    if (text == null)
      return null;
    if (match == null)
      return text;
    if (replace == null)
      return text;
    int pos = text.indexOf(match);
    if (pos == -1)
      return text;
    return text.substring(0, pos) + replace + text.substring(pos + match.length());
  }

  private static String getCurrentDateTime(String format) {
    Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("PST"));
    String DATE_FORMAT = format;
    SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
    sdf.setTimeZone(TimeZone.getTimeZone("PST"));
    return sdf.format(cal.getTime());
  }

  public static String getCurrentDate()
  {
    return getCurrentDateTime("MM/dd/yyyy");
  }

  public static String getCurrentTime() {
    return getCurrentDateTime("MM/dd/yyyy HH:mm:ss");
  }

  public static String firstUpper(String input) {
    if (input == null)
      return null;
    if (input.length() < 2) {
      return input.toUpperCase();
    }
    String firstChar = input.substring(0, 1).toUpperCase();
    String lastChars = input.substring(1);

    return firstChar + lastChars;
  }

  public static String getIPAddress(String host)
  {
    String dottedQuad = "N/A";
    try {
      dottedQuad = InetAddress.getByName(host).getHostAddress();
    } catch (Exception e) {
      logger.error("", e);
    }
    return dottedQuad;
  }

  public static boolean notEmpty(String s)
  {
    if (s == null) {
      return false;
    }
    return !s.trim().equals("");
  }

  public static Float round(Float input, int decimalPlace)
  {
    if (input == null)
      return null;
    if (Float.isNaN(input.floatValue()))
      return Float.valueOf((0.0F / 0.0F));
    BigDecimal bd = new BigDecimal(input.floatValue());
    bd = bd.setScale(decimalPlace, 4);
    return Float.valueOf(bd.floatValue());
  }

  public static String roundAndDisplay(Float input, int decimalPlace) {
    if (input == null)
      return "-";
    float conv = round(input, decimalPlace).floatValue();
    String rep = "" + conv;
    int depl = 0;
    while ((depl = rep.length() - rep.indexOf(".") - 1) < decimalPlace) {
      rep = rep + "0";
    }
    if (decimalPlace == 0) {
      int c = rep.indexOf(".");
      if (c != -1) {
        rep = rep.substring(0, c);
      }
    }
    return rep;
  }

  public static String roundAndDisplay(String input, int decimalPlace) {
    if ((input == null) || (input.trim().equals("")))
      return null;
    float inputFloat = Float.parseFloat(input);
    if ((Float.isInfinite(inputFloat)) || (Float.isNaN(inputFloat)))
      return null;
    return "" + round(Float.valueOf(inputFloat), decimalPlace);
  }

  public static String getMemoryUsageStats() {
    return "Memory usage: " + round(Float.valueOf((float)(Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / 1024.0F / 1024.0F), 1) + "MB, total: " + round(Float.valueOf((float)Runtime.getRuntime().totalMemory() / 1024.0F / 1024.0F), 1) + "MB, Max: " + round(Float.valueOf((float)Runtime.getRuntime().maxMemory() / 1024.0F / 1024.0F), 1) + "MB";
  }

  public static byte[] readFromFile(File f)
    throws IOException
  {
    ByteArrayOutputStream bo = new ByteArrayOutputStream();
    InputStream in = new BufferedInputStream(new FileInputStream(f));
    byte[] temp = new byte[1024];
    int c = 0;
    while ((c = in.read(temp)) != -1) {
      bo.write(temp, 0, c);
    }
    byte[] res = bo.toByteArray();
    in.close();
    return res;
  }

  public static byte[] readFromInputStream(InputStream in)
    throws IOException
  {
    ByteArrayOutputStream bo = new ByteArrayOutputStream();
    byte[] temp = new byte[1024];
    int c = 0;
    while ((c = in.read(temp)) != -1) {
      bo.write(temp, 0, c);
    }
    byte[] res = bo.toByteArray();
    return res;
  }

  public static String readStringFromInputStream(InputStream in)
    throws IOException
  {
    StringBuffer sb = new StringBuffer();
    BufferedReader reader = new BufferedReader(new InputStreamReader(in));
    String temp = null;
    while ((temp = reader.readLine()) != null) {
      sb.append(temp + "\n");
    }
    return sb.toString();
  }

  public static String recurseException(Throwable thr)
  {
    String message = recurseOtherException(thr);
    int counter = 0;
    while ((thr != null) && (counter++ < 100)) {
      thr = thr.getCause();
      String mess = recurseOtherException(thr);
      if (mess != null) {
        message = message + ",\n" + mess;
      }
    }

    if ((message == null) || (message.length() == 0)) {
      message = "No error message was available.";
    }
    logger.error(message);
    return message;
  }

  private static String recurseOtherException(Throwable thr) {
    String message = thr != null ? thr.getMessage() : "";
    int counter = 0;
    while ((thr != null) && (counter++ < 100)) {
      if ((thr instanceof JDBCException)) {
        JDBCException jdbce = (JDBCException)thr;
        thr = jdbce.getSQLException();
      }
      if ((thr instanceof SQLException)) {
        SQLException sqle = (SQLException)thr;
        thr = sqle.getNextException();
      }

      String mess = thr != null ? thr.getMessage() : null;
      if (mess != null) {
        message = message + ",\n" + mess;
      }
    }

    if ((message == null) || (message.length() == 0))
      message = "No error message was available.";
    return message;
  }

  public static void globalUserException(Throwable thr)
  {
    String message = thr != null ? thr.getMessage() : "";
    int counter = 0;
    while ((thr != null) && (counter++ < 100)) {
      thr = thr.getCause();
      String mess = thr != null ? thr.getMessage() : null;
      if (mess != null) {
        message = message + ",\n" + mess;
      }
    }

    if ((message == null) || (message.length() == 0)) {
      message = "No error message was available.";
    }
    globalUserException(message);
  }

  public static void globalUserException(String s) {
    try {
      logger.debug("Showing a single exception " + s);
      SwingUtilities.invokeAndWait(new Tools.2(s));
    }
    catch (Exception e)
    {
      logger.error("Problem while displaying error ", e);
    }
  }

  public static boolean isNotEmptyNullDefaultOrNullString(String in)
  {
    return (in != null) && (!in.trim().equals("")) && (!in.trim().equals("null")) && (!in.trim().equals("..."));
  }

  public static boolean isNotEmptyNullOrNullString(String in)
  {
    return (in != null) && (!in.trim().equals("")) && (!in.trim().equals("null"));
  }

  public static boolean isEmptyNullOrNullString(String in)
  {
    return (in == null) || (in.trim().equals("")) || (in.trim().equals("null"));
  }

  public static String prependComa(String res)
  {
    if (res == null)
      return null;
    if (res.length() > 0)
      res = ", " + res;
    return res;
  }

  public static String appendComa(String res)
  {
    if (res == null)
      return null;
    if (res.length() > 0)
      res = res + ", ";
    return res;
  }

  public static void appendComa(StringBuffer res)
  {
    if (res == null)
      return;
    if (res.length() > 0)
      res.append(", ");
  }

  public static void safeClearOutputStream(PageContext pageContext, JspWriter out)
  {
    try
    {
      out.clear();
      out = pageContext.pushBody();
    }
    catch (Exception e) {
      logger.debug("WARN " + e);
    }
  }

  public static void safeEncode(JPEGImageEncoder encoder, BufferedImage bufferedImage)
  {
    try
    {
      encoder.encode(bufferedImage);
    } catch (IOException ioe) {
      if ((ioe != null) && (ioe.getMessage() != null) && (ioe.getMessage().contains("reading encoded JPEG Stream")))
      {
        logger.debug("warn - maybe user stopped download", ioe);
      }
      else logger.error("", ioe);
    }
  }

  public static void checkSocketPort(int portNumber)
    throws Exception
  {
    try
    {
      try
      {
        DatagramSocket socket = new DatagramSocket(portNumber);
        socket.close();
      }
      catch (BindException be1) {
        try {
          Thread.sleep(5000L);
        } catch (Exception ee) {
          logger.error("", ee);
        }
        DatagramSocket socket = new DatagramSocket(portNumber);
        socket.close();
      }
    }
    catch (BindException be) {
      throw new Exception("Cannot bind on port " + portNumber + ", check that the Desktop Software, the WiBox or a 3rd party software is not already using that port! \n(Wait some time before restarting the program)\nCause: " + safeExceptionMessage(be));
    }
  }

  public static String executeSafeCommand(String command)
    throws Exception
  {
    try
    {
      return executeCommand(command); } catch (Exception e) {
    }
    return "An error occurred: " + safeExceptionMessage(e);
  }

  public static String executeCommand(String command)
    throws Exception
  {
    Process p = Runtime.getRuntime().exec(command);
    InputStream in = p.getInputStream();
    LineNumberReader ln = new LineNumberReader(new InputStreamReader(in));
    String temp = null;
    StringBuffer buffer = new StringBuffer(100);
    while ((temp = ln.readLine()) != null) {
      buffer.append(temp);
      buffer.append("\n");
    }
    p.waitFor();
    return buffer.toString();
  }

  public static String filterBadCharacters(String in)
  {
    if (in == null)
      return null;
    StringBuffer sb = new StringBuffer(in.length());
    for (int i = 0; i < in.length(); i++) {
      String ss = in.substring(i, i + 1);
      System.out.println("CHAR " + ss + "," + ss.charAt(0) + ",");
      if (ss.charAt(0) != ' ')
        sb.append(ss);
      else {
        sb.append("\n");
      }
    }
    return sb.toString();
  }

  public static String getARP()
    throws Exception
  {
    if (isWindows()) {
      return executeSafeCommand("arp -a");
    }
    return executeSafeCommand("/sbin/arp");
  }

  public static String getIPInfo()
    throws Exception
  {
    if (isWindows()) {
      return executeSafeCommand("ipconfig").replaceAll("\n\n", "\n");
    }
    return executeSafeCommand("ifconfig").replaceAll("\n\n", "\n");
  }

  public static String getIPRoutes()
    throws Exception
  {
    if (isWindows()) {
      return executeCommand("route print").replaceAll("\n\n", "\n");
    }
    return executeCommand("route -v").replaceAll("\n\n", "\n");
  }

  public static boolean isWindows()
  {
    return System.getProperty("os.name").startsWith("Windows");
  }

  public static boolean isMacOSX()
  {
    return System.getProperty("os.name").toLowerCase().startsWith("mac os x");
  }

  public static List getAllIpAddresses()
    throws Exception
  {
    if (!isWindows()) {
      throw new RuntimeException("getAllIpAddresses only supported for Windows platform!");
    }
    List res = new ArrayList();

    String dd = executeCommand("netsh interface ip show address");

    Pattern pattern = Pattern.compile("\\d+.\\d+.\\d+.\\d+");
    Matcher matcher = pattern.matcher(dd);

    while (matcher.find()) {
      String group = matcher.group().trim();
      System.out.println("Match " + group);
      if (!group.startsWith("255.255.")) {
        res.add(group);
      }
    }

    return res;
  }

  public static String getValueOrDefault(String val, String def)
  {
    if (val != null)
      return val;
    return def;
  }

  public static List getNetworkInterfaces()
  {
    List res = new ArrayList();
    try
    {
      Enumeration e = NetworkInterface.getNetworkInterfaces();

      if (e != null)
        while (e.hasMoreElements()) {
          NetworkInterface netface = (NetworkInterface)e.nextElement();

          Enumeration e2 = netface.getInetAddresses();

          while (e2.hasMoreElements()) {
            InetAddress ip = (InetAddress)e2.nextElement();

            res.add(ip.getHostAddress());
          }
        }
    } catch (Exception ee) {
      logger.error("", ee);
    }
    return res;
  }

  public static String truncate(String input, int maxLength)
  {
    if (input == null)
      return null;
    if (input.length() > maxLength) {
      return input.substring(0, maxLength);
    }
    return input;
  }

  public static Integer convertStringToInteger(String s)
  {
    if ((s == null) || (s.trim().length() == 0))
      return null;
    return new Integer(s);
  }

  public static Float convertStringToFloat(String s)
  {
    if ((s == null) || (s.trim().length() == 0))
      return null;
    return new Float(s);
  }

  public static Long convertStringToLong(String s)
  {
    if ((s == null) || (s.trim().length() == 0))
      return null;
    return new Long(s);
  }

  public static Float convertIntegerToFloat(Integer i)
  {
    if (i == null)
      return null;
    return new Float(i.intValue());
  }

  public static Integer convertFloatToInteger(Float f)
  {
    if (f == null)
      return null;
    return new Integer((int)f.floatValue());
  }

  public static String convertIntegerToString(Integer s)
  {
    if (s == null)
      return null;
    return "" + s;
  }

  public static final boolean isDifferent(String s1, String s2)
  {
    if (s1 == null)
    {
      return s2 != null;
    }

    if (s2 == null) {
      return true;
    }
    return !s1.equals(s2);
  }

  public static final boolean isDifferent(Integer s1, Integer s2)
  {
    if (s1 == null)
    {
      return s2 != null;
    }

    if (s2 == null) {
      return true;
    }
    return s1.intValue() != s2.intValue();
  }

  public static final boolean isDifferent(List<Integer> s1, List<Integer> s2)
  {
    if (s1 == null)
    {
      return s2 != null;
    }

    if (s2 == null) {
      return true;
    }
    if (s1.size() != s2.size())
      return true;
    for (int i = 0; i < s1.size(); i++) {
      if (((Integer)s1.get(i)).intValue() != ((Integer)s2.get(i)).intValue())
        return true;
    }
    return false;
  }

  public static final Integer[] convertToIntegerArray(Object[] data)
  {
    if (data == null)
      return null;
    Integer[] res = new Integer[data.length];
    int counter = 0;
    for (Object obj : data) {
      res[(counter++)] = ((Integer)obj);
    }
    return res;
  }

  public static final String[] convertToStringArray(Object[] data)
  {
    if (data == null)
      return null;
    String[] res = new String[data.length];
    int counter = 0;
    for (Object obj : data) {
      res[(counter++)] = ((String)obj);
    }
    return res;
  }

  public static int smartCompare(String s1, String s2)
  {
    if (s1 == null) {
      if (s2 == null)
        return 0;
      return s2.compareTo(s1);
    }
    if (s1.equals(s2)) {
      return 0;
    }

    int minLength = Math.min(s1.length(), s2.length());
    String block1 = "";
    String block2 = "";
    for (int i = 0; i < minLength; i++) {
      char c1 = s1.charAt(i);
      char c2 = s2.charAt(i);
      boolean checkBlocks = false;

      if ((isNumber(c1)) || (isNumber(c2)))
      {
        if (isNumber(c1))
          block1 = block1 + c1;
        if (isNumber(c2))
          block2 = block2 + c2;
      } else if (c1 == c2)
      {
        if ((block1.length() == 0) && (block2.length() == 0))
        {
          continue;
        }

      }
      else
      {
        checkBlocks = true;
      }

      if ((!checkBlocks) && (i != minLength - 1))
        continue;
      if ((block1.length() != 0) && (block2.length() != 0)) {
        int b1 = Integer.parseInt(block1);
        int b2 = Integer.parseInt(block2);

        if (b1 < b2)
          return -1;
        if (b1 > b2) {
          return 1;
        }
        block1 = block2 = "";
      }
      else
      {
        return ("" + c1).compareTo("" + c2);
      }

    }

    logger.error("This is an internal error (4325) for s1 " + s1 + ", s2 " + s2);
    return -1;
  }

  public static boolean isNumber(char s)
  {
    return "0123456789".indexOf(s) != -1;
  }

  public static void main(String[] args) throws Exception
  {
    args = null;
    DatabaseLoader.quickConfigure();
    smartCompare("Temperature (10)", "Temperature (2)");
    logger.debug("IP: " + getIPAddressesString());
    logger.debug("MAC: " + getMACAddressesString());
  }

  public static String getOptionForName(WebForm form, String optionName, String optionDisplay)
  {
    String[] actual = form.getOptionValues(optionName);
    String[] display = form.getOptions(optionName);
    int counter = 0;
    for (String disp : display)
    {
      if (disp.equals(optionDisplay))
        return actual[counter];
      counter++;
    }

    return null;
  }

  public static String getExtension(File f)
  {
    if (f == null)
      return null;
    String ext = null;
    String s = f.getName();
    int i = s.lastIndexOf('.');

    if ((i > 0) && (i < s.length() - 1)) {
      ext = s.substring(i + 1).toLowerCase();
    }
    return ext;
  }

  public static Map<String, String> convertToMapStringString(Map<String, Object> input)
  {
    Map result = new HashMap();
    Iterator it = input.keySet().iterator();
    while (it.hasNext()) {
      String key = (String)it.next();
      result.put(key, String.valueOf(input.get(key)));
    }
    return result;
  }

  public static Object[][][] expandObjectArray(Object[] objects)
  {
    if (objects == null)
      return (Object[][][])null;
    Object[][][] res = new Object[objects.length][5][2];
    for (int i = 0; i < objects.length; i++) {
      Object obj = objects[i];
      Object[] tr = (Object[])(Object[])obj;
      for (int j = 0; j < tr.length; j++) {
        Object obj2 = tr[j];
        Object[] tr2 = (Object[])(Object[])obj2;
        res[i][j][0] = tr2[0];
        res[i][j][1] = tr2[1];
      }
    }
    return res;
  }

  public static double stableAtan(double a, double b)
  {
    if (Math.abs(b) >= Math.abs(a)) {
      return Math.atan(a / b);
    }
    double theta = Math.atan(b / a);
    if (theta >= 0.0D) {
      return 1.570796326794897D - theta;
    }
    return -1.0D * (1.570796326794897D + theta);
  }

  public static String convertObjectToString(Object object)
  {
    if (object == null)
      return null;
    return String.valueOf(object);
  }

  public static Integer convertObjectToInteger(Object object)
  {
    if (object == null)
      return null;
    if ((object instanceof Integer))
      return (Integer)object;
    return new Integer("" + object);
  }

  public static Object[] removeNullsFromList(Object[] objects)
  {
    if (objects == null)
      return null;
    List res = new ArrayList();
    for (Object o : objects) {
      if (o != null)
        res.add(o);
    }
    return res.toArray();
  }

  public static void safeCreateDirectoryIfNotExisting(File directory)
  {
    if (!directory.exists())
      directory.mkdir();
  }

  public static String safeExceptionMessage(Throwable thr)
  {
    return thr != null ? thr.getMessage() : "N/A";
  }

  public static void runMethodFromStaticClass(String className, String methodName)
    throws Exception
  {
    Class cl = Class.forName(className);
    Method meth = cl.getMethod(methodName, new Class[0]);
    meth.invoke(null, new Object[0]);
  }

  public static String getIPAddressesString()
    throws UnknownHostException, SocketException
  {
    StringBuffer result = new StringBuffer(48);

    InetAddress addr = InetAddress.getLocalHost();

    String hostname = addr.getHostName();
    result.append(hostname);

    Enumeration e = NetworkInterface.getNetworkInterfaces();

    while (e.hasMoreElements()) {
      NetworkInterface ni = (NetworkInterface)e.nextElement();

      Enumeration e2 = ni.getInetAddresses();
      while (e2.hasMoreElements()) {
        InetAddress ip = (InetAddress)e2.nextElement();

        result.append(",").append(ip.toString().substring(1));
      }
    }

    return result.toString();
  }

  public static String getMACAddressesString()
    throws Exception
  {
    StringBuffer result = new StringBuffer(48);
    Enumeration e = NetworkInterface.getNetworkInterfaces();

    while (e.hasMoreElements()) {
      NetworkInterface ni = (NetworkInterface)e.nextElement();

      if (ni != null) {
        byte[] mac = null;
        try {
          mac = (byte[])(byte[])callMethod(ni, "getHardwareAddress");
        }
        catch (NoSuchMethodException nsme) {
          logger.debug("" + nsme);
        }
        if (mac != null) {
          if (result.length() > 0) result.append(",");
          result.append(convertAndPad(mac[0]) + ":" + convertAndPad(mac[1]) + ":" + convertAndPad(mac[2]) + ":" + convertAndPad(mac[3]) + ":" + convertAndPad(mac[4]) + ":" + convertAndPad(mac[5]));
        }
      }
    }
    return result.toString();
  }

  private static String convertAndPad(byte data)
  {
    String s = "" + (data & 0xFF);
    if (s.length() == 1) s = "0" + s;
    return s;
  }

  private static Object callMethod(Object object, String method)
    throws Exception
  {
    Method m = object.getClass().getMethod(method, new Class[0]);
    return m.invoke(object, new Object[0]);
  }

  public static String replaceAll(String text, String match, String replace)
  {
    if (text == null)
      return null;
    if (match == null)
      return text;
    if (replace == null) {
      return text;
    }
    StringBuffer sb = new StringBuffer(text.length());
    for (int i = 0; i < text.length(); i++) {
      String chr = text.substring(i, Math.min(i + match.length(), text.length()));

      if (chr.equals(match)) {
        sb.append(replace);
        i += match.length() - 1;
      } else {
        sb.append(text.substring(i, i + 1));
      }

    }

    return sb.toString();
  }

  public static String getDisplayFromActual(List<Displayable> list, String actual)
  {
    for (Displayable disp : list)
    {
      if ((disp.getActualValue() != null) && (disp.getActualValue().equals(actual))) return disp.getDisplayValue();
    }
    return "N/A";
  }

  public static Date getDate(int hh, int mm)
  {
    GregorianCalendar gc = new GregorianCalendar();
    gc.set(11, hh);
    gc.set(12, mm);
    gc.set(13, 0);

    if (gc.before(new GregorianCalendar())) {
      gc.add(6, 1);
    }
    return gc.getTime();
  }

  public static long[] getDateFromMonthYear(int month, int year)
  {
    GregorianCalendar gc = new GregorianCalendar();
    gc.set(11, 0);
    gc.set(12, 0);
    gc.set(13, 0);

    gc.set(5, 1);
    gc.set(2, month);
    gc.set(1, year);

    long d1 = gc.getTime().getTime();

    gc.set(2, month + 1);
    gc.add(13, -1);

    long d2 = gc.getTime().getTime();

    return new long[] { d1, d2 };
  }

  public static long[] getStartEndTimestampForToday()
  {
    GregorianCalendar gc = new GregorianCalendar();
    gc.set(11, 0);
    gc.set(12, 0);
    gc.set(13, 0);
    gc.set(14, 0);

    long d1 = gc.getTime().getTime();
    long d2 = d1 + 86400000L - 1000L;

    return new long[] { d1, d2 };
  }

  public static long[] getDateFromDayMonthYear(int day, int month, int year)
  {
    GregorianCalendar gc = new GregorianCalendar();
    gc.set(11, 0);
    gc.set(12, 0);
    gc.set(13, 0);
    gc.set(14, 0);

    gc.set(5, day);
    gc.set(2, month);
    gc.set(1, year);

    long d1 = gc.getTime().getTime();
    long d2 = d1 + 86400000L - 1000L;

    return new long[] { d1, d2 };
  }

  public static int getNumberOfDays(int month, int year)
  {
    GregorianCalendar gc = new GregorianCalendar();
    gc.set(11, 0);
    gc.set(12, 0);
    gc.set(13, 0);

    gc.set(5, 1);
    gc.set(2, month);
    gc.set(1, year);

    gc.set(2, month + 1);
    gc.add(13, -1);

    return gc.get(5);
  }

  public static int getCurrentMonth()
  {
    GregorianCalendar gc = new GregorianCalendar();
    gc.setTime(new Date(System.currentTimeMillis()));
    return gc.get(2);
  }

  public static int getCurrentYear()
  {
    GregorianCalendar gc = new GregorianCalendar();
    gc.setTime(new Date(System.currentTimeMillis()));
    return gc.get(1);
  }

  public static void sendInfo(String urlString, Map<String, String> map)
    throws IOException
  {
    StringBuffer mapKeys = new StringBuffer(100);
    Iterator it = map.keySet().iterator();
    while (it.hasNext()) {
      String key = (String)it.next();
      String value = (String)map.get(key);
      if (mapKeys.length() != 0) mapKeys.append("&");
      mapKeys.append(Web.escapeURL(key) + "=" + Web.escapeURL(value));
    }
    URL url = new URL(urlString + "?" + mapKeys.toString());
    url.getContent();
  }

  public static String showAsDate(Long date)
  {
    if (date == null) return "N/A";
    return "" + new Date(date.longValue());
  }

  public static Float parseNullableFloat(String s)
  {
    if ((s == null) || (s.equalsIgnoreCase("null"))) return null;
    return Float.valueOf(Float.parseFloat(s));
  }
}