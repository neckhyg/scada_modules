package com.aginova.util;

import com.aginova.data.Common;
import com.aginova.exception.UserException;
import java.io.IOException;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;
import java.util.Locale;
import java.util.StringTokenizer;
import java.util.TimeZone;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;

public final class Web
{
  private static final Logger logger = Logger.getLogger(Web.class);

  private static final List monthsList = Arrays.asList(new Object[] { new DisplayableImpl("0", "January"), new DisplayableImpl("1", "February"), new DisplayableImpl("2", "March"), new DisplayableImpl("3", "April"), new DisplayableImpl("4", "May"), new DisplayableImpl("5", "June"), new DisplayableImpl("6", "July"), new DisplayableImpl("7", "August"), new DisplayableImpl("8", "September"), new DisplayableImpl("9", "October"), new DisplayableImpl("10", "November"), new DisplayableImpl("11", "December") });

  private static final List yearsList = Arrays.asList(new Object[] { new DisplayableImpl("2006", "2006"), new DisplayableImpl("2007", "2007"), new DisplayableImpl("2008", "2008"), new DisplayableImpl("2009", "2009"), new DisplayableImpl("2010", "2010"), new DisplayableImpl("2011", "2011"), new DisplayableImpl("2012", "2012") });

  public static int INPUT_DEFAULT_WIDTH = 18;

  public static int TEXT_TYPE = 1;
  public static int PASSWORD_TYPE = 2;
  public static int HIDDEN_TYPE = 3;
  public static int CHECKBOX_TYPE = 4;
  public static int TEXTAREA_TYPE = 5;
  public static int RADIO_TYPE = 6;

  public static int MARGIN_WIDTH = 1;
  private static final long milPerDay = 86400000L;
  private static final long milPerOra = 3600000L;
  private static final long milPerMin = 60000L;
  private static final long milPerSec = 1000L;
  static List booleanListDisplay = Arrays.asList(new String[] { "Yes", "No" });
  static List booleanListActualTrue = Arrays.asList(new String[] { "true", "false" });

  private static DateFormat formatter = null;
  private static DateFormat international_formatter = null;

  public static int getIntValue(HttpServletRequest request, String fieldName, int defaultValue)
  {
    String temp = request.getParameter(fieldName);
    if ((temp == null) || (temp.equals("..."))) {
      return defaultValue;
    }
    return Integer.parseInt(temp);
  }

  public static String getValue(HttpServletRequest request, String fieldName)
  {
    String temp = request.getParameter(fieldName);
    if ((temp == null) || (temp.equals("..."))) {
      return null;
    }
    return temp;
  }

  public static String getValue(HttpServletRequest request, String fieldName, String defaultValue)
  {
    String temp = request.getParameter(fieldName);
    String res = temp;
    if ((temp == null) || (temp.equals("..."))) {
      res = null;
    }
    if (res == null) {
      res = defaultValue;
    }
    return res;
  }

  public static String niceText(Date data)
  {
    if (data == null) {
      return "-";
    }
    return "" + data;
  }

  public static String niceText(String data) {
    if ((data == null) || (data.trim().equals("")) || (data.trim().equals("null"))) {
      return "-";
    }
    return data;
  }

  public static String niceText(Object data) {
    if ((data == null) || (("" + data).trim().equals("")) || (("" + data).trim().equals("null"))) {
      return "-";
    }
    return "" + data;
  }

  public static String nice(Displayable data) {
    if ((data == null) || (data.getDisplayValue() == null)) {
      return "-";
    }
    return escapeHTML(data.getDisplayValue());
  }

  public static String nice(String data) {
    if ((data == null) || (data.trim().equals("")) || (data.trim().equals("null"))) {
      return "-";
    }

    return escapeHTML(data, false);
  }

  public static String nice(Integer data) {
    if (data == null) {
      return "-";
    }
    return "" + data;
  }

  public static String nice(Object[] array, int index) {
    if ((array == null) || (array[index] == null)) {
      return "-";
    }
    return "" + array[index];
  }

  public static String niceXML(String data) {
    if ((data == null) || (data.trim().equals("")) || (data.trim().equals("null"))) {
      return "-";
    }
    return escapeXML(data);
  }

  public static String callHelp(HttpServletRequest request, String helpTopic, String displayTopic)
  {
    String current = request.getParameter("current");
    if (current == null)
      current = "home";
    return "main.jsp?&amp;subcurrent=" + request.getParameter("subcurrent") + "&amp;targetPage=help.jsp" + "&amp;callingPage=" + request.getParameter("current") + "_" + request.getParameter("subcurrent") + "&amp;helpTopic=" + helpTopic + "&amp;displayTopic=" + displayTopic;
  }

  public static String getDateAsnumberOfDays(long difMil)
  {
    return getDateAsnumberOfDays(difMil, false);
  }

  public static String getDateAsnumberOfDays(long difMil, boolean shortDisplay)
  {
    long days = difMil / 86400000L;
    long ore = (difMil - days * 86400000L) / 3600000L;
    long min = (difMil - days * 86400000L - ore * 3600000L) / 60000L;
    long sec = (difMil - days * 86400000L - ore * 3600000L - min * 60000L) / 1000L;

    if (days < 1L) {
      if (ore < 1L) {
        if (min < 1L) {
          return sec + (shortDisplay ? "s" : " sec");
        }
        return min + (shortDisplay ? "m" : " min") + (sec != 0L ? " " + sec + "s" : "");
      }

      return ore + "h" + (min != 0L ? " " + min : "");
    }
    if (days == 1L) {
      return "1 day";
    }
    if (days > 1000L) {
      return "-";
    }
    return days + " days";
  }

  public static String getDateAsnumberOfDays(Date d)
  {
    long now = System.currentTimeMillis();
    long difMil = now - d.getTime();
    return getDateAsnumberOfDays(difMil);
  }

  public static ExtMap generateMap(HttpServletRequest request) {
    ExtMap map = new ExtMap();
    Enumeration enumeration = request.getParameterNames();
    while (enumeration.hasMoreElements()) {
      String name = String.valueOf(enumeration.nextElement());
      String[] values = request.getParameterValues(name);
      map.put(name, values);
    }
    return map;
  }

  public static String getTrueBooleanSelect(HttpSession session, HttpServletRequest request, String name, String defaultActualValue, String onchange, Common object, boolean readOnly) {
    return getSelect(session, request, name, booleanListActualTrue, booleanListDisplay, Arrays.asList(new String[] { defaultActualValue }), onchange, false, false, object, readOnly, false, null);
  }

  public static String getTrueBooleanSelect(HttpServletRequest request, String name, String defaultActual, String onchange, boolean emptyDefault, boolean multiple, Common object)
  {
    return getSelect(request, name, booleanListActualTrue, booleanListDisplay, defaultActual, onchange, emptyDefault, multiple, object);
  }

  public static List getList(HttpServletRequest request, String fieldName)
  {
    String[] temp = request.getParameterValues(fieldName);
    if (temp == null) {
      return null;
    }
    return new ArrayList(Arrays.asList(temp));
  }

  public static String getRequest(HttpServletRequest request, String fieldName, String defValue)
  {
    return getRequest(request, fieldName, defValue, null);
  }

  public static String getRequest(HttpServletRequest request, String fieldName, String defValue, Common object)
  {
    return getRequest(null, request, fieldName, defValue, object);
  }

  public static String getRequest(HttpSession session, HttpServletRequest request, String fieldName, String defValue, Common object)
  {
    logger.debug("DEBUG_getRequest " + fieldName + ", defValue " + defValue + ", object " + object);

    String temp = request.getParameter(fieldName);
    if ((temp == null) && (object != null)) {
      temp = object.getStringWithoutException(fieldName);
      logger.debug("DEBUG_Temp after object getstring " + temp + ", is null?" + (temp == null));
    }

    if (session != null) {
      Object obj = session.getAttribute(fieldName);
      if (obj != null) {
        String fromSess = null;
        if ((obj instanceof String)) {
          fromSess = (String)obj;
        } else {
          String[] list = (String[])(String[])obj;
          if (list.length > 0) {
            fromSess = list[0];
          }
        }
        if ((temp == null) && (fromSess != null)) {
          return fromSess;
        }
      }
    }

    if ((temp == null) && (defValue != null)) {
      temp = defValue;
    }
    if (temp == null)
      temp = "";
    if (session != null) session.setAttribute(fieldName, temp);
    return temp;
  }

  public static List getRequestParameters(HttpSession session, HttpServletRequest request, String fieldName, List defValue, Common object)
  {
    List temp = ArrayTools.asNullableList(request.getParameterValues(fieldName));

    if ((temp == null) && (object != null)) {
      temp = object.getList(fieldName);
    }

    if (session != null) {
      List fromSess = null;
      Object obj = session.getAttribute(fieldName);
      logger.debug("From session: " + ArrayTools.objectToStringVisual(obj));
      if (obj != null) {
        if ((obj instanceof List))
          fromSess = (List)obj;
        else if ((obj instanceof String[]))
          fromSess = Arrays.asList((String[])(String[])obj);
        else {
          fromSess = Arrays.asList(new Object[] { obj });
        }
      }

      if ((temp == null) && (fromSess != null)) {
        return fromSess;
      }
    }

    if (((temp == null) || (temp.size() == 0)) && (defValue != null)) {
      temp = defValue;
    }
    if (temp == null)
      temp = new ArrayList();
    if (session != null) {
      logger.debug("Setting session " + fieldName + ", temp: " + temp);
      Object obj = session.getAttribute(fieldName);
      session.setAttribute(fieldName, ArrayTools.listToStringArray(temp));
    }
    return temp;
  }

  private static void removeOptionFromSession(HttpSession session, String fieldName, String fieldValue)
  {
    logger.debug("removeOptionFromSession fieldName " + fieldName + ", fieldValue " + fieldValue + ", session " + session);
    if (session == null) return;
    if (fieldValue == null) return;
    List fromSess = null;
    Object obj = session.getAttribute(fieldName);
    if (obj != null)
    {
      fromSess = new ArrayList(Arrays.asList((String[])(String[])obj));
      fromSess.remove(fieldValue);
      logger.debug("fromSess2 " + fromSess);
      session.setAttribute(fieldName, ArrayTools.listToStringArray(fromSess));
    }
  }

  public static String getInput(HttpServletRequest request, int type, String name, String defValue)
  {
    return getInput(request, type, name, defValue, null);
  }

  public static String getInput(HttpServletRequest request, int type, String name, String defValue, String onclick)
  {
    return getInput(request, type, name, defValue, onclick, null);
  }

  public static String getInput(HttpServletRequest request, int type, String name, String defValue, String onclick, Common object)
  {
    return getInput(request, type, name, defValue, onclick, object, false);
  }

  public static String getInput(HttpServletRequest request, int type, String name, String defValue, String onclick, Common object, boolean readOnly)
  {
    return getInput(request, type, name, defValue, onclick, object, readOnly, INPUT_DEFAULT_WIDTH);
  }

  public static String getInput(HttpServletRequest request, int type, String name, String defValue, String onclick, Common object, boolean readOnly, int size)
  {
    return getInput(request, type, name, defValue, onclick, object, readOnly, size, null);
  }

  public static String getInput(HttpServletRequest request, int type, String name, String defValue, String onclick, Common object, boolean readOnly, int size, String onKeyPress)
  {
    return getInput(null, request, type, name, defValue, onclick, object, readOnly, size, onKeyPress);
  }

  public static String getInput(HttpSession session, HttpServletRequest request, int type, String name, String defValue, String onclick, Common object, boolean readOnly, int size, String onKeyPress)
  {
    StringBuffer sb = new StringBuffer();

    String typeString = null;
    String specialCheck = "";
    String input = "input";
    if (type == TEXT_TYPE) {
      typeString = "text";
    } else if (type == PASSWORD_TYPE) {
      typeString = "password";
    } else if (type == TEXTAREA_TYPE) {
      input = "textarea rows=\"3\"";
    } else if (type == HIDDEN_TYPE) {
      typeString = "hidden";
    } else if (type == CHECKBOX_TYPE) {
      typeString = "checkbox";

      if (("" + getRequest(session, request, name, defValue, object)).equals("true"))
        specialCheck = " checked ";
    }
    else if (type == RADIO_TYPE) {
      typeString = "radio";

      if (("" + getRequest(session, request, name, defValue, object)).equals("true"))
        specialCheck = " checked ";
    }
    else {
      logger.error("Type not valid " + type);
    }

    sb.append("<" + input + " class=\"formFont " + (readOnly ? "readonly" : "") + " \"");
    if (typeString != null) {
      sb.append(" type=\"").append(typeString).append("\"");
    }
    sb.append(" size=\"").append(size).append("\" name=\"").append(name).append("\" id=\"").append(name).append("\" ");

    if (type != TEXTAREA_TYPE) {
      sb.append(" value=\"").append(escapeHTML(getRequest(session, request, name, defValue, object)) + "\"");
    }

    if (onclick != null) {
      sb.append(" onclick=\"" + onclick + "\" ");
    }

    if (onKeyPress != null) {
      if (type == TEXTAREA_TYPE)
        sb.append(" onChange=\"" + onKeyPress + "\" ");
      else {
        sb.append(" onKeyPress=\"javascript:" + onKeyPress + "\" ");
      }
    }

    if (readOnly) {
      sb.append(" readonly=\"readonly\" ");
    }
    sb.append(specialCheck);
    sb.append("/>");

    if (type == TEXTAREA_TYPE) {
      sb.append(getRequest(session, request, name, defValue, object));
      sb.append("</textarea>");
    }

    return sb.toString();
  }

  public static String getSelect(HttpServletRequest request, String name, List rows, String defaultActual, String onchange, boolean emptyDefault)
  {
    return getSelect(request, name, ArrayTools.getColumn(rows, 0), ArrayTools.getColumn(rows, 1), defaultActual, onchange, emptyDefault);
  }

  public static String getMultiSelect(HttpServletRequest request, String name, List rows, String defaultActual, String onchange, boolean emptyDefault)
  {
    return getSelect(request, name, ArrayTools.getColumn(rows, 0), ArrayTools.getColumn(rows, 1), defaultActual, onchange, emptyDefault, true);
  }

  public static String getSelect(HttpServletRequest request, String name, List actualValues, List displayValues, String defaultActual, String onchange, boolean emptyDefault)
  {
    return getSelect(request, name, actualValues, displayValues, defaultActual, onchange, emptyDefault, false);
  }

  public static String getMultiSelect(HttpServletRequest request, String name, List actualValues, List displayValues, List defaultActuals, String onchange, boolean emptyDefault)
  {
    return getSelect(request, name, actualValues, displayValues, defaultActuals, onchange, emptyDefault, true, null);
  }

  public static String getMultiSelect(HttpServletRequest request, String name, List actualValues, List displayValues, String defaultActual, String onchange, boolean emptyDefault)
  {
    return getSelect(request, name, actualValues, displayValues, defaultActual, onchange, emptyDefault, true);
  }

  public static String getMultiSelect(HttpServletRequest request, String name, List actualValues, List displayValues, String defaultActual, String onchange, boolean emptyDefault, Common object)
  {
    return getSelect(request, name, actualValues, displayValues, defaultActual, onchange, emptyDefault, true, object);
  }

  public static String getSelect(HttpServletRequest request, String name, List actualValues, List displayValues, String defaultActual, String onchange, boolean emptyDefault, boolean multiple)
  {
    return getSelect(request, name, actualValues, displayValues, defaultActual, onchange, emptyDefault, multiple, null);
  }

  public static String getSelect(HttpServletRequest request, String name, List actualValues, List displayValues, String defaultActual, String onchange, boolean emptyDefault, boolean multiple, Common object)
  {
    List defaultActuals = null;
    if (defaultActual != null) {
      defaultActuals = new ArrayList();
      defaultActuals.add(defaultActual);
    }
    return getSelect(request, name, actualValues, displayValues, defaultActuals, onchange, emptyDefault, multiple, object);
  }

  public static String getSelect(HttpServletRequest request, String name, List actualValues, List displayValues, String defaultActual, String onchange, boolean emptyDefault, boolean multiple, Common object, boolean readOnly)
  {
    List defaultActuals = null;
    if (defaultActual != null) {
      defaultActuals = new ArrayList();
      defaultActuals.add(defaultActual);
    }
    return getSelect(request, name, actualValues, displayValues, defaultActuals, onchange, emptyDefault, multiple, object, readOnly);
  }

  public static String getSelect(HttpServletRequest request, String name, List actualValues, List displayValues, List defaultActuals, String onchange, boolean emptyDefault, boolean multiple, Common object)
  {
    return getSelect(request, name, actualValues, displayValues, defaultActuals, onchange, emptyDefault, multiple, object, false);
  }

  public static String getSelect(HttpServletRequest request, String name, List actualValues, List displayValues, List defaultActuals, String onchange, boolean emptyDefault, boolean multiple, Common object, boolean readOnly)
  {
    return getSelect(request, name, actualValues, displayValues, defaultActuals, onchange, emptyDefault, multiple, object, readOnly, false, null);
  }

  public static String getSelect(HttpServletRequest request, String name, List actualValues, List displayValues, List defaultActuals, String onchange, boolean emptyDefault, boolean multiple, Common object, boolean readOnly, boolean showSearch, Integer fixedWidth)
  {
    return getSelect(null, request, name, actualValues, displayValues, defaultActuals, onchange, emptyDefault, multiple, object, readOnly, showSearch, fixedWidth);
  }

  public static String getSelect(HttpSession session, HttpServletRequest request, String name, List actualValues, List displayValues, List defaultActuals, String onchange, boolean emptyDefault, boolean multiple, Common object, boolean readOnly, boolean showSearch, Integer fixedWidth)
  {
    StringBuffer sb = new StringBuffer();
    StringBuffer readOnlyString = new StringBuffer();

    String multipleStr = "";
    if (multiple) {
      multipleStr = "multiple=\"multiple\"";
    }

    String id = "" + (int)(Math.random() * 100000.0D);
    if (showSearch)
    {
      sb.append("<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\n\t<tbody>\n\t<tr>\n\t\t<td colspan=\"2\">");
    }

    sb.append("<select " + (multiple ? "size=\"5\"" : "") + (readOnly ? " disabled=\"true\" " : "") + " class=\"formFont" + (multiple ? " formMulti" : "") + "\" name=\"").append(name).append("\" ").append(" id=\"").append(name).append("\" onclick=\"try{holdTimer();}catch(exception){}\"  onchange=\"" + onchange + "\" " + multipleStr + (fixedWidth != null ? " style=\"width:" + fixedWidth + "px\"" : "") + ">");

    if ((actualValues == null) || (displayValues == null) || (actualValues.size() != displayValues.size()))
    {
      throw new RuntimeException("Problems with actual/display values size or null! " + actualValues + "," + displayValues);
    }

    List selectedValues = getRequestParameters(session, request, name, defaultActuals, object);

    int size = actualValues.size();

    String selected1 = "";
    if ((defaultActuals != null) && (defaultActuals.size() > 0) && (defaultActuals.get(0).equals("...")))
    {
      selected1 = " selected=\"selected\" ";
    }
    if (emptyDefault) {
      sb.append("<option value=\"...\"" + selected1 + ">...</option>");
    }

    boolean allowSelectOption = true;

    for (int i = 0; i < size; i++) {
      Object actualObject = actualValues.get(i);
      Object displayObject = displayValues.get(i);

      String actual = null;
      String display = null;

      if ((actualObject instanceof Displayable))
        actual = ((Displayable)actualObject).getActualValue();
      else {
        actual = String.valueOf(actualObject);
      }

      String displayClass = null;
      if ((displayObject instanceof Displayable)) {
        display = ((Displayable)displayObject).getDisplayValue();
        displayClass = ((Displayable)displayObject).getStyleClass();
      } else {
        display = String.valueOf(displayObject);
      }

      String selected = "";
      for (int u = 0; u < selectedValues.size(); u++)
      {
        String displayRep = null;

        Object selsel = selectedValues.get(u);
        if (selsel != null) {
          if ((selsel instanceof Displayable)) {
            displayRep = ((Displayable)selsel).getActualValue();
          }
          else {
            displayRep = String.valueOf(selsel);
          }

        }

        if ((displayRep != null) && (displayRep.equals(actual.toString()))) {
          if (allowSelectOption) {
            selected = " selected=\"selected\" ";
            if (multiple) continue; allowSelectOption = false;
          }
          else {
            removeOptionFromSession(session, name, displayRep);
          }
        }
      }
      sb.append("<option value=\"" + actual + "\"" + selected + (displayClass != null ? "class=\"" + displayClass + "\"" : "") + ">" + escapeHTML(display) + "</option>");

      if ((readOnly) && (selected.length() > 0)) {
        readOnlyString.append("<input type=\"hidden\" name=\"" + name + "\" value=\"" + actual + "\"></input>");
      }

    }

    sb.append("</select>");
    if (showSearch) {
      sb.append("\n</td></tr>\t<tr><td width=\"21\"><img src=\"images/search_icon.png\" style=\"margin-bottom:1px\" width=\"20px\"/></td>\n\t\t<td>\n\t\t\t<input id=\"rt" + id + "\" type=\"text\" onkeyup=\"showAdditional('" + name + "','rt" + id + "');\" onfocus=\"setSearchInfo('rt" + id + "');\" onblur=\"setSearchInfo('rt" + id + "');\" class=\"searchBox\" value=\"Search...\" " + (fixedWidth != null ? " style=\"width:" + (fixedWidth.intValue() - 22) + "px\"" : "") + "/>\n" + "\t\t</td>\n" + "\t</tr></tbody></table>");
    }

    if (readOnly) {
      sb.append(readOnlyString);
    }

    return sb.toString();
  }

  public static boolean getBoolean(HttpSession session, String value, boolean defaultValue)
  {
    try {
      Object obj = session.getAttribute(value);
      String temp = null;
      if ((obj instanceof String)) {
        temp = (String)obj;
      } else if ((obj instanceof String[])) {
        String[] tt = (String[])(String[])obj;
        if (tt.length > 0) {
          if (tt.length == 1)
            temp = tt[0];
          else
            throw new Exception("unsupported choice for String[] " + ArrayTools.arrayToStringVisual(tt));
        }
        else {
          throw new Exception("unsupported choice for String[] was empty for value " + value);
        }
      }
      if ((temp != null) && (temp.equalsIgnoreCase("true"))) {
        return true;
      }
      if ((temp != null) && (temp.equalsIgnoreCase("false"))) {
        return false;
      }
      return defaultValue;
    } catch (Throwable thr) {
      logger.error("Unexpected...", thr);
    }return defaultValue;
  }

  public static Integer getInteger(HttpSession session, HttpServletRequest request, String fieldName, Integer defaultValue)
  {
    try
    {
      String temp = getRequest(session, request, fieldName, null, (Common)null);

      if (Tools.isNotEmptyNullOrNullString(temp)) {
        if (temp.equals("...")) return defaultValue;
        return Integer.valueOf(Integer.parseInt(temp));
      }
    } catch (Throwable thr) {
      logger.error("Unexpected...", thr);
    }

    return defaultValue;
  }

  public static Float getFloat(HttpServletRequest request, String value, Float defaultValue)
  {
    try
    {
      String temp = request.getParameter(value);
      if (Tools.isNotEmptyNullOrNullString(temp))
        return Float.valueOf(Float.parseFloat(temp));
    }
    catch (Throwable thr) {
      logger.error("Unexpected...", thr);
    }

    return defaultValue;
  }

  public static boolean getBoolean(HttpServletRequest request, String value, boolean defaultValue)
  {
    try
    {
      String temp = request.getParameter(value);
      if ((temp != null) && (temp.equalsIgnoreCase("true"))) {
        return true;
      }
      if ((temp != null) && (temp.equalsIgnoreCase("false"))) {
        return false;
      }
      return defaultValue;
    } catch (Throwable thr) {
      logger.error("Unexpected...", thr);
    }return defaultValue;
  }

  public static boolean getBoolean(HttpServletRequest request, String value)
  {
    try
    {
      String temp = request.getParameter(value);

      return (temp != null) && (temp.equalsIgnoreCase("true"));
    }
    catch (Throwable thr)
    {
      logger.error("Unexpected...", thr);
    }return false;
  }

  public static String getClassIfParameter(HttpServletRequest request, String className, String key, String value)
  {
    try
    {
      String temp = request.getParameter(key);
      if ((temp != null) && (temp.equals(value))) {
        return " class=\"" + className + "\" ";
      }
      return " ";
    } catch (Throwable thr) {
      logger.error("Unexpected...", thr);
    }return " ";
  }

  public static String getURLSetParameter(HttpServletRequest request, String key, String value)
  {
    Enumeration enumeration = request.getParameterNames();
    String basic = request.getServletPath() + "?";

    boolean used = false;
    boolean useAnd = false;

    while (enumeration.hasMoreElements()) {
      String name = String.valueOf(enumeration.nextElement());
      String[] values = request.getParameterValues(name);
      for (int i = 0; i < values.length; i++)
      {
        String repValue = values[i];
        if ((key != null) && (key.equals(name))) {
          repValue = value;
          used = true;
        }
        if (useAnd)
          basic = basic + "&";
        basic = basic + name + "=" + repValue;
        useAnd = true;
      }
    }
    if (!used) {
      if (useAnd)
        basic = basic + "&";
      basic = basic + key + "=" + value;
    }

    return basic;
  }

  public static String getProgressBar(float percentage) {
    if (percentage < 0.0F) {
      return "<span class=\"\">(Not enough data)</span>";
    }
    StringBuffer sb = new StringBuffer(50);
    sb.append("<table class=\"statusGlobalTable\"><tr><td height=\"5\"><table class=\"statusTable\" cellspacing=\"0\" cellpadding=\"0\" width=\"60\" ><tr>");
    sb.append("<td height=\"5\" class=\"statusTableFull\" width=\"" + percentage * 60.0F + "\"></td>");

    sb.append("<td class=\"statusTableEmpty\" width=\"" + (1.0F - percentage) * 60.0F + "\"></td>");
    sb.append("</tr></table></td><td class=\"statusTableText\">" + Math.round(percentage * 100.0F) + "%</td></tr></table>");

    return sb.toString();
  }

  public static String getHiddenInfoFromObject(String listOfFields, Common object)
  {
    StringBuffer sb = new StringBuffer();
    StringTokenizer st = new StringTokenizer(listOfFields, ",");
    while (st.hasMoreElements()) {
      String key = (String)st.nextElement();
      String value = object.getStringWithoutException(key);
      sb.append("<input type=\"hidden\" name=\"" + key + "\" value=\"" + value + "\" />");
    }
    return sb.toString();
  }

  public static String getCurrentInformation(HttpServletRequest request) {
    StringBuffer sb = new StringBuffer();
    Enumeration enumeration = request.getParameterNames();

    while (enumeration.hasMoreElements()) {
      String name = String.valueOf(enumeration.nextElement());
      String[] values = request.getParameterValues(name);
      for (int i = 0; i < values.length; i++)
      {
        if ((!name.equals("current")) && (!name.equals("subcurrent")) && (!name.equals("cat")))
          continue;
        String repValue = values[i];
        sb.append("<input type=\"hidden\" name=\"" + name + "\" value=\"" + repValue + "\" />");
      }

    }

    return sb.toString();
  }

  public static void emptyDHTML(HttpSession session) {
    session.setAttribute("CURRENT_DHTML", null);
    session.setAttribute("CURRENT_DHTML_SCRIPT", null);
    session.setAttribute("CURRENT_END_SCRIPTS", null);
  }

  public static void storeEndScripts(HttpSession session, String script) {
    session.setAttribute("CURRENT_END_SCRIPTS", script);
  }

  public static void storeDHTML(HttpSession session, String listOfNames, String script) {
    session.setAttribute("CURRENT_DHTML", listOfNames);
    session.setAttribute("CURRENT_DHTML_SCRIPT", script);
  }

  public static void addDHTML(HttpSession session, String listOfNames, String script) {
    String existing_dhtml = "";
    String existing_dhtml_script = "";

    if (session.getAttribute("CURRENT_DHTML") != null) {
      existing_dhtml = (String)session.getAttribute("CURRENT_DHTML");
      existing_dhtml = existing_dhtml + ",";
    }
    if (session.getAttribute("CURRENT_DHTML_SCRIPT") != null) {
      existing_dhtml_script = (String)session.getAttribute("CURRENT_DHTML_SCRIPT");
    }
    session.setAttribute("CURRENT_DHTML", existing_dhtml + listOfNames);
    session.setAttribute("CURRENT_DHTML_SCRIPT", existing_dhtml_script + script);
  }

  public static String getDHTML(HttpSession session)
  {
    String result = "";
    String curr = (String)session.getAttribute("CURRENT_DHTML");
    if (curr != null) {
      String script = (String)session.getAttribute("CURRENT_DHTML_SCRIPT");
      result = result + "<script type=\"text/javascript\"><!--\nSET_DHTML(" + curr + ");\n" + (script != null ? script : "") + "\n" + "//--></script>";
    }

    curr = (String)session.getAttribute("CURRENT_END_SCRIPTS");
    if (curr != null) {
      result = result + "<script type=\"text/javascript\" src=\"" + curr + "\"></script>";
    }
    return result;
  }

  public static final String escapeJavascript(String text)
  {
    if (text == null)
      return null;
    StringBuffer sb = new StringBuffer();
    int n = text.length();
    for (int i = 0; i < n; i++) {
      char c = text.charAt(i);
      switch (c) {
      case '\'':
        sb.append("\\'");
        break;
      case '"':
        sb.append("\\\"");
        break;
      case '\r':
        sb.append("\\r");
        break;
      default:
        sb.append(c);
      }
    }

    return sb.toString();
  }

  public static final String escapeHTML(String s) {
    return escapeHTML(s, true);
  }

  public static final String escapeHTML(String s, boolean noBreakingSpaces) {
    if (s == null)
      return null;
    StringBuffer sb = new StringBuffer();
    int n = s.length();
    for (int i = 0; i < n; i++) {
      char c = s.charAt(i);
      switch (c) {
      case '<':
        sb.append("&lt;");
        break;
      case '>':
        sb.append("&gt;");
        break;
      case '&':
        sb.append("&amp;");
        break;
      case '"':
        sb.append("&quot;");
        break;
      case 'à':
        sb.append("&agrave;");
        break;
      case 'À':
        sb.append("&Agrave;");
        break;
      case 'â':
        sb.append("&acirc;");
        break;
      case 'Â':
        sb.append("&Acirc;");
        break;
      case 'ä':
        sb.append("&auml;");
        break;
      case 'Ä':
        sb.append("&Auml;");
        break;
      case 'å':
        sb.append("&aring;");
        break;
      case 'Å':
        sb.append("&Aring;");
        break;
      case 'æ':
        sb.append("&aelig;");
        break;
      case 'Æ':
        sb.append("&AElig;");
        break;
      case 'ç':
        sb.append("&ccedil;");
        break;
      case 'Ç':
        sb.append("&Ccedil;");
        break;
      case 'é':
        sb.append("&eacute;");
        break;
      case 'É':
        sb.append("&Eacute;");
        break;
      case 'è':
        sb.append("&egrave;");
        break;
      case 'È':
        sb.append("&Egrave;");
        break;
      case 'ê':
        sb.append("&ecirc;");
        break;
      case 'Ê':
        sb.append("&Ecirc;");
        break;
      case 'ë':
        sb.append("&euml;");
        break;
      case 'Ë':
        sb.append("&Euml;");
        break;
      case 'ï':
        sb.append("&iuml;");
        break;
      case 'Ï':
        sb.append("&Iuml;");
        break;
      case 'ô':
        sb.append("&ocirc;");
        break;
      case 'Ô':
        sb.append("&Ocirc;");
        break;
      case 'ö':
        sb.append("&ouml;");
        break;
      case 'Ö':
        sb.append("&Ouml;");
        break;
      case 'ø':
        sb.append("&oslash;");
        break;
      case 'Ø':
        sb.append("&Oslash;");
        break;
      case 'ß':
        sb.append("&szlig;");
        break;
      case 'ù':
        sb.append("&ugrave;");
        break;
      case 'Ù':
        sb.append("&Ugrave;");
        break;
      case 'û':
        sb.append("&ucirc;");
        break;
      case 'Û':
        sb.append("&Ucirc;");
        break;
      case 'ü':
        sb.append("&uuml;");
        break;
      case 'Ü':
        sb.append("&Uuml;");
        break;
      case '®':
        sb.append("&reg;");
        break;
      case '©':
        sb.append("&copy;");
        break;
      case '\'':
        sb.append("&#146;");
        break;
      case '?':
        sb.append("&#63;");
        break;
      case ' ':
        sb.append(noBreakingSpaces ? "&nbsp;" : " ");
        break;
      default:
        sb.append(c);
      }
    }

    return sb.toString();
  }

  public static String escapeSMS(String sms)
  {
    if (sms == null) {
      return null;
    }
    StringBuffer sb = new StringBuffer();
    int n = sms.length();
    for (int i = 0; i < n; i++) {
      char c = sms.charAt(i);
      switch (c) {
      case '°':
        sb.append(" deg. ");
        break;
      default:
        sb.append(c);
      }
    }

    String output = "";
    try
    {
      output = URLEncoder.encode(sb.toString(), "ISO-8859-1");
    } catch (Exception e) {
      logger.error("", e);
    }
    return output;
  }

  public static final String escapeXML(String s)
  {
    StringBuffer sb = new StringBuffer();
    int n = s.length();
    for (int i = 0; i < n; i++) {
      char c = s.charAt(i);
      switch (c) {
      case '<':
        sb.append("&lt;");
        break;
      case '>':
        sb.append("&gt;");
        break;
      case '&':
        sb.append("&amp;");
        break;
      case '"':
        sb.append("&quot;");
        break;
      case 'à':
        sb.append("&agrave;");
        break;
      case 'À':
        sb.append("&Agrave;");
        break;
      case 'â':
        sb.append("&acirc;");
        break;
      case 'Â':
        sb.append("&Acirc;");
        break;
      case 'ä':
        sb.append("&auml;");
        break;
      case 'Ä':
        sb.append("&Auml;");
        break;
      case 'å':
        sb.append("&aring;");
        break;
      case 'Å':
        sb.append("&Aring;");
        break;
      case 'æ':
        sb.append("&aelig;");
        break;
      case 'Æ':
        sb.append("&AElig;");
        break;
      case 'ç':
        sb.append("&ccedil;");
        break;
      case 'Ç':
        sb.append("&Ccedil;");
        break;
      case 'é':
        sb.append("&eacute;");
        break;
      case 'É':
        sb.append("&Eacute;");
        break;
      case 'è':
        sb.append("&egrave;");
        break;
      case 'È':
        sb.append("&Egrave;");
        break;
      case 'ê':
        sb.append("&ecirc;");
        break;
      case 'Ê':
        sb.append("&Ecirc;");
        break;
      case 'ë':
        sb.append("&euml;");
        break;
      case 'Ë':
        sb.append("&Euml;");
        break;
      case 'ï':
        sb.append("&iuml;");
        break;
      case 'Ï':
        sb.append("&Iuml;");
        break;
      case 'ô':
        sb.append("&ocirc;");
        break;
      case 'Ô':
        sb.append("&Ocirc;");
        break;
      case 'ö':
        sb.append("&ouml;");
        break;
      case 'Ö':
        sb.append("&Ouml;");
        break;
      case 'ø':
        sb.append("&oslash;");
        break;
      case 'Ø':
        sb.append("&Oslash;");
        break;
      case 'ß':
        sb.append("&szlig;");
        break;
      case 'ù':
        sb.append("&ugrave;");
        break;
      case 'Ù':
        sb.append("&Ugrave;");
        break;
      case 'û':
        sb.append("&ucirc;");
        break;
      case 'Û':
        sb.append("&Ucirc;");
        break;
      case 'ü':
        sb.append("&uuml;");
        break;
      case 'Ü':
        sb.append("&Uuml;");
        break;
      case '®':
        sb.append("&reg;");
        break;
      case '©':
        sb.append("&copy;");
        break;
      case '?':
        sb.append("&euro;");
        break;
      default:
        sb.append(c);
      }
    }

    return sb.toString();
  }

  public static String display(Displayable disp, String def) {
    String temp = def;
    if (disp != null) {
      temp = disp.getDisplayValue();
    }
    if (temp == null)
      temp = def;
    if (temp == null)
      temp = "";
    return temp;
  }

  public static String getWidth()
  {
    return "100%";
  }

  public static float angleFromValue(double value, double min, double max) {
    double range = max - min;
    double percentile = (value - min) / range;
    return (float)((165.0D + percentile * 210.0D) % 360.0D);
  }

  public static String toUpperCase(String str) {
    if (str == null)
      return null;
    return str.toUpperCase();
  }

  public static String getHighLight(HttpSession session, String key, String value) {
    String vv = (String)session.getAttribute(key);
    String HIGHLIGHTED = " highlighted ";
    String NOT_HIGHLIGHTED = "";
    if (vv == null) {
      if (value == null)
        return HIGHLIGHTED;
      if (value.equals(""))
        return HIGHLIGHTED;
      return NOT_HIGHLIGHTED;
    }
    if (vv.equals(value)) {
      return HIGHLIGHTED;
    }
    return NOT_HIGHLIGHTED;
  }

  public static String storeSession(String identifier, HttpSession session, HttpServletRequest request)
  {
    String pp = request.getParameter(identifier);
    if (pp != null)
      session.setAttribute(identifier, pp);
    else {
      pp = (String)session.getAttribute(identifier);
    }
    return pp;
  }

  public static String storeSession(String identifier, HttpSession session, HttpServletRequest request, String defaultValue)
  {
    String pp = request.getParameter(identifier);
    if (pp != null) {
      session.setAttribute(identifier, pp);
    } else {
      pp = (String)session.getAttribute(identifier);
      if (pp == null) {
        pp = defaultValue;
        session.setAttribute(identifier, pp);
      }
    }
    return pp;
  }

  public static boolean storeBooleanSession(String identifier, HttpSession session, HttpServletRequest request, boolean defaultValue)
  {
    String pp = request.getParameter(identifier);
    if (pp != null)
      session.setAttribute(identifier, pp);
    else {
      pp = (String)session.getAttribute(identifier);
    }
    if (pp == null)
    {
      return defaultValue;
    }
    return new Boolean(pp).booleanValue();
  }

  public static String formatDate(Date date)
  {
    if (formatter == null)
    {
      formatter = new SimpleDateFormat("EEE MMM dd HH:mm:ss yyyy", Locale.US);
      formatter.setTimeZone(TimeZone.getDefault());
    }
    String str = formatter.format(date);
    return str;
  }

  public static String formatInternationalDate(Date date) {
    if (international_formatter == null) {
      formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
      formatter.setTimeZone(TimeZone.getDefault());
    }

    String str = formatter.format(date);
    return str;
  }

  public static boolean isIE(HttpServletRequest request)
  {
    String ua = request.getHeader("User-Agent");

    boolean isMSIE = (ua != null) && (ua.indexOf("MSIE") != -1);
    return isMSIE;
  }

  public static long getDateDuration(String dateType)
  {
    if (dateType.equals("live"))
      return 900000L;
    if (dateType.equals("hour"))
      return 3600000L;
    if (dateType.equals("day"))
      return 86400000L;
    if (dateType.equals("week"))
      return 604800000L;
    if (dateType.equals("month"))
      return 2592000000L;
    if (dateType.equals("year")) {
      return 31536000000L;
    }
    logger.error("Unknown dateType " + dateType);
    return 0L;
  }

  public static String getRangeForDuration(long duration)
  {
    if (duration < 900000L)
      return "live";
    if (duration < 3600000L)
      return "hour";
    if (duration < 86400000L)
      return "day";
    if (duration < 604800000L)
      return "week";
    if (duration < 2592000000L)
      return "month";
    return "year";
  }

  public static int getMinutesOffsetWithServer(HttpSession session)
  {
    Integer offset = (Integer)session.getAttribute("PROPERTY_TIMEZONE_OFFEST");
    int server_offset = TimeZone.getDefault().getOffset(System.currentTimeMillis()) / 60 / 1000;
    return offset.intValue() - server_offset;
  }

  public static String getDisplayDate(long ts, HttpSession session)
  {
    int server_offset = TimeZone.getDefault().getOffset(ts);

    Integer offsetStr = null;

    if (session != null) {
      offsetStr = (Integer)session.getAttribute("PROPERTY_TIMEZONE_OFFEST");
    }

    if (offsetStr != null) {
      int offSet = offsetStr.intValue();
      long newTs = ts + offSet * 60 * 1000 - server_offset;
      return formatDate(new Date(newTs));
    }
    logger.error("Could not find timezone");

    return "Server time: " + formatDate(new Date(ts));
  }

  public static long getTimeZoneCorrected(long ts, HttpSession session)
  {
    int server_offset = TimeZone.getDefault().getOffset(ts);

    Integer offsetStr = null;

    if (session != null) {
      offsetStr = (Integer)session.getAttribute("PROPERTY_TIMEZONE_OFFEST");
    }

    if (offsetStr != null) {
      int offSet = offsetStr.intValue();
      long newTs = ts + offSet * 60 * 1000 - server_offset;
      return newTs;
    }

    return ts;
  }

  public static void main(String[] args)
  {
    System.out.println(getDateDuration("hour"));
    System.out.println(getDateAsnumberOfDays(213700000L));
    System.out.println("Escaped URL: " + escapeURL("é"));
  }

  public static boolean isPDA(HttpServletRequest request)
  {
    if (getBoolean(request, "pda", false))
      return true;
    if (getBoolean(request, "enhancedPDA", false))
      return true;
    String user_agent = request.getHeader("user-agent");
    logger.debug("user-agent " + user_agent);
    return (user_agent != null) && ((user_agent.contains("iPhone")) || (user_agent.contains("Palm")) || (user_agent.contains("Windows Mobile")) || (user_agent.contains("IEMobile")) || (user_agent.contains("Android")) || (user_agent.contains("Opera/9.5 (Windows NT 5.1")));
  }

  public static boolean isEnhancedPDA(HttpServletRequest request, HttpSession session)
  {
    boolean result = false;

    Boolean fromSession = (Boolean)session.getAttribute("enhancedPDA");
    if ((fromSession != null) && (fromSession.booleanValue()))
      return true;
    if (getBoolean(request, "enhancedPDA", false)) {
      result = true;
    } else {
      String user_agent = request.getHeader("user-agent");
      result = (user_agent != null) && ((user_agent.contains("Opera/9.5")) || (user_agent.contains("iPhone")));
    }

    if (result)
      session.setAttribute("enhancedPDA", Boolean.valueOf(true));
    return result;
  }

  public static boolean isBrowserSupported(HttpServletRequest request)
  {
    String user_agent = request.getHeader("user-agent");
    if (user_agent == null)
      return false;
    user_agent = user_agent.toLowerCase();
    return (user_agent != null) && ((user_agent.contains("firefox")) || (user_agent.contains("msie")));
  }

  public static String getHelp(String language_key)
  {
    return getRawHelp(Lang.getLang().getLang(language_key));
  }

  public static String getRawHelp(String text)
  {
    return getRawHelp(text, 150);
  }

  public static String getRawHelp(String text, int width)
  {
    return getRawHelp(text, width, null);
  }

  public static String getRawHelp(String text, int width, String includeHTML)
  {
    String id = "hlp_" + (int)(Math.random() * 100000.0D);
    return getRawHelp(text, width, includeHTML, id);
  }

  public static String getRawHelp(String text, int width, String includeHTML, String id)
  {
    StringBuffer temp = new StringBuffer();

    temp.append("<a href=\"javascript:void(0);\" onmouseover=\"Tip('" + escapeHTML(text, false) + "', BORDERCOLOR,'#eef1ff',WIDTH, " + width + ", ABOVE, true, OFFSETX, 1, FADEIN, 400, FADEOUT, 300, FIX, ['" + id + "', 0, 5]);\" onmouseout=\"UnTip();\" style=\"outline:none\">");

    if (includeHTML == null) {
      temp.append("<img id=\"" + id + "\" src=\"images/InlineHelpIcon.png\" alt=\"Online help\" border=\"0\" align=\"top\"/>");
    }
    else {
      temp.append(includeHTML);
    }
    temp.append("</a>");
    return temp.toString();
  }

  public static String getImageWithHelp(String imageSrc, String altText, String helpText, Integer imageWidth, Integer imageHeight)
  {
    StringBuffer temp = new StringBuffer();
    String id = "hlp_" + (int)(Math.random() * 100000.0D);
    temp.append("<img border=\"0\" src=\"" + imageSrc + "\" id=\"" + id + "\"");
    if (helpText != null) {
      temp.append(" onmouseover=\"Tip('" + helpText + "', BORDERCOLOR,'#eef1ff',ABOVE, true, OFFSETX, 1, FADEIN, 400, FADEOUT, 300, FIX, ['" + id + "', 0, 5]);\" onmouseout=\"UnTip();\"");
    }

    if (altText != null)
      temp.append(" alt=\"" + altText + "\"");
    if (imageWidth != null)
      temp.append(" width=\"" + imageWidth + "\"");
    if (imageHeight != null) {
      temp.append(" height=\"" + imageHeight + "\"");
    }
    temp.append(" />");
    return temp.toString();
  }

  public static String getSortImage(String direction, String current, String compare, boolean opposite)
  {
    if ((direction == null) || (current == null) || (compare == null) || (!compare.equals(current)))
    {
      return "";
    }
    if (direction.equals("desc")) {
      return "<img src=\"images/sort_" + (opposite ? "down" : "up") + ".gif\" border=\"0\" alt=\"sort descending\"/>";
    }

    return "<img src=\"images/sort_" + (opposite ? "up" : "down") + ".gif\" border=\"0\" alt=\"sort descending\"/>";
  }

  public static String getWarningBox(String warningText)
  {
    StringBuffer sb = new StringBuffer(warningText.length() + 100);
    sb.append("<div class=\"genericWarning\" >\n <table><tr><td width=\"30\" style=\"vertical-align:top\"><img src=\"images/alert.gif\" alt=\"warning\"/></td><td>");
    sb.append(warningText);
    sb.append("</td></tr></table></div>");
    return sb.toString();
  }

  public static void trackTask(HttpServletResponse response, long taskID)
    throws IOException
  {
    response.sendRedirect("main.jsp?targetPage=trackTask.jsp&taskID=" + taskID);
  }

  public static List getMonthsList() {
    return monthsList;
  }

  public static List getYearsList()
  {
    return yearsList;
  }

  public static String escapeURL(String aURLFragment)
  {
    String result = null;
    try {
      if (aURLFragment == null) return null;
      result = URLEncoder.encode(aURLFragment, "UTF-8");
    }
    catch (UnsupportedEncodingException ex) {
      throw new RuntimeException("UTF-8 not supported", ex);
    }
    return result;
  }

  public static String getImageTag(String sourcePath, String altText)
  {
    return getImageTag(sourcePath, altText, null, null);
  }

  public static String getImageTag(String sourcePath, String altText, Integer width, Integer height)
  {
    return "<img src=\"" + sourcePath + "\" alt=\"" + altText + "\"" + (width != null ? " width=\"" + width + "\"" : "") + (height != null ? " height=\"" + height + "\"" : "") + " />";
  }

  public static String getDisplayTable(String formName, boolean skipFormInformation, String jspPage, Web.DataProvider dataProvider, HttpServletRequest request, Integer maxWidth, int PAGE_SIZE, String noResultErrorMessage)
  {
    try
    {
      StringBuffer html = new StringBuffer(150);

      dataProvider.compute();
      String[] headers = dataProvider.getHeaders();

      if (!skipFormInformation) html.append("<form name=\"" + formName + "\" action=\"main.jsp\" method=\"post\">");
      html.append("<input type=\"hidden\" name=\"targetPage\" value=\"" + jspPage + "\"/>");
      html.append("<input type=\"hidden\" name=\"newStart\" value=\"0\"/>");
      html.append("<table class=\"gradient-style\" cellspacing=\"0px\" cellpadding=\"10px\" style=\"min-width:600px");
      if (maxWidth != null) {
        html.append(";max-width:" + maxWidth + "px");
      }
      html.append("\">");

      html.append("<thead><tr valign=\"top\">");

      int colspan = 0;
      int start = -1;

      start = getIntValue(request, "newStart", 0);
      if (start < 0) start = 0;

      for (String header : headers) {
        html.append("<th>").append(header).append("</th>");
        colspan++;
      }
      html.append("</tr></thead>");

      int totalCount = dataProvider.getTotalRowCount();

      int current_page_sub = -1;
      try {
        current_page_sub = getIntValue(request, "current_page", -1);
      }
      catch (NumberFormatException nfe)
      {
      }
      logger.debug("current_page_sub " + current_page_sub);

      int number_of_pages = totalCount / PAGE_SIZE + (totalCount % PAGE_SIZE != 0 ? 1 : 0);
      int current_page = start / PAGE_SIZE + 1;

      if (current_page_sub != -1) {
        if (current_page_sub < 1) current_page_sub = 1;
        if (current_page_sub > number_of_pages) current_page_sub = number_of_pages;
        current_page = current_page_sub;
        start = (current_page - 1) * PAGE_SIZE;
      }

      List rows = dataProvider.getRows(start, PAGE_SIZE);
      if (rows.size() == 0) throw new UserException(noResultErrorMessage);
      int rowCount = 0;
      for (String[] row : rows) {
        html.append("<tr class=\"tableCell" + rowCount % 2 + "\">");
        for (String cell : row) {
          html.append("<td>").append(cell).append("</td>");
        }
        html.append("</tr>");
        rowCount++;
      }

      html.append("<tfoot><tr class=\"tableHeader\"><td align=\"right\" colspan=\"" + colspan + "\">");
      if (start > 0)
        html.append("<a href=\"javascript:previousPageGeneric(document." + formName + "," + (start - PAGE_SIZE) + ");\"><img src=\"images/btn_page_left_off.gif\" alt=\"Previous\" border=\"0\"/></a>");
      else {
        html.append("<img src=\"images/btn_page_left_out.gif\" alt=\"Previous\" border=\"0\"/>");
      }
      html.append("&nbsp;");
      if (start + PAGE_SIZE < totalCount)
        html.append("<a href=\"javascript:nextPageGeneric(document." + formName + "," + (start + PAGE_SIZE) + ");\"><img src=\"images/btn_page_right_off.gif\" alt=\"Next\" border=\"0\"/></a>");
      else {
        html.append("<img src=\"images/btn_page_right_out.gif\" alt=\"Next\" border=\"0\"/>");
      }

      html.append("&nbsp; Page ");
      html.append("<input type=\"text\" name=\"current_page\" value=\"" + current_page + "\" class=\"formFont listView\" onkeypress=\"return submitForm(this,event,document." + formName + ");\" size=\"1\"/>");
      html.append(" of ");
      html.append(number_of_pages);
      html.append("</td></tr></tfoot>");

      html.append("</table>");

      if (!skipFormInformation) html.append("</form>");

      return html.toString();
    } catch (Exception e) {
      if ((e instanceof UserException)) {
        logger.debug("User exception " + e);
        return "<img src=\"images/error.gif\" alt=\"error\" style=\"vertical-align:middle\"/>" + e.getMessage();
      }
      logger.error("", e);
    }return "Error: " + e.getMessage();
  }
}