package com.aginova.util;

public abstract interface Listener
{
  public abstract void notifyChange();
}