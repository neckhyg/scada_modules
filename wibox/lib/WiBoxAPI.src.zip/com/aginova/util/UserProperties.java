package com.aginova.util;

import java.io.File;
import java.io.PrintStream;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;

public abstract class UserProperties
{
  private static final Logger logger = Logger.getLogger(UserProperties.class);

  public static String APPLICATION_NAME = "APPLICATION_NAME";
  static UserProperties userProps;
  static Map<String, Class> classCache;

  public static String getProperty(String key)
  {
    if (key.equals(APPLICATION_NAME)) {
      return "marine/";
    }

    return null;
  }

  public static String convertToApplicationSpecific(HttpSession session, String jspName) {
    URL resource = null;
    try
    {
      resource = session.getServletContext().getResource("/" + userProps.getInternalApplicationPath() + "/" + jspName);
    }
    catch (Exception e)
    {
      logger.error("Error while writing URL", e);
    }

    if (resource != null) {
      logger.debug("RETURNING " + userProps.getInternalApplicationPath() + "/" + jspName);
      return userProps.getInternalApplicationPath() + "/" + jspName;
    }

    String path = new File(jspName).getParent() + "/" + userProps.getInternalApplicationPath() + "/" + jspName;
    logger.debug("*PATH " + path);
    logger.debug("*PARENT " + new File(jspName).getParent());
    logger.debug("*Exists " + jspName + " : " + new File(jspName).exists());
    logger.debug("*Exists " + userProps.getInternalApplicationPath() + "/" + jspName + " : " + new File(new StringBuilder().append(userProps.getInternalApplicationPath()).append("/").append(jspName).toString()).exists());

    logger.debug(new File("test").getAbsolutePath());

    logger.debug("RETURNING " + jspName);
    return jspName;
  }

  public static String getApplicationExtension() {
    return DBConnectionProperties.getDBConnectionProperties().getProperty(DBConnectionProperties.INSTALL_APPLICATION);
  }

  public static Class getAppropriateClass(String completeName)
  {
    return getAppropriateClass(completeName, false);
  }

  public static Class getAppropriateClass(String completeName, boolean useImplementation)
  {
    String key = completeName + useImplementation;
    Class finalClass = (Class)classCache.get(key);
    if (finalClass != null) {
      logger.debug("Returning from cache " + finalClass.getName());
      return finalClass;
    }

    String useImplEndString = useImplementation ? "Impl" : "";
    try {
      String overwrittenClass = userProps.getInternalClassExtension();
      if (overwrittenClass != null) {
        int li = completeName.lastIndexOf(".");
        String endName = completeName.substring(li);
        try {
          String firstAttempt = overwrittenClass + endName + useImplEndString;
          logger.debug("firstAttempt " + firstAttempt);
          finalClass = Class.forName(firstAttempt);
        }
        catch (ClassNotFoundException cnfe) {
          try {
            String secondAttempt = overwrittenClass + endName;
            logger.debug("secondAttempt " + secondAttempt);
            finalClass = Class.forName(secondAttempt);
          }
          catch (ClassNotFoundException cnfe1) {
            try {
              logger.debug("Did not find " + overwrittenClass + endName + ", will use com.aginova.motes" + endName + " instead.");

              finalClass = Class.forName("com.aginova.motes" + endName);
            } catch (ClassNotFoundException cnfe2) {
              logger.debug("Did not find it, will use " + completeName + " instead.");
              finalClass = Class.forName(completeName);
            }
          }
        }
      }
      else
      {
        finalClass = Class.forName(completeName);
      }
    } catch (Exception e) {
      e.printStackTrace();
      System.out.println("TEST exception " + e.getMessage());
      logger.error("Error while finding appropriate class " + e);
    }

    classCache.put(key, finalClass);

    return finalClass;
  }

  public static Object initiateAppropriateClass(String completeName)
  {
    return initiateAppropriateClass(completeName, false);
  }

  public static Object initiateAppropriateClass(String completeName, boolean useImplementation) {
    try {
      logger.debug("initiateAppropriateClass completeName=" + completeName + ",useImplementation? " + useImplementation);
      Class cl = getAppropriateClass(completeName, useImplementation);
      Object obj = cl.newInstance();
      logger.debug("TEST returning object " + obj);
      return obj;
    } catch (Exception e) {
      if (e != null) e.printStackTrace();
      logger.error("Error while finding appropriate class ", e);

      logger.warn("Returning null");
    }return null;
  }
  public abstract String getInternalApplicationPath();

  public String getInternalClassExtension() {
    return null;
  }

  static
  {
    if (getApplicationExtension().equalsIgnoreCase(DBConnectionProperties.APPLICATION_MARINE))
      userProps = new UserPropertiesMarines();
    else if (getApplicationExtension().equalsIgnoreCase(DBConnectionProperties.APPLICATION_TEMPERATURE))
      userProps = new UserPropertiesTemperature();
    else if (getApplicationExtension().equalsIgnoreCase(DBConnectionProperties.APPLICATION_HOME))
      userProps = new UserPropertiesHome();
    else if (getApplicationExtension().equalsIgnoreCase(DBConnectionProperties.APPLICATION_HOSPITAL))
      userProps = new UserPropertiesHospital();
    else if (getApplicationExtension().equalsIgnoreCase(DBConnectionProperties.APPLICATION_OILGAS))
      userProps = new UserPropertiesOilGas();
    else if (getApplicationExtension().equalsIgnoreCase(DBConnectionProperties.APPLICATION_PIPELINE))
      userProps = new UserPropertiesPipelines();
    else if (getApplicationExtension().equalsIgnoreCase(DBConnectionProperties.APPLICATION_TESTING))
      userProps = new UserPropertiesTesting();
    else {
      throw new RuntimeException("NOT CONFIGURED FOR APPLICATION " + getApplicationExtension());
    }

    classCache = new HashMap();
  }

  public static final class UserPropertiesPipelines extends UserProperties
  {
    public String getInternalApplicationPath()
    {
      return "pipeline";
    }

    public String getInternalClassExtension() {
      return "com.aginova.app.pipeline";
    }
  }

  public static final class UserPropertiesOilGas extends UserProperties
  {
    public String getInternalApplicationPath()
    {
      return "oilgas";
    }

    public String getInternalClassExtension() {
      return "com.aginova.app.oilgas";
    }
  }

  public static final class UserPropertiesTemperature extends UserProperties
  {
    public String getInternalApplicationPath()
    {
      return "temperature";
    }

    public String getInternalClassExtension() {
      return "com.aginova.app.temperature";
    }
  }

  public static final class UserPropertiesTesting extends UserProperties
  {
    public String getInternalApplicationPath()
    {
      return "testing";
    }

    public String getInternalClassExtension() {
      return "com.aginova.testing";
    }
  }

  public static final class UserPropertiesHospital extends UserProperties
  {
    public String getInternalApplicationPath()
    {
      return "hospital";
    }

    public String getInternalClassExtension() {
      return "com.aginova.app.hospital";
    }
  }

  public static final class UserPropertiesHome extends UserProperties
  {
    public String getInternalApplicationPath()
    {
      return "home";
    }

    public String getInternalClassExtension() {
      return "com.aginova.app.home";
    }
  }

  public static final class UserPropertiesMarines extends UserProperties
  {
    public String getInternalApplicationPath()
    {
      return "marine";
    }

    public String getInternalClassExtension() {
      return "com.aginova.marine";
    }
  }
}