package com.aginova.util;

public class DisplayableImpl
  implements Displayable
{
  String actual;
  String display;

  public DisplayableImpl(String actual, String display)
  {
    this.actual = actual;
    this.display = display;
  }

  public String getDisplayValue() {
    return this.display;
  }

  public String getActualValue() {
    return this.actual;
  }

  public String toString() {
    return getDisplayValue();
  }

  public String getStyleClass()
  {
    return null;
  }
}