package com.aginova.util;

import com.aginova.engine.DatabaseLoader;
import java.io.PrintStream;
import java.math.BigInteger;
import java.net.InetAddress;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import org.apache.log4j.Logger;

public class ArrayTools
{
  private static final Logger logger = Logger.getLogger(ArrayTools.class);
  private static final String ALLHEX = "0123456789ABCDEF";
  private static byte[] correspondingNibble = new byte[103];

  public static String byteToHex(int data)
  {
    String dd = Integer.toHexString(data);
    if (dd.length() < 2)
      dd = "0" + dd;
    return dd;
  }

  public static String toString(byte[] bytes)
  {
    StringBuffer sb = new StringBuffer(bytes.length);
    sb.append("[");
    for (int i = 0; i < bytes.length; i++) {
      if (i != 0)
        sb.append(",");
      sb.append(bytes[i]);
    }
    sb.append("]");
    return sb.toString();
  }

  public static String toHexStringSpace(byte[] bytes, int length)
  {
    StringBuffer sb = new StringBuffer(length);
    sb.append("[");
    for (int i = 0; i < length; i++) {
      if (i != 0)
        sb.append(" ");
      sb.append(byteToHex(bytes[i] & 0xFF));
    }
    sb.append("]");
    return sb.toString();
  }

  public static String toSignedShortStringSpace(byte[] bytes)
  {
    StringBuffer sb = new StringBuffer(bytes.length);
    sb.append("[");
    for (int i = 0; i < bytes.length; i += 2) {
      if (i != 0) {
        sb.append(",");
      }

      sb.append("" + readSigned16Bits(bytes, i));
    }
    sb.append("]");
    return sb.toString();
  }

  public static String toHexStringSpace(byte[] bytes)
  {
    return toHexStringSpace(bytes, bytes.length);
  }

  public static String toHexString(byte[] bytes)
  {
    StringBuffer sb = new StringBuffer(bytes.length);
    sb.append("[");
    for (int i = 0; i < bytes.length; i++) {
      if (i != 0)
        sb.append(",");
      sb.append(byteToHex(bytes[i] & 0xFF));
    }
    sb.append("]");
    return sb.toString();
  }

  public static byte[] toByteArray(String s)
  {
    s = s.toUpperCase();
    byte[] temp = new byte[s.length()];
    for (int i = 0; i < s.length(); i++) {
      temp[i] = (byte)"0123456789ABCDEF".indexOf(s.charAt(i));
    }
    return temp;
  }

  public static boolean isInArrayWithStar(String[] vals, String val) {
    for (int i = 0; i < vals.length; i++) {
      String tt = vals[i];
      if (tt.equals("*")) {
        return true;
      }
      if (vals[i].equals(val)) {
        return true;
      }
    }
    return false;
  }

  public static int[] stringArrayToIntArray(String[] vals)
  {
    if (vals == null) return null;
    int[] result = new int[vals.length];
    int counter = 0;
    for (String val : vals) {
      result[counter] = Integer.parseInt(vals[counter]);
      counter++;
    }
    return result;
  }

  public static int[] listToIntArray(List list)
  {
    if (list == null)
      return null;
    int size = list.size();
    int[] res = new int[size];
    for (int i = 0; i < size; i++) {
      Object obj = list.get(i);
      if ((obj instanceof Integer)) {
        res[i] = ((Integer)obj).intValue();
      }
      else {
        res[i] = Integer.parseInt((String)obj);
      }
    }

    return res;
  }

  public static List subList(List input, int maxElements)
  {
    if (maxElements < 0) throw new RuntimeException("Max elements must be greater than zero! Was: " + maxElements);
    if (input.size() > maxElements) {
      return input.subList(0, maxElements);
    }
    return input;
  }

  public static String[] listToStringArray(List list)
  {
    if (list == null)
      return null;
    int size = list.size();
    String[] res = new String[size];
    for (int i = 0; i < size; i++) {
      res[i] = ((String)list.get(i));
    }

    return res;
  }

  public static boolean[] listToBooleanArray(List list)
  {
    if (list == null)
      return null;
    int size = list.size();
    boolean[] res = new boolean[size];
    for (int i = 0; i < size; i++) {
      res[i] = ((Boolean)list.get(i)).booleanValue();
    }

    return res;
  }

  public static List StringArrayToList(String[] sarray) {
    if (sarray == null)
      return null;
    int length = sarray.length;
    List list = new ArrayList();
    for (int i = 0; i < length; i++) {
      list.add(sarray[i]);
    }

    return list;
  }

  public static List getColumn(List rows, int column) {
    if (rows == null)
      return null;
    List result = new ArrayList();
    for (int i = 0; i < rows.size(); i++) {
      List row = (List)rows.get(i);
      result.add(row.get(column));
    }
    return result;
  }

  public static String arrayToStringVisual(Object[][] sarray) {
    return arrayToStringVisual(sarray, ",");
  }

  public static String arrayToStringVisual(Object[] sarray) {
    return arrayToStringVisual(sarray, ",");
  }

  public static String arrayToStringVisual(List sarray) {
    if (sarray == null) return null;
    return arrayToStringVisual(sarray.toArray(), ",");
  }

  public static String arrayToStringSpacedVisual(List sarray) {
    if (sarray == null) return null;
    return arrayToStringVisual(sarray.toArray(), ", ");
  }

  public static String arrayToStringVisual(Object[] sarray, String spacer) {
    if (sarray == null)
      return null;
    int length = sarray.length;
    StringBuffer sb = new StringBuffer();
    for (int i = 0; i < length; i++) {
      if (i != 0)
        sb.append(spacer);
      sb.append(sarray[i]);
    }

    return sb.toString();
  }

  public static String arrayToStringVisual(Object[][] sarray, String spacer) {
    if (sarray == null)
      return null;
    int length = sarray.length;
    StringBuffer sb = new StringBuffer();
    for (int i = 0; i < length; i++) {
      if (i != 0)
        sb.append(spacer);
      sb.append(arrayToStringVisual(sarray[i], spacer));
    }

    return sb.toString();
  }

  public static String objectToStringVisual(Object obj)
  {
    return objectToStringVisual(obj, ",");
  }

  public static String objectToStringVisual(Object obj, String spacer)
  {
    if ((obj instanceof Object[])) {
      Object[] list = (Object[])(Object[])obj;
      StringBuffer res = new StringBuffer();
      res.append("[");
      for (int i = 0; i < list.length; i++) {
        Object oo = list[i];
        if (res.length() != 1) res.append(spacer);
        res.append(objectToStringVisual(oo, spacer));
      }
      res.append("]");
      return res.toString();
    }if ((obj instanceof int[])) {
      int[] list = (int[])(int[])obj;
      StringBuffer res = new StringBuffer();
      res.append("[");
      for (int i = 0; i < list.length; i++) {
        Object oo = Integer.valueOf(list[i]);
        if (res.length() != 1) res.append(spacer);
        res.append(objectToStringVisual(oo, spacer));
      }
      res.append("]");
      return res.toString();
    }if ((obj instanceof Map)) {
      StringBuffer res = new StringBuffer();
      res.append("[");
      Map map = (Map)obj;
      Set keys = map.keySet();
      Iterator it = keys.iterator();
      while (it.hasNext()) {
        Object key = it.next();
        Object value = map.get(key);
        if (res.length() != 1) res.append(spacer);
        res.append(objectToStringVisual(key, spacer) + ":" + objectToStringVisual(value, spacer));
      }
      res.append("]");
      return res.toString();
    }if ((obj instanceof Set)) {
      Set set = (Set)obj;
      StringBuffer res = new StringBuffer();
      res.append("[");
      Iterator it = set.iterator();
      while (it.hasNext()) {
        Object oo = it.next();
        if (res.length() != 1) res.append(spacer);
        res.append(objectToStringVisual(oo, spacer));
      }
      res.append("]");
      return res.toString();
    }if ((obj instanceof List)) {
      List list = (List)obj;
      StringBuffer res = new StringBuffer();
      res.append("[");
      for (int i = 0; i < list.size(); i++) {
        Object oo = list.get(i);
        if (res.length() != 1) res.append(spacer);
        res.append(objectToStringVisual(oo, spacer));
      }
      res.append("]");
      return res.toString();
    }if ((obj instanceof Displayable)) {
      return ((Displayable)obj).getDisplayValue();
    }
    return "" + obj;
  }

  public static String arrayToStringVisual(int[] sarray)
  {
    if (sarray == null)
      return null;
    int length = sarray.length;
    StringBuffer sb = new StringBuffer();
    for (int i = 0; i < length; i++) {
      if (i != 0)
        sb.append(",");
      sb.append("" + sarray[i]);
    }

    return sb.toString();
  }

  public static List tokenizeCVS(String temp) {
    List list = new ArrayList();

    boolean ignoreMode = false;
    StringBuffer buffer = new StringBuffer(50);
    for (int i = 0; i < temp.length(); i++) {
      char c = temp.charAt(i);
      switch (c) {
      case ';':
        if (!ignoreMode)
        {
          list.add(buffer.toString());
          buffer.setLength(0);
        }
        else {
          buffer.append(c);
        }
        break;
      case '"':
        if ((temp.length() < i + 1) && (temp.charAt(i + 1) == '"'))
        {
          buffer.append('"');
          i++;
        } else {
          ignoreMode = !ignoreMode;
        }
        break;
      default:
        buffer.append(c);
      }
    }

    list.add(buffer.toString());

    return list;
  }

  public static byte[] appendBytes(byte[] d1, byte[] d2) {
    byte[] result = new byte[d1.length + d2.length];
    System.arraycopy(d1, 0, result, 0, d1.length);
    System.arraycopy(d2, 0, result, d1.length, d2.length);
    return result;
  }

  public static byte[] appendBytes(byte[] d1, byte[] d2, byte[] d3) {
    byte[] result = new byte[d1.length + d2.length + d3.length];
    System.arraycopy(d1, 0, result, 0, d1.length);
    System.arraycopy(d2, 0, result, d1.length, d2.length);
    System.arraycopy(d3, 0, result, d1.length + d2.length, d3.length);
    return result;
  }

  public static byte[] fromHexString(String s)
  {
    int stringLength = s.length();
    if ((stringLength & 0x1) != 0)
    {
      throw new IllegalArgumentException("fromHexString requires an even number of hex characters");
    }byte[] b = new byte[stringLength / 2];

    int i = 0; for (int j = 0; i < stringLength; j++)
    {
      int high = charToNibble(s.charAt(i));
      int low = charToNibble(s.charAt(i + 1));
      b[j] = (byte)(high << 4 | low);

      i += 2;
    }

    return b;
  }

  private static int charToNibble(char c)
  {
    int nibble = correspondingNibble[c];
    if (nibble < 0)
    {
      throw new IllegalArgumentException("Invalid hex character: " + c);
    }
    return nibble;
  }

  public static Integer hex32BitsToSignedInteger(String hex)
  {
    if (hex == null) return null;
    BigInteger big = new BigInteger(hex, 16);
    return Integer.valueOf((int)big.longValue());
  }

  public static void main(String[] args)
    throws Exception
  {
    byte[] b1 = { 90, 45, 90, 45 };

    DatabaseLoader.quickConfigure();

    System.out.println("TEST0 " + Integer.toHexString(-1));
    System.out.println("TESTA " + (int)Long.parseLong(Integer.toHexString(-1), 16));
    System.out.println("TEST1 " + Integer.parseInt("e395", 16));
    System.out.println("TEST1 " + convertHexStringToDouble("ffffe395"));

    System.out.println("TEST " + objectToStringVisual(new Object[] { "1", "2" }, ","));

    System.out.println("convertHexToSignedShort " + convertHexToSignedShort("bfc5"));
    System.out.println("convertHexToSignedShort " + convertHexToSignedShort("4533"));

    System.out.println("hex " + hex32BitsToSignedInteger("fffffffe"));
    System.out.println(hexToUInt32("d5:18:00:00:66:28:2d:06:64:00:00:00:64:00:00:00:00:00:00:00:00:58:00:00:00:00:00:01:00", 0));
    System.out.println(hexToUInt16("00:01", 0));
    System.out.println(toSignedShortStringSpace(b1));

    System.out.println(readSigned16Bits(b1, 0));
    long i = Long.valueOf("ffffffff", 16).longValue();
    System.out.println("i " + i);
  }

  public static void write32Bits(byte[] data, int pos, int value)
  {
    data[pos] = (byte)(value >> 24);
    data[(pos + 1)] = (byte)(value >> 16);
    data[(pos + 2)] = (byte)(value >> 8);
    data[(pos + 3)] = (byte)(value >> 0);
  }

  public static void write32BitsLSB(byte[] data, int pos, int value) {
    data[(pos + 3)] = (byte)(value >> 24);
    data[(pos + 2)] = (byte)(value >> 16);
    data[(pos + 1)] = (byte)(value >> 8);
    data[pos] = (byte)(value >> 0);
  }

  public static void write16Bits(byte[] data, int pos, int value) {
    data[pos] = (byte)(value >> 8);
    data[(pos + 1)] = (byte)(value >> 0);
  }

  public static void write16BitsLSB(byte[] data, int pos, int value) {
    data[(pos + 1)] = (byte)(value >> 8);
    data[pos] = (byte)(value >> 0);
  }

  public static void write8Bits(byte[] data, int pos, int value) {
    data[pos] = (byte)(value >> 0);
  }

  public static int read32Bits(byte[] data, int pos)
  {
    return ((data[pos] & 0xFF) << 24) + ((data[(pos + 1)] & 0xFF) << 16) + ((data[(pos + 2)] & 0xFF) << 8) + ((data[(pos + 3)] & 0xFF) << 0);
  }

  public static int read32BitsLSB(byte[] data, int pos)
  {
    return ((data[pos] & 0xFF) << 0) + ((data[(pos + 1)] & 0xFF) << 8) + ((data[(pos + 2)] & 0xFF) << 16) + ((data[(pos + 3)] & 0xFF) << 24);
  }

  public static int read16Bits(byte[] data, int pos)
  {
    return ((data[pos] & 0xFF) << 8) + ((data[(pos + 1)] & 0xFF) << 0);
  }

  public static int read16BitsLSB(byte[] data, int pos)
  {
    return ((data[(pos + 1)] & 0xFF) << 8) + ((data[pos] & 0xFF) << 0);
  }

  public static Integer read16BitsLSB(String data)
  {
    if (data == null) return null;
    if (data.length() != 4) throw new RuntimeException("Not the right length ! Was " + data.length());
    return Integer.valueOf((Integer.parseInt(data.substring(2, 4), 16) << 8) + (Integer.parseInt(data.substring(0, 2), 16) << 0));
  }

  public static Integer read16Bits(String data)
  {
    if (data == null) return null;
    if (data.length() != 4) throw new RuntimeException("Not the right length ! Was " + data.length());
    return Integer.valueOf(Integer.parseInt(data.substring(0, 4), 16));
  }

  public static int readSigned16Bits(byte[] data, int pos)
  {
    return (data[pos] << 8) + ((data[(pos + 1)] & 0xFF) << 0);
  }

  public static int read8Bits(byte[] data, int pos)
  {
    return (data[pos] & 0xFF) << 0;
  }

  public static String[] intToStringArray(int[] input)
  {
    String[] res = new String[input.length];
    for (int i = 0; i < input.length; i++) {
      res[i] = ("" + input[i]);
    }
    return res;
  }

  public static String truncateMessage(String in, int length)
  {
    if (in == null) return "";
    return in.substring(0, Math.min(in.length(), length));
  }

  public static String truncateDisplay(String in, int length)
  {
    if (in == null) return null;
    if (in.length() < length) return in;
    return in.substring(0, Math.max(1, length - 3)) + "...";
  }

  public static String[] comaStringToStringArray(String val)
  {
    if (val == null) return null;
    List res = new ArrayList();
    StringTokenizer st = new StringTokenizer(val, ",");
    while (st.hasMoreTokens()) {
      res.add(st.nextToken());
    }
    return listToStringArray(res);
  }

  public static int[] tokensToIntArray(String tokens)
  {
    StringTokenizer st = new StringTokenizer(tokens, ",");
    List data = new ArrayList();
    while (st.hasMoreTokens()) {
      String str = st.nextToken();
      data.add(Integer.valueOf(Integer.parseInt(str)));
    }
    return listToIntArray(data);
  }

  public static String byteArrayToHexString(ByteBuffer b)
  {
    byte[] arr = b.array();
    return byteArrayToHexString(arr, 0, arr.length, " ");
  }

  public static String byteArrayToHexString(byte[] b, int length)
  {
    return byteArrayToHexString(b, 0, length, " ");
  }

  public static String byteArrayToHexString(byte[] b, int start, int length, String separator)
  {
    StringBuffer sb = new StringBuffer(b.length * 2);
    for (int i = start; i < start + length; i++)
    {
      int v = b[i] & 0xFF;
      if (v < 16)
      {
        sb.append('0');
      }
      sb.append(Integer.toHexString(v));
      sb.append(separator);
    }
    return sb.toString().toUpperCase();
  }

  public static String hexToString(String hexValue)
  {
    if (hexValue == null) return null;
    StringBuffer sb = new StringBuffer(hexValue.length() / 2);
    StringTokenizer st = new StringTokenizer(hexValue, ":");
    while (st.hasMoreTokens()) {
      String temp = st.nextToken();
      if (temp.equals("00")) break;
      sb.append(new Character((char)Integer.parseInt(temp, 16)));
    }
    return sb.toString();
  }

  public static void checkHex(String hexString)
    throws Exception
  {
    for (int i = 0; i < hexString.length(); i++) {
      String s = ("" + hexString.charAt(i)).toUpperCase();

      if (((i - 2) % 3 == 0) && (i != 0)) {
        if (s.equals(":")) continue; throw new Exception("Expecting ':' at position " + i + " of " + hexString);
      }

      if ("0123456789ABCDEF".indexOf(s) != -1) continue; throw new Exception("Invalid character at position " + i + ", was expecting one of '" + "0123456789ABCDEF" + "'");
    }
  }

  public static String stringToHex(String stringValue, int length)
  {
    if (stringValue == null) return null;
    StringBuffer sb = new StringBuffer(stringValue.length() * 3);
    for (int i = 0; (i < stringValue.length()) && (i < length); i++) {
      if (i != 0) sb.append(":");
      sb.append(byteToHex(stringValue.charAt(i)));
    }
    String res = pad(sb.toString(), length);
    return res;
  }

  public static String uint32ToHex(int value)
  {
    return byteToHex(value & 0xFF) + ":" + byteToHex(value >> 8 & 0xFF) + ":" + byteToHex(value >> 16 & 0xFF) + ":" + byteToHex(value >> 24 & 0xFF);
  }

  public static String uint16ToHex(int value)
  {
    return byteToHex(value & 0xFF) + ":" + byteToHex(value >> 8 & 0xFF);
  }

  public static int hexToUInt16(String hexString, int position)
  {
    String sub = hexString.substring(position * 3, position * 3 + 6 - 1);
    return Integer.parseInt(sub.substring(0, 2), 16) + 256 * Integer.parseInt(sub.substring(3, 5), 16);
  }

  public static int hexToUInt32(String hexString, int position)
  {
    String sub = hexString.substring(position * 3, position * 3 + 12 - 1);

    int tot = Integer.parseInt(sub.substring(0, 2), 16) + 256 * Integer.parseInt(sub.substring(3, 5), 16) + 65536 * Integer.parseInt(sub.substring(6, 8), 16) + 16777216 * Integer.parseInt(sub.substring(9, 11), 16);

    return tot;
  }

  public static Float convertHexToFloat(String hexString)
  {
    int bits = (int)Long.parseLong(hexString, 16);
    Float testSample = Float.valueOf(Float.intBitsToFloat(bits));
    return Float.valueOf(testSample.floatValue());
  }

  public static Short convertHexToSignedShort(String hexString)
  {
    if (hexString == null) return null;
    int ch1 = Integer.parseInt(hexString.substring(0, 2), 16);
    int ch2 = Integer.parseInt(hexString.substring(2, 4), 16);
    return Short.valueOf((short)((ch1 << 8) + (ch2 << 0)));
  }

  public static String uint8ToHex(int value)
  {
    return byteToHex(value & 0xFF);
  }

  public static String pad(String hexString, int totalLength)
  {
    while (hexString.length() < totalLength * 3 - 1) {
      hexString = hexString + ":00";
    }
    return hexString;
  }

  public static String IPToHex(String ipAddress)
    throws Exception
  {
    byte[] dd = InetAddress.getByName(ipAddress).getAddress();
    return byteToHex(dd[0] & 0xFF) + ":" + byteToHex(dd[1] & 0xFF) + ":" + byteToHex(dd[2] & 0xFF) + ":" + byteToHex(dd[3] & 0xFF);
  }

  public static String toASCII(byte[] data)
  {
    return new String(data);
  }

  public static List sortList(List input)
  {
    Collections.sort(input);
    return input;
  }

  public static List asNullableList(String[] strings)
  {
    if (strings == null) return null;
    return Arrays.asList(strings);
  }

  public static Float convertHexStringToFloat(String hex)
  {
    if (hex == null) return null;
    hex = hex.trim();
    if (hex.length() != 8) throw new RuntimeException("IEEE-754 float must be of length 8.");
    byte b1 = (byte)Integer.parseInt(hex.substring(0, 2), 16);
    byte b2 = (byte)Integer.parseInt(hex.substring(2, 4), 16);
    byte b3 = (byte)Integer.parseInt(hex.substring(4, 6), 16);
    byte b4 = (byte)Integer.parseInt(hex.substring(6, 8), 16);

    int tempbits = 0xFF & b4 | (0xFF & b3) << 8 | (0xFF & b2) << 16 | (0xFF & b1) << 24;
    float ff = Float.intBitsToFloat(tempbits);
    return Float.valueOf(ff);
  }

  public static Double convertHexStringToDouble(String hex)
  {
    if (hex == null) return null;
    hex = hex.trim();
    if (hex.length() != 8) throw new RuntimeException("32-bit signed integer must be 8 digits (was " + hex.length() + " digits instead)");
    int data = (int)Long.parseLong(hex, 16);
    return new Double(data);
  }

  public static Object[][] listToArray(List<Object[]> list)
  {
    if (list == null) return (Object[][])null;
    Object[][] result = new Object[list.size()][];
    int i = 0;
    for (Object[] row : list) {
      result[i] = row;
      i++;
    }
    return result;
  }

  public static int indexOf(String[] list, String item)
  {
    if (list == null) throw new IllegalArgumentException("List cannot be null");
    for (int i = 0; i < list.length; i++) {
      if (list[i].equals(item))
        return i;
    }
    return -1;
  }

  public static String getStringFromSingleArray(String[] array)
  {
    if ((array == null) || (array.length == 0)) return null;
    if (array.length > 1) throw new RuntimeException("Array has more than one element: " + array.length);
    return array[0];
  }

  public static boolean containsAnyIgnoreCase(String text, String possibleChars)
  {
    if ((possibleChars == null) || (text == null)) return false;
    for (int i = 0; i < possibleChars.length(); i++) {
      if (text.indexOf(possibleChars.charAt(i)) != -1) return true;
    }
    return false;
  }

  public static boolean containsOnlyIgnoreCase(String text, String possibleChars)
  {
    if ((possibleChars == null) || (text == null)) return false;
    for (int i = 0; i < text.length(); i++) {
      if (possibleChars.indexOf(text.charAt(i)) == -1) return false;
    }
    return true;
  }

  public static String[] removeFromList(String[] input, String value)
  {
    if (input == null) return null;
    List result = new ArrayList();
    for (String temp : input) {
      if (temp != null) {
        if (temp.equals(value)) continue; result.add(temp);
      } else {
        if (value == null) continue; result.add(temp);
      }
    }
    return listToStringArray(result);
  }

  public static boolean isEqual(String s1, String s2)
  {
    if (s1 == null) {
      return s2 == null;
    }

    return s1.equals(s2);
  }

  static
  {
    for (int i = 0; i <= 102; i++)
    {
      correspondingNibble[i] = -1;
    }
    for (int i = 48; i <= 57; i++)
    {
      correspondingNibble[i] = (byte)(i - 48);
    }
    for (int i = 65; i <= 70; i++)
    {
      correspondingNibble[i] = (byte)(i - 65 + 10);
    }
    for (int i = 97; i <= 102; i++)
    {
      correspondingNibble[i] = (byte)(i - 97 + 10);
    }
  }
}