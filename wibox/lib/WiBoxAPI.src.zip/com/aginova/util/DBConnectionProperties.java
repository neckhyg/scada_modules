package com.aginova.util;

import com.aginova.exception.DBPropertiesNotSetException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;

public class DBConnectionProperties
{
  public static String DB_TYPE = "DB_TYPE";
  public static String DEBUG_LEVEL = "DEBUG_LEVEL";

  public static String DB_LOGIN = "DB_LOGIN";
  public static String DB_PASSWORD = "DB_PASSWORD";
  public static String DB_PORT = "DB_PORT";
  public static String DB_HOST = "DB_HOST";
  public static String INSTALL_APPLICATION = "INSTALL_APPLICATION";
  public static String APPLICATION_IMAGE = "APPLICATION_IMAGE";
  public static String DEFAULT_LANGUAGE = "DEFAULT_LANGUAGE";
  public static String GOOGLE_KEY = "GOOGLE_KEY";
  public static String GOOGLE_HOSTPORT = "GOOGLE_HOSTPORT";
  public static String CUSTOMER_NAME = "CUSTOMER_NAME";
  public static String CUSTOMER_COMPANY_NAME = "CUSTOMER_COMPANY_NAME";
  public static String APPLICATION_MARINE = "marine";
  public static String APPLICATION_OILGAS = "oilgas";
  public static String APPLICATION_PIPELINE = "pipeline";
  public static String APPLICATION_TEMPERATURE = "temperature";
  public static String APPLICATION_HOME = "home";
  public static String APPLICATION_HOSPITAL = "hospital";
  public static String APPLICATION_TESTING = "testing";

  private static String[] supportedApps = { APPLICATION_MARINE, APPLICATION_OILGAS, APPLICATION_PIPELINE, APPLICATION_TESTING, APPLICATION_HOME, APPLICATION_HOSPITAL };

  private static List neededValues = new ArrayList();
  public static String ORACLE;
  public static String SQL_SERV;
  public static String ACCESS;
  public static String MYSQL;
  public static String POSTGRESQL;
  public static String HSQLDB;
  private boolean loaded = false;
  public static String DB_ID;
  private static final String FILE_NAME = "nova_properties.ini";
  private String usedFileName = null;
  private static DBConnectionProperties dbProperties;
  private Properties properties = null;

  public static String[] getSupportedApps()
  {
    return supportedApps;
  }

  private static void loadProperties()
    throws DBPropertiesNotSetException
  {
    loadProperties(null);
  }

  public static void loadProperties(String fileName)
    throws DBPropertiesNotSetException
  {
    dbProperties = new DBConnectionProperties();
    try {
      System.out.println("Loading " + fileName);
      dbProperties.load(fileName);

      dbProperties.checkContents();

      dbProperties.loaded = true;
    } catch (FileNotFoundException fnfe) {
      throw new DBPropertiesNotSetException("File was not found...");
    } catch (IOException ioe) {
      throw new DBPropertiesNotSetException("File was impossible to read...");
    }
  }

  public static boolean isDBPropertiesLoaded()
  {
    if (dbProperties == null)
      return false;
    return dbProperties.loaded;
  }

  public static synchronized DBConnectionProperties getDBConnectionProperties()
  {
    if (dbProperties == null) {
      System.out.println("Creating new properties...");
      dbProperties = new DBConnectionProperties();
    }

    return dbProperties;
  }

  private Properties getProperties()
  {
    return this.properties;
  }

  private DBConnectionProperties()
  {
    this.properties = new Properties();
  }

  public void setProperty(String name, String value)
  {
    this.properties.put(name, value);
  }

  public String getProperty(String name)
  {
    return (String)this.properties.get(name);
  }

  private void checkContents() throws DBPropertiesNotSetException {
    for (int i = 0; i < neededValues.size(); i++) {
      String key = (String)neededValues.get(i);
      String temp = getProperty(key);
      if (key.equals(DB_PASSWORD))
        continue;
      if ((temp == null) || (temp.trim().equals("")))
        throw new DBPropertiesNotSetException("DB setting " + key + " is not set");
    }
  }

  public void load(String fileName)
    throws DBPropertiesNotSetException, FileNotFoundException, IOException
  {
    if (fileName != null)
      this.usedFileName = fileName;
    else {
      this.usedFileName = "nova_properties.ini";
    }

    System.out.println("usedFileName " + this.usedFileName);

    File props = new File(this.usedFileName);
    if (!props.exists()) {
      System.out.println("The file " + this.usedFileName + " does not exist!");
      throw new DBPropertiesNotSetException("The file " + this.usedFileName + " does not exist!");
    }

    System.out.println("Using file " + props.getAbsolutePath());

    InputStream in = new FileInputStream(this.usedFileName);
    this.properties.load(in);
  }

  public void save()
    throws FileNotFoundException, IOException
  {
    System.out.println("Saving file..." + this.usedFileName);
    if (this.usedFileName == null)
      throw new RuntimeException("Must call the load() method before calling save !");
    OutputStream out = new FileOutputStream(this.usedFileName);
    this.properties.store(out, "DB Properties, do not change (generated)");
    System.out.println("Saving file...OK");
  }

  public String toString() {
    return this.properties.toString();
  }

  public String getURL() {
    String db_type = getProperty(DB_TYPE);
    String db_host = getProperty(DB_HOST);
    String db_port = getProperty(DB_PORT);
    String db_id = getProperty(DB_ID);
    return getURL(db_type, db_host, db_port, db_id);
  }

  public static String getURL(String db_type, String db_host, String db_port, String db_id)
  {
    String url = null;
    if (db_type.equalsIgnoreCase(SQL_SERV)) {
      url = "jdbc:sqlserver://" + db_host + ":" + db_port + ";SelectMethod=cursor" + ";DatabaseName=" + db_id;
    }
    else if (db_type.equalsIgnoreCase(MYSQL))
      url = "jdbc:mysql://" + db_host + ":" + db_port + "/" + db_id + "?autoReconnect=true";
    else if (db_type.equalsIgnoreCase(POSTGRESQL))
      url = "jdbc:postgresql://" + db_host + ":" + db_port + "/" + db_id;
    else if (db_type.equalsIgnoreCase(ORACLE))
      url = "jdbc:oracle:thin:@" + db_host + ":" + db_port + ":" + db_id;
    else if (db_type.equalsIgnoreCase(HSQLDB))
      url = "jdbc:hsqldb:file:" + db_id;
    else {
      throw new RuntimeException("URL for " + db_type + " not Implemented!");
    }
    return url;
  }

  public String getClassName() {
    String db_type = getProperty(DB_TYPE);
    return getClassName(db_type);
  }

  public static String getClassName(String db_type)
  {
    String className = null;

    if (db_type == null) {
      throw new RuntimeException("DB Type was null (not set properly) !");
    }
    if (db_type.equalsIgnoreCase(ORACLE))
      className = "oracle.jdbc.driver.OracleDriver";
    else if (db_type.equalsIgnoreCase(SQL_SERV))
      className = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
    else if (db_type.equalsIgnoreCase(ACCESS))
      className = "org.objectweb.rmijdbc.Driver";
    else if (db_type.equalsIgnoreCase(MYSQL))
      className = "com.mysql.jdbc.Driver";
    else if (db_type.equalsIgnoreCase(POSTGRESQL))
      className = "org.postgresql.Driver";
    else if (db_type.equalsIgnoreCase(HSQLDB))
      className = "org.hsqldb.jdbcDriver";
    else {
      throw new RuntimeException("Unknown Database");
    }
    return className;
  }

  public String getHibernateDialect() {
    String type = getProperty(DB_TYPE);

    if (type.equalsIgnoreCase(MYSQL))
      return "org.hibernate.dialect.MySQLDialect";
    if (type.equalsIgnoreCase(POSTGRESQL))
      return "org.hibernate.dialect.PostgreSQLDialect";
    if (type.equalsIgnoreCase(ORACLE))
      return "org.hibernate.dialect.Oracle10gDialect";
    if (type.equalsIgnoreCase(SQL_SERV))
      return "org.hibernate.dialect.SQLServerDialect";
    if (type.equalsIgnoreCase(HSQLDB)) {
      return "org.hibernate.dialect.HSQLDialect";
    }

    throw new RuntimeException("Dialect not supported for DB " + type);
  }

  public boolean isSQLServer() {
    return getProperty(DB_TYPE).equalsIgnoreCase(SQL_SERV);
  }

  public boolean isPostgreSQL() {
    return getProperty(DB_TYPE).equalsIgnoreCase(POSTGRESQL);
  }

  public boolean isOracle() {
    return getProperty(DB_TYPE).equalsIgnoreCase(ORACLE);
  }

  public boolean isMySQL() {
    return getProperty(DB_TYPE).equalsIgnoreCase(MYSQL);
  }

  public boolean isHSQLDB() {
    return getProperty(DB_TYPE).equalsIgnoreCase(HSQLDB);
  }

  public String getIndexHint(String indexName)
  {
    if (isMySQL()) {
      return " use index (" + indexName + ") ";
    }
    return " ";
  }

  public String castFromBooleanToInteger(String value)
  {
    if (isPostgreSQL()) {
      return value + "::boolean::integer";
    }
    return value;
  }

  public String convertToString(String columnName)
  {
    if (isPostgreSQL()) return "to_char(" + columnName + ",'999999999')";
    return columnName;
  }

  public String getDropTable(String table)
  {
    if (isOracle())
      return "drop table " + table;
    if (isPostgreSQL())
      return "drop table " + table;
    if (isHSQLDB())
      return "drop table " + table + " if exists";
    if (isSQLServer())
      return "drop table " + table;
    if (isMySQL()) {
      return "drop table if exists " + table;
    }
    return "drop table " + table;
  }

  public String getTruncateTable(String table)
  {
    if (isOracle())
      return "truncate table " + table;
    if (isPostgreSQL())
      return "truncate table " + table;
    if (isHSQLDB())
      return "truncate table " + table;
    if (isSQLServer())
      return "truncate table " + table;
    if (isMySQL()) {
      return "truncate table " + table;
    }
    return "truncate table " + table;
  }

  public String getDropColumn(String table, String column)
  {
    if (isOracle())
      return "alter table " + table + " drop column " + column;
    if (isPostgreSQL())
      return "alter table " + table + " drop column " + column;
    if (isHSQLDB())
      return "alter table " + table + " drop column " + column;
    if (isSQLServer()) {
      return "alter table " + table + " drop column " + column;
    }
    return "alter table " + table + " drop column " + column;
  }

  public String getDropIndex(String table, String index)
  {
    if (isOracle())
      return "drop index " + index;
    if (isPostgreSQL())
      return "drop index " + index;
    if (isHSQLDB())
      return "drop index " + index;
    if (isSQLServer()) {
      return "drop index '" + table + "." + index + "'";
    }
    return "drop index " + index + " on " + table;
  }

  public String getAlterColumnType(String table, String column, String newColumnType, Boolean notNull)
  {
    if (isPostgreSQL())
    {
      return "alter table " + table + " alter " + column + " type " + newColumnType + ";";
    }
    if (isHSQLDB()) {
      if (notNull != null) {
        if (notNull.booleanValue())
          newColumnType = newColumnType + "  not null";
        else {
          newColumnType = newColumnType + "  null";
        }
      }
      return "alter table " + table + " alter column " + column + " " + newColumnType + ";";
    }
    if (isOracle()) {
      return "alter table " + table + " modify( " + column + "  " + newColumnType + (notNull != null ? " null" : notNull.booleanValue() ? " not null" : "") + ")";
    }
    if ("timestamp".equals(newColumnType)) {
      newColumnType = "timestamp null";
    }

    if (notNull != null) {
      if (notNull.booleanValue())
        newColumnType = newColumnType + "  not null";
      else {
        newColumnType = newColumnType + "  default null";
      }
    }

    return "alter table " + table + " modify " + column + " " + newColumnType + ";";
  }

  public String getRenameColumn(String tableName, String oldColumnName, String newColumnName, String definition)
  {
    if (isOracle()) {
      return "alter table " + tableName + " rename column " + oldColumnName + " to " + newColumnName;
    }
    if (isMySQL()) {
      return "alter table " + tableName + " change column " + oldColumnName + " " + newColumnName + " " + definition;
    }
    if (isHSQLDB()) {
      return "alter table " + tableName + " alter column " + oldColumnName + " rename to " + newColumnName;
    }
    if (isPostgreSQL()) {
      return "alter table " + tableName + " rename column " + oldColumnName + " to " + newColumnName;
    }
    if (isSQLServer()) {
      return "EXEC sp_rename '" + tableName + "." + oldColumnName + "' , '" + newColumnName + "','COLUMN'";
    }

    throw new RuntimeException("Not implemented: getRenameColumn for this database.");
  }

  public String getBooleanValue(boolean value)
  {
    if (isOracle())
      return value ? "1" : "0";
    if (isMySQL())
      return value ? "1" : "0";
    if (isHSQLDB())
      return value ? "1" : "0";
    if (isPostgreSQL())
      return value ? "true" : "false";
    if (isSQLServer()) {
      return value ? "1" : "0";
    }
    throw new RuntimeException("Not implemented: getBooleanValue for this database.");
  }

  public String getRoundValue(String value)
  {
    if (isOracle())
      return "round(" + value + ")";
    if (isMySQL())
      return "round(" + value + ")";
    if (isHSQLDB())
      return "round(" + value + ",0)";
    if (isPostgreSQL())
      return "round(" + value + ")";
    if (isSQLServer()) {
      return "round(" + value + ",0)";
    }
    throw new RuntimeException("Not implemented: getRoundValue for this database.");
  }

  public String getStandardDeviation(String value)
  {
    if (isOracle())
      return "stddev(" + value + ")";
    if (isMySQL())
      return "stddev(" + value + ")";
    if (isHSQLDB())
      return "stddev(" + value + ")";
    if (isPostgreSQL())
      return "stddev(" + value + ")";
    if (isSQLServer()) {
      return "stdev(" + value + ")";
    }
    throw new RuntimeException("Not implemented: getStandardDeviation for this database.");
  }

  public String getNaturalLogarithm(String value)
  {
    if (isOracle())
      return "ln(" + value + ")";
    if (isMySQL())
      return "ln(" + value + ")";
    if (isHSQLDB())
      return "ln(" + value + ")";
    if (isPostgreSQL())
      return "ln(" + value + ")";
    if (isSQLServer()) {
      return "log(" + value + ")";
    }
    throw new RuntimeException("Not implemented: getNaturalLogarithm for this database.");
  }

  public String getDBTime()
  {
    if (isOracle())
      return "select UNIX_TIMESTAMP() as ts from dual";
    if (isMySQL())
      return "select UNIX_TIMESTAMP() as ts";
    if (isHSQLDB())
      return "select UNIX_TIMESTAMP() as ts FROM INFORMATION_SCHEMA.SYSTEM_TABLES where table_name = 'SYSTEM_ALIASES'";
    if (isPostgreSQL())
      return "select UNIX_TIMESTAMP() as ts";
    if (isSQLServer()) {
      return "select dbo.UNIX_TIMESTAMP() as ts";
    }
    throw new RuntimeException("Not implemented: getDBTime() for this database.");
  }

  public String getDayFunction(String date)
  {
    if (isOracle())
      return "to_char(" + date + ",'DD')";
    if (isMySQL())
      return "day(" + date + ")";
    if (isSQLServer())
      return "day(" + date + ")";
    if (isPostgreSQL())
    {
      return "extract(day from " + date + ")";
    }if (isHSQLDB()) {
      return "DAYOFMONTH(" + date + ")";
    }
    throw new RuntimeException("Unsupported Database: " + getProperty(DB_TYPE) + " for function 'getDayFunction'");
  }

  public String getLessThanFunction(String v1, String v2)
  {
    if (isOracle()) return "DECODE(SIGN(" + v1 + "-" + v2 + "), -1, 1, 0)";
    if (isSQLServer()) return "dbo.lessthan(" + v1 + "," + v2 + ")";
    return v1 + "<" + v2;
  }

  public String getUnixTimestamp()
  {
    if (isSQLServer()) {
      return " dbo.UNIX_TIMESTAMP() ";
    }
    return " UNIX_TIMESTAMP() ";
  }

  public boolean isDuplicateKeyError(int cause)
  {
    return (isSQLServer()) && 
      (cause == 2601);
  }

  public String getFromUnixTimestamp(String val)
  {
    if (isSQLServer()) {
      return " dbo.FROM_UNIXTIME(" + val + ") ";
    }
    return " FROM_UNIXTIME(" + val + ") ";
  }

  public String getFromUnixTimestamp(long val)
  {
    if (isSQLServer()) {
      SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
      return "'" + sdf.format(new Date(val * 1000L)) + "'";
    }
    return " FROM_UNIXTIME(" + val + ") ";
  }

  public String getDistinctWord()
  {
    return " distinct ";
  }

  public static boolean isApplication(String name)
  {
    return getDBConnectionProperties().getProperty(INSTALL_APPLICATION).equals(name);
  }

  public static String getIniFile(ServletConfig config)
  {
    String REAL_PATH = config.getServletContext().getRealPath("");
    String CONTEXT_NAME = "";

    System.out.println("REAL_PATH " + REAL_PATH);

    if (REAL_PATH != null) {
      int c = REAL_PATH.lastIndexOf("\\");
      if (c == -1) {
        c = REAL_PATH.lastIndexOf("/");
      }
      if (c != -1) {
        CONTEXT_NAME = REAL_PATH.substring(c + 1);
      }
    }
    if (CONTEXT_NAME.equals("public_html")) {
      CONTEXT_NAME = "";
    }

    String PROPERTIES_FILE = "nova_properties.ini";
    if (CONTEXT_NAME.length() > 0) {
      PROPERTIES_FILE = "nova_" + CONTEXT_NAME + "_properties.ini";
    }
    return PROPERTIES_FILE;
  }

  public String getSingleSelectTest()
  {
    if (isOracle()) {
      return "select * from user_views";
    }
    return "select 1";
  }

  public static boolean isGoogleMapSet()
  {
    return true;
  }

  public static void main(String[] args) {
    System.out.println(System.currentTimeMillis());
  }

  static
  {
    neededValues.add(DB_LOGIN);
    neededValues.add(DB_PASSWORD);
    neededValues.add(DB_PORT);
    neededValues.add(DB_HOST);

    ORACLE = "Oracle";
    SQL_SERV = "SqlServer";
    ACCESS = "Access";
    MYSQL = "MySQL";
    POSTGRESQL = "PostgreSQL";
    HSQLDB = "HSQLDB";

    DB_ID = "DB_ID";

    dbProperties = null;
  }
}