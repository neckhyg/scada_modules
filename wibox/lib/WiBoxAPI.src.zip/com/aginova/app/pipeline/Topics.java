package com.aginova.app.pipeline;

import com.aginova.business.Descriptor;
import com.aginova.portlets.PipelineSummary;
import com.aginova.portlets.Portlet;
import com.aginova.portlets.SystemStatus;
import com.aginova.util.Lang;
import java.util.ArrayList;
import java.util.List;

public class Topics extends com.aginova.business.Topics
{
  private List list;

  public List getDescriptorList()
  {
    if (this.list == null) {
      this.list = new ArrayList();
      List descrList = null;
      descrList = new ArrayList();
      descrList.add(new Descriptor("search", Lang.getLang().getLang("topics_marines_search"), null));

      descrList.add(new Descriptor("analyze", Lang.getLang().getLang("topics_marines_analyze"), null));

      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      this.list.add(new Descriptor("home", Lang.getLang().getLang("topics_marines_home"), null));

      descrList = new ArrayList();

      descrList.add(new Descriptor("visual", Lang.getLang().getLang("topics_marines_visual"), null));

      descrList.add(new Descriptor("maintenance", Lang.getLang().getLang("topics_marines_maintenance"), null));

      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      this.list.add(new Descriptor("livedata", Lang.getLang().getLang("topics_marines_vehicules_corrosion"), descrList));

      descrList = new ArrayList();
      descrList.add(new Descriptor("motes", Lang.getLang().getLang("topics_marines_motes"), null));

      descrList.add(new Descriptor("profile", Lang.getLang().getLang("topics_marines_mote_profiles"), null));

      descrList.add(new Descriptor("sensortype", Lang.getLang().getLang("topics_marines_mote_sensortype"), null));

      descrList.add(new Descriptor("coating", Lang.getLang().getLang("topics_marines_administration_coating"), null, "admin_coating.jsp"));

      descrList.add(new Descriptor("latestevents", Lang.getLang().getLang("topics_marines_mote_lastestevents"), null));

      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      this.list.add(new Descriptor("status", Lang.getLang().getLang("topics_marines_wireless_network"), descrList));

      descrList = new ArrayList();
      descrList.add(new Descriptor("history", Lang.getLang().getLang("topics_marines_notifications_history"), null));

      descrList.add(new Descriptor("setup", Lang.getLang().getLang("topics_marines_notifications_setup"), null));

      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      this.list.add(new Descriptor("notifications", Lang.getLang().getLang("topics_marines_notifications"), descrList));

      descrList = new ArrayList();
      descrList.add(new Descriptor("graphs", Lang.getLang().getLang("topics_marines_report_graph"), null));

      descrList.add(new Descriptor("data", Lang.getLang().getLang("topics_marines_report_data"), null));

      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      this.list.add(new Descriptor("report", Lang.getLang().getLang("topics_marines_report"), descrList));

      descrList = new ArrayList();
      descrList.add(new Descriptor("user", Lang.getLang().getLang("topics_marines_administration_users"), null));

      descrList.add(new Descriptor("role", Lang.getLang().getLang("topics_marines_administration_role"), null));

      descrList.add(new Descriptor("vehicles", Lang.getLang().getLang("topics_marines_administration_vehicules"), null));

      descrList.add(new Descriptor("setup", Lang.getLang().getLang("topics_marines_administration_setup"), null));

      descrList.add(new Descriptor("simul", Lang.getLang().getLang("topics_marines_administration_simul"), null));

      descrList.add(new Descriptor("logs", Lang.getLang().getLang("topics_marines_administration_logs"), null));

      descrList.add(new Descriptor("lang", Lang.getLang().getLang("topics_marines_administration_lang"), null));

      descrList.add(new Descriptor("", "", null));
      this.list.add(new Descriptor("admin", Lang.getLang().getLang("topics_marines_administration"), descrList));
    }

    return this.list;
  }

  public Portlet[] getListOfPortlets() {
    return new Portlet[] { new PipelineSummary(), new SystemStatus() };
  }

  public boolean isDirectMoteView()
  {
    return false;
  }

  public boolean isWiFiProductOnly()
  {
    return false;
  }
}