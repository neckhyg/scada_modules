package com.aginova.app.temperature;

import com.aginova.business.Descriptor;
import com.aginova.portlets.Portlet;
import com.aginova.portlets.SystemStats;
import java.util.ArrayList;
import java.util.List;

public class Topics extends com.aginova.business.Topics
{
  private List list;

  public List getDescriptorList()
  {
    if (this.list == null) {
      this.list = new ArrayList();
      List descrList = null;
      descrList = new ArrayList();
      descrList.add(new Descriptor("search", "Search", null));
      descrList.add(new Descriptor("analyze", "Analyse", null));
      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      this.list.add(new Descriptor("home", "Home", null));

      descrList = new ArrayList();

      descrList.add(new Descriptor("visual", "Visual", null));
      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));

      this.list.add(new Descriptor("livedata", "Temperature Monitoring", descrList));

      descrList = new ArrayList();
      descrList.add(new Descriptor("status", "Status", null));
      descrList.add(new Descriptor("", " ", null));
      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      this.list.add(new Descriptor("status", "Wireless network", descrList));

      descrList = new ArrayList();
      descrList.add(new Descriptor("setup", "Setup", null));
      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      this.list.add(new Descriptor("notifications", "Notification Setup", descrList));

      descrList = new ArrayList();
      descrList.add(new Descriptor("graphs", "Graphs", null));
      descrList.add(new Descriptor("data", "Data", null));
      descrList.add(new Descriptor("intelligence", "Intelligence", null));
      descrList.add(new Descriptor("failure", "Failure Prediction", null));
      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      this.list.add(new Descriptor("report", "Intelligence", descrList));

      descrList = new ArrayList();
      descrList.add(new Descriptor("user", "Users", null));
      descrList.add(new Descriptor("role", "Permissions", null));
      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      descrList.add(new Descriptor("", "", null));
      this.list.add(new Descriptor("admin", "Administration", descrList));
    }

    return this.list;
  }

  public Portlet[] getListOfPortlets()
  {
    return new Portlet[] { new SystemStats() };
  }

  public boolean isDirectMoteView()
  {
    return false;
  }

  public boolean isWiFiProductOnly()
  {
    return false;
  }
}