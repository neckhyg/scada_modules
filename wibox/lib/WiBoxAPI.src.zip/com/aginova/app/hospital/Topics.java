package com.aginova.app.hospital;

import com.aginova.business.Descriptor;
import com.aginova.portlets.MoteHelper;
import com.aginova.portlets.Portlet;
import com.aginova.portlets.SensorsMapView;
import com.aginova.portlets.SystemInfo;
import com.aginova.portlets.SystemStats;
import java.util.List;
import org.apache.log4j.Logger;

public class Topics extends com.aginova.business.Topics
{
  private static final Logger logger = Logger.getLogger(Topics.class);

  private Portlet[] portlets = { new SystemInfo(), new SystemStats(), new SensorsMapView("images/noimage.gif", new MoteHelper()) };

  protected void addSensorTypeItem(List subList)
  {
  }

  protected void addCoatingItem(List subList)
  {
  }

  protected void addProfilesItems(List descrList)
  {
  }

  protected Descriptor getAdminDescriptor()
  {
    Descriptor parent = super.getAdminDescriptor();
    return parent;
  }

  protected void addFlashItem(List descrList)
  {
  }

  protected void addVehiclesItem(List descrList)
  {
  }

  protected void addImport(List descrList)
  {
  }

  public Portlet[] getListOfPortlets()
  {
    return this.portlets;
  }

  public boolean isDirectMoteView()
  {
    return true;
  }

  public boolean isWiFiProductOnly()
  {
    return true;
  }
}