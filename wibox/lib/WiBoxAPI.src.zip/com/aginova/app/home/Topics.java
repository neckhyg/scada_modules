package com.aginova.app.home;

import com.aginova.business.Descriptor;
import com.aginova.portlets.MoteHelper;
import com.aginova.portlets.Portlet;
import com.aginova.portlets.SensorsMapView;
import com.aginova.portlets.SystemInfo;
import com.aginova.portlets.SystemStats;
import com.aginova.util.Lang;
import java.util.ArrayList;
import java.util.List;

public class Topics extends com.aginova.business.Topics
{
  private Portlet[] portlets = { new SystemInfo(), new SystemStats(), new SensorsMapView("images/home/home_automation.jpg", new MoteHelper()) };

  protected Descriptor getMonitoringDescriptor()
  {
    List descrList = new ArrayList();

    descrList.add(new Descriptor("video", "Video", null, "video.jsp"));
    descrList.add(new Descriptor("notifications", "Notifications", null, "notifications_history.jsp", true, false, new String[] { "createNotification.jsp" }));

    return new Descriptor("livedata", Lang.getLang().getLang("topics_home_monitoring"), descrList, "livedata_summary.jsp");
  }

  protected Descriptor getAdminDescriptor()
  {
    Descriptor parent = super.getAdminDescriptor();
    parent.getDescrList().remove(6);
    return parent;
  }

  public Portlet[] getListOfPortlets()
  {
    return this.portlets;
  }

  public boolean isDirectMoteView()
  {
    return true;
  }

  public boolean isWiFiProductOnly()
  {
    return false;
  }
}