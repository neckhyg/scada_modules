package com.aginova.app.oilgas;

import com.aginova.motes.Mote;
import com.aginova.portlets.PortletHelper;
import com.aginova.portlets.PortletHelper.Content;
import com.aginova.storage.Camp;
import com.aginova.storage.UserGroup;
import com.aginova.storage.Vehicle;
import com.aginova.util.Hibernate;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class OilgasHelper extends PortletHelper
{
  public static final int STD_WIDTH = 500;
  public static final int STD_HEIGHT = 400;
  public static final int MOTE_Z_POS = 135;
  public static final int IMG_Z_POS = 130;

  public PortletHelper.Content getContent(String asset_id, Camp camp, List<UserGroup> group_id, int mode, boolean readonly)
  {
    if (mode == 2) {
      if ((asset_id == null) || (asset_id.equals(""))) {
        return getOverviewContent(camp);
      }
      return getAssetContent(asset_id, null, group_id, readonly);
    }

    return getAssetContent(asset_id, camp, group_id, readonly);
  }

  public PortletHelper.Content getOverviewContent(Camp camp)
  {
    PortletHelper.Content content = new PortletHelper.Content();

    String names = "\"mainView\"+NO_DRAG";
    String scripts = "";
    String later = "";
    Session sess = Hibernate.getSafeSession();

    int assetCounter = 0;

    Transaction tx = null;
    try {
      tx = sess.beginTransaction();

      scripts = scripts + "dd.elements.mainView.setZ(130);\n";

      String query = "from Vehicle as Vehicle";
      if (camp != null) {
        query = query + " where vehicle_location=" + camp.getCamp_id();
      }

      List allVehicles = sess.createQuery(query).list();

      assetCounter = allVehicles.size();

      for (int i = 0; i < assetCounter; i++) {
        Vehicle v = (Vehicle)allVehicles.get(i);

        String src = "genimages/generateVehicleIcon.jsp?displayDetails=false&name=" + v.get_vehicle_display() + "&image=" + v.getImage() + "&corrLevel=" + v.getCorrosionLevel(sess) + "&lastSeen=" + v.getLast_heartbeat_received();

        later = later + "<div style=\"position:absolute;left:0px;top:0px;\">";
        later = later + "<img src=\"" + src + "\" width=\"" + Vehicle.IMAGE_WIDTH_SMALL + "\" height=\"" + Vehicle.IMAGE_HEIGHT + "\" name=\"test" + i + "\">";

        later = later + "</div>";

        if (names.length() > 0)
          names = names + ",";
        names = names + "\"test" + i + "\"";

        scripts = scripts + "dd.elements.test" + i + ".mote_id=" + v.getVehicle_id() + ";\n";
        scripts = scripts + "dd.elements.test" + i + ".setZ(" + 135 + ");\n";

        if (v.getPosX1() != -1) {
          scripts = scripts + "dd.elements.test" + i + ".moveTo(" + v.getPosX1() + "+dd.elements.mainView.x," + v.getPosY1() + "+dd.elements.mainView.y);\n";

          scripts = scripts + "dd.elements.test" + i + ".xpos=" + v.getPosX1() + "+dd.elements.mainView.x;\n";

          scripts = scripts + "dd.elements.test" + i + ".ypos=" + v.getPosY1() + "+dd.elements.mainView.y;\n";
        }
      }

      Hibernate.safeCommit(tx);
    }
    catch (Exception e)
    {
      throw new RuntimeException(e);
    }
    finally {
      Hibernate.safeClose(sess);
    }
    content.names = names;
    content.scripts = scripts;
    content.later = later;
    content.imageWidth = 500;
    content.imageHeight = 400;
    content.detailsPage = "vehicle_details.jsp?vehicle_id=";
    content.asset = "vehicle";
    content.assetCounter = assetCounter;
    return content;
  }

  public PortletHelper.Content getAssetContent(String asset_id, Camp camp, List<UserGroup> group_id, boolean readonly)
  {
    PortletHelper.Content content = new PortletHelper.Content();

    String names = "\"mainView\"+NO_DRAG";
    String scripts = "";
    String later = "";
    Session sess = Hibernate.getSafeSession();
    int assetCounter = 0;
    Transaction tx = sess.beginTransaction();
    try
    {
      scripts = scripts + "dd.elements.mainView.setZ(130);\n";

      List allSensors = Mote.getAllMotes(sess, asset_id, camp, group_id);
      assetCounter = allSensors.size();

      for (int i = 0; i < assetCounter; i++) {
        Mote mote = (Mote)allSensors.get(i);

        later = later + "<div style=\"position:absolute;left:0px;top:0px;\">";
        if (mote.isSensor()) {
          String icon = mote.getIcon(sess);

          later = later + "<img style=\"cursor:hand\" src=\"images/" + icon + "\" title=\"" + mote.getCompleteLocationOrIdentifier() + "\"  width=\"27\" height=\"28\" name=\"test" + i + "\">";
        }
        else
        {
          later = later + "<img style=\"cursor:hand\" src=\"images/icon_reader.gif\" title=\"" + mote.getCompleteLocationOrIdentifier() + "\"    width=\"27\" height=\"28\" name=\"test" + i + "\">";
        }

        later = later + "</div>";

        if (names.length() > 0)
          names = names + ",";
        names = names + "\"test" + i + "\"";

        if (readonly) {
          names = names + "+NO_DRAG";
        }

        scripts = scripts + "dd.elements.test" + i + ".mote_id=" + mote.getMote_id() + ";\n";
        scripts = scripts + "dd.elements.test" + i + ".setZ(" + 135 + ");\n";
        scripts = scripts + "dd.elements.test" + i + ".setCursor(CURSOR_HAND);\n";

        if (mote.getIntPosX() != -1) {
          scripts = scripts + "dd.elements.test" + i + ".moveTo(" + mote.getIntPosX() + "+dd.elements.mainView.x-dd.elements.test" + i + ".w/2," + mote.getIntPosY() + "+dd.elements.mainView.y-dd.elements.test" + i + ".h/2);\n";

          scripts = scripts + "dd.elements.test" + i + ".xpos=" + mote.getIntPosX() + "+dd.elements.mainView.x;\n";

          scripts = scripts + "dd.elements.test" + i + ".ypos=" + mote.getIntPosY() + "+dd.elements.mainView.y;\n";
        }

      }

      Hibernate.safeCommit(tx);
    }
    catch (Exception e)
    {
      throw new RuntimeException(e);
    } finally {
      Hibernate.safeClose(sess);
    }
    content.names = names;
    content.scripts = scripts;
    content.later = later;
    content.detailsPage = "sensors_details.jsp?mote_id=";
    content.asset = "mote";
    content.imageWidth = 500;
    content.imageHeight = 400;
    content.assetCounter = assetCounter;
    return content;
  }
}