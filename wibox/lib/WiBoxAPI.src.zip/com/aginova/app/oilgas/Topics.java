package com.aginova.app.oilgas;

import com.aginova.business.ProductInformation;
import com.aginova.crossbow.DefaultSensorDescriptor;
import com.aginova.motes.Mote;
import com.aginova.portlets.MoteHelper;
import com.aginova.portlets.Portlet;
import com.aginova.portlets.SensorsMapView;
import com.aginova.util.Displayable;
import com.aginova.util.DisplayableImpl;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class Topics extends com.aginova.business.Topics
{
  public static final String SENSOR_TYPE_BP_CORR1 = "bpCorr1";
  public static final String SENSOR_TYPE_BP_CORR2 = "bpCorr2";
  public static final String SENSOR_TYPE_BP_CORR3 = "bpCorr3";
  public static final String SENSOR_TYPE_BP_CORR4 = "bpCorr4";
  public static final String SENSOR_TYPE_BP_CORR5 = "bpCorr5";
  public static final String SENSOR_TYPE_BP_CORR6 = "bpCorr6";
  public static final String SENSOR_TYPE_BP_CORR7 = "bpCorr7";
  public static final String SENSOR_TYPE_BP_CORR8 = "bpCorr8";
  public static final String SENSOR_TYPE_BP_CORR9 = "bpCorr9";
  public static final String SENSOR_TYPE_BP_CORR10 = "bpCorr10";
  public static final String SENSOR_TYPE_BP_CORR11 = "bpCorr11";
  public static final String SENSOR_TYPE_BP_CORR12 = "bpCorr12";
  public static final String SENSOR_TYPE_BP_CORR13 = "bpCorr13";
  public static final String SENSOR_TYPE_BP_CORR14 = "bpCorr14";
  public static final String SENSOR_TYPE_BP_CORR15 = "bpCorr15";
  public static final String SENSOR_TYPE_BP_CORR16 = "bpCorr16";
  public static final String SENSOR_TYPE_BP_CORR17 = "bpCorr17";
  public static final String SENSOR_TYPE_BP_CORR18 = "bpCorr18";
  public static final String SENSOR_TYPE_BP_CORR19 = "bpCorr19";
  public static final String SENSOR_TYPE_BP_CORR20 = "bpCorr20";
  public static final String SENSOR_TYPE_BP_CORR21 = "bpCorr21";
  public static final String SENSOR_TYPE_BP_CORR22 = "bpCorr22";
  public static final String SENSOR_TYPE_BP_CORR23 = "bpCorr23";
  public static final String SENSOR_TYPE_BP_CORR24 = "bpCorr24";
  public static final String SENSOR_TYPE_BP_WET1 = "bpWet1";
  public static final String SENSOR_TYPE_BP_WET2 = "bpWet2";
  public static final String SENSOR_TYPE_BP_WET3 = "bpWet3";
  public static final String SENSOR_TYPE_BP_WET4 = "bpWet4";
  public static final String SENSOR_TYPE_BP_WET5 = "bpWet5";
  public static final String SENSOR_TYPE_BP_WET6 = "bpWet6";
  public static final String SENSOR_TYPE_BP_WET7 = "bpWet7";
  public static final String SENSOR_TYPE_BP_WET8 = "bpWet8";
  public static final String SENSOR_TYPE_BP_WET9 = "bpWet9";
  public static final String SENSOR_TYPE_BP_WET10 = "bpWet10";
  public static final String SENSOR_TYPE_BP_WET11 = "bpWet11";
  public static final String SENSOR_TYPE_BP_WET12 = "bpWet12";
  public static final String SENSOR_TYPE_BP_WET13 = "bpWet13";
  public static final String SENSOR_TYPE_BP_WET14 = "bpWet14";
  public static final String SENSOR_TYPE_BP_WET15 = "bpWet15";
  public static final String SENSOR_TYPE_BP_WET16 = "bpWet16";
  public static final String SENSOR_TYPE_BP_WET17 = "bpWet17";
  public static final String SENSOR_TYPE_BP_WET18 = "bpWet18";
  public static final String SENSOR_TYPE_BP_WET19 = "bpWet19";
  public static final String SENSOR_TYPE_BP_WET20 = "bpWet20";
  public static final String SENSOR_TYPE_BP_WET21 = "bpWet21";
  public static final String SENSOR_TYPE_BP_WET22 = "bpWet22";
  public static final String SENSOR_TYPE_BP_WET23 = "bpWet23";
  public static final String SENSOR_TYPE_BP_WET24 = "bpWet24";

  public Portlet[] getListOfPortlets()
  {
    return new Portlet[] { new SensorsMapView("images/oilgas/refinery_large.jpg", new MoteHelper()) };
  }

  public List getDefaultImages()
  {
    List allTypes = new ArrayList(Arrays.asList(new Displayable[] { new DisplayableImpl("images/oilgas/pipe.jpg", "Curved pipeline") }));

    Session sess = com.aginova.util.Hibernate.getSafeSession();
    Transaction tx = null;
    try {
      tx = sess.beginTransaction();
      List allImages = sess.createQuery("from ImageGallery as ImageGallery").list();
      allTypes.addAll(allImages);
      com.aginova.util.Hibernate.safeCommit(tx);
    }
    catch (Exception e)
    {
      throw new RuntimeException(e);
    } finally {
      com.aginova.util.Hibernate.safeClose(sess);
    }

    return allTypes;
  }

  public boolean isDirectMoteView()
  {
    return true;
  }

  public boolean isWiFiProductOnly()
  {
    return false;
  }

  public static float[] computeWaterDetectionLevels(Mote mote)
  {
    Session sess = com.aginova.util.Hibernate.getSafeSession();
    Transaction tx = null;
    try {
      tx = sess.beginTransaction();
      String query = "select min(rload0) r0,min(rload1) r1,min(rload2) r2,min(rload3) r3,min(rload4) r4,min(rload5) r5,min(rload6) r6,min(rload7) r7,min(rload8) r8,min(rload9) r9,min(rload10) r10,min(rload11) r11,min(rload12) r12,min(rload13) r13,min(rload14) r14,min(rload15) r15,min(rload16) r16,min(rload17) r17,min(rload18) r18,min(rload19) r19,min(rload20) r20 from nova_data_t where mote_id=? group by mote_id";

      Object[] data = (Object[])(Object[])sess.createSQLQuery(query).addScalar("r0", org.hibernate.Hibernate.FLOAT).addScalar("r1", org.hibernate.Hibernate.FLOAT).addScalar("r2", org.hibernate.Hibernate.FLOAT).addScalar("r3", org.hibernate.Hibernate.FLOAT).addScalar("r4", org.hibernate.Hibernate.FLOAT).addScalar("r5", org.hibernate.Hibernate.FLOAT).addScalar("r6", org.hibernate.Hibernate.FLOAT).addScalar("r7", org.hibernate.Hibernate.FLOAT).addScalar("r8", org.hibernate.Hibernate.FLOAT).addScalar("r9", org.hibernate.Hibernate.FLOAT).addScalar("r10", org.hibernate.Hibernate.FLOAT).addScalar("r11", org.hibernate.Hibernate.FLOAT).addScalar("r12", org.hibernate.Hibernate.FLOAT).addScalar("r13", org.hibernate.Hibernate.FLOAT).addScalar("r14", org.hibernate.Hibernate.FLOAT).addScalar("r15", org.hibernate.Hibernate.FLOAT).addScalar("r16", org.hibernate.Hibernate.FLOAT).addScalar("r17", org.hibernate.Hibernate.FLOAT).addScalar("r18", org.hibernate.Hibernate.FLOAT).addScalar("r19", org.hibernate.Hibernate.FLOAT).addScalar("r20", org.hibernate.Hibernate.FLOAT).setInteger(0, mote.getMote_id()).uniqueResult();

      boolean bp500 = false;
      if (mote.getProduct_number().equals(ProductInformation.XCORRBP500)) {
        bp500 = true;
      }
      int R100K = 100000;
      int R2M = 2000000;

      float[] results = new float[21];
      int limit = 0;
      for (int i = 0; i < results.length; i++) {
        if (i < 7)
          limit = bp500 ? 100000 : 2000000;
        else {
          limit = bp500 ? 2000000 : 100000;
        }
        if ((data != null) && (data[i] != null))
          results[i] = ((limit - ((Float)data[i]).floatValue()) / limit);
        else
          results[i] = 0.0F;
      }
      com.aginova.util.Hibernate.safeCommit(tx);
      i = results;
      return i;
    }
    catch (Exception e)
    {
      throw new RuntimeException(e);
    } finally {
      com.aginova.util.Hibernate.safeClose(sess); } throw localObject;
  }

  public static Float[] computeCUIDetectionLevels(Mote mote)
  {
    Session sess = com.aginova.util.Hibernate.getSafeSession();
    Transaction tx = null;
    try {
      tx = sess.beginTransaction();
      String query = "select min(bpCorr1) r1,min(bpCorr2) r2,min(bpCorr3) r3,min(bpCorr4) r4,min(bpCorr5) r5,min(bpCorr6) r6,min(bpCorr7) r7,min(bpCorr8) r8,min(bpCorr9) r9,min(bpCorr10) r10,min(bpCorr11) r11,min(bpCorr12) r12,min(bpCorr13) r13,min(bpCorr14) r14,min(bpCorr15) r15,min(bpCorr16) r16,min(bpCorr17) r17,min(bpCorr18) r18,min(bpCorr19) r19,min(bpCorr20) r20,min(bpCorr21) r21,min(bpCorr22) r22,min(bpCorr23) r23,min(bpCorr24) r24, min(bpWet1) c1,min(bpWet2) c2,min(bpWet3) c3,min(bpWet4) c4,min(bpWet5) c5,min(bpWet6) c6,min(bpWet7) c7,min(bpWet8) c8,min(bpWet9) c9,min(bpWet10) c10,min(bpWet11) c11,min(bpWet12) c12,min(bpWet13) c13,min(bpWet14) c14,min(bpWet15) c15,min(bpWet16) c16,min(bpWet17) c17,min(bpWet18) c18,min(bpWet19) c19,min(bpWet20) c20,min(bpWet21) c21,min(bpWet22) c22,min(bpWet23) c23,min(bpWet24) c24 from nova_data_t where mote_id=? group by mote_id";

      Object[] data = (Object[])(Object[])sess.createSQLQuery(query).addScalar("r1", org.hibernate.Hibernate.FLOAT).addScalar("r2", org.hibernate.Hibernate.FLOAT).addScalar("r3", org.hibernate.Hibernate.FLOAT).addScalar("r4", org.hibernate.Hibernate.FLOAT).addScalar("r5", org.hibernate.Hibernate.FLOAT).addScalar("r6", org.hibernate.Hibernate.FLOAT).addScalar("r7", org.hibernate.Hibernate.FLOAT).addScalar("r8", org.hibernate.Hibernate.FLOAT).addScalar("r9", org.hibernate.Hibernate.FLOAT).addScalar("r10", org.hibernate.Hibernate.FLOAT).addScalar("r11", org.hibernate.Hibernate.FLOAT).addScalar("r12", org.hibernate.Hibernate.FLOAT).addScalar("r13", org.hibernate.Hibernate.FLOAT).addScalar("r14", org.hibernate.Hibernate.FLOAT).addScalar("r15", org.hibernate.Hibernate.FLOAT).addScalar("r16", org.hibernate.Hibernate.FLOAT).addScalar("r17", org.hibernate.Hibernate.FLOAT).addScalar("r18", org.hibernate.Hibernate.FLOAT).addScalar("r19", org.hibernate.Hibernate.FLOAT).addScalar("r20", org.hibernate.Hibernate.FLOAT).addScalar("r21", org.hibernate.Hibernate.FLOAT).addScalar("r22", org.hibernate.Hibernate.FLOAT).addScalar("r23", org.hibernate.Hibernate.FLOAT).addScalar("r24", org.hibernate.Hibernate.FLOAT).addScalar("c1", org.hibernate.Hibernate.FLOAT).addScalar("c2", org.hibernate.Hibernate.FLOAT).addScalar("c3", org.hibernate.Hibernate.FLOAT).addScalar("c4", org.hibernate.Hibernate.FLOAT).addScalar("c5", org.hibernate.Hibernate.FLOAT).addScalar("c6", org.hibernate.Hibernate.FLOAT).addScalar("c7", org.hibernate.Hibernate.FLOAT).addScalar("c8", org.hibernate.Hibernate.FLOAT).addScalar("c9", org.hibernate.Hibernate.FLOAT).addScalar("c10", org.hibernate.Hibernate.FLOAT).addScalar("c11", org.hibernate.Hibernate.FLOAT).addScalar("c12", org.hibernate.Hibernate.FLOAT).addScalar("c13", org.hibernate.Hibernate.FLOAT).addScalar("c14", org.hibernate.Hibernate.FLOAT).addScalar("c15", org.hibernate.Hibernate.FLOAT).addScalar("c16", org.hibernate.Hibernate.FLOAT).addScalar("c17", org.hibernate.Hibernate.FLOAT).addScalar("c18", org.hibernate.Hibernate.FLOAT).addScalar("c19", org.hibernate.Hibernate.FLOAT).addScalar("c20", org.hibernate.Hibernate.FLOAT).addScalar("c21", org.hibernate.Hibernate.FLOAT).addScalar("c22", org.hibernate.Hibernate.FLOAT).addScalar("c23", org.hibernate.Hibernate.FLOAT).addScalar("c24", org.hibernate.Hibernate.FLOAT).setInteger(0, mote.getMote_id()).uniqueResult();

      Float[] results = new Float[48];
      float upperLimit = 0.0F;
      float lowerLimit = 0.0F;
      for (int i = 0; i < results.length; i++) {
        if (i < 24)
        {
          upperLimit = 204800.0F;
          lowerLimit = 2048.0F;
        }
        else {
          upperLimit = 2048000.0F;
          lowerLimit = 20480.0F;
        }

        float delta = upperLimit - lowerLimit;

        if ((data != null) && (data[i] != null)) {
          results[i] = Float.valueOf((delta - ((Float)data[i]).floatValue() - lowerLimit) / delta);
        }
        else
          results[i] = Float.valueOf(0.0F);
      }
      com.aginova.util.Hibernate.safeCommit(tx);
      i = results;
      return i;
    }
    catch (Exception e)
    {
      throw new RuntimeException(e);
    } finally {
      com.aginova.util.Hibernate.safeClose(sess); } throw localObject;
  }

  public void addSensors(List sensorsDescriptors)
  {
    super.addSensors(sensorsDescriptors);
    sensorsDescriptors.add(new DefaultSensorDescriptor("Corrosivity (1)", null, "bpCorr1", "bpCorr1", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_CORROSIVITY, "Corrosivity", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Corrosivity (2)", null, "bpCorr2", "bpCorr2", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_CORROSIVITY, "Corrosivity", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Corrosivity (3)", null, "bpCorr3", "bpCorr3", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_CORROSIVITY, "Corrosivity", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Corrosivity (4)", null, "bpCorr4", "bpCorr4", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_CORROSIVITY, "Corrosivity", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Corrosivity (5)", null, "bpCorr5", "bpCorr5", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_CORROSIVITY, "Corrosivity", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Corrosivity (6)", null, "bpCorr6", "bpCorr6", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_CORROSIVITY, "Corrosivity", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Corrosivity (7)", null, "bpCorr7", "bpCorr7", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_CORROSIVITY, "Corrosivity", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Corrosivity (8)", null, "bpCorr8", "bpCorr8", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_CORROSIVITY, "Corrosivity", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Corrosivity (9)", null, "bpCorr9", "bpCorr9", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_CORROSIVITY, "Corrosivity", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Corrosivity (10)", null, "bpCorr10", "bpCorr10", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_CORROSIVITY, "Corrosivity", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Corrosivity (11)", null, "bpCorr11", "bpCorr11", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_CORROSIVITY, "Corrosivity", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Corrosivity (12)", null, "bpCorr12", "bpCorr12", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_CORROSIVITY, "Corrosivity", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Corrosivity (13)", null, "bpCorr13", "bpCorr13", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_CORROSIVITY, "Corrosivity", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Corrosivity (14)", null, "bpCorr14", "bpCorr14", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_CORROSIVITY, "Corrosivity", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Corrosivity (15)", null, "bpCorr15", "bpCorr15", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_CORROSIVITY, "Corrosivity", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Corrosivity (16)", null, "bpCorr16", "bpCorr16", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_CORROSIVITY, "Corrosivity", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Corrosivity (17)", null, "bpCorr17", "bpCorr17", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_CORROSIVITY, "Corrosivity", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Corrosivity (18)", null, "bpCorr18", "bpCorr18", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_CORROSIVITY, "Corrosivity", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Corrosivity (19)", null, "bpCorr19", "bpCorr19", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_CORROSIVITY, "Corrosivity", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Corrosivity (20)", null, "bpCorr20", "bpCorr20", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_CORROSIVITY, "Corrosivity", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Corrosivity (21)", null, "bpCorr21", "bpCorr21", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_CORROSIVITY, "Corrosivity", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Corrosivity (22)", null, "bpCorr22", "bpCorr22", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_CORROSIVITY, "Corrosivity", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Corrosivity (23)", null, "bpCorr23", "bpCorr23", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_CORROSIVITY, "Corrosivity", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Corrosivity (24)", null, "bpCorr24", "bpCorr24", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_CORROSIVITY, "Corrosivity", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Wetness (1)", null, "bpWet1", "bpWet1", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_WETNESS, "Wetness", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Wetness (2)", null, "bpWet2", "bpWet2", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_WETNESS, "Wetness", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Wetness (3)", null, "bpWet3", "bpWet3", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_WETNESS, "Wetness", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Wetness (4)", null, "bpWet4", "bpWet4", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_WETNESS, "Wetness", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Wetness (5)", null, "bpWet5", "bpWet5", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_WETNESS, "Wetness", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Wetness (6)", null, "bpWet6", "bpWet6", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_WETNESS, "Wetness", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Wetness (7)", null, "bpWet7", "bpWet7", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_WETNESS, "Wetness", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Wetness (8)", null, "bpWet8", "bpWet8", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_WETNESS, "Wetness", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Wetness (9)", null, "bpWet9", "bpWet9", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_WETNESS, "Wetness", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Wetness (10)", null, "bpWet10", "bpWet10", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_WETNESS, "Wetness", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Wetness (11)", null, "bpWet11", "bpWet11", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_WETNESS, "Wetness", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Wetness (12)", null, "bpWet12", "bpWet12", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_WETNESS, "Wetness", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Wetness (13)", null, "bpWet13", "bpWet13", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_WETNESS, "Wetness", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Wetness (14)", null, "bpWet14", "bpWet14", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_WETNESS, "Wetness", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Wetness (15)", null, "bpWet15", "bpWet15", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_WETNESS, "Wetness", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Wetness (16)", null, "bpWet16", "bpWet16", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_WETNESS, "Wetness", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Wetness (17)", null, "bpWet17", "bpWet17", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_WETNESS, "Wetness", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Wetness (18)", null, "bpWet18", "bpWet18", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_WETNESS, "Wetness", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Wetness (19)", null, "bpWet19", "bpWet19", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_WETNESS, "Wetness", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Wetness (20)", null, "bpWet20", "bpWet20", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_WETNESS, "Wetness", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Wetness (21)", null, "bpWet21", "bpWet21", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_WETNESS, "Wetness", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Wetness (22)", null, "bpWet22", "bpWet22", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_WETNESS, "Wetness", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Wetness (23)", null, "bpWet23", "bpWet23", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_WETNESS, "Wetness", 1));

    sensorsDescriptors.add(new DefaultSensorDescriptor("Wetness (24)", null, "bpWet24", "bpWet24", "Ohm", Float.valueOf(0.0F), Float.valueOf(100.0F), 50, SENSOR_VIEW_COLORMAP, AXIS_TYPE_LINEAR, VISUAL_TYPE_STANDARD, AXIS_GROUP_WETNESS, "Wetness", 1));
  }
}