package nanoxml;

public class XMLParseException extends RuntimeException
{
  private int lineNr;

  public XMLParseException(String tag, String message)
  {
    super("XML Parse Exception during parsing of " + (tag == null ? "the XML definition" : new StringBuffer().append("a ").append(tag).append("-tag").toString()) + ": " + message);

    this.lineNr = -1;
  }

  public XMLParseException(String tag, int lineNr, String message)
  {
    super("XML Parse Exception during parsing of " + (tag == null ? "the XML definition" : new StringBuffer().append("a ").append(tag).append("-tag").toString()) + " at line " + lineNr + ": " + message);

    this.lineNr = lineNr;
  }

  public int getLineNr()
  {
    return this.lineNr;
  }
}