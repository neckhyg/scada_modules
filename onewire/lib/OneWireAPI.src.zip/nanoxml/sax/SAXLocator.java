package nanoxml.sax;

import org.xml.sax.Locator;

class SAXLocator
  implements Locator
{
  private String systemId;
  private int lineNr;

  SAXLocator(String systemId)
  {
    this.systemId = systemId;
    this.lineNr = -1;
  }

  void setLineNr(int lineNr)
  {
    this.lineNr = lineNr;
  }

  public String getPublicId()
  {
    return null;
  }

  public String getSystemId()
  {
    return this.systemId;
  }

  public int getLineNumber()
  {
    return this.lineNr;
  }

  public int getColumnNumber()
  {
    return -1;
  }
}