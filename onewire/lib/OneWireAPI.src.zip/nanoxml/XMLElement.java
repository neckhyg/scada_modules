package nanoxml;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.Serializable;
import java.io.StringWriter;
import java.io.Writer;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Vector;

public class XMLElement
  implements Serializable
{
  static final long serialVersionUID = 6685035139346394777L;
  public static final int NANOXML_MAJOR_VERSION = 1;
  public static final int NANOXML_MINOR_VERSION = 6;
  private Properties attributes;
  private Vector children;
  private String tagName;
  private String contents;
  private Properties conversionTable;
  private boolean skipLeadingWhitespace;
  private int lineNr;
  private boolean ignoreCase;

  public XMLElement()
  {
    this(new Properties(), false, true, true);
  }

  public XMLElement(Properties conversionTable)
  {
    this(conversionTable, false, true, true);
  }

  public XMLElement(boolean skipLeadingWhitespace)
  {
    this(new Properties(), skipLeadingWhitespace, true, true);
  }

  public XMLElement(Properties conversionTable, boolean skipLeadingWhitespace)
  {
    this(conversionTable, skipLeadingWhitespace, true, true);
  }

  public XMLElement(Properties conversionTable, boolean skipLeadingWhitespace, boolean ignoreCase)
  {
    this(conversionTable, skipLeadingWhitespace, true, ignoreCase);
  }

  protected XMLElement(Properties conversionTable, boolean skipLeadingWhitespace, boolean fillBasicConversionTable, boolean ignoreCase)
  {
    this.ignoreCase = ignoreCase;
    this.skipLeadingWhitespace = skipLeadingWhitespace;
    this.tagName = null;
    this.contents = "";
    this.attributes = new Properties();
    this.children = new Vector();
    this.conversionTable = conversionTable;
    this.lineNr = 0;

    if (fillBasicConversionTable)
    {
      this.conversionTable.put("lt", "<");
      this.conversionTable.put("gt", ">");
      this.conversionTable.put("quot", "\"");
      this.conversionTable.put("apos", "'");
      this.conversionTable.put("amp", "&");
    }
  }

  public void addChild(XMLElement child)
  {
    this.children.addElement(child);
  }

  public void addProperty(String key, Object value)
  {
    if (this.ignoreCase)
    {
      key = key.toUpperCase();
    }

    this.attributes.put(key, value.toString());
  }

  public void addProperty(String key, int value)
  {
    if (this.ignoreCase)
    {
      key = key.toUpperCase();
    }

    this.attributes.put(key, Integer.toString(value));
  }

  public void addProperty(String key, double value)
  {
    if (this.ignoreCase)
    {
      key = key.toUpperCase();
    }

    this.attributes.put(key, Double.toString(value));
  }

  public int countChildren()
  {
    return this.children.size();
  }

  public Enumeration enumeratePropertyNames()
  {
    return this.attributes.keys();
  }

  public Enumeration enumerateChildren()
  {
    return this.children.elements();
  }

  public Vector getChildren()
  {
    return this.children;
  }

  public String getContents()
  {
    return this.contents;
  }

  public int getLineNr()
  {
    return this.lineNr;
  }

  public int getIntProperty(String key, Hashtable valueSet, String defaultValue)
  {
    String val = this.attributes.getProperty(key);

    if (this.ignoreCase)
    {
      key = key.toUpperCase();
    }

    if (val == null)
    {
      val = defaultValue;
    }
    Integer result;
    try {
      result = (Integer)valueSet.get(val);
    }
    catch (ClassCastException e)
    {
      throw invalidValueSet(key);
    }

    if (result == null)
    {
      throw invalidValue(key, val, this.lineNr);
    }

    return result.intValue();
  }

  public String getProperty(String key)
  {
    if (this.ignoreCase)
    {
      key = key.toUpperCase();
    }

    return this.attributes.getProperty(key);
  }

  public String getProperty(String key, String defaultValue)
  {
    if (this.ignoreCase)
    {
      key = key.toUpperCase();
    }

    return this.attributes.getProperty(key, defaultValue);
  }

  public int getProperty(String key, int defaultValue)
  {
    if (this.ignoreCase)
    {
      key = key.toUpperCase();
    }

    String val = this.attributes.getProperty(key);

    if (val == null)
    {
      return defaultValue;
    }

    try
    {
      return Integer.parseInt(val);
    }
    catch (NumberFormatException e) {
    }
    throw invalidValue(key, val, this.lineNr);
  }

  public double getProperty(String key, double defaultValue)
  {
    if (this.ignoreCase)
    {
      key = key.toUpperCase();
    }

    String val = this.attributes.getProperty(key);

    if (val == null)
    {
      return defaultValue;
    }

    try
    {
      return Double.valueOf(val).doubleValue();
    }
    catch (NumberFormatException e) {
    }
    throw invalidValue(key, val, this.lineNr);
  }

  public boolean getProperty(String key, String trueValue, String falseValue, boolean defaultValue)
  {
    if (this.ignoreCase)
    {
      key = key.toUpperCase();
    }

    String val = this.attributes.getProperty(key);

    if (val == null)
    {
      return defaultValue;
    }
    if (val.equals(trueValue))
    {
      return true;
    }
    if (val.equals(falseValue))
    {
      return false;
    }

    throw invalidValue(key, val, this.lineNr);
  }

  public Object getProperty(String key, Hashtable valueSet, String defaultValue)
  {
    if (this.ignoreCase)
    {
      key = key.toUpperCase();
    }

    String val = this.attributes.getProperty(key);

    if (val == null)
    {
      val = defaultValue;
    }

    Object result = valueSet.get(val);

    if (result == null)
    {
      throw invalidValue(key, val, this.lineNr);
    }

    return result;
  }

  public String getStringProperty(String key, Hashtable valueSet, String defaultValue)
  {
    if (this.ignoreCase)
    {
      key = key.toUpperCase();
    }

    String val = this.attributes.getProperty(key);

    if (val == null)
    {
      val = defaultValue;
    }
    String result;
    try {
      result = (String)valueSet.get(val);
    }
    catch (ClassCastException e)
    {
      throw invalidValueSet(key);
    }

    if (result == null)
    {
      throw invalidValue(key, val, this.lineNr);
    }

    return result;
  }

  public int getSpecialIntProperty(String key, Hashtable valueSet, String defaultValue)
  {
    if (this.ignoreCase)
    {
      key = key.toUpperCase();
    }

    String val = this.attributes.getProperty(key);

    if (val == null)
    {
      val = defaultValue;
    }
    Integer result;
    try {
      result = (Integer)valueSet.get(val);
    }
    catch (ClassCastException e)
    {
      throw invalidValueSet(key);
    }

    if (result == null)
    {
      try
      {
        return Integer.parseInt(val);
      }
      catch (NumberFormatException e)
      {
        throw invalidValue(key, val, this.lineNr);
      }
    }

    return result.intValue();
  }

  public double getSpecialDoubleProperty(String key, Hashtable valueSet, String defaultValue)
  {
    if (this.ignoreCase)
    {
      key = key.toUpperCase();
    }

    String val = this.attributes.getProperty(key);

    if (val == null)
    {
      val = defaultValue;
    }
    Double result;
    try {
      result = (Double)valueSet.get(val);
    }
    catch (ClassCastException e)
    {
      throw invalidValueSet(key);
    }

    if (result == null)
    {
      try
      {
        result = Double.valueOf(val);
      }
      catch (NumberFormatException e)
      {
        throw invalidValue(key, val, this.lineNr);
      }
    }

    return result.doubleValue();
  }

  public String getTagName()
  {
    return this.tagName;
  }

  private boolean isIdentifierChar(char ch)
  {
    return ((ch >= 'A') && (ch <= 'Z')) || ((ch >= 'a') && (ch <= 'z')) || ((ch >= '0') && (ch <= '9')) || (".-_:".indexOf(ch) >= 0);
  }

  public void parseFromReader(Reader reader)
    throws IOException, XMLParseException
  {
    parseFromReader(reader, 1);
  }

  public void parseFromReader(Reader reader, int startingLineNr)
    throws IOException, XMLParseException
  {
    int blockSize = 4096;
    char[] input = null;
    int size = 0;
    while (true)
    {
      if (input == null)
      {
        input = new char[blockSize];
      }
      else
      {
        char[] oldInput = input;
        input = new char[input.length + blockSize];
        System.arraycopy(oldInput, 0, input, 0, oldInput.length);
      }

      int charsRead = reader.read(input, size, blockSize);

      if (charsRead < 0)
      {
        break;
      }

      size += charsRead;
    }

    parseCharArray(input, 0, size, startingLineNr);
  }

  public void parseString(String string)
    throws XMLParseException
  {
    parseCharArray(string.toCharArray(), 0, string.length(), 1);
  }

  public int parseString(String string, int offset)
    throws XMLParseException
  {
    return parseCharArray(string.toCharArray(), offset, string.length(), 1);
  }

  public int parseString(String string, int offset, int end)
    throws XMLParseException
  {
    return parseCharArray(string.toCharArray(), offset, end, 1);
  }

  public int parseString(String string, int offset, int end, int startingLineNr)
    throws XMLParseException
  {
    return parseCharArray(string.toCharArray(), offset, end, startingLineNr);
  }

  public int parseCharArray(char[] input, int offset, int end)
    throws XMLParseException
  {
    return parseCharArray(input, offset, end, 1);
  }

  public int parseCharArray(char[] input, int offset, int end, int startingLineNr)
    throws XMLParseException
  {
    int[] lineNr = new int[1];
    lineNr[0] = startingLineNr;
    return parseCharArray(input, offset, end, lineNr);
  }

  private int parseCharArray(char[] input, int offset, int end, int[] currentLineNr)
    throws XMLParseException
  {
    this.lineNr = currentLineNr[0];
    this.tagName = null;
    this.contents = null;
    this.attributes = new Properties();
    this.children = new Vector();
    try
    {
      offset = skipWhitespace(input, offset, end, currentLineNr);
    }
    catch (XMLParseException e)
    {
      return offset;
    }

    offset = skipPreamble(input, offset, end, currentLineNr);
    offset = scanTagName(input, offset, end, currentLineNr);
    this.lineNr = currentLineNr[0];
    offset = scanAttributes(input, offset, end, currentLineNr);
    int[] contentOffset = new int[1];
    int[] contentSize = new int[1];
    int contentLineNr = currentLineNr[0];
    offset = scanContent(input, offset, end, contentOffset, contentSize, currentLineNr);

    if (contentSize[0] > 0)
    {
      scanChildren(input, contentOffset[0], contentSize[0], contentLineNr);

      if (this.children.size() > 0)
      {
        this.contents = null;
      }
      else
      {
        processContents(input, contentOffset[0], contentSize[0], contentLineNr);

        for (int i = 0; i < this.contents.length(); i++) {
          if (this.contents.charAt(i) > ' ') {
            return offset;
          }
        }

        this.contents = null;
      }
    }

    return offset;
  }

  private void processContents(char[] input, int contentOffset, int contentSize, int contentLineNr)
    throws XMLParseException
  {
    int[] lineNr = new int[1];
    lineNr[0] = contentLineNr;

    if (!this.skipLeadingWhitespace)
    {
      String str = new String(input, contentOffset, contentSize);
      this.contents = decodeString(str, lineNr[0]);
      return;
    }

    StringBuffer result = new StringBuffer(contentSize);
    int end = contentSize + contentOffset;

    for (int i = contentOffset; i < end; i++)
    {
      char ch = input[i];

      while ((ch == '\r') || (ch == '\n'))
      {
        lineNr[0] += 1;
        result.append(ch);

        i++;
        ch = input[i];

        if (ch != '\n')
        {
          result.append(ch);
        }

        do
        {
          i++;
          ch = input[i];
        }while ((ch == ' ') || (ch == '\t'));
      }

      if (i >= end)
        continue;
      result.append(input[i]);
    }

    this.contents = decodeString(result.toString(), lineNr[0]);
  }

  public void removeChild(XMLElement child)
  {
    this.children.removeElement(child);
  }

  public void removeChild(String key)
  {
    if (this.ignoreCase)
    {
      key = key.toUpperCase();
    }

    this.attributes.remove(key);
  }

  private int scanAttributes(char[] input, int offset, int end, int[] lineNr)
    throws XMLParseException
  {
    while (true)
    {
      offset = skipWhitespace(input, offset, end, lineNr);

      char ch = input[offset];

      if ((ch == '/') || (ch == '>'))
      {
        break;
      }

      offset = scanOneAttribute(input, offset, end, lineNr);
    }

    return offset;
  }

  protected void scanChildren(char[] input, int contentOffset, int contentSize, int contentLineNr)
    throws XMLParseException
  {
    int end = contentOffset + contentSize;
    int offset = contentOffset;
    int[] lineNr = new int[1];
    lineNr[0] = contentLineNr;

    while (offset < end)
    {
      try
      {
        offset = skipWhitespace(input, offset, end, lineNr);
      }
      catch (XMLParseException e)
      {
        return;
      }

      if ((input[offset] != '<') || ((input[(offset + 1)] == '!') && (input[(offset + 2)] == '[')))
      {
        return;
      }

      XMLElement child = createAnotherElement();
      offset = child.parseCharArray(input, offset, end, lineNr);
      this.children.addElement(child);
    }
  }

  protected XMLElement createAnotherElement()
  {
    return new XMLElement(this.conversionTable, this.skipLeadingWhitespace, false, this.ignoreCase);
  }

  private int scanContent(char[] input, int offset, int end, int[] contentOffset, int[] contentSize, int[] lineNr)
    throws XMLParseException
  {
    if (input[offset] == '/')
    {
      contentSize[0] = 0;

      if (input[(offset + 1)] != '>')
      {
        throw expectedInput("'>'", lineNr[0]);
      }

      return offset + 2;
    }

    if (input[offset] != '>')
    {
      throw expectedInput("'>'", lineNr[0]);
    }

    if (this.skipLeadingWhitespace)
    {
      offset = skipWhitespace(input, offset + 1, end, lineNr);
    }
    else
    {
      offset++;
    }

    contentOffset[0] = offset;
    int level = 0;
    char[] tag = this.tagName.toCharArray();
    end -= tag.length + 2;

    while ((offset < end) && (level >= 0))
    {
      if (input[offset] == '<')
      {
        boolean ok = true;

        if ((offset < end - 3) && (input[(offset + 1)] == '!') && (input[(offset + 2)] == '-') && (input[(offset + 3)] == '-'))
        {
          offset += 3;

          while ((offset < end) && ((input[(offset - 2)] != '-') || (input[(offset - 1)] != '-') || (input[(offset - 0)] != '>')))
          {
            offset++;
          }

          offset++;
          continue;
        }

        if ((offset < end - 1) && (input[(offset + 1)] == '!') && (input[(offset + 2)] == '['))
        {
          offset++;
          continue;
        }

        for (int i = 0; (ok) && (i < tag.length); i++)
        {
          ok &= input[(offset + (i + 1))] == tag[i];
        }

        ok &= !isIdentifierChar(input[(offset + tag.length + 1)]);

        if (ok)
        {
          while ((offset < end) && (input[offset] != '>'))
          {
            offset++;
          }

          if (input[(offset - 1)] == '/')
            continue;
          level++; continue;
        }

        if (input[(offset + 1)] == '/')
        {
          ok = true;

          for (int i = 0; (ok) && (i < tag.length); i++)
          {
            ok &= input[(offset + (i + 2))] == tag[i];
          }

          if (ok)
          {
            contentSize[0] = (offset - contentOffset[0]);
            offset += tag.length + 2;
            try
            {
              offset = skipWhitespace(input, offset, end + tag.length + 2, lineNr);
            }
            catch (XMLParseException e)
            {
            }

            if (input[offset] != '>')
              continue;
            level--;
            offset++; continue;
          }

        }

      }

      if (input[offset] == '\r')
      {
        lineNr[0] += 1;

        if ((offset != end) && (input[(offset + 1)] == '\n'))
        {
          offset++;
        }
      }
      else if (input[offset] == '\n')
      {
        lineNr[0] += 1;
      }

      offset++;
    }

    if (level >= 0)
    {
      throw unexpectedEndOfData(lineNr[0]);
    }

    if (this.skipLeadingWhitespace)
    {
      int i = contentOffset[0] + contentSize[0] - 1;

      while ((contentSize[0] >= 0) && (input[i] <= ' '))
      {
        i--;
        contentSize[0] -= 1;
      }
    }

    return offset;
  }

  private String scanIdentifier(char[] input, int offset, int end)
  {
    int begin = offset;

    while ((offset < end) && (isIdentifierChar(input[offset])))
    {
      offset++;
    }

    if ((offset == end) || (offset == begin))
    {
      return null;
    }

    return new String(input, begin, offset - begin);
  }

  private int scanOneAttribute(char[] input, int offset, int end, int[] lineNr)
    throws XMLParseException
  {
    String key = scanIdentifier(input, offset, end);

    if (key == null)
    {
      throw syntaxError("an attribute key", lineNr[0]);
    }

    offset = skipWhitespace(input, offset + key.length(), end, lineNr);

    if (this.ignoreCase)
    {
      key = key.toUpperCase();
    }

    if (input[offset] != '=')
    {
      throw valueMissingForAttribute(key, lineNr[0]);
    }

    offset = skipWhitespace(input, offset + 1, end, lineNr);

    String value = scanString(input, offset, end, lineNr);

    if (value == null)
    {
      throw syntaxError("an attribute value", lineNr[0]);
    }

    if ((value.charAt(0) == '"') || (value.charAt(0) == '\''))
    {
      value = value.substring(1, value.length() - 1);
      offset += 2;
    }

    this.attributes.put(key, decodeString(value, lineNr[0]));
    return offset + value.length();
  }

  private String scanString(char[] input, int offset, int end, int[] lineNr)
    throws XMLParseException
  {
    char delim = input[offset];

    if ((delim == '"') || (delim == '\''))
    {
      int begin = offset;
      offset++;

      while ((offset < end) && (input[offset] != delim))
      {
        if (input[offset] == '\r')
        {
          lineNr[0] += 1;

          if ((offset != end) && (input[(offset + 1)] == '\n'))
          {
            offset++;
          }
        }
        else if (input[offset] == '\n')
        {
          lineNr[0] += 1;
        }

        offset++;
      }

      if (offset == end)
      {
        return null;
      }

      return new String(input, begin, offset - begin + 1);
    }

    return scanIdentifier(input, offset, end);
  }

  private int scanTagName(char[] input, int offset, int end, int[] lineNr)
    throws XMLParseException
  {
    this.tagName = scanIdentifier(input, offset, end);

    if (this.tagName == null)
    {
      throw syntaxError("a tag name", lineNr[0]);
    }

    return offset + this.tagName.length();
  }

  public void setContent(String content)
  {
    this.contents = content;
  }

  public void setTagName(String tagName)
  {
    this.tagName = tagName;
  }

  protected int skipBogusTag(char[] input, int offset, int end, int[] lineNr)
  {
    int level = 1;

    while (offset < end)
    {
      char ch = input[(offset++)];

      switch (ch)
      {
      case '\r':
        if ((offset < end) && (input[offset] == '\n'))
        {
          offset++;
        }

        lineNr[0] += 1;
        break;
      case '\n':
        lineNr[0] += 1;
        break;
      case '<':
        level++;
        break;
      case '>':
        level--;

        if (level != 0) continue;
        return offset;
      }

    }

    throw unexpectedEndOfData(lineNr[0]);
  }

  private int skipPreamble(char[] input, int offset, int end, int[] lineNr)
    throws XMLParseException
  {
    char ch;
    do
    {
      offset = skipWhitespace(input, offset, end, lineNr);

      if (input[offset] != '<')
      {
        expectedInput("'<'", lineNr[0]);
      }

      offset++;

      if (offset >= end)
      {
        throw unexpectedEndOfData(lineNr[0]);
      }

      ch = input[offset];

      if ((ch != '!') && (ch != '?'))
        continue;
      offset = skipBogusTag(input, offset, end, lineNr);
    }
    while (!isIdentifierChar(ch));

    return offset;
  }

  private int skipWhitespace(char[] input, int offset, int end, int[] lineNr)
  {
    int startLine = lineNr[0];

    while (offset < end)
    {
      if ((offset + 6 < end) && (input[(offset + 3)] == '-') && (input[(offset + 2)] == '-') && (input[(offset + 1)] == '!') && (input[offset] == '<'))
      {
        offset += 4;

        while ((input[offset] != '-') || (input[(offset + 1)] != '-') || (input[(offset + 2)] != '>'))
        {
          if (offset + 2 >= end)
          {
            throw unexpectedEndOfData(startLine);
          }

          offset++;
        }

        offset += 2;
      }
      else if (input[offset] == '\r')
      {
        lineNr[0] += 1;

        if ((offset != end) && (input[(offset + 1)] == '\n'))
        {
          offset++;
        }
      }
      else if (input[offset] == '\n')
      {
        lineNr[0] += 1;
      } else {
        if (input[offset] > ' ')
        {
          break;
        }
      }
      offset++;
    }

    if (offset == end)
    {
      throw unexpectedEndOfData(startLine);
    }

    return offset;
  }

  protected String decodeString(String s, int lineNr)
  {
    StringBuffer result = new StringBuffer(s.length());
    int index = 0;

    while (index < s.length())
    {
      int index2 = (s + '&').indexOf('&', index);
      int index3 = (s + "<![CDATA[").indexOf("<![CDATA[", index);
      int index4 = (s + "<!--").indexOf("<!--", index);

      if ((index2 <= index3) && (index2 <= index4))
      {
        result.append(s.substring(index, index2));

        if (index2 == s.length())
        {
          break;
        }

        index = s.indexOf(';', index2);

        if (index < 0)
        {
          result.append(s.substring(index2));
          break;
        }

        String key = s.substring(index2 + 1, index);

        if (key.charAt(0) == '#')
        {
          if (key.charAt(1) == 'x')
          {
            result.append((char)Integer.parseInt(key.substring(2), 16));
          }
          else
          {
            result.append((char)Integer.parseInt(key.substring(1), 10));
          }

        }
        else
        {
          result.append(this.conversionTable.getProperty(key, "&" + key + ';'));
        }

      }
      else if (index3 <= index4)
      {
        int end = (s + "]]>").indexOf("]]>", index3 + 9);
        result.append(s.substring(index, index3));
        result.append(s.substring(index3 + 9, end));
        index = end + 2;
      }
      else
      {
        result.append(s.substring(index, index4));
        index = (s + "-->").indexOf("-->", index4) + 2;
      }

      index++;
    }

    return result.toString();
  }

  public String toString()
  {
    StringWriter writer = new StringWriter();
    write(writer);
    return writer.toString();
  }

  public void write(Writer writer)
  {
    write(writer, 0);
  }

  public void write(Writer writer, int indent)
  {
    PrintWriter out = new PrintWriter(writer);

    for (int i = 0; i < indent; i++)
    {
      out.print(' ');
    }

    if (this.tagName == null)
    {
      writeEncoded(out, this.contents);
      return;
    }

    out.print('<');
    out.print(this.tagName);

    if (!this.attributes.isEmpty())
    {
      Enumeration l_enum = this.attributes.keys();

      while (l_enum.hasMoreElements())
      {
        out.print(' ');
        String key = (String)l_enum.nextElement();
        String value = (String)this.attributes.get(key);
        out.print(key);
        out.print("=\"");
        writeEncoded(out, value);
        out.print('"');
      }
    }

    if ((this.contents != null) && (this.contents.length() > 0))
    {
      if (this.skipLeadingWhitespace)
      {
        out.println('>');

        for (int i = 0; i < indent + 4; i++)
        {
          out.print(' ');
        }

        out.println(this.contents);

        for (int i = 0; i < indent; i++)
        {
          out.print(' ');
        }
      }
      else
      {
        out.print('>');
        writeEncoded(out, this.contents);
      }

      out.print("</");
      out.print(this.tagName);
      out.println('>');
    }
    else if (this.children.isEmpty())
    {
      out.println("/>");
    }
    else {
      out.println('>');
      Enumeration l_enum = enumerateChildren();

      while (l_enum.hasMoreElements())
      {
        XMLElement child = (XMLElement)l_enum.nextElement();
        child.write(writer, indent + 4);
      }

      for (int i = 0; i < indent; i++)
      {
        out.print(' ');
      }

      out.print("</");
      out.print(this.tagName);
      out.println('>');
    }
  }

  protected void writeEncoded(PrintWriter out, String str)
  {
    for (int i = 0; i < str.length(); i++)
    {
      char ch = str.charAt(i);

      switch (ch)
      {
      case '<':
        out.write("&lt;");
        break;
      case '>':
        out.write("&gt;");
        break;
      case '&':
        out.write("&amp;");
        break;
      case '"':
        out.write("&quot;");
        break;
      case '\'':
        out.write("&apos;");
        break;
      case '\n':
      case '\r':
        out.write(ch);
        break;
      default:
        if ((ch < ' ') || (ch > '~'))
        {
          out.write("&#x");
          out.write(Integer.toString(ch, 16));
          out.write(59);
        }
        else
        {
          out.write(ch);
        }
      }
    }
  }

  private XMLParseException invalidValueSet(String key)
  {
    String msg = "Invalid value set (key = \"" + key + "\")";
    return new XMLParseException(getTagName(), msg);
  }

  private XMLParseException invalidValue(String key, String value, int lineNr)
  {
    String msg = "Attribute \"" + key + "\" does not contain a valid " + "value (\"" + value + "\")";

    return new XMLParseException(getTagName(), lineNr, msg);
  }

  private XMLParseException unexpectedEndOfData(int lineNr)
  {
    String msg = "Unexpected end of data reached";
    return new XMLParseException(getTagName(), lineNr, msg);
  }

  private XMLParseException syntaxError(String context, int lineNr)
  {
    String msg = "Syntax error while parsing " + context;
    return new XMLParseException(getTagName(), lineNr, msg);
  }

  private XMLParseException expectedInput(String charSet, int lineNr)
  {
    String msg = "Expected: " + charSet;
    return new XMLParseException(getTagName(), lineNr, msg);
  }

  private XMLParseException valueMissingForAttribute(String key, int lineNr)
  {
    String msg = "Value missing for attribute with key \"" + key + "\"";
    return new XMLParseException(getTagName(), lineNr, msg);
  }
}