package org.xml.sax;

public class SAXParseException extends SAXException
{
  private String publicId;
  private String systemId;
  private int lineNumber;
  private int columnNumber;

  public SAXParseException(String message, Locator locator)
  {
    super(message);
    this.publicId = locator.getPublicId();
    this.systemId = locator.getSystemId();
    this.lineNumber = locator.getLineNumber();
    this.columnNumber = locator.getColumnNumber();
  }

  public SAXParseException(String message, Locator locator, Exception e)
  {
    super(message, e);
    this.publicId = locator.getPublicId();
    this.systemId = locator.getSystemId();
    this.lineNumber = locator.getLineNumber();
    this.columnNumber = locator.getColumnNumber();
  }

  public SAXParseException(String message, String publicId, String systemId, int lineNumber, int columnNumber)
  {
    super(message);
    this.publicId = publicId;
    this.systemId = systemId;
    this.lineNumber = lineNumber;
    this.columnNumber = columnNumber;
  }

  public SAXParseException(String message, String publicId, String systemId, int lineNumber, int columnNumber, Exception e)
  {
    super(message, e);
    this.publicId = publicId;
    this.systemId = systemId;
    this.lineNumber = lineNumber;
    this.columnNumber = columnNumber;
  }

  public String getPublicId()
  {
    return this.publicId;
  }

  public String getSystemId()
  {
    return this.systemId;
  }

  public int getLineNumber()
  {
    return this.lineNumber;
  }

  public int getColumnNumber()
  {
    return this.columnNumber;
  }
}