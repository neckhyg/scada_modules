package org.xml.sax;

public class SAXException extends Exception
{
  private String message;
  private Exception exception;

  public SAXException(String message)
  {
    this.message = message;
    this.exception = null;
  }

  public SAXException(Exception e)
  {
    this.message = null;
    this.exception = e;
  }

  public SAXException(String message, Exception e)
  {
    this.message = message;
    this.exception = e;
  }

  public String getMessage()
  {
    if ((this.message == null) && (this.exception != null)) {
      return this.exception.getMessage();
    }
    return this.message;
  }

  public Exception getException()
  {
    return this.exception;
  }

  public String toString()
  {
    return getMessage();
  }
}