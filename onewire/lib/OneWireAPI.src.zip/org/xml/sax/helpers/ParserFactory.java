package org.xml.sax.helpers;

import org.xml.sax.Parser;

public class ParserFactory
{
  public static Parser makeParser()
    throws ClassNotFoundException, IllegalAccessException, InstantiationException, NullPointerException, ClassCastException
  {
    String className = System.getProperty("org.xml.sax.parser");
    if (className == null) {
      throw new NullPointerException("No value for sax.parser property");
    }
    return makeParser(className);
  }

  public static Parser makeParser(String className)
    throws ClassNotFoundException, IllegalAccessException, InstantiationException, ClassCastException
  {
    return (Parser)Class.forName(className).newInstance();
  }
}