package com.dalsemi.onewire.utils;

public class SHA
{
  private static final int[] KTN = { 1518500249, 1859775393, -1894007588, -899497514 };
  private static final int H0 = 1732584193;
  private static final int H1 = -271733879;
  private static final int H2 = -1732584194;
  private static final int H3 = 271733878;
  private static final int H4 = -1009589776;
  private static int word;
  private static int i;
  private static int j;
  private static int ShftTmp;
  private static int Temp;
  private static final int[] MTword;
  private static final int[] H = new int[5];

  public static final synchronized byte[] ComputeSHA(byte[] MT, byte[] result, int offset)
  {
    ComputeSHA(MT, H);

    for (i = 0; i < 5; i += 1)
    {
      word = H[(4 - i)];
      j = (i << 2) + offset;
      result[(j + 0)] = (byte)(word & 0xFF);
      result[(j + 1)] = (byte)(word >>> 8 & 0xFF);
      result[(j + 2)] = (byte)(word >>> 16 & 0xFF);
      result[(j + 3)] = (byte)(word >>> 24 & 0xFF);
    }

    return result;
  }

  public static final synchronized void ComputeSHA(byte[] MT, int[] ABCDE)
  {
    for (i = 0; i < 16; i += 1) {
      MTword[i] = ((MT[(i * 4)] & 0xFF) << 24 | (MT[(i * 4 + 1)] & 0xFF) << 16 | (MT[(i * 4 + 2)] & 0xFF) << 8 | MT[(i * 4 + 3)] & 0xFF);
    }

    for (i = 16; i < 80; i += 1)
    {
      ShftTmp = MTword[(i - 3)] ^ MTword[(i - 8)] ^ MTword[(i - 14)] ^ MTword[(i - 16)];
      MTword[i] = (ShftTmp << 1 & 0xFFFFFFFE | ShftTmp >>> 31 & 0x1);
    }

    ABCDE[0] = 1732584193;
    ABCDE[1] = -271733879;
    ABCDE[2] = -1732584194;
    ABCDE[3] = 271733878;
    ABCDE[4] = -1009589776;

    for (i = 0; i < 80; i += 1)
    {
      ShftTmp = ABCDE[0] << 5 & 0xFFFFFFE0 | ABCDE[0] >>> 27 & 0x1F;
      Temp = NLF(ABCDE[1], ABCDE[2], ABCDE[3], i) + ABCDE[4] + KTN[(i / 20)] + MTword[i] + ShftTmp;
      ABCDE[4] = ABCDE[3];
      ABCDE[3] = ABCDE[2];
      ABCDE[2] = (ABCDE[1] << 30 & 0xC0000000 | ABCDE[1] >>> 2 & 0x3FFFFFFF);
      ABCDE[1] = ABCDE[0];
      ABCDE[0] = Temp;
    }
  }

  private static final int NLF(int B, int C, int D, int n)
  {
    if (n < 20)
      return B & C | (B ^ 0xFFFFFFFF) & D;
    if (n < 40)
      return B ^ C ^ D;
    if (n < 60) {
      return B & C | B & D | C & D;
    }
    return B ^ C ^ D;
  }

  static
  {
    MTword = new int[80];
  }
}