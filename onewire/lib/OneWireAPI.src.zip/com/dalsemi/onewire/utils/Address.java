package com.dalsemi.onewire.utils;

public class Address
{
  public static boolean isValid(byte[] address)
  {
    if ((address[0] != 0) && (CRC8.compute(address) == 0))
      return true;
    if ((address[0] & 0x7F) == 28)
    {
      return 0 == CRC8.compute(address, 2, 6, CRC8.compute(127, CRC8.compute(address[0], 0)));
    }

    return false;
  }

  public static boolean isValid(String address)
  {
    return isValid(toByteArray(address));
  }

  public static boolean isValid(long address)
  {
    return isValid(toByteArray(address));
  }

  public static String toString(byte[] address)
  {
    byte[] barr = new byte[16];
    int index = 0;

    for (int i = 7; i >= 0; i--)
    {
      int ch = address[i] >> 4 & 0xF;
      ch += (ch > 9 ? 55 : 48);
      barr[(index++)] = (byte)ch;
      ch = address[i] & 0xF;
      ch += (ch > 9 ? 55 : 48);
      barr[(index++)] = (byte)ch;
    }

    return new String(barr);
  }

  public static String toString(long address)
  {
    return toString(toByteArray(address));
  }

  public static byte[] toByteArray(String address)
  {
    byte[] address_byte = new byte[8];

    for (int i = 0; i < 8; i++)
    {
      address_byte[(7 - i)] = (byte)(Character.digit(address.charAt(i * 2), 16) << 4 | Character.digit(address.charAt(i * 2 + 1), 16));
    }

    return address_byte;
  }

  public static byte[] toByteArray(long address)
  {
    byte[] address_byte = new byte[8];

    address_byte[0] = (byte)(int)address;
    address >>>= 8;
    address_byte[1] = (byte)(int)address;
    address >>>= 8;
    address_byte[2] = (byte)(int)address;
    address >>>= 8;
    address_byte[3] = (byte)(int)address;
    address >>>= 8;
    address_byte[4] = (byte)(int)address;
    address >>>= 8;
    address_byte[5] = (byte)(int)address;
    address >>>= 8;
    address_byte[6] = (byte)(int)address;
    address >>>= 8;
    address_byte[7] = (byte)(int)address;

    return address_byte;
  }

  public static long toLong(byte[] address)
  {
    long longVal = address[7] & 0xFF;
    longVal <<= 8;
    longVal |= address[6] & 0xFF;
    longVal <<= 8;
    longVal |= address[5] & 0xFF;
    longVal <<= 8;
    longVal |= address[4] & 0xFF;
    longVal <<= 8;
    longVal |= address[3] & 0xFF;
    longVal <<= 8;
    longVal |= address[2] & 0xFF;
    longVal <<= 8;
    longVal |= address[1] & 0xFF;
    longVal <<= 8;
    longVal |= address[0] & 0xFF;

    return longVal;
  }

  public static long toLong(String address)
  {
    return toLong(toByteArray(address));
  }
}