package com.dalsemi.onewire.utils;

public class Bit
{
  public static void arrayWriteBit(int state, int index, int offset, byte[] buf)
  {
    int nbyt = index >>> 3;
    int nbit = index - (nbyt << 3);

    if (state == 1)
    {
      int tmp23_22 = (nbyt + offset);
      byte[] tmp23_18 = buf; tmp23_18[tmp23_22] = (byte)(tmp23_18[tmp23_22] | 1 << nbit);
    }
    else
    {
      int tmp40_39 = (nbyt + offset);
      byte[] tmp40_35 = buf; tmp40_35[tmp40_39] = (byte)(tmp40_35[tmp40_39] & (1 << nbit ^ 0xFFFFFFFF));
    }
  }

  public static int arrayReadBit(int index, int offset, byte[] buf)
  {
    int nbyt = index >>> 3;
    int nbit = index - (nbyt << 3);

    return buf[(nbyt + offset)] >>> nbit & 0x1;
  }
}