package com.dalsemi.onewire.utils;

import com.dalsemi.onewire.container.OneWireContainer;

public class OWPathElement
{
  private OneWireContainer owc;
  private int channel;

  private OWPathElement()
  {
  }

  public OWPathElement(OneWireContainer owcInstance, int channelNumber)
  {
    this.owc = owcInstance;
    this.channel = channelNumber;
  }

  public OneWireContainer getContainer()
  {
    return this.owc;
  }

  public int getChannel()
  {
    return this.channel;
  }
}