package com.dalsemi.onewire.utils;

public class CRC16
{
  private static final int[] ODD_PARITY = { 0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0 };

  public static int compute(int dataToCrc)
  {
    return compute(dataToCrc, 0);
  }

  public static int compute(int dataToCrc, int seed)
  {
    int dat = (dataToCrc ^ seed & 0xFF) & 0xFF;

    seed = (seed & 0xFFFF) >>> 8;

    int indx1 = dat & 0xF;
    int indx2 = dat >>> 4;

    if ((ODD_PARITY[indx1] ^ ODD_PARITY[indx2]) == 1) {
      seed ^= 49153;
    }
    dat <<= 6;
    seed ^= dat;
    dat <<= 1;
    seed ^= dat;

    return seed;
  }

  public static int compute(byte[] dataToCrc)
  {
    return compute(dataToCrc, 0, dataToCrc.length, 0);
  }

  public static int compute(byte[] dataToCrc, int off, int len)
  {
    return compute(dataToCrc, off, len, 0);
  }

  public static int compute(byte[] dataToCrc, int off, int len, int seed)
  {
    for (int i = 0; i < len; i++) {
      seed = compute(dataToCrc[(i + off)], seed);
    }
    return seed;
  }

  public static int compute(byte[] dataToCrc, int seed)
  {
    return compute(dataToCrc, 0, dataToCrc.length, seed);
  }
}