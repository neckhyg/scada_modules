package com.dalsemi.onewire.utils;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import com.dalsemi.onewire.container.OneWireContainer;
import com.dalsemi.onewire.container.OneWireSensor;
import com.dalsemi.onewire.container.SwitchContainer;
import java.util.Enumeration;
import java.util.Vector;

public class OWPath
{
  private Vector elements;
  private DSPortAdapter adapter;

  public OWPath(DSPortAdapter adapter)
  {
    this.adapter = adapter;
    this.elements = new Vector(2, 1);
  }

  public OWPath(DSPortAdapter adapter, OWPath currentOWPath)
  {
    this.adapter = adapter;
    this.elements = new Vector(2, 1);

    copy(currentOWPath);
  }

  public void copy(OWPath currentOWPath)
  {
    this.elements.removeAllElements();

    if (currentOWPath != null)
    {
      Enumeration path_enum = currentOWPath.getAllOWPathElements();
      while (path_enum.hasMoreElements())
      {
        this.elements.addElement((OWPathElement)path_enum.nextElement());
      }
    }
  }

  public void add(OneWireContainer owc, int channel)
  {
    this.elements.addElement(new OWPathElement(owc, channel));
  }

  public boolean equals(OWPath compareOWPath)
  {
    return toString().equals(compareOWPath.toString());
  }

  public Enumeration getAllOWPathElements()
  {
    return this.elements.elements();
  }

  public String toString()
  {
    String st = new String("");
    try
    {
      st = this.adapter.getAdapterName() + "_" + this.adapter.getPortName() + "/";
    }
    catch (OneWireException e)
    {
      st = this.adapter.getAdapterName() + "/";
    }

    for (int i = 0; i < this.elements.size(); i++)
    {
      OWPathElement element = (OWPathElement)this.elements.elementAt(i);
      OneWireContainer owc = element.getContainer();

      st = st + owc.getAddressAsString() + "_" + element.getChannel() + "/";
    }

    return st;
  }

  public void open()
    throws OneWireException, OneWireIOException
  {
    for (int i = 0; i < this.elements.size(); i++)
    {
      OWPathElement path_element = (OWPathElement)this.elements.elementAt(i);

      SwitchContainer sw = (SwitchContainer)path_element.getContainer();

      byte[] sw_state = sw.readDevice();

      sw.setLatchState(path_element.getChannel(), true, sw.hasSmartOn(), sw_state);

      sw.writeDevice(sw_state);
    }

    if (this.elements.size() == 0)
    {
      this.adapter.reset();
    }
  }

  public void close()
    throws OneWireException, OneWireIOException
  {
    for (int i = this.elements.size() - 1; i >= 0; i--)
    {
      OWPathElement path_element = (OWPathElement)this.elements.elementAt(i);

      SwitchContainer sw = (SwitchContainer)path_element.getContainer();

      byte[] sw_state = sw.readDevice();
      sw.setLatchState(path_element.getChannel(), false, false, sw_state);
      sw.writeDevice(sw_state);
    }
  }
}