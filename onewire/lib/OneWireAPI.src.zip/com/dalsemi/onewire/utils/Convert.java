package com.dalsemi.onewire.utils;

public class Convert
{
  private static final char[] lookup_hex = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
  private static final double FIVE_NINTHS = 0.5555555555555556D;
  static final double d_POSITIVE_INFINITY = (1.0D / 0.0D);
  static final double d_NEGATIVE_INFINITY = (-1.0D / 0.0D);
  static final float f_POSITIVE_INFINITY = (1.0F / 1.0F);
  static final float f_NEGATIVE_INFINITY = (1.0F / -1.0F);

  public static final double toFahrenheit(double celsiusTemperature)
  {
    return celsiusTemperature * 1.8D + 32.0D;
  }

  public static final double toCelsius(double fahrenheitTemperature)
  {
    return (fahrenheitTemperature - 32.0D) * 0.5555555555555556D;
  }

  public static final long toLong(byte[] byteArray, int offset, int len)
  {
    long val = 0L;

    len = Math.min(len, 8);

    for (int i = len - 1; i >= 0; i--)
    {
      val <<= 8;
      val |= byteArray[(offset + i)] & 0xFF;
    }

    return val;
  }

  public static final long toLong(byte[] byteArray)
  {
    return toLong(byteArray, 0, Math.min(8, byteArray.length));
  }

  public static final void toByteArray(long longVal, byte[] byteArray, int offset, int len)
  {
    int max = offset + len;

    for (int i = offset; i < max; i++)
    {
      byteArray[i] = (byte)(int)longVal;
      longVal >>>= 8;
    }
  }

  public static final void toByteArray(long longVal, byte[] byteArray)
  {
    toByteArray(longVal, byteArray, 0, 8);
  }

  public static final byte[] toByteArray(long longVal)
  {
    byte[] byteArray = new byte[8];
    toByteArray(longVal, byteArray, 0, 8);
    return byteArray;
  }

  public static final int toInt(byte[] byteArray, int offset, int len)
  {
    int val = 0;

    len = Math.min(len, 4);

    for (int i = len - 1; i >= 0; i--)
    {
      val <<= 8;
      val |= byteArray[(offset + i)] & 0xFF;
    }

    return val;
  }

  public static final int toInt(byte[] byteArray)
  {
    return toInt(byteArray, 0, Math.min(4, byteArray.length));
  }

  public static final void toByteArray(int intVal, byte[] byteArray, int offset, int len)
  {
    int max = offset + len;

    for (int i = offset; i < max; i++)
    {
      byteArray[i] = (byte)intVal;
      intVal >>>= 8;
    }
  }

  public static final void toByteArray(int intVal, byte[] byteArray)
  {
    toByteArray(intVal, byteArray, 0, 4);
  }

  public static final byte[] toByteArray(int intVal)
  {
    byte[] byteArray = new byte[4];
    toByteArray(intVal, byteArray, 0, 4);
    return byteArray;
  }

  public static final byte[] toByteArray(String strData)
    throws Convert.ConvertException
  {
    byte[] bDataTmp = new byte[strData.length() * 2];
    int len = toByteArray(strData, bDataTmp, 0, bDataTmp.length);
    byte[] bData = new byte[len];
    System.arraycopy(bDataTmp, 0, bData, 0, len);
    return bData;
  }

  public static final int toByteArray(String strData, byte[] bData)
    throws Convert.ConvertException
  {
    return toByteArray(strData, bData, 0, bData.length);
  }

  public static final int toByteArray(String strData, byte[] bData, int offset, int length)
    throws Convert.ConvertException
  {
    int strIndex = 0; int strLength = strData.length();
    int index = offset;
    int end = length + offset;

    while ((index < end) && (strIndex < strLength)) {
      char lower = '0';
      char upper;
      do upper = strData.charAt(strIndex++);

      while ((strIndex < strLength) && (Character.isWhitespace(upper)));

      if (strIndex < strLength)
      {
        lower = strData.charAt(strIndex++);
        if (Character.isWhitespace(lower))
        {
          lower = upper;
          upper = '0';
        }
      }
      else {
        if (Character.isWhitespace(upper))
          continue;
        lower = upper;
        upper = '0';
      }

      int uVal = Character.digit(upper, 16);
      int lVal = Character.digit(lower, 16);
      if ((uVal != -1) && (lVal != -1))
      {
        bData[(index++)] = (byte)((uVal & 0xF) << 4 | lVal & 0xF);
      }
      else {
        throw new ConvertException("Bad character in input string: " + upper + lower);
      }
    }
    return index - offset;
  }

  public static final String toHexString(byte[] data)
  {
    return toHexString(data, 0, data.length, "");
  }

  public static final String toHexString(byte[] data, int offset, int length)
  {
    return toHexString(data, offset, length, "");
  }

  public static final String toHexString(byte[] data, String delimeter)
  {
    return toHexString(data, 0, data.length, delimeter);
  }

  public static final String toHexString(byte[] data, int offset, int length, String delimeter)
  {
    StringBuffer value = new StringBuffer(length * (2 + delimeter.length()));
    int max = length + offset;
    int lastDelim = max - 1;
    for (int i = offset; i < max; i++)
    {
      byte bits = data[i];
      value.append(lookup_hex[(bits >> 4 & 0xF)]);
      value.append(lookup_hex[(bits & 0xF)]);
      if (i < lastDelim)
        value.append(delimeter);
    }
    return value.toString();
  }

  public static final String toHexString(byte bValue)
  {
    char[] hexValue = new char[2];
    hexValue[1] = lookup_hex[(bValue & 0xF)];
    hexValue[0] = lookup_hex[(bValue >> 4 & 0xF)];
    return new String(hexValue);
  }

  public static final String toHexString(char[] data)
  {
    return toHexString(data, 0, data.length, "");
  }

  public static final String toHexString(char[] data, int offset, int length)
  {
    return toHexString(data, offset, length, "");
  }

  public static final String toHexString(char[] data, String delimeter)
  {
    return toHexString(data, 0, data.length, delimeter);
  }

  public static final String toHexString(char[] data, int offset, int length, String delimeter)
  {
    StringBuffer value = new StringBuffer(length * (2 + delimeter.length()));
    int max = length + offset;
    int lastDelim = max - 1;
    for (int i = offset; i < max; i++)
    {
      char bits = data[i];
      value.append(lookup_hex[(bits >> '\004' & 0xF)]);
      value.append(lookup_hex[(bits & 0xF)]);
      if (i < lastDelim)
        value.append(delimeter);
    }
    return value.toString();
  }

  public static final String toHexString(char bValue)
  {
    char[] hexValue = new char[2];
    hexValue[1] = lookup_hex[(bValue & 0xF)];
    hexValue[0] = lookup_hex[(bValue >> '\004' & 0xF)];
    return new String(hexValue);
  }

  public static final long toLong(String strData)
    throws Convert.ConvertException
  {
    return toLong(toByteArray(strData));
  }

  public static final String toHexString(long lValue)
  {
    return toHexString(toByteArray(lValue), "");
  }

  public static final int toInt(String strData)
    throws Convert.ConvertException
  {
    return toInt(toByteArray(strData));
  }

  public static final String toHexString(int iValue)
  {
    return toHexString(toByteArray(iValue), "");
  }

  public static final String toString(double dubbel, int nFrac)
  {
    if (dubbel == (1.0D / 0.0D))
      return "Infinity";
    if (dubbel == (-1.0D / 0.0D))
      return "-Infinity";
    if (dubbel != dubbel) {
      return "NaN";
    }

    if (nFrac <= 0)
    {
      return Long.toString(()(dubbel + 0.5D));
    }

    long dWhole = ()dubbel;

    double sign = dWhole < 0L ? -1.0D : 1.0D;

    double shifter = 1.0D;
    for (int i = 0; i < nFrac; i++) {
      shifter *= 10.0D;
    }

    long dFrac = ()((dubbel - dWhole) * sign * shifter + 0.5D);

    String fracString = Long.toString(dFrac);
    int fracLength = fracString.length();

    if (fracLength > nFrac)
    {
      dWhole += 1L;
      fracLength = 0;
    }

    String wholeString = Long.toString(dWhole);
    int wholeLength = wholeString.length();

    char[] dubbelChars = new char[wholeLength + 1 + nFrac];

    wholeString.getChars(0, wholeLength, dubbelChars, 0);

    dubbelChars[wholeLength] = '.';

    int i = wholeLength + 1;
    int max = i + nFrac - fracLength;
    for (; i < max; i++) {
      dubbelChars[i] = '0';
    }

    if (fracLength > 0) {
      fracString.getChars(0, fracLength, dubbelChars, max);
    }
    return new String(dubbelChars, 0, dubbelChars.length);
  }

  public static final String toString(float flote, int nFrac)
  {
    if (flote == (1.0F / 1.0F))
      return "Infinity";
    if (flote == (1.0F / -1.0F))
      return "-Infinity";
    if (flote != flote) {
      return "NaN";
    }

    if (nFrac <= 0)
    {
      return Long.toString(()(flote + 0.5F));
    }

    long fWhole = ()flote;

    float sign = fWhole < 0L ? -1.0F : 1.0F;

    float shifter = 1.0F;
    for (int i = 0; i < nFrac; i++) {
      shifter *= 10.0F;
    }

    long fFrac = ()((flote - (float)fWhole) * sign * shifter + 0.5F);

    String fracString = Long.toString(fFrac);
    int fracLength = fracString.length();

    if (fracLength > nFrac)
    {
      fWhole += 1L;
      fracLength = 0;
    }

    String wholeString = String.valueOf(fWhole);
    int wholeLength = wholeString.length();

    char[] floteChars = new char[wholeLength + 1 + nFrac];

    wholeString.getChars(0, wholeLength, floteChars, 0);

    floteChars[wholeLength] = '.';

    int i = wholeLength + 1;
    int max = i + nFrac - fracLength;
    for (; i < max; i++) {
      floteChars[i] = '0';
    }

    if (fracLength > 0) {
      fracString.getChars(0, fracLength, floteChars, max);
    }
    return new String(floteChars, 0, floteChars.length);
  }

  public static class ConvertException extends Exception
  {
    public ConvertException(String message)
    {
      super();
    }

    public ConvertException()
    {
    }
  }
}