package com.dalsemi.onewire;

import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import com.dalsemi.onewire.adapter.TMEXAdapter;
import java.io.File;
import java.io.FileInputStream;
import java.io.PrintStream;
import java.util.Enumeration;
import java.util.Properties;
import java.util.Vector;

public class OneWireAccessProvider
{
  private static String smartDefaultPort = "COM1";

  private static boolean useOverrideAdapter = false;
  private static DSPortAdapter overrideAdapter = null;
  private static final String owapi_version = "1.10";

  public static String getVersion()
  {
    return "1.10";
  }

  public static void main(String[] args)
  {
    System.out.println("1-Wire API for Java (Desktop), v1.10");
    System.out.println("Copyright (C) 1999-2006 Dallas Semiconductor Corporation, All Rights Reserved.");
    System.out.println("");
    System.out.println("Default Adapter: " + getProperty("onewire.adapter.default"));
    System.out.println("   Default Port: " + getProperty("onewire.port.default"));
    System.out.println("");
    System.out.println("Download latest API and examples from:");
    System.out.println("http://www.maxim-ic.com/products/ibutton/software/1wire/1wire_api.cfm");
    System.out.println("");
  }

  public static Enumeration enumerateAllAdapters()
  {
    Vector adapter_vector = new Vector(3, 1);

    String class_name = null;
    boolean TMEX_loaded = false;
    boolean serial_loaded = false;

    if (useOverrideAdapter)
    {
      adapter_vector.addElement(overrideAdapter);
      return adapter_vector.elements();
    }
    DSPortAdapter adapter_instance;
    if ((System.getProperty("os.arch").indexOf("86") != -1) && (System.getProperty("os.name").indexOf("Windows") != -1))
    {
      for (int port_type = 0; port_type <= 15; port_type++)
      {
        try
        {
          adapter_instance = new TMEXAdapter(port_type);

          if (adapter_instance.getPortNames().hasMoreElements())
          {
            adapter_vector.addElement(adapter_instance);
            TMEX_loaded = true;
          }
        }
        catch (Exception e)
        {
        }
        catch (Error e)
        {
        }
      }

    }

    Class adapter_class;
    try
    {
      adapter_class = Class.forName("com.dalsemi.onewire.adapter.USerialAdapter");

      adapter_instance = (DSPortAdapter)adapter_class.newInstance();

      if (!adapter_instance.getPortNames().hasMoreElements())
      {
        if (!TMEX_loaded)
        {
          System.err.println("Warning: serial communications API not setup properly, no ports in enumeration ");

          System.err.println("Pure-Java DS9097U adapter will not work, not added to adapter enum");
        }

      }
      else
      {
        adapter_vector.addElement(adapter_instance);
        serial_loaded = true;
      }
    }
    catch (UnsatisfiedLinkError e)
    {
      if (!TMEX_loaded)
      {
        System.err.println("WARNING: Could not load serial comm API for pure-Java DS9097U adapter.");

        System.err.println("This message can be safely ignored if you are using TMEX Drivers or");

        System.err.println("the NetAdapter to connect to the 1-Wire Network.");

        System.err.println();
      }
    }
    catch (NoClassDefFoundError e)
    {
      if (!TMEX_loaded)
      {
        System.err.println();
        System.err.println("WARNING: Could not load serial comm API for pure-Java DS9097U adapter: " + e);

        System.err.println("This message can be safely ignored if you are using TMEX Drivers or");

        System.err.println("the NetAdapter to connect to the 1-Wire Network.");

        System.err.println();
      }

    }
    catch (Exception e)
    {
    }

    if ((!TMEX_loaded) && (!serial_loaded))
    {
      System.err.println();
      System.err.println("Standard drivers for 1-Wire are not found.");
      System.err.println("Please download the latest drivers from http://www.ibutton.com ");
      System.err.println("Or install RXTX Serial Communications API from http://www.rxtx.org ");
      System.err.println();
    }

    try
    {
      adapter_class = Class.forName("com.dalsemi.onewire.adapter.NetAdapter");

      adapter_instance = (DSPortAdapter)adapter_class.newInstance();

      adapter_vector.addElement(adapter_instance);
    }
    catch (NoClassDefFoundError e)
    {
      System.err.println("Warning: Could not load NetAdapter: " + e);
    }
    catch (Exception e)
    {
    }

    try
    {
      for (int reg_num = 0; reg_num <= 15; reg_num++)
      {
        class_name = getProperty("onewire.register.adapter" + reg_num);

        if (class_name == null)
        {
          break;
        }
        adapter_class = Class.forName(class_name);
        adapter_instance = (DSPortAdapter)adapter_class.newInstance();
        adapter_vector.addElement(adapter_instance);
      }
    }
    catch (UnsatisfiedLinkError e)
    {
      System.err.println("Warning: Adapter \"" + class_name + "\" was registered in " + "properties file, but the class could not be loaded");
    }
    catch (ClassNotFoundException e)
    {
      System.err.println("Adapter \"" + class_name + "\" was registered in properties file, " + " but the class was not found");
    }
    catch (Exception e)
    {
    }

    if (adapter_vector.isEmpty()) {
      System.err.println("No 1-Wire adapter classes found");
    }
    return adapter_vector.elements();
  }

  public static DSPortAdapter getAdapter(String adapterName, String portName)
    throws OneWireIOException, OneWireException
  {
    DSPortAdapter found_adapter = null;

    if (useOverrideAdapter) {
      return overrideAdapter;
    }

    Enumeration adapter_enum = enumerateAllAdapters();
    while (adapter_enum.hasMoreElements())
    {
      DSPortAdapter adapter = (DSPortAdapter)adapter_enum.nextElement();

      if ((found_adapter != null) || (!adapter.getAdapterName().equals(adapterName)))
      {
        try
        {
          adapter.freePort();
        }
        catch (Exception e)
        {
        }

      }
      else if (adapter.selectPort(portName))
      {
        adapter.beginExclusive(true);
        try
        {
          if (adapter.adapterDetected()) {
            found_adapter = adapter;
          }
          else
          {
            adapter.freePort();

            throw new OneWireException("Port found \"" + portName + "\" but Adapter \"" + adapterName + "\" not detected");
          }

        }
        finally
        {
          adapter.endExclusive();
        }
      }
      else {
        throw new OneWireException("Specified port \"" + portName + "\" could not be selected for adapter \"" + adapterName + "\"");
      }

    }

    if (found_adapter != null) {
      return found_adapter;
    }

    throw new OneWireException("Specified adapter name \"" + adapterName + "\" is not known");
  }

  public static DSPortAdapter getDefaultAdapter()
    throws OneWireIOException, OneWireException
  {
    if (useOverrideAdapter)
    {
      return overrideAdapter;
    }

    return getAdapter(getProperty("onewire.adapter.default"), getProperty("onewire.port.default"));
  }

  public static String getProperty(String propName)
  {
    try
    {
      if (useOverrideAdapter)
      {
        if (propName.equals("onewire.adapter.default"))
          return overrideAdapter.getAdapterName();
        if (propName.equals("onewire.port.default")) {
          return overrideAdapter.getPortName();
        }
      }
    }
    catch (Exception e)
    {
    }

    Properties onewire_properties = new Properties();
    FileInputStream prop_file = null;
    String ret_str = null;
    try
    {
      ret_str = System.getProperty(propName, null);
    }
    catch (Exception e)
    {
      ret_str = null;
    }

    if (ret_str == null)
    {
      String path = new String("");

      for (int i = 0; i <= 1; i++)
      {
        try
        {
          prop_file = new FileInputStream(path + "onewire.properties");
        }
        catch (Exception e)
        {
          prop_file = null;
        }

        if (prop_file != null)
        {
          try
          {
            onewire_properties.load(prop_file);

            ret_str = onewire_properties.getProperty(propName, null);
          }
          catch (Exception e)
          {
            ret_str = null;
          }

        }

        if (ret_str != null)
        {
          break;
        }
        path = System.getProperty("java.home") + File.separator + "lib" + File.separator;
      }

    }

    if (ret_str == null)
    {
      try
      {
        if (propName.equals("onewire.adapter.default"))
          ret_str = TMEXAdapter.getDefaultAdapterName();
        else if (propName.equals("onewire.port.default")) {
          ret_str = TMEXAdapter.getDefaultPortName();
        }

        if (ret_str != null)
        {
          if (ret_str.length() <= 0) {
            ret_str = null;
          }

        }

      }
      catch (Exception e)
      {
      }
      catch (Error e)
      {
      }

    }

    if (ret_str == null)
    {
      if (propName.equals("onewire.adapter.default"))
        ret_str = "DS9097U";
      else if (propName.equals("onewire.port.default"))
      {
        try
        {
          Class adapter_class = Class.forName("com.dalsemi.onewire.adapter.USerialAdapter");

          DSPortAdapter adapter_instance = (DSPortAdapter)adapter_class.newInstance();

          if (adapter_instance.getPortNames().hasMoreElements()) {
            ret_str = (String)adapter_instance.getPortNames().nextElement();
          }
        }
        catch (Exception e)
        {
        }
        catch (Error e)
        {
        }

      }

    }

    return ret_str;
  }

  public static void setUseOverridingAdapter(DSPortAdapter adapter)
  {
    useOverrideAdapter = true;
    overrideAdapter = adapter;
  }

  public static void clearUseOverridingAdapter()
  {
    useOverrideAdapter = false;
    overrideAdapter = null;
  }
}