package com.dalsemi.onewire.adapter;

import com.dalsemi.onewire.OneWireAccessProvider;
import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.container.OneWireContainer;
import com.dalsemi.onewire.utils.Bit;
import com.dalsemi.onewire.utils.CRC8;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Enumeration;

public class USerialAdapter extends DSPortAdapter
{
  private static final int ADAPTER_ID_FAMILY = 9;
  private static final int EXTENDED_READ_PAGE = 195;
  private static final char NORMAL_SEARCH_CMD = 'ð';
  private static final char ALARM_SEARCH_CMD = 'ì';
  private static String classVersion = "0.10";
  private static int maxBaud;
  private SerialService serial;
  private boolean adapterPresent;
  private boolean extraBytesReceived;
  UPacketBuilder uBuild;
  private OneWireState owState;
  private UAdapterState uState;
  private StringBuffer inBuffer;
  private boolean haveLocalUse;
  private Object syncObject;
  private static boolean doDebugMessages = false;

  public USerialAdapter()
  {
    this.serial = null;
    this.owState = new OneWireState();
    this.uState = new UAdapterState(this.owState);
    this.uBuild = new UPacketBuilder(this.uState);
    this.inBuffer = new StringBuffer();
    this.adapterPresent = false;
    this.haveLocalUse = false;
    this.syncObject = new Object();
  }

  protected void finalize()
  {
    try
    {
      freePort();
    }
    catch (Exception e)
    {
    }
  }

  public static void CleanUpByThread(Thread t)
  {
    if (doDebugMessages)
      System.out.println("CleanUpByThread called: Thread=" + t);
    SerialService.CleanUpByThread(t);
  }

  public String getAdapterName()
  {
    return "DS9097U";
  }

  public String getPortTypeDescription()
  {
    return "serial communication port";
  }

  public String getClassVersion()
  {
    return classVersion;
  }

  public Enumeration getPortNames()
  {
    return SerialService.getSerialPortIdentifiers();
  }

  public boolean selectPort(String newPortName)
    throws OneWireIOException, OneWireException
  {
    this.serial = SerialService.getSerialService(newPortName);

    if (this.serial == null) {
      throw new OneWireException("USerialAdapter: selectPort(), Not such serial port: " + newPortName);
    }

    try
    {
      beginLocalExclusive();

      this.serial.openPort();

      i = 1;
    }
    catch (IOException ioe)
    {
      int i;
      throw new OneWireIOException(ioe.toString());
    }
    finally
    {
      endLocalExclusive();
    }
  }

  public String getPortName()
    throws OneWireException
  {
    if (this.serial != null) {
      return this.serial.getPortName();
    }
    throw new OneWireException("USerialAdapter-getPortName, port not selected");
  }

  public void freePort()
    throws OneWireException
  {
    try
    {
      beginLocalExclusive();

      this.adapterPresent = false;

      this.serial.closePort();
    }
    catch (IOException ioe)
    {
      throw new OneWireException("Error closing serial port");
    }
    finally
    {
      endLocalExclusive();
    }
  }

  public boolean adapterDetected()
    throws OneWireIOException, OneWireException
  {
    boolean rt;
    try
    {
      beginLocalExclusive();
      uAdapterPresent();

      rt = uVerify();
    }
    catch (OneWireException e)
    {
      rt = false;
    }
    finally
    {
      endLocalExclusive();
    }

    return rt;
  }

  public String getAdapterVersion()
    throws OneWireIOException, OneWireException
  {
    String version_string = "DS2480 based adapter";
    try
    {
      beginLocalExclusive();

      if (uAdapterPresent())
      {
        if (this.uState.revision == 0) {
          reset();
        }
        version_string = version_string.concat(", version " + (this.uState.revision >> '\002'));

        String str1 = version_string; jsr 23; return str1;
      }

      throw new OneWireIOException("USerialAdapter-getAdapterVersion, adapter not present");
    }
    finally
    {
      endLocalExclusive();
    }
  }

  public String getAdapterAddress()
    throws OneWireIOException, OneWireException
  {
    OneWireState preserved_mstate = this.owState;

    this.owState = new OneWireState();
    try
    {
      beginLocalExclusive();

      if (uAdapterPresent())
      {
        setSearchAllDevices();
        targetAllFamilies();
        targetFamily(9);

        Enumeration adapter_id_enum = getAllDeviceContainers();
        byte[] address = new byte[8];
        String str;
        while (adapter_id_enum.hasMoreElements())
        {
          OneWireContainer ibutton = (OneWireContainer)adapter_id_enum.nextElement();

          System.arraycopy(ibutton.getAddress(), 0, address, 0, 8);

          if (!select(address))
          {
            continue;
          }
          byte[] read_buffer = new byte[37];
          int cnt = 0;

          read_buffer[(cnt++)] = -61;

          read_buffer[(cnt++)] = 0;
          read_buffer[(cnt++)] = 0;

          for (int i = 0; i < 34; i++) {
            read_buffer[(cnt++)] = -1;
          }

          int crc8 = CRC8.compute(read_buffer, 0, 3, 0);

          dataBlock(read_buffer, 0, cnt);

          if (CRC8.compute(read_buffer, 3, 1, crc8) != 0)
          {
            continue;
          }
          if (CRC8.compute(read_buffer, 4, 33, 0) != 0)
          {
            continue;
          }
          for (i = 4; i < 36; i++) {
            if (read_buffer[i] == -1) {
              continue;
            }
          }
          if (i == 36) {
            str = ibutton.getAddressAsString(); jsr 49;
          }
        }

      }
      else
      {
        throw new OneWireIOException("USerialAdapter-getAdapterAddress, adapter not present");
      }

    }
    catch (OneWireException e)
    {
    }
    finally
    {
      this.owState = preserved_mstate;

      endLocalExclusive();
    }

    return "<not available>";
  }

  public boolean canOverdrive()
    throws OneWireIOException, OneWireException
  {
    return true;
  }

  public boolean canHyperdrive()
    throws OneWireIOException, OneWireException
  {
    return false;
  }

  public boolean canFlex()
    throws OneWireIOException, OneWireException
  {
    return true;
  }

  public boolean canProgram()
    throws OneWireIOException, OneWireException
  {
    try
    {
      beginLocalExclusive();

      if (uAdapterPresent())
      {
        if (this.uState.revision == 0) {
          reset();
        }

        boolean bool = this.uState.programVoltageAvailable; jsr 21; return bool;
      }

      throw new OneWireIOException("USerialAdapter-canProgram, adapter not present");
    }
    finally
    {
      endLocalExclusive();
    }
  }

  public boolean canDeliverPower()
    throws OneWireIOException, OneWireException
  {
    return true;
  }

  public boolean canDeliverSmartPower()
    throws OneWireIOException, OneWireException
  {
    return false;
  }

  public boolean canBreak()
    throws OneWireIOException, OneWireException
  {
    return true;
  }

  public boolean findFirstDevice()
    throws OneWireIOException, OneWireException
  {
    this.owState.searchLastDiscrepancy = 0;
    this.owState.searchFamilyLastDiscrepancy = 0;
    this.owState.searchLastDevice = false;

    return findNextDevice();
  }

  public boolean findNextDevice()
    throws OneWireIOException, OneWireException
  {
    try
    {
      beginLocalExclusive();
      int i;
      if (this.owState.searchLastDevice)
      {
        this.owState.searchLastDiscrepancy = 0;
        this.owState.searchFamilyLastDiscrepancy = 0;
        this.owState.searchLastDevice = false;

        i = 0; jsr 337;
      }

      if ((this.owState.searchLastDiscrepancy == 0) && (!this.owState.searchLastDevice) && (this.owState.searchIncludeFamilies.length == 1))
      {
        this.owState.searchLastDiscrepancy = 64;

        byte[] new_id = new byte[8];

        new_id[0] = this.owState.searchIncludeFamilies[0];

        for (int i = 1; i < 8; i++) {
          new_id[i] = 0;
        }

        System.arraycopy(new_id, 0, this.owState.ID, 0, 8);
      }
      boolean search_result;
      boolean is_excluded;
      do
      {
        search_result = search(this.owState);
        int j;
        if (search_result)
        {
          is_excluded = false;

          for (int i = 0; i < this.owState.searchExcludeFamilies.length; i++)
          {
            if (this.owState.ID[0] != this.owState.searchExcludeFamilies[i])
              continue;
            is_excluded = true;

            break;
          }

          if (!is_excluded)
          {
            boolean is_included = false;

            for (int i = 0; i < this.owState.searchIncludeFamilies.length; )
            {
              if (this.owState.ID[0] == this.owState.searchIncludeFamilies[i])
              {
                is_included = true;

                break;
              }
              i++;
            }

            if ((is_included) || (this.owState.searchIncludeFamilies.length == 0))
            {
              j = 1; jsr 104;
            }
          }
        }

        if ((!this.owState.searchLastDevice) && (this.owState.searchFamilyLastDiscrepancy != 0))
        {
          this.owState.searchLastDiscrepancy = this.owState.searchFamilyLastDiscrepancy;

          this.owState.searchFamilyLastDiscrepancy = 0;
          this.owState.searchLastDevice = false;
        }
        else
        {
          this.owState.searchLastDiscrepancy = 0;
          this.owState.searchFamilyLastDiscrepancy = 0;
          this.owState.searchLastDevice = false;
          search_result = false;
        }
      }
      while (search_result);

      return false;
    }
    finally
    {
      endLocalExclusive();
    }
  }

  public void getAddress(byte[] address)
  {
    System.arraycopy(this.owState.ID, 0, address, 0, 8);
  }

  public void setAddress(byte[] address)
  {
    System.arraycopy(address, 0, this.owState.ID, 0, 8);
  }

  public boolean isPresent(byte[] address)
    throws OneWireIOException, OneWireException
  {
    try
    {
      beginLocalExclusive();

      if (uAdapterPresent())
      {
        if (this.owState.oneWireLevel != 0) {
          setPowerNormal();
        }

        if (this.owState.oneWireSpeed == '\002') {
          boolean bool = blockIsPresent(address, false); jsr 129; return bool;
        }

        OneWireState onewire_state = new OneWireState();

        System.arraycopy(address, 0, onewire_state.ID, 0, 8);

        onewire_state.searchLastDiscrepancy = 64;
        onewire_state.searchFamilyLastDiscrepancy = 0;
        onewire_state.searchLastDevice = false;
        onewire_state.searchOnlyAlarmingButtons = false;

        if (search(onewire_state))
        {
          for (i = 0; i < 8; i++) {
            if (address[i] != onewire_state.ID[i]) {
              int i = 0; jsr 52; return i;
            }
          }
          int j = 1; jsr 33; return j;
        }

        int i = 0; jsr 24; return i;
      }

      throw new OneWireIOException("Error communicating with adapter");
    }
    finally
    {
      endLocalExclusive();
    }
  }

  public boolean isAlarming(byte[] address)
    throws OneWireIOException, OneWireException
  {
    try
    {
      beginLocalExclusive();

      if (uAdapterPresent())
      {
        if (this.owState.oneWireLevel != 0) {
          setPowerNormal();
        }

        if (this.owState.oneWireSpeed == '\002') {
          boolean bool = blockIsPresent(address, true); jsr 129; return bool;
        }

        OneWireState onewire_state = new OneWireState();

        System.arraycopy(address, 0, onewire_state.ID, 0, 8);

        onewire_state.searchLastDiscrepancy = 64;
        onewire_state.searchFamilyLastDiscrepancy = 0;
        onewire_state.searchLastDevice = false;
        onewire_state.searchOnlyAlarmingButtons = true;

        if (search(onewire_state))
        {
          for (i = 0; i < 8; i++) {
            if (address[i] != onewire_state.ID[i]) {
              int i = 0; jsr 52; return i;
            }
          }
          int j = 1; jsr 33; return j;
        }

        int i = 0; jsr 24; return i;
      }

      throw new OneWireIOException("Error communicating with adapter");
    }
    finally
    {
      endLocalExclusive();
    }
  }

  public void setSearchOnlyAlarmingDevices()
  {
    this.owState.searchOnlyAlarmingButtons = true;
  }

  public void setNoResetSearch()
  {
    this.owState.skipResetOnSearch = true;
  }

  public void setSearchAllDevices()
  {
    this.owState.searchOnlyAlarmingButtons = false;
    this.owState.skipResetOnSearch = false;
  }

  public void targetAllFamilies()
  {
    this.owState.searchIncludeFamilies = new byte[0];
    this.owState.searchExcludeFamilies = new byte[0];
  }

  public void targetFamily(int familyID)
  {
    this.owState.searchIncludeFamilies = new byte[1];
    this.owState.searchIncludeFamilies[0] = (byte)familyID;
  }

  public void targetFamily(byte[] familyID)
  {
    this.owState.searchIncludeFamilies = new byte[familyID.length];

    System.arraycopy(familyID, 0, this.owState.searchIncludeFamilies, 0, familyID.length);
  }

  public void excludeFamily(int familyID)
  {
    this.owState.searchExcludeFamilies = new byte[1];
    this.owState.searchExcludeFamilies[0] = (byte)familyID;
  }

  public void excludeFamily(byte[] familyID)
  {
    this.owState.searchExcludeFamilies = new byte[familyID.length];

    System.arraycopy(familyID, 0, this.owState.searchExcludeFamilies, 0, familyID.length);
  }

  public boolean beginExclusive(boolean blocking)
    throws OneWireException
  {
    return this.serial.beginExclusive(blocking);
  }

  public void endExclusive()
  {
    this.serial.endExclusive();
  }

  private void beginLocalExclusive()
    throws OneWireException
  {
    if (this.serial == null) {
      throw new OneWireException("USerialAdapter: port not selected ");
    }

    if (this.serial.haveExclusive()) {
      return;
    }

    do
    {
      synchronized (this.syncObject)
      {
        this.haveLocalUse = this.serial.beginExclusive(false);
      }
      if (this.haveLocalUse) continue;
      try {
        Thread.sleep(50L);
      }
      catch (Exception e)
      {
      }
    }
    while (!this.haveLocalUse);
  }

  private void endLocalExclusive()
  {
    synchronized (this.syncObject)
    {
      if (this.haveLocalUse)
      {
        this.haveLocalUse = false;

        this.serial.endExclusive();
      }
    }
  }

  public void putBit(boolean bitValue)
    throws OneWireIOException, OneWireException
  {
    try
    {
      beginLocalExclusive();

      if (uAdapterPresent())
      {
        if (this.owState.oneWireLevel != 0) {
          setPowerNormal();
        }

        this.serial.flush();

        this.uBuild.restart();

        int bit_offset = this.uBuild.dataBit(bitValue, this.owState.levelChangeOnNextBit);

        if (this.owState.levelChangeOnNextBit)
        {
          this.owState.levelChangeOnNextBit = false;

          this.owState.oneWireLevel = '\001';
        }

        char[] result_array = uTransaction(this.uBuild);

        if (bitValue != this.uBuild.interpretOneWireBit(result_array[bit_offset]))
        {
          throw new OneWireIOException("1-Wire communication error, echo was incorrect");
        }
      }
      else {
        throw new OneWireIOException("Error communicating with adapter");
      }
    }
    catch (IOException ioe) {
      throw new OneWireIOException(ioe.toString());
    }
    finally
    {
      endLocalExclusive(); }  } 
  // ERROR //
  public boolean getBit() throws OneWireIOException, OneWireException { // Byte code:
    //   0: aload_0
    //   1: invokespecial 38	com/dalsemi/onewire/adapter/USerialAdapter:beginLocalExclusive	()V
    //   4: aload_0
    //   5: invokespecial 49	com/dalsemi/onewire/adapter/USerialAdapter:uAdapterPresent	()Z
    //   8: ifeq +115 -> 123
    //   11: aload_0
    //   12: getfield 5	com/dalsemi/onewire/adapter/USerialAdapter:owState	Lcom/dalsemi/onewire/adapter/OneWireState;
    //   15: getfield 83	com/dalsemi/onewire/adapter/OneWireState:oneWireLevel	C
    //   18: ifeq +7 -> 25
    //   21: aload_0
    //   22: invokevirtual 84	com/dalsemi/onewire/adapter/USerialAdapter:setPowerNormal	()V
    //   25: aload_0
    //   26: getfield 2	com/dalsemi/onewire/adapter/USerialAdapter:serial	Lcom/dalsemi/onewire/adapter/SerialService;
    //   29: invokevirtual 97	com/dalsemi/onewire/adapter/SerialService:flush	()V
    //   32: aload_0
    //   33: getfield 11	com/dalsemi/onewire/adapter/USerialAdapter:uBuild	Lcom/dalsemi/onewire/adapter/UPacketBuilder;
    //   36: invokevirtual 98	com/dalsemi/onewire/adapter/UPacketBuilder:restart	()V
    //   39: aload_0
    //   40: getfield 11	com/dalsemi/onewire/adapter/USerialAdapter:uBuild	Lcom/dalsemi/onewire/adapter/UPacketBuilder;
    //   43: iconst_1
    //   44: aload_0
    //   45: getfield 5	com/dalsemi/onewire/adapter/USerialAdapter:owState	Lcom/dalsemi/onewire/adapter/OneWireState;
    //   48: getfield 99	com/dalsemi/onewire/adapter/OneWireState:levelChangeOnNextBit	Z
    //   51: invokevirtual 100	com/dalsemi/onewire/adapter/UPacketBuilder:dataBit	(ZZ)I
    //   54: istore_1
    //   55: aload_0
    //   56: getfield 5	com/dalsemi/onewire/adapter/USerialAdapter:owState	Lcom/dalsemi/onewire/adapter/OneWireState;
    //   59: getfield 99	com/dalsemi/onewire/adapter/OneWireState:levelChangeOnNextBit	Z
    //   62: ifeq +19 -> 81
    //   65: aload_0
    //   66: getfield 5	com/dalsemi/onewire/adapter/USerialAdapter:owState	Lcom/dalsemi/onewire/adapter/OneWireState;
    //   69: iconst_0
    //   70: putfield 99	com/dalsemi/onewire/adapter/OneWireState:levelChangeOnNextBit	Z
    //   73: aload_0
    //   74: getfield 5	com/dalsemi/onewire/adapter/USerialAdapter:owState	Lcom/dalsemi/onewire/adapter/OneWireState;
    //   77: iconst_1
    //   78: putfield 83	com/dalsemi/onewire/adapter/OneWireState:oneWireLevel	C
    //   81: aload_0
    //   82: aload_0
    //   83: getfield 11	com/dalsemi/onewire/adapter/USerialAdapter:uBuild	Lcom/dalsemi/onewire/adapter/UPacketBuilder;
    //   86: invokespecial 101	com/dalsemi/onewire/adapter/USerialAdapter:uTransaction	(Lcom/dalsemi/onewire/adapter/UPacketBuilder;)[C
    //   89: astore_2
    //   90: aload_2
    //   91: arraylength
    //   92: iload_1
    //   93: iconst_1
    //   94: iadd
    //   95: if_icmpne +19 -> 114
    //   98: aload_0
    //   99: getfield 11	com/dalsemi/onewire/adapter/USerialAdapter:uBuild	Lcom/dalsemi/onewire/adapter/UPacketBuilder;
    //   102: aload_2
    //   103: iload_1
    //   104: caload
    //   105: invokevirtual 102	com/dalsemi/onewire/adapter/UPacketBuilder:interpretOneWireBit	(C)Z
    //   108: istore_3
    //   109: jsr +45 -> 154
    //   112: iload_3
    //   113: ireturn
    //   114: iconst_0
    //   115: istore 4
    //   117: jsr +37 -> 154
    //   120: iload 4
    //   122: ireturn
    //   123: new 41	com/dalsemi/onewire/adapter/OneWireIOException
    //   126: dup
    //   127: ldc 88
    //   129: invokespecial 43	com/dalsemi/onewire/adapter/OneWireIOException:<init>	(Ljava/lang/String;)V
    //   132: athrow
    //   133: astore_1
    //   134: new 41	com/dalsemi/onewire/adapter/OneWireIOException
    //   137: dup
    //   138: aload_1
    //   139: invokevirtual 42	java/lang/Throwable:toString	()Ljava/lang/String;
    //   142: invokespecial 43	com/dalsemi/onewire/adapter/OneWireIOException:<init>	(Ljava/lang/String;)V
    //   145: athrow
    //   146: astore 5
    //   148: jsr +6 -> 154
    //   151: aload 5
    //   153: athrow
    //   154: astore 6
    //   156: aload_0
    //   157: invokespecial 44	com/dalsemi/onewire/adapter/USerialAdapter:endLocalExclusive	()V
    //   160: ret 6
    //
    // Exception table:
    //   from	to	target	type
    //   0	133	133	java/io/IOException
    //   0	146	146	finally } 
  public void putByte(int byteValue) throws OneWireIOException, OneWireException { byte[] temp_block = new byte[1];

    temp_block[0] = (byte)byteValue;

    dataBlock(temp_block, 0, 1);

    if (temp_block[0] != (byte)byteValue)
      throw new OneWireIOException("Error short on 1-Wire during putByte");
  }

  public int getByte()
    throws OneWireIOException, OneWireException
  {
    byte[] temp_block = new byte[1];

    temp_block[0] = -1;

    dataBlock(temp_block, 0, 1);

    if (temp_block.length == 1) {
      return temp_block[0] & 0xFF;
    }
    throw new OneWireIOException("Error communicating with adapter");
  }

  public byte[] getBlock(int len)
    throws OneWireIOException, OneWireException
  {
    byte[] temp_block = new byte[len];

    for (int i = 0; i < len; i++) {
      temp_block[i] = -1;
    }
    getBlock(temp_block, len);

    return temp_block;
  }

  public void getBlock(byte[] arr, int len)
    throws OneWireIOException, OneWireException
  {
    getBlock(arr, 0, len);
  }

  public void getBlock(byte[] arr, int off, int len)
    throws OneWireIOException, OneWireException
  {
    for (int i = off; i < len; i++) {
      arr[i] = -1;
    }
    dataBlock(arr, off, len);
  }

  public void dataBlock(byte[] dataBlock, int off, int len)
    throws OneWireIOException, OneWireException
  {
    try
    {
      beginLocalExclusive();

      if (uAdapterPresent())
      {
        if (this.owState.oneWireLevel != 0) {
          setPowerNormal();
        }

        setStreamingSpeed(0);

        this.serial.flush();

        this.uBuild.restart();
        int data_offset;
        char[] ret_data;
        if ((len == 1) && (this.owState.levelChangeOnNextByte))
        {
          data_offset = this.uBuild.primedDataByte(dataBlock[off]);

          this.owState.levelChangeOnNextByte = false;

          ret_data = uTransaction(this.uBuild);

          this.owState.oneWireLevel = '\001';

          dataBlock[off] = this.uBuild.interpretPrimedByte(ret_data, data_offset);
        }
        else
        {
          data_offset = this.uBuild.dataBytes(dataBlock, off, len);

          ret_data = uTransaction(this.uBuild);

          this.uBuild.interpretDataBytes(ret_data, data_offset, dataBlock, off, len);
        }
      }
      else {
        throw new OneWireIOException("Error communicating with adapter");
      }
    }
    catch (IOException ioe) {
      throw new OneWireIOException(ioe.toString());
    }
    finally
    {
      endLocalExclusive(); }  } 
  // ERROR //
  public int reset() throws OneWireIOException, OneWireException { // Byte code:
    //   0: aload_0
    //   1: invokespecial 38	com/dalsemi/onewire/adapter/USerialAdapter:beginLocalExclusive	()V
    //   4: aload_0
    //   5: invokespecial 49	com/dalsemi/onewire/adapter/USerialAdapter:uAdapterPresent	()Z
    //   8: ifeq +82 -> 90
    //   11: aload_0
    //   12: getfield 5	com/dalsemi/onewire/adapter/USerialAdapter:owState	Lcom/dalsemi/onewire/adapter/OneWireState;
    //   15: getfield 83	com/dalsemi/onewire/adapter/OneWireState:oneWireLevel	C
    //   18: ifeq +7 -> 25
    //   21: aload_0
    //   22: invokevirtual 84	com/dalsemi/onewire/adapter/USerialAdapter:setPowerNormal	()V
    //   25: aload_0
    //   26: getfield 2	com/dalsemi/onewire/adapter/USerialAdapter:serial	Lcom/dalsemi/onewire/adapter/SerialService;
    //   29: invokevirtual 97	com/dalsemi/onewire/adapter/SerialService:flush	()V
    //   32: aload_0
    //   33: getfield 11	com/dalsemi/onewire/adapter/USerialAdapter:uBuild	Lcom/dalsemi/onewire/adapter/UPacketBuilder;
    //   36: invokevirtual 98	com/dalsemi/onewire/adapter/UPacketBuilder:restart	()V
    //   39: aload_0
    //   40: getfield 11	com/dalsemi/onewire/adapter/USerialAdapter:uBuild	Lcom/dalsemi/onewire/adapter/UPacketBuilder;
    //   43: invokevirtual 113	com/dalsemi/onewire/adapter/UPacketBuilder:oneWireReset	()I
    //   46: istore_1
    //   47: aload_0
    //   48: aload_0
    //   49: getfield 11	com/dalsemi/onewire/adapter/USerialAdapter:uBuild	Lcom/dalsemi/onewire/adapter/UPacketBuilder;
    //   52: invokespecial 101	com/dalsemi/onewire/adapter/USerialAdapter:uTransaction	(Lcom/dalsemi/onewire/adapter/UPacketBuilder;)[C
    //   55: astore_2
    //   56: aload_2
    //   57: arraylength
    //   58: iload_1
    //   59: iconst_1
    //   60: iadd
    //   61: if_icmpne +19 -> 80
    //   64: aload_0
    //   65: getfield 11	com/dalsemi/onewire/adapter/USerialAdapter:uBuild	Lcom/dalsemi/onewire/adapter/UPacketBuilder;
    //   68: aload_2
    //   69: iload_1
    //   70: caload
    //   71: invokevirtual 114	com/dalsemi/onewire/adapter/UPacketBuilder:interpretOneWireReset	(C)I
    //   74: istore_3
    //   75: jsr +46 -> 121
    //   78: iload_3
    //   79: ireturn
    //   80: new 41	com/dalsemi/onewire/adapter/OneWireIOException
    //   83: dup
    //   84: ldc 115
    //   86: invokespecial 43	com/dalsemi/onewire/adapter/OneWireIOException:<init>	(Ljava/lang/String;)V
    //   89: athrow
    //   90: new 41	com/dalsemi/onewire/adapter/OneWireIOException
    //   93: dup
    //   94: ldc 88
    //   96: invokespecial 43	com/dalsemi/onewire/adapter/OneWireIOException:<init>	(Ljava/lang/String;)V
    //   99: athrow
    //   100: astore_1
    //   101: new 41	com/dalsemi/onewire/adapter/OneWireIOException
    //   104: dup
    //   105: aload_1
    //   106: invokevirtual 42	java/lang/Throwable:toString	()Ljava/lang/String;
    //   109: invokespecial 43	com/dalsemi/onewire/adapter/OneWireIOException:<init>	(Ljava/lang/String;)V
    //   112: athrow
    //   113: astore 4
    //   115: jsr +6 -> 121
    //   118: aload 4
    //   120: athrow
    //   121: astore 5
    //   123: aload_0
    //   124: invokespecial 44	com/dalsemi/onewire/adapter/USerialAdapter:endLocalExclusive	()V
    //   127: ret 5
    //
    // Exception table:
    //   from	to	target	type
    //   0	100	100	java/io/IOException
    //   0	113	113	finally } 
  public void setPowerDuration(int timeFactor) throws OneWireIOException, OneWireException { if (timeFactor != 5) {
      throw new OneWireException("USerialAdapter-setPowerDuration, does not support this duration, infinite only");
    }

    this.owState.levelTimeFactor = 5;
  }

  public boolean startPowerDelivery(int changeCondition)
    throws OneWireIOException, OneWireException
  {
    try
    {
      beginLocalExclusive();

      if (changeCondition == 1)
      {
        this.owState.levelChangeOnNextBit = true;
        this.owState.primedLevelValue = '\001';
      }
      else if (changeCondition == 2)
      {
        this.owState.levelChangeOnNextByte = true;
        this.owState.primedLevelValue = '\001';
      }
      else if (changeCondition == 0)
      {
        int i;
        if (uAdapterPresent())
        {
          if (this.owState.oneWireLevel != 0) {
            setPowerNormal();
          }

          this.serial.flush();

          this.uBuild.restart();

          set_SPUD_offset = this.uBuild.setParameter('0', '\016');

          this.uBuild.sendCommand('í', false);

          char[] result_array = uTransaction(this.uBuild);

          if (result_array.length == set_SPUD_offset + 1)
          {
            this.owState.oneWireLevel = '\001';

            i = 1; jsr 57;
          }
        }
        else {
          throw new OneWireIOException("Error communicating with adapter");
        }
      }
      else {
        throw new OneWireException("Invalid power delivery condition");
      }
      set_SPUD_offset = 0;
    }
    catch (IOException ioe)
    {
      int set_SPUD_offset;
      throw new OneWireIOException(ioe.toString());
    }
    finally
    {
      endLocalExclusive();
    }
  }

  public void setProgramPulseDuration(int timeFactor)
    throws OneWireIOException, OneWireException
  {
    if (timeFactor != 7)
      throw new OneWireException("Only support EPROM length program pulse duration");
  }

  public boolean startProgramPulse(int changeCondition)
    throws OneWireIOException, OneWireException
  {
    if (!this.uState.programVoltageAvailable) {
      throw new OneWireException("USerialAdapter: startProgramPulse, program voltage not available");
    }

    if (changeCondition != 0) {
      throw new OneWireException("USerialAdapter: startProgramPulse, CONDITION_NOW only currently supported");
    }

    try
    {
      beginLocalExclusive();

      this.uBuild.restart();

      this.uBuild.setParameter(' ', '\b');

      this.uBuild.sendCommand('ý', true);

      uTransaction(this.uBuild);

      return 1;
    }
    finally
    {
      endLocalExclusive();
    }
  }

  public void startBreak()
    throws OneWireIOException, OneWireException
  {
    try
    {
      beginLocalExclusive();

      this.serial.setDTR(false);
      this.serial.setRTS(false);

      sleep(200L);

      this.owState.oneWireLevel = '\002';
    }
    finally
    {
      endLocalExclusive();
    }
  }

  public void setPowerNormal()
    throws OneWireIOException, OneWireException
  {
    try
    {
      beginLocalExclusive();

      if (this.owState.oneWireLevel == '\001')
      {
        if (uAdapterPresent())
        {
          this.serial.flush();

          this.uBuild.restart();

          this.uBuild.sendCommand('ñ', true);

          this.uBuild.sendCommand('í', false);

          int pulse_response_offset = this.uBuild.sendCommand('ñ', true);

          char[] result_array = uTransaction(this.uBuild);

          if (result_array.length == pulse_response_offset + 1)
          {
            this.owState.oneWireLevel = '\000';
          }
          else
          {
            throw new OneWireIOException("Did not get a response back from stop power delivery");
          }
        }
      }
      else if (this.owState.oneWireLevel == '\002')
      {
        this.serial.setDTR(true);
        this.serial.setRTS(true);

        sleep(300L);

        this.owState.oneWireLevel = '\000';

        this.adapterPresent = false;

        if (!uAdapterPresent()) {
          throw new OneWireIOException("Did not get a response back from adapter after break");
        }
      }
    }
    catch (IOException ioe)
    {
      throw new OneWireIOException(ioe.toString());
    }
    finally
    {
      endLocalExclusive();
    }
  }

  public void setSpeed(int speed)
    throws OneWireIOException, OneWireException
  {
    try
    {
      beginLocalExclusive();

      if ((speed == 0) || (speed == 2) || (speed == 1))
      {
        this.owState.oneWireSpeed = (char)speed;

        if (speed == 2)
          this.uState.uSpeedMode = '\b';
        else
          this.uState.uSpeedMode = '\004';
      }
      else {
        throw new OneWireException("Requested speed is not supported by this adapter");
      }

    }
    finally
    {
      endLocalExclusive();
    }
  }

  public int getSpeed()
  {
    return this.owState.oneWireSpeed;
  }

  private boolean search(OneWireState mState)
    throws OneWireIOException, OneWireException
  {
    int reset_offset = 0;

    if (uAdapterPresent())
    {
      if (this.owState.oneWireLevel != 0) {
        setPowerNormal();
      }

      setStreamingSpeed(1);

      this.uBuild.restart();

      if (!mState.skipResetOnSearch) {
        reset_offset = this.uBuild.oneWireReset();
      }
      if (mState.searchOnlyAlarmingButtons)
        this.uBuild.dataByte('ì');
      else {
        this.uBuild.dataByte('ð');
      }

      int search_offset = this.uBuild.search(mState);

      char[] result_array = uTransaction(this.uBuild);

      if (!mState.skipResetOnSearch) {
        this.uBuild.interpretOneWireReset(result_array[reset_offset]);
      }
      return this.uBuild.interpretSearch(mState, result_array, search_offset);
    }

    throw new OneWireIOException("Error communicating with adapter");
  }

  private boolean blockIsPresent(byte[] address, boolean alarmOnly)
    throws OneWireIOException, OneWireException
  {
    byte[] send_packet = new byte[24];

    reset();

    if (alarmOnly)
      putByte(236);
    else {
      putByte(240);
    }

    for (int i = 0; i < 24; i++) {
      send_packet[i] = -1;
    }

    for (i = 0; i < 64; i++) {
      Bit.arrayWriteBit(Bit.arrayReadBit(i, 0, address), (i + 1) * 3 - 1, 0, send_packet);
    }

    dataBlock(send_packet, 0, 24);

    int cnt = 56; int goodbits = 0;

    for (i = 168; i < 192; i += 3)
    {
      int tst = Bit.arrayReadBit(i, 0, send_packet) << 1 | Bit.arrayReadBit(i + 1, 0, send_packet);

      int s = Bit.arrayReadBit(cnt++, 0, address);

      if (tst == 3)
      {
        goodbits = 0;

        break;
      }

      if (((s == 1) && (tst == 2)) || ((s == 0) && (tst == 1))) {
        goodbits++;
      }
    }

    return goodbits >= 8;
  }

  private void setStreamingSpeed(int operation)
    throws OneWireIOException
  {
    int baud = UPacketBuilder.getDesiredBaud(operation, this.owState.oneWireSpeed, maxBaud);

    if (baud == this.serial.getBaudRate()) {
      return;
    }
    if (doDebugMessages)
      System.out.println("Changing baud rate from " + this.serial.getBaudRate() + " to " + baud);
    char ubaud;
    switch (baud)
    {
    case 115200:
      ubaud = '\006';
      break;
    case 57600:
      ubaud = '\004';
      break;
    case 19200:
      ubaud = '\002';
      break;
    case 9600:
    default:
      ubaud = '\000';
    }

    if (ubaud == this.uState.ubaud) {
      return;
    }

    this.adapterPresent = false;

    this.uBuild.restart();

    int baud_offset = this.uBuild.setParameter('p', ubaud);
    try
    {
      this.serial.flush();

      RawSendPacket pkt = (RawSendPacket)this.uBuild.getPackets().nextElement();

      char[] temp_buf = new char[pkt.buffer.length()];

      pkt.buffer.getChars(0, pkt.buffer.length(), temp_buf, 0);
      this.serial.write(temp_buf);

      sleep(5L);
      this.serial.flush();

      sleep(5L);
      this.serial.setBaudRate(baud);
    }
    catch (IOException ioe)
    {
      throw new OneWireIOException(ioe.toString());
    }

    this.uState.ubaud = ubaud;

    sleep(5L);

    this.uBuild.restart();

    baud_offset = this.uBuild.getParameter(112);

    this.uBuild.setSpeed();
    try
    {
      this.serial.flush();

      char[] result_array = uTransaction(this.uBuild);

      if (result_array.length == 1)
      {
        if (((result_array[baud_offset] & 0xF1) == 0) && ((result_array[baud_offset] & 0xE) == this.uState.ubaud))
        {
          if (doDebugMessages) {
            System.out.println("Success, baud changed and DS2480 is there");
          }

          this.adapterPresent = true;

          sleep(150L);
          this.serial.flush();

          return;
        }
      }
    }
    catch (IOException ioe)
    {
      if (doDebugMessages)
        System.err.println("USerialAdapter-setStreamingSpeed: " + ioe);
    }
    catch (OneWireIOException e)
    {
      if (doDebugMessages) {
        System.err.println("USerialAdapter-setStreamingSpeed: " + e);
      }
    }
    if (doDebugMessages)
      System.out.println("Failed to change baud of DS2480");
  }

  private boolean uAdapterPresent()
    throws OneWireException
  {
    boolean rt = true;

    if (!this.adapterPresent)
    {
      uMasterReset();

      if (!uVerify())
      {
        uMasterReset();

        if (!uVerify())
        {
          uPowerReset();

          if (!uVerify()) {
            rt = false;
          }
        }
      }
    }
    this.adapterPresent = rt;

    if (doDebugMessages) {
      System.out.println("DEBUG: AdapterPresent result: " + rt);
    }
    return rt;
  }

  private void uMasterReset()
  {
    if (doDebugMessages) {
      System.out.println("DEBUG: uMasterReset");
    }

    try
    {
      this.serial.setBaudRate(9600);

      this.uState.ubaud = '\000';

      this.owState.oneWireSpeed = '\000';
      this.uState.uSpeedMode = '\004';
      this.uState.ubaud = '\000';

      this.serial.sendBreak(10);
      sleep(5L);

      this.serial.flush();
      this.serial.write('Á');
      this.serial.flush();
    }
    catch (IOException e)
    {
      if (doDebugMessages)
        System.err.println("USerialAdapter-uMasterReset: " + e);
    }
  }

  private void uPowerReset()
  {
    if (doDebugMessages) {
      System.out.println("DEBUG: uPowerReset");
    }

    try
    {
      this.serial.setBaudRate(9600);

      this.uState.ubaud = '\000';

      this.owState.oneWireSpeed = '\000';
      this.uState.uSpeedMode = '\004';
      this.uState.ubaud = '\000';

      this.serial.setDTR(false);
      this.serial.setRTS(false);
      sleep(300L);
      this.serial.setDTR(true);
      this.serial.setRTS(true);
      sleep(1L);

      this.serial.flush();
      this.serial.write('Á');
      this.serial.flush();
    }
    catch (IOException e)
    {
      if (doDebugMessages)
        System.err.println("USerialAdapter-uPowerReset: " + e);
    }
  }

  private boolean uVerify()
  {
    try
    {
      this.serial.flush();

      this.uBuild.restart();

      this.uBuild.setParameter('\020', this.uState.uParameters[this.owState.oneWireSpeed].pullDownSlewRate);

      this.uBuild.setParameter('@', this.uState.uParameters[this.owState.oneWireSpeed].write1LowTime);

      this.uBuild.setParameter('P', this.uState.uParameters[this.owState.oneWireSpeed].sampleOffsetTime);

      this.uBuild.setParameter('0', '\016');

      int baud_offset = this.uBuild.getParameter(112);

      int bit_offset = this.uBuild.dataBit(true, false);

      char[] result_array = uTransaction(this.uBuild);

      if (result_array.length == bit_offset + 1)
      {
        if (((result_array[baud_offset] & 0xF1) == 0) && ((result_array[baud_offset] & 0xE) == this.uState.ubaud) && ((result_array[bit_offset] & 0xF0) == '') && ((result_array[bit_offset] & 0xC) == this.uState.uSpeedMode))
        {
          return true;
        }
      }
    }
    catch (IOException ioe) {
      if (doDebugMessages)
        System.err.println("USerialAdapter-uVerify: " + ioe);
    }
    catch (OneWireIOException e)
    {
      if (doDebugMessages) {
        System.err.println("USerialAdapter-uVerify: " + e);
      }
    }
    return false;
  }

  private char[] uTransaction(UPacketBuilder tempBuild)
    throws OneWireIOException
  {
    try
    {
      this.serial.flush();
      this.inBuffer.setLength(0);

      Enumeration packet_enum = tempBuild.getPackets();
      while (packet_enum.hasMoreElements())
      {
        RawSendPacket pkt = (RawSendPacket)packet_enum.nextElement();

        if ((pkt.buffer.length() == 0) && (pkt.returnLength == 0))
        {
          sleep(6L);
          this.serial.flush();
        }
        else
        {
          char[] temp_buf = new char[pkt.buffer.length()];

          pkt.buffer.getChars(0, pkt.buffer.length(), temp_buf, 0);

          int offset = this.inBuffer.length();

          this.serial.write(temp_buf);

          this.inBuffer.append(this.serial.readWithTimeout(pkt.returnLength));
        }
      }

      char[] ret_buffer = new char[this.inBuffer.length()];

      this.inBuffer.getChars(0, this.inBuffer.length(), ret_buffer, 0);

      this.extraBytesReceived = (this.inBuffer.length() > tempBuild.totalReturnLength);

      this.inBuffer.setLength(0);

      return ret_buffer;
    }
    catch (IOException e)
    {
      this.adapterPresent = false;
    }

    throw new OneWireIOException(e.toString());
  }

  private void sleep(long msTime)
  {
    if (doDebugMessages) {
      System.out.println("DEBUG: sleep(" + msTime + ")");
    }
    try
    {
      Thread.sleep(msTime);
    }
    catch (InterruptedException e)
    {
    }
  }

  static
  {
    maxBaud = 115200;

    String max_baud_str = OneWireAccessProvider.getProperty("onewire.serial.maxbaud");

    if (max_baud_str != null)
    {
      try
      {
        maxBaud = Integer.parseInt(max_baud_str);
      }
      catch (NumberFormatException e)
      {
        maxBaud = 0;
      }

    }

    if (doDebugMessages) {
      System.out.println("DEBUG: getMaxBaud from properties: " + maxBaud);
    }

    if ((maxBaud != 115200) && (maxBaud != 57600) && (maxBaud != 19200) && (maxBaud != 9600))
    {
      maxBaud = 115200;
    }
  }
}