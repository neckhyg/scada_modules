package com.dalsemi.onewire.adapter;

import com.dalsemi.onewire.OneWireAccessProvider;
import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.utils.Address;
import com.dalsemi.onewire.utils.CRC16;
import com.dalsemi.onewire.utils.Convert;
import com.dalsemi.onewire.utils.Convert.ConvertException;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileWriter;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.Writer;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Random;

public class NetAdapterSim
  implements Runnable, NetAdapterConstants
{
  protected static boolean SIM_DEBUG = false;

  protected static final Random rand = new Random();
  protected PrintWriter logFile;
  protected String execCommand;
  protected Process process;
  protected BufferedReader processOutput;
  protected BufferedReader processError;
  protected OutputStreamWriter processInput;
  protected byte[] fakeAddress = null;

  protected ServerSocket serverSocket = null;

  protected byte[] netAdapterSecret = null;

  protected volatile boolean hostStopped = false; protected volatile boolean hostRunning = false;

  protected boolean singleThreaded = true;

  protected Hashtable hashHandlers = null;

  protected MulticastListener multicastListener = null;

  protected int timeoutInSeconds = 30;

  protected long timeOfLastCommand = 0L;
  protected static final long IGNORE_TIME_MIN = 2L;
  protected static final long IGNORE_TIME_MAX = 1000L;
  private static final String OW_RESET_RESULT = "onewire reset at time";
  private static final String OW_RESET_CMD = "task tb.xow_master.ow_reset";
  private static final int OW_RESET_RUN_LENGTH = 1000000;
  private static final String OW_WRITE_BYTE_ARG = "deposit tb.xow_master.ow_write_byte.data = 8'h";
  private static final String OW_WRITE_BYTE_CMD = "task tb.xow_master.ow_write_byte";
  private static final int OW_WRITE_BYTE_RUN_LENGTH = 520000;
  private static final String OW_READ_RESULT = "(data=";
  private static final String OW_READ_BYTE_CMD = "task tb.xow_master.ow_read_byte";
  private static final int OW_READ_BYTE_RUN_LENGTH = 632009;
  private static final String OW_READ_SLOT_CMD = "task tb.xow_master.ow_read_slot";
  private static final int OW_READ_SLOT_RUN_LENGTH = 80000;
  private static final String OW_WRITE_ZERO_CMD = "task tb.xow_master.ow_write0";
  private static final int OW_WRITE_ZERO_RUN_LENGTH = 80000;
  private static final String OW_WRITE_ONE_CMD = "task tb.xow_master.ow_write1";
  private static final int OW_WRITE_ONE_RUN_LENGTH = 80000;
  private static final String GENERIC_CMD_END = "Ran until";
  private static final long PING_MS_RUN_LENGTH = 1000000L;
  private static final String RUN = "run ";
  private static final String LINE_DELIM = "\r\n";
  private static final String PROMPT = "ncsim> ";

  public NetAdapterSim(String execCmd, String logFilename)
    throws IOException
  {
    this(execCmd, logFilename, 6161, false);
  }

  public NetAdapterSim(String execCmd, byte[] fakeAddress, String logFile, int listenPort)
    throws IOException
  {
    this(execCmd, logFile, listenPort, false);
  }

  public NetAdapterSim(String execCmd, String logFilename, boolean multiThread)
    throws IOException
  {
    this(execCmd, logFilename, 6161, multiThread);
  }

  public NetAdapterSim(String execCmd, String logFilename, int listenPort, boolean multiThread)
    throws IOException
  {
    this.execCommand = execCmd;
    this.process = Runtime.getRuntime().exec(execCmd);
    this.processOutput = new BufferedReader(new InputStreamReader(this.process.getInputStream()));
    this.processError = new BufferedReader(new InputStreamReader(this.process.getErrorStream()));
    this.processInput = new OutputStreamWriter(this.process.getOutputStream());

    int complete = 0;
    while (complete < 2)
    {
      String line = this.processOutput.readLine();
      if ((complete == 0) && (line.indexOf("read ok (data=17)") >= 0))
      {
        complete++;
      }
      else {
        if ((complete != 1) || (line.indexOf("ncsim> ") < 0))
          continue;
        complete++;
      }

    }

    if (logFilename != null) {
      this.logFile = new PrintWriter(new FileWriter(logFilename), true);
    }

    simulationGetAddress();

    this.serverSocket = new ServerSocket(listenPort);

    this.singleThreaded = (!multiThread);
    if (multiThread)
    {
      this.hashHandlers = new Hashtable();
      this.timeoutInSeconds = 0;
    }

    String secret = OneWireAccessProvider.getProperty("NetAdapter.secret");
    if (secret != null)
      this.netAdapterSecret = secret.getBytes();
    else
      this.netAdapterSecret = "Adapter Secret Default".getBytes();
  }

  public NetAdapterSim(String execCmd, String logFilename, ServerSocket serverSock)
    throws IOException
  {
    this(execCmd, logFilename, serverSock, false);
  }

  public NetAdapterSim(String execCmd, String logFilename, ServerSocket serverSock, boolean multiThread)
    throws IOException
  {
    this.execCommand = execCmd;
    this.process = Runtime.getRuntime().exec(execCmd);
    this.processOutput = new BufferedReader(new InputStreamReader(this.process.getInputStream()));
    this.processError = new BufferedReader(new InputStreamReader(this.process.getErrorStream()));
    this.processInput = new OutputStreamWriter(this.process.getOutputStream());

    int complete = 0;
    while (complete < 2)
    {
      String line = this.processOutput.readLine();
      if ((complete == 0) && (line.indexOf("read ok (data=17)") >= 0))
      {
        complete++;
      }
      else {
        if ((complete != 1) || (line.indexOf("ncsim> ") < 0))
          continue;
        complete++;
      }

    }

    if (logFilename != null) {
      this.logFile = new PrintWriter(new FileWriter(logFilename), true);
    }

    simulationGetAddress();

    this.serverSocket = serverSock;

    this.singleThreaded = (!multiThread);
    if (multiThread)
    {
      this.hashHandlers = new Hashtable();
      this.timeoutInSeconds = 0;
    }

    String secret = OneWireAccessProvider.getProperty("NetAdapter.secret");
    if (secret != null)
      this.netAdapterSecret = secret.getBytes();
    else
      this.netAdapterSecret = "Adapter Secret Default".getBytes();
  }

  public void setSecret(String secret)
  {
    this.netAdapterSecret = secret.getBytes();
  }

  public void createMulticastListener()
    throws IOException, UnknownHostException
  {
    createMulticastListener(6163);
  }

  public void createMulticastListener(int port)
    throws IOException, UnknownHostException
  {
    String group = OneWireAccessProvider.getProperty("NetAdapter.MulticastGroup");

    if (group == null)
      group = "228.5.6.7";
    createMulticastListener(port, group);
  }

  public void createMulticastListener(int port, String group)
    throws IOException, UnknownHostException
  {
    if (this.multicastListener == null)
    {
      byte[] versionBytes = Convert.toByteArray(1);

      byte[] listenPortBytes = new byte[5];
      Convert.toByteArray(this.serverSocket.getLocalPort(), listenPortBytes, 0, 4);

      listenPortBytes[4] = -1;

      this.multicastListener = new MulticastListener(port, group, versionBytes, listenPortBytes);

      new Thread(this.multicastListener).start();
    }
  }

  public void run()
  {
    this.hostRunning = true;
    while (!this.hostStopped)
    {
      Socket sock = null;
      try
      {
        sock = this.serverSocket.accept();

        this.timeOfLastCommand = System.currentTimeMillis();
        handleConnection(sock);
      }
      catch (IOException ioe1)
      {
        try
        {
          if (sock != null)
            sock.close();
        }
        catch (IOException ioe2) {
        }
      }
    }
    this.hostRunning = false;
  }

  public void handleConnection(Socket sock)
    throws IOException
  {
    SocketHandler sh = new SocketHandler(sock);
    if (this.singleThreaded)
    {
      sh.run();
    }
    else
    {
      Thread t = new Thread(sh);
      t.start();
      synchronized (this.hashHandlers)
      {
        this.hashHandlers.put(t, sh);
      }
    }
  }

  public void stopHost()
  {
    this.hostStopped = true;
    try
    {
      this.serverSocket.close();
    }
    catch (IOException ioe)
    {
    }

    int i = 0;
    while ((this.hostRunning) && (i++ < 100)) try {
        Thread.sleep(10L);
      } catch (Exception ) {
      } if (!this.singleThreaded)
    {
      synchronized (this.hashHandlers)
      {
        Enumeration e = this.hashHandlers.elements();
        while (e.hasMoreElements()) {
          ((SocketHandler)e.nextElement()).stopHandler();
        }
      }
    }
    if (this.multicastListener != null)
      this.multicastListener.stopListener();
  }

  private boolean sendVersionUID(NetAdapterConstants.Connection conn)
    throws IOException
  {
    conn.output.writeInt(1);
    conn.output.flush();

    byte retVal = conn.input.readByte();

    return retVal == -1;
  }

  private void processRequests(NetAdapterConstants.Connection conn)
    throws IOException
  {
    if (this.logFile != null) {
      this.logFile.println("\n------------------------------------------");
    }

    byte cmd = 0;

    cmd = conn.input.readByte();

    if (this.logFile != null) {
      this.logFile.println("CMD received: " + Integer.toHexString(cmd));
    }

    if (cmd == 9)
    {
      simulationPing(1000L);
      conn.output.writeByte(-1);
      conn.output.flush();
    }
    else
    {
      long timeDelta = System.currentTimeMillis() - this.timeOfLastCommand;
      if ((SIM_DEBUG) && (this.logFile != null))
        this.logFile.println("general: timeDelta=" + timeDelta);
      if ((timeDelta >= 2L) && (timeDelta <= 1000L))
      {
        simulationPing(timeDelta);
      }

      try
      {
        switch (cmd)
        {
        case 8:
          close(conn);
          break;
        case 16:
          adapterReset(conn);
          break;
        case 17:
          adapterPutBit(conn);
          break;
        case 18:
          adapterPutByte(conn);
          break;
        case 19:
          adapterGetBit(conn);
          break;
        case 20:
          adapterGetByte(conn);
          break;
        case 21:
          adapterGetBlock(conn);
          break;
        case 22:
          adapterDataBlock(conn);
          break;
        case 23:
          adapterSetPowerDuration(conn);
          break;
        case 24:
          adapterStartPowerDelivery(conn);
          break;
        case 25:
          adapterSetProgramPulseDuration(conn);
          break;
        case 26:
          adapterStartProgramPulse(conn);
          break;
        case 27:
          adapterStartBreak(conn);
          break;
        case 28:
          adapterSetPowerNormal(conn);
          break;
        case 29:
          adapterSetSpeed(conn);
          break;
        case 30:
          adapterGetSpeed(conn);
          break;
        case 31:
          adapterBeginExclusive(conn);
          break;
        case 32:
          adapterEndExclusive(conn);
          break;
        case 33:
          adapterFindFirstDevice(conn);
          break;
        case 34:
          adapterFindNextDevice(conn);
          break;
        case 35:
          adapterGetAddress(conn);
          break;
        case 36:
          adapterSetSearchOnlyAlarmingDevices(conn);
          break;
        case 37:
          adapterSetNoResetSearch(conn);
          break;
        case 38:
          adapterSetSearchAllDevices(conn);
          break;
        case 39:
          adapterTargetAllFamilies(conn);
          break;
        case 40:
          adapterTargetFamily(conn);
          break;
        case 41:
          adapterExcludeFamily(conn);
          break;
        case 42:
          adapterCanBreak(conn);
          break;
        case 43:
          adapterCanDeliverPower(conn);
          break;
        case 44:
          adapterCanDeliverSmartPower(conn);
          break;
        case 45:
          adapterCanFlex(conn);
          break;
        case 46:
          adapterCanHyperdrive(conn);
          break;
        case 47:
          adapterCanOverdrive(conn);
          break;
        case 48:
          adapterCanProgram(conn);
          break;
        case 9:
        case 10:
        case 11:
        case 12:
        case 13:
        case 14:
        case 15:
        default:
          if ((!SIM_DEBUG) || (this.logFile == null)) break;
          this.logFile.println("Unkown command received: " + cmd);
        }

      }
      catch (OneWireException owe)
      {
        if ((SIM_DEBUG) && (this.logFile != null))
          this.logFile.println("Exception: " + owe.toString());
        conn.output.writeByte(-16);
        conn.output.writeUTF(owe.toString());
        conn.output.flush();
      }
      this.timeOfLastCommand = System.currentTimeMillis();
    }
  }

  private void close(NetAdapterConstants.Connection conn)
  {
    try
    {
      if (conn.sock != null)
      {
        conn.sock.close();
      }
    }
    catch (IOException ioe)
    {
    }
    conn.sock = null;
    conn.input = null;
    conn.output = null;
  }

  private void adapterFindFirstDevice(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    boolean b = true;

    if (this.logFile != null)
    {
      this.logFile.println("   findFirstDevice returned " + b);
    }

    conn.output.writeByte(-1);
    conn.output.writeBoolean(b);
    conn.output.flush();
  }

  private void adapterFindNextDevice(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    boolean b = false;

    if (this.logFile != null)
    {
      this.logFile.println("   findNextDevice returned " + b);
    }

    conn.output.writeByte(-1);
    conn.output.writeBoolean(b);
    conn.output.flush();
  }

  private void adapterGetAddress(NetAdapterConstants.Connection conn)
    throws IOException
  {
    if (this.logFile != null)
    {
      this.logFile.println("   adapter.getAddress(byte[]) called");
    }

    conn.output.writeByte(-1);
    conn.output.write(this.fakeAddress, 0, 8);
    conn.output.flush();
  }

  private void adapterSetSearchOnlyAlarmingDevices(NetAdapterConstants.Connection conn)
    throws IOException
  {
    if (this.logFile != null)
    {
      this.logFile.println("   setSearchOnlyAlarmingDevices called");
    }

    conn.output.writeByte(-1);
    conn.output.flush();
  }

  private void adapterSetNoResetSearch(NetAdapterConstants.Connection conn)
    throws IOException
  {
    if (this.logFile != null)
    {
      this.logFile.println("   setNoResetSearch called");
    }

    conn.output.writeByte(-1);
    conn.output.flush();
  }

  private void adapterSetSearchAllDevices(NetAdapterConstants.Connection conn)
    throws IOException
  {
    if (this.logFile != null)
    {
      this.logFile.println("   setSearchAllDevices called");
    }

    conn.output.writeByte(-1);
    conn.output.flush();
  }

  private void adapterTargetAllFamilies(NetAdapterConstants.Connection conn)
    throws IOException
  {
    if (this.logFile != null)
    {
      this.logFile.println("   targetAllFamilies called");
    }

    conn.output.writeByte(-1);
    conn.output.flush();
  }

  private void adapterTargetFamily(NetAdapterConstants.Connection conn)
    throws IOException
  {
    int len = conn.input.readInt();

    byte[] family = new byte[len];
    conn.input.readFully(family, 0, len);

    if (this.logFile != null)
    {
      this.logFile.println("   targetFamily called");
      this.logFile.println("      families: " + Convert.toHexString(family));
    }

    conn.output.writeByte(-1);
    conn.output.flush();
  }

  private void adapterExcludeFamily(NetAdapterConstants.Connection conn)
    throws IOException
  {
    int len = conn.input.readInt();

    byte[] family = new byte[len];
    conn.input.readFully(family, 0, len);

    if (this.logFile != null)
    {
      this.logFile.println("   excludeFamily called");
      this.logFile.println("      families: " + Convert.toHexString(family));
    }

    conn.output.writeByte(-1);
    conn.output.flush();
  }

  private void adapterBeginExclusive(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    if (this.logFile != null)
    {
      this.logFile.println("   adapter.beginExclusive called");
    }

    conn.input.readBoolean();

    boolean b = true;

    conn.output.writeByte(-1);
    conn.output.writeBoolean(b);
    conn.output.flush();

    if (this.logFile != null)
    {
      this.logFile.println("      adapter.beginExclusive returned " + b);
    }
  }

  private void adapterEndExclusive(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    if (this.logFile != null)
    {
      this.logFile.println("   adapter.endExclusive called");
    }

    conn.output.writeByte(-1);
    conn.output.flush();
  }

  private void adapterReset(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    int i = 1;

    if (this.logFile != null)
    {
      this.logFile.println("   reset returned " + i);
    }

    simulationReset();

    conn.output.writeByte(-1);
    conn.output.writeInt(i);
    conn.output.flush();
  }

  private void adapterPutBit(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    boolean bit = conn.input.readBoolean();

    if (this.logFile != null)
    {
      this.logFile.println("   putBit called");
      this.logFile.println("      bit=" + bit);
    }

    simulationPutBit(bit);
    conn.output.writeByte(-1);
    conn.output.flush();
  }

  private void adapterPutByte(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    byte b = conn.input.readByte();

    if (this.logFile != null)
    {
      this.logFile.println("   putByte called");
      this.logFile.println("      byte=" + Convert.toHexString(b));
    }

    simulationPutByte(b);

    conn.output.writeByte(-1);
    conn.output.flush();
  }

  private void adapterGetBit(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    boolean bit = simulationGetBit();

    if (this.logFile != null)
    {
      this.logFile.println("   getBit called");
      this.logFile.println("      bit=" + bit);
    }

    conn.output.writeByte(-1);
    conn.output.writeBoolean(bit);
    conn.output.flush();
  }

  private void adapterGetByte(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    int b = simulationGetByte();

    if (this.logFile != null)
    {
      this.logFile.println("   getByte called");
      this.logFile.println("      byte=" + Convert.toHexString((byte)b));
    }

    conn.output.writeByte(-1);
    conn.output.writeByte(b);
    conn.output.flush();
  }

  private void adapterGetBlock(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    int len = conn.input.readInt();
    if (this.logFile != null)
    {
      this.logFile.println("   getBlock called");
      this.logFile.println("      len=" + len);
    }

    byte[] b = new byte[len];
    for (int i = 0; i < len; i++)
    {
      b[i] = simulationGetByte();
    }

    if (this.logFile != null)
    {
      this.logFile.println("      returned: " + Convert.toHexString(b));
    }

    conn.output.writeByte(-1);
    conn.output.write(b, 0, len);
    conn.output.flush();
  }

  private void adapterDataBlock(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    if (this.logFile != null)
    {
      this.logFile.println("   DataBlock called");
    }

    int len = conn.input.readInt();

    byte[] b = new byte[len];
    conn.input.readFully(b, 0, len);

    if (this.logFile != null)
    {
      this.logFile.println("      " + len + " bytes");
      this.logFile.println("      Send: " + Convert.toHexString(b));
    }

    for (int i = 0; i < len; i++)
    {
      if (b[i] == -1)
      {
        b[i] = simulationGetByte();
      }
      else
      {
        simulationPutByte(b[i]);
      }
    }

    if (this.logFile != null)
    {
      this.logFile.println("      Recv: " + Convert.toHexString(b));
    }

    conn.output.writeByte(-1);
    conn.output.write(b, 0, len);
    conn.output.flush();
  }

  private void adapterSetPowerDuration(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    int timeFactor = conn.input.readInt();

    if (this.logFile != null)
    {
      this.logFile.println("   setPowerDuration called");
      this.logFile.println("      timeFactor=" + timeFactor);
    }

    conn.output.writeByte(-1);
    conn.output.flush();
  }

  private void adapterStartPowerDelivery(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    int changeCondition = conn.input.readInt();

    if (this.logFile != null)
    {
      this.logFile.println("   startPowerDelivery called");
      this.logFile.println("      changeCondition=" + changeCondition);
    }

    boolean success = true;

    conn.output.writeByte(-1);
    conn.output.writeBoolean(success);
    conn.output.flush();
  }

  private void adapterSetProgramPulseDuration(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    int timeFactor = conn.input.readInt();

    if (this.logFile != null)
    {
      this.logFile.println("   setProgramPulseDuration called");
      this.logFile.println("      timeFactor=" + timeFactor);
    }

    conn.output.writeByte(-1);
    conn.output.flush();
  }

  private void adapterStartProgramPulse(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    int changeCondition = conn.input.readInt();

    if (this.logFile != null)
    {
      this.logFile.println("   startProgramPulse called");
      this.logFile.println("      changeCondition=" + changeCondition);
    }

    boolean success = true;

    conn.output.writeByte(-1);
    conn.output.writeBoolean(success);
    conn.output.flush();
  }

  private void adapterStartBreak(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    if (this.logFile != null)
    {
      this.logFile.println("   startBreak called");
    }

    conn.output.writeByte(-1);
    conn.output.flush();
  }

  private void adapterSetPowerNormal(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    if (this.logFile != null)
    {
      this.logFile.println("   setPowerNormal called");
    }

    conn.output.writeByte(-1);
    conn.output.flush();
  }

  private void adapterSetSpeed(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    int speed = conn.input.readInt();

    if (this.logFile != null)
    {
      this.logFile.println("   setSpeed called");
      this.logFile.println("      speed=" + speed);
    }

    conn.output.writeByte(-1);
    conn.output.flush();
  }

  private void adapterGetSpeed(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    int speed = 0;

    if (this.logFile != null)
    {
      this.logFile.println("   getSpeed called");
      this.logFile.println("      speed=" + speed);
    }

    conn.output.writeByte(-1);
    conn.output.writeInt(speed);
    conn.output.flush();
  }

  private void adapterCanOverdrive(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    boolean b = false;

    if (this.logFile != null)
    {
      this.logFile.println("   canOverdrive returned " + b);
    }

    conn.output.writeByte(-1);
    conn.output.writeBoolean(b);
    conn.output.flush();
  }

  private void adapterCanHyperdrive(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    boolean b = false;

    if (this.logFile != null)
    {
      this.logFile.println("   canHyperDrive returned " + b);
    }

    conn.output.writeByte(-1);
    conn.output.writeBoolean(b);
    conn.output.flush();
  }

  private void adapterCanFlex(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    boolean b = false;

    if (this.logFile != null)
    {
      this.logFile.println("   canFlex returned " + b);
    }

    conn.output.writeByte(-1);
    conn.output.writeBoolean(b);
    conn.output.flush();
  }

  private void adapterCanProgram(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    boolean b = true;

    if (this.logFile != null)
    {
      this.logFile.println("   canProgram returned " + b);
    }

    conn.output.writeByte(-1);
    conn.output.writeBoolean(b);
    conn.output.flush();
  }

  private void adapterCanDeliverPower(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    boolean b = true;

    if (this.logFile != null)
    {
      this.logFile.println("   canDeliverPower returned " + b);
    }

    conn.output.writeByte(-1);
    conn.output.writeBoolean(b);
    conn.output.flush();
  }

  private void adapterCanDeliverSmartPower(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    boolean b = true;

    if (this.logFile != null)
    {
      this.logFile.println("   canDeliverSmartPower returned " + b);
    }

    conn.output.writeByte(-1);
    conn.output.writeBoolean(b);
    conn.output.flush();
  }

  private void adapterCanBreak(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    boolean b = true;

    if (this.logFile != null)
    {
      this.logFile.println("   canBreak returned " + b);
    }

    conn.output.writeByte(-1);
    conn.output.writeBoolean(b);
    conn.output.flush();
  }

  private void simulationReset()
    throws IOException
  {
    if ((SIM_DEBUG) && (this.logFile != null))
    {
      this.logFile.println("reset: Writing=task tb.xow_master.ow_reset");
      this.logFile.println("reset: Writing=run 1000000");
    }
    this.processInput.write("task tb.xow_master.ow_reset\r\n");
    this.processInput.write("run 1000000\r\n");
    this.processInput.flush();

    int complete = 0;
    while (complete < 2)
    {
      String line = this.processOutput.readLine();
      if ((SIM_DEBUG) && (this.logFile != null))
        this.logFile.println("reset: complete=" + complete + ", read=" + line);
      if ((complete == 0) && (line.indexOf("onewire reset at time") >= 0))
      {
        complete++;
      }
      else {
        if ((complete != 1) || (line.indexOf("Ran until") < 0))
          continue;
        complete++;
      }
    }

    if ((SIM_DEBUG) && (this.logFile != null))
      this.logFile.println("reset: Complete");
  }

  private boolean simulationGetBit()
    throws IOException
  {
    boolean bit = true;

    if ((SIM_DEBUG) && (this.logFile != null))
    {
      this.logFile.println("getBit: Writing=task tb.xow_master.ow_read_slot");
      this.logFile.println("getBit: Writing=run 80000");
    }
    this.processInput.write("task tb.xow_master.ow_read_slot\r\n");
    this.processInput.write("run 80000\r\n");
    this.processInput.flush();

    int complete = 0;
    while (complete < 3)
    {
      String line = this.processOutput.readLine();
      if ((SIM_DEBUG) && (this.logFile != null))
        this.logFile.println("getBit: complete=" + complete + ", read=" + line);
      if ((complete == 0) && (line.indexOf("OW = 1'b0") >= 0))
      {
        complete++;
      }
      else if ((complete == 1) && (line.indexOf("OW = 1'b0") >= 0))
      {
        bit = false;
        complete++;
      }
      else if ((complete == 1) && (line.indexOf("OW = 1'b1") >= 0))
      {
        bit = true;
        complete++;
      }
      else {
        if ((complete != 2) || (line.indexOf("Ran until") < 0))
          continue;
        complete++;
      }
    }

    if ((SIM_DEBUG) && (this.logFile != null))
      this.logFile.println("getBit: Complete");
    return bit;
  }

  private byte simulationGetByte()
    throws IOException
  {
    byte bits = 0;

    if ((SIM_DEBUG) && (this.logFile != null))
    {
      this.logFile.println("getByte: Writing=task tb.xow_master.ow_read_byte");
      this.logFile.println("getByte: Writing=run 632009");
    }
    this.processInput.write("task tb.xow_master.ow_read_byte\r\n");
    this.processInput.write("run 632009\r\n");
    this.processInput.flush();
    try
    {
      int complete = 0;
      while (complete < 2)
      {
        String line = this.processOutput.readLine();
        if ((SIM_DEBUG) && (this.logFile != null))
          this.logFile.println("getByte: complete=" + complete + ", read=" + line);
        if ((complete == 0) && (line.indexOf("(data=") >= 0))
        {
          int i = line.indexOf("(data=") + "(data=".length();
          String bitstr = line.substring(i, i + 2);
          if ((SIM_DEBUG) && (this.logFile != null))
            this.logFile.println("getByte: bitstr=" + bitstr);
          bits = (byte)(Convert.toInt(bitstr) & 0xFF);
          complete++;
        }
        else {
          if ((complete != 1) || (line.indexOf("Ran until") < 0))
            continue;
          complete++;
        }
      }

      if ((SIM_DEBUG) && (this.logFile != null))
        this.logFile.println("getByte: complete");
    }
    catch (Convert.ConvertException ce)
    {
      if ((SIM_DEBUG) && (this.logFile != null))
        this.logFile.println("Error during hex string conversion: " + ce);
    }
    return bits;
  }

  private void simulationPutBit(boolean bit)
    throws IOException
  {
    if (bit)
    {
      if ((SIM_DEBUG) && (this.logFile != null))
      {
        this.logFile.println("putBit: Writing=task tb.xow_master.ow_write1");
        this.logFile.println("putBit: Writing=run 80000");
      }
      this.processInput.write("task tb.xow_master.ow_write1\r\n");
      this.processInput.write("run 80000\r\n");
    }
    else
    {
      if ((SIM_DEBUG) && (this.logFile != null))
      {
        this.logFile.println("putBit: Writing=task tb.xow_master.ow_write0");
        this.logFile.println("putBit: Writing=run 80000");
      }
      this.processInput.write("task tb.xow_master.ow_write0\r\n");
      this.processInput.write("run 80000\r\n");
    }
    this.processInput.flush();

    int complete = 0;
    while (complete < 1)
    {
      String line = this.processOutput.readLine();
      if ((SIM_DEBUG) && (this.logFile != null))
        this.logFile.println("putBit: complete=" + complete + ", read=" + line);
      if ((complete != 0) || (line.indexOf("Ran until") < 0))
        continue;
      complete++;
    }

    if ((SIM_DEBUG) && (this.logFile != null))
      this.logFile.println("putBit: complete");
  }

  private void simulationPutByte(byte b)
    throws IOException
  {
    if ((SIM_DEBUG) && (this.logFile != null))
    {
      this.logFile.println("putByte: Writing=deposit tb.xow_master.ow_write_byte.data = 8'h" + Convert.toHexString(b));
      this.logFile.println("putByte: Writing=task tb.xow_master.ow_write_byte");
      this.logFile.println("putByte: Writing=run 520000");
    }
    this.processInput.write("deposit tb.xow_master.ow_write_byte.data = 8'h" + Convert.toHexString(b) + "\r\n");
    this.processInput.write("task tb.xow_master.ow_write_byte\r\n");
    this.processInput.write("run 520000\r\n");
    this.processInput.flush();

    int complete = 0;
    while (complete < 1)
    {
      String line = this.processOutput.readLine();
      if ((SIM_DEBUG) && (this.logFile != null))
        this.logFile.println("putByte: complete=" + complete + ", read=" + line);
      if ((complete != 0) || (line.indexOf("Ran until") < 0))
        continue;
      complete++;
    }

    if ((SIM_DEBUG) && (this.logFile != null))
      this.logFile.println("putByte: complete");
  }

  private void simulationPing(long timeDelta)
    throws IOException
  {
    if ((SIM_DEBUG) && (this.logFile != null))
    {
      this.logFile.println("ping: timeDelta=" + timeDelta);
      this.logFile.println("ping: Writing=run " + 1000000L * timeDelta);
    }
    this.processInput.write("run " + 1000000L * timeDelta + "\r\n");
    this.processInput.flush();

    int complete = 0;
    while (complete < 1)
    {
      String line = this.processOutput.readLine();
      if ((SIM_DEBUG) && (this.logFile != null))
        this.logFile.println("ping: complete=" + complete + ", read=" + line);
      if ((complete != 0) || (line.indexOf("Ran until") < 0))
        continue;
      complete++;
    }

    if ((SIM_DEBUG) && (this.logFile != null))
      this.logFile.println("ping: complete");
  }

  private void simulationGetAddress()
    throws IOException
  {
    this.fakeAddress = new byte[8];

    simulationReset();

    simulationPutByte(51);

    for (int i = 0; i < 8; i++)
      this.fakeAddress[i] = simulationGetByte();
  }

  public static void main(String[] args)
    throws Exception
  {
    System.out.println("NetAdapterSim");
    if (args.length < 1)
    {
      System.out.println("");
      System.out.println("   java com.dalsemi.onewire.adapter.NetAdapterSim <execCmd> <logFilename> <simDebug>");
      System.out.println("");
      System.out.println("   execCmd     - the command to start the simulator");
      System.out.println("   logFilename - the name of the file to log output to");
      System.out.println("   simDebug    - 'true' or 'false', turns on debug output from simulation");
      System.out.println("");
      System.exit(1);
    }

    String execCmd = args[0];
    System.out.println("   Executing: " + execCmd);
    String logFilename = null;
    if (args.length > 1)
    {
      if (!args[1].toLowerCase().equals("false"))
      {
        logFilename = args[1];
        System.out.println("   Logging data to file: " + logFilename);
      }
    }
    if (args.length > 2)
    {
      SIM_DEBUG = args[2].toLowerCase().equals("true");
      System.out.println("   Simulation Debugging is: " + (SIM_DEBUG ? "enabled" : "disabled"));
    }

    NetAdapterSim host = new NetAdapterSim(execCmd, logFilename);
    System.out.println("Device Address=" + Address.toString(host.fakeAddress));

    System.out.println("Starting Multicast Listener...");
    host.createMulticastListener();

    System.out.println("Starting NetAdapter Host...");
    new Thread(host).start();
    System.out.println("NetAdapter Host Started");
  }

  private class SocketHandler
    implements Runnable
  {
    private NetAdapterConstants.Connection conn;
    private volatile boolean handlerRunning = false;

    public SocketHandler(Socket sock)
      throws IOException
    {
      sock.setSoTimeout(NetAdapterSim.this.timeoutInSeconds * 1000);

      this.conn = new NetAdapterConstants.Connection();
      this.conn.sock = sock;
      this.conn.input = new DataInputStream(this.conn.sock.getInputStream());

      this.conn.output = new DataOutputStream(new BufferedOutputStream(this.conn.sock.getOutputStream()));

      if (!NetAdapterSim.this.sendVersionUID(this.conn))
      {
        throw new IOException("send version failed");
      }

      byte[] chlg = new byte[8];
      NetAdapterSim.rand.nextBytes(chlg);
      this.conn.output.write(chlg);
      this.conn.output.flush();

      int crc = CRC16.compute(NetAdapterSim.this.netAdapterSecret, 0);
      crc = CRC16.compute(chlg, crc);
      int answer = this.conn.input.readInt();
      if (answer != crc)
      {
        this.conn.output.writeByte(-16);
        this.conn.output.writeUTF("Client Authentication Failed");
        this.conn.output.flush();
        throw new IOException("authentication failed");
      }

      this.conn.output.writeByte(-1);
      this.conn.output.flush();
    }

    public void run()
    {
      this.handlerRunning = true;
      try
      {
        do
        {
          NetAdapterSim.this.processRequests(this.conn);

          if (NetAdapterSim.this.hostStopped) break; 
        }while (this.conn.sock != null);
      }
      catch (Throwable )
      {
        if (NetAdapterSim.this.logFile != null)
          ???.printStackTrace();
        NetAdapterSim.this.close(this.conn);
      }
      this.handlerRunning = false;

      if ((!NetAdapterSim.this.hostStopped) && (!NetAdapterSim.this.singleThreaded))
      {
        synchronized (NetAdapterSim.this.hashHandlers)
        {
          NetAdapterSim.this.hashHandlers.remove(Thread.currentThread());
        }
      }
    }

    public void stopHandler()
    {
      int i = 0;
      int timeout = 3000;
      while ((this.handlerRunning) && (i++ < timeout)) try {
          Thread.sleep(10L);
        }
        catch (Exception e)
        {
        }
    }
  }
}