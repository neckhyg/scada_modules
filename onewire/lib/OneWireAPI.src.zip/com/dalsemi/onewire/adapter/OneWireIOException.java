package com.dalsemi.onewire.adapter;

import com.dalsemi.onewire.OneWireException;

public class OneWireIOException extends OneWireException
{
  public OneWireIOException()
  {
  }

  public OneWireIOException(String desc)
  {
    super(desc);
  }
}