package com.dalsemi.onewire.adapter;

import com.dalsemi.onewire.OneWireAccessProvider;
import gnu.io.CommPort;
import gnu.io.CommPortIdentifier;
import gnu.io.NoSuchPortException;
import gnu.io.SerialPort;
import gnu.io.SerialPortEvent;
import gnu.io.SerialPortEventListener;
import gnu.io.UnsupportedCommOperationException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

public class SerialService
  implements SerialPortEventListener
{
  private static final boolean DEBUG = false;
  private final String comPortName;
  private SerialPort serialPort = null;

  private InputStream serialInputStream = null;

  private OutputStream serialOutputStream = null;

  private int currentThreadHash = 0;

  private byte[] tempArray = new byte[''];

  private transient boolean dataAvailable = false;

  private final Vector users = new Vector(4);
  private final boolean byteBang;
  private static final Vector vPortIDs = new Vector(2);

  private static Hashtable knownServices = new Hashtable();

  private static Hashtable uniqueServices = new Hashtable();

  public static void CleanUpByThread(Thread t)
  {
    try
    {
      SerialService temp = (SerialService)knownServices.get(t);
      if (temp == null) {
        return;
      }
      synchronized (temp)
      {
        if (t.hashCode() == temp.currentThreadHash)
        {
          temp.currentThreadHash = 0;
        }
      }

      temp.closePortByThreadID(t);
      knownServices.remove(t);
    }
    catch (Exception e)
    {
    }
  }

  private SerialService()
  {
    this.comPortName = null;
    this.byteBang = false;
  }

  protected SerialService(String strComPort)
  {
    this.comPortName = strComPort;

    String prop = OneWireAccessProvider.getProperty("onewire.serial.bytebangread");

    if (prop != null)
    {
      if (prop.indexOf("true") != -1)
        this.byteBang = true;
      else {
        this.byteBang = false;
      }
    }
    else
      this.byteBang = false;
  }

  public static SerialService getSerialService(String strComPort)
  {
    synchronized (uniqueServices)
    {
      String strLowerCaseComPort = strComPort.toLowerCase();
      Object o = uniqueServices.get(strLowerCaseComPort);
      if (o != null)
      {
        return (SerialService)o;
      }

      SerialService sps = new SerialService(strComPort);
      uniqueServices.put(strLowerCaseComPort, sps);
      return sps;
    }
  }

  public void serialEvent(SerialPortEvent spe)
  {
    this.dataAvailable = true;
  }

  public synchronized void openPort()
    throws IOException
  {
    openPort(null);
  }

  public synchronized void openPort(SerialPortEventListener spel)
    throws IOException
  {
    if (this.users.indexOf(Thread.currentThread()) == -1) {
      this.users.addElement(Thread.currentThread());
    }
    if (isPortOpen())
      return;
    CommPortIdentifier port_id;
    try
    {
      port_id = CommPortIdentifier.getPortIdentifier(this.comPortName);
    }
    catch (NoSuchPortException nspe)
    {
      throw new IOException("No such port (" + this.comPortName + "). " + nspe);
    }

    if (port_id.isCurrentlyOwned())
    {
      throw new IOException("Port In Use (" + this.comPortName + ")");
    }

    try
    {
      this.serialPort = ((SerialPort)port_id.open("Dallas Semiconductor", 2000));

      if (spel != null)
        this.serialPort.addEventListener(spel);
      else
        this.serialPort.addEventListener(this);
      this.serialPort.notifyOnOutputEmpty(true);
      this.serialPort.notifyOnDataAvailable(true);

      this.serialPort.setFlowControlMode(0);

      this.serialInputStream = this.serialPort.getInputStream();
      this.serialOutputStream = this.serialPort.getOutputStream();

      this.serialOutputStream.write(0);

      this.serialPort.disableReceiveFraming();
      this.serialPort.disableReceiveThreshold();
      this.serialPort.enableReceiveTimeout(1);

      this.serialPort.setSerialPortParams(9600, 8, 1, 0);

      this.serialPort.setDTR(true);
      this.serialPort.setRTS(true);
    }
    catch (Exception e)
    {
      if (this.serialPort != null) {
        this.serialPort.close();
      }
      this.serialPort = null;

      throw new IOException("Could not open port (" + this.comPortName + ") :" + e);
    }
  }

  public synchronized void setNotifyOnDataAvailable(boolean notify)
  {
    this.serialPort.notifyOnDataAvailable(notify);
  }

  public static Enumeration getSerialPortIdentifiers()
  {
    synchronized (vPortIDs)
    {
      Enumeration e;
      if (vPortIDs.size() == 0)
      {
        e = CommPortIdentifier.getPortIdentifiers();
        while (e.hasMoreElements())
        {
          CommPortIdentifier portID = (CommPortIdentifier)e.nextElement();
          if (portID.getPortType() == 1)
            vPortIDs.addElement(portID.getName());
        }
      }
      return vPortIDs.elements();
    }
  }

  public synchronized String getPortName()
  {
    return this.comPortName;
  }

  public synchronized boolean isPortOpen()
  {
    return this.serialPort != null;
  }

  public synchronized boolean isDTR()
  {
    return this.serialPort.isDTR();
  }

  public synchronized void setDTR(boolean newDTR)
  {
    this.serialPort.setDTR(newDTR);
  }

  public synchronized boolean isRTS()
  {
    return this.serialPort.isRTS();
  }

  public synchronized void setRTS(boolean newRTS)
  {
    this.serialPort.setRTS(newRTS);
  }

  public synchronized void sendBreak(int duration)
  {
    this.serialPort.sendBreak(duration);
  }

  public synchronized int getBaudRate()
  {
    return this.serialPort.getBaudRate();
  }

  public synchronized void setBaudRate(int baudRate)
    throws IOException
  {
    if (!isPortOpen()) {
      throw new IOException("Port Not Open");
    }

    try
    {
      this.serialPort.setSerialPortParams(baudRate, 8, 1, 0);
    }
    catch (UnsupportedCommOperationException uncoe)
    {
      throw new IOException("Failed to set baud rate: " + uncoe);
    }
  }

  public synchronized void closePort()
    throws IOException
  {
    closePortByThreadID(Thread.currentThread());
  }

  public synchronized void flush()
    throws IOException
  {
    if (!isPortOpen()) {
      throw new IOException("Port Not Open");
    }
    this.serialOutputStream.flush();
    while (this.serialInputStream.available() > 0)
      this.serialInputStream.read();
  }

  public boolean beginExclusive(boolean blocking)
  {
    if (blocking)
    {
      while (!beginExclusive())
        try {
          Thread.sleep(50L);
        } catch (Exception e) {
        }
      return true;
    }

    return beginExclusive();
  }

  public synchronized void endExclusive()
  {
    if (this.currentThreadHash == Thread.currentThread().hashCode())
    {
      this.currentThreadHash = 0;
    }
    knownServices.remove(Thread.currentThread());
  }

  public synchronized boolean haveExclusive()
  {
    return this.currentThreadHash == Thread.currentThread().hashCode();
  }

  private synchronized boolean beginExclusive()
  {
    if (this.currentThreadHash == 0)
    {
      this.currentThreadHash = Thread.currentThread().hashCode();
      knownServices.put(Thread.currentThread(), this);

      return true;
    }

    return this.currentThreadHash == Thread.currentThread().hashCode();
  }

  private synchronized void closePortByThreadID(Thread t)
  {
    boolean singleUser = this.users.size() == 1;

    this.users.removeElement(t);

    if ((singleUser) || (this.users.isEmpty()))
    {
      if (!isPortOpen()) {
        return;
      }

      this.serialPort.removeEventListener();
      this.serialPort.close();
      this.serialPort = null;
      this.serialInputStream = null;
      this.serialOutputStream = null;
    }
  }

  public synchronized int available()
    throws IOException
  {
    if (!isPortOpen()) {
      throw new IOException("Port Not Open");
    }
    return this.serialInputStream.available();
  }

  public synchronized int read()
    throws IOException
  {
    if (!isPortOpen()) {
      throw new IOException("Port Not Open");
    }
    return this.serialInputStream.read();
  }

  public synchronized int read(byte[] buffer)
    throws IOException
  {
    if (!isPortOpen()) {
      throw new IOException("Port Not Open");
    }
    return read(buffer, 0, buffer.length);
  }

  public synchronized int read(byte[] buffer, int offset, int length)
    throws IOException
  {
    if (!isPortOpen()) {
      throw new IOException("Port Not Open");
    }
    return this.serialInputStream.read(buffer, offset, length);
  }

  public synchronized int readWithTimeout(byte[] buffer, int offset, int length)
    throws IOException
  {
    if (!isPortOpen()) {
      throw new IOException("Port Not Open");
    }

    long max_timeout = System.currentTimeMillis() + length * 20 + 800L;
    int count = 0;

    if (this.byteBang)
    {
      do
      {
        int new_byte = this.serialInputStream.read();

        if (new_byte != -1)
        {
          buffer[(count + offset)] = (byte)new_byte;
          count++;
        }
        else
        {
          if (System.currentTimeMillis() > max_timeout)
          {
            break;
          }
          Thread.yield();
        }

      }

      while (length > count);
    }
    else
    {
      do
      {
        int get_num = this.serialInputStream.available();

        if (get_num > 0)
        {
          if (get_num + count > length) {
            get_num = length - count;
          }

          count += this.serialInputStream.read(buffer, count + offset, get_num);
        }
        else
        {
          if (System.currentTimeMillis() > max_timeout)
            length = 0;
          Thread.yield();
        }
      }
      while (length > count);
    }

    return count;
  }

  public synchronized char[] readWithTimeout(int length)
    throws IOException
  {
    byte[] buffer = new byte[length];

    int count = readWithTimeout(buffer, 0, length);

    if (length != count) {
      throw new IOException("readWithTimeout, timeout waiting for return bytes (wanted " + length + ", got " + count + ")");
    }

    char[] returnBuffer = new char[length];
    for (int i = 0; i < length; i++) {
      returnBuffer[i] = (char)(buffer[i] & 0xFF);
    }
    return returnBuffer;
  }

  public synchronized void write(int data)
    throws IOException
  {
    if (!isPortOpen()) {
      throw new IOException("Port Not Open");
    }

    try
    {
      this.serialOutputStream.write(data);
      this.serialOutputStream.flush();
    }
    catch (IOException e)
    {
      if ((System.getProperty("os.name").indexOf("Linux") == -1) || (e.toString().indexOf("Interrupted") == -1))
      {
        throw new IOException("write(char): " + e);
      }
    }
  }

  public synchronized void write(byte[] data, int offset, int length) throws IOException {
    if (!isPortOpen()) {
      throw new IOException("Port Not Open");
    }

    try
    {
      this.serialOutputStream.write(data, offset, length);
      this.serialOutputStream.flush();
    }
    catch (IOException e)
    {
      if ((System.getProperty("os.name").indexOf("Linux") == -1) || (e.toString().indexOf("Interrupted") == -1))
      {
        throw new IOException("write(char): " + e);
      }
    }
  }

  public synchronized void write(byte[] data) throws IOException
  {
    write(data, 0, data.length);
  }

  public synchronized void write(String data) throws IOException
  {
    byte[] dataBytes = data.getBytes();
    write(dataBytes, 0, dataBytes.length);
  }

  public synchronized void write(char data)
    throws IOException
  {
    write(data);
  }

  public synchronized void write(char[] data)
    throws IOException
  {
    write(data, 0, data.length);
  }

  public synchronized void write(char[] data, int offset, int length)
    throws IOException
  {
    if (length > this.tempArray.length) {
      this.tempArray = new byte[length];
    }
    for (int i = 0; i < length; i++) {
      this.tempArray[i] = (byte)data[i];
    }
    write(this.tempArray, 0, length);
  }
}