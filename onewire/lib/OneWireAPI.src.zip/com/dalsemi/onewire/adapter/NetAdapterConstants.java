package com.dalsemi.onewire.adapter;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;

public abstract interface NetAdapterConstants
{
  public static final boolean DEBUG = false;
  public static final int versionUID = 1;
  public static final boolean BUFFERED_OUTPUT = true;
  public static final int DEFAULT_PORT = 6161;
  public static final String DEFAULT_SECRET = "Adapter Secret Default";
  public static final String DEFAULT_MULTICAST_GROUP = "228.5.6.7";
  public static final int DEFAULT_MULTICAST_PORT = 6163;
  public static final byte RET_SUCCESS = -1;
  public static final byte RET_FAILURE = -16;
  public static final byte CMD_CLOSECONNECTION = 8;
  public static final byte CMD_PINGCONNECTION = 9;
  public static final byte CMD_RESET = 16;
  public static final byte CMD_PUTBIT = 17;
  public static final byte CMD_PUTBYTE = 18;
  public static final byte CMD_GETBIT = 19;
  public static final byte CMD_GETBYTE = 20;
  public static final byte CMD_GETBLOCK = 21;
  public static final byte CMD_DATABLOCK = 22;
  public static final byte CMD_SETPOWERDURATION = 23;
  public static final byte CMD_STARTPOWERDELIVERY = 24;
  public static final byte CMD_SETPROGRAMPULSEDURATION = 25;
  public static final byte CMD_STARTPROGRAMPULSE = 26;
  public static final byte CMD_STARTBREAK = 27;
  public static final byte CMD_SETPOWERNORMAL = 28;
  public static final byte CMD_SETSPEED = 29;
  public static final byte CMD_GETSPEED = 30;
  public static final byte CMD_BEGINEXCLUSIVE = 31;
  public static final byte CMD_ENDEXCLUSIVE = 32;
  public static final byte CMD_FINDFIRSTDEVICE = 33;
  public static final byte CMD_FINDNEXTDEVICE = 34;
  public static final byte CMD_GETADDRESS = 35;
  public static final byte CMD_SETSEARCHONLYALARMINGDEVICES = 36;
  public static final byte CMD_SETNORESETSEARCH = 37;
  public static final byte CMD_SETSEARCHALLDEVICES = 38;
  public static final byte CMD_TARGETALLFAMILIES = 39;
  public static final byte CMD_TARGETFAMILY = 40;
  public static final byte CMD_EXCLUDEFAMILY = 41;
  public static final byte CMD_CANBREAK = 42;
  public static final byte CMD_CANDELIVERPOWER = 43;
  public static final byte CMD_CANDELIVERSMARTPOWER = 44;
  public static final byte CMD_CANFLEX = 45;
  public static final byte CMD_CANHYPERDRIVE = 46;
  public static final byte CMD_CANOVERDRIVE = 47;
  public static final byte CMD_CANPROGRAM = 48;
  public static final Connection EMPTY_CONNECTION = new Connection();

  public static final class Connection
  {
    public Socket sock = null;

    public DataInputStream input = null;

    public DataOutputStream output = null;
  }
}