package com.dalsemi.onewire.adapter;

import com.dalsemi.onewire.OneWireAccessProvider;
import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.utils.CRC16;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;

public class NetAdapter extends DSPortAdapter
  implements NetAdapterConstants
{
  protected static final String UNSPECIFIED_ERROR = "An unspecified error occurred.";
  protected static final String COMM_FAILED = "IO Error: ";
  protected static final Integer NOT_OWNED = new Integer(0);

  protected Integer currentThreadHash = NOT_OWNED;

  protected NetAdapterConstants.Connection conn = NetAdapterConstants.EMPTY_CONNECTION;

  protected String portNameForReconnect = null;

  protected byte[] netAdapterSecret = null;

  protected boolean useCustomSecret = false;

  protected Boolean multicastEnabled = null;

  protected String multicastGroup = null;

  protected int datagramPort = -1;

  public NetAdapter()
  {
    try
    {
      resetSecret();
    }
    catch (Throwable t)
    {
      setSecret("Adapter Secret Default");
    }
  }

  public void setSecret(String secret)
  {
    if (secret != null)
    {
      this.netAdapterSecret = secret.getBytes();
    }
    else
      resetSecret();
  }

  public void resetSecret()
  {
    String secret = OneWireAccessProvider.getProperty("NetAdapter.Secret");
    if (secret != null)
      this.netAdapterSecret = secret.getBytes();
    else
      this.netAdapterSecret = "Adapter Secret Default".getBytes();
  }

  private void checkReturnValue(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException, OneWireIOException
  {
    byte retVal = conn.input.readByte();
    if (retVal != -1)
    {
      String errorMsg;
      if (retVal == -16)
      {
        errorMsg = conn.input.readUTF();
      }
      else
      {
        errorMsg = "An unspecified error occurred.";

        freePort();
        selectPort(this.portNameForReconnect);
      }

      throw new OneWireIOException(errorMsg);
    }
  }

  public void pingHost()
    throws OneWireException, OneWireIOException
  {
    try
    {
      synchronized (this.conn)
      {
        this.conn.output.writeByte(9);
        this.conn.output.flush();

        checkReturnValue(this.conn);
      }
    }
    catch (IOException ioe)
    {
      throw new OneWireException("IO Error: " + ioe.getMessage());
    }
  }

  public boolean adapterDetected()
    throws OneWireIOException, OneWireException
  {
    synchronized (this.conn)
    {
      return (this.conn != NetAdapterConstants.EMPTY_CONNECTION) && (this.conn.sock != null) ? 1 : 0;
    }
  }

  public String getAdapterName()
  {
    return "NetAdapter";
  }

  public String getPortTypeDescription()
  {
    return "Network 'Hostname:Port'";
  }

  public String getClassVersion()
  {
    return "1"; } 
  // ERROR //
  public java.util.Enumeration getPortNames() { // Byte code:
    //   0: new 44	java/util/Vector
    //   3: dup
    //   4: invokespecial 45	java/util/Vector:<init>	()V
    //   7: astore_1
    //   8: aload_0
    //   9: getfield 9	com/dalsemi/onewire/adapter/NetAdapter:multicastEnabled	Ljava/lang/Boolean;
    //   12: ifnonnull +37 -> 49
    //   15: aconst_null
    //   16: astore_2
    //   17: ldc 46
    //   19: invokestatic 18	com/dalsemi/onewire/OneWireAccessProvider:getProperty	(Ljava/lang/String;)Ljava/lang/String;
    //   22: astore_2
    //   23: goto +4 -> 27
    //   26: astore_3
    //   27: aload_2
    //   28: ifnull +14 -> 42
    //   31: aload_0
    //   32: aload_2
    //   33: invokestatic 47	java/lang/Boolean:valueOf	(Ljava/lang/String;)Ljava/lang/Boolean;
    //   36: putfield 9	com/dalsemi/onewire/adapter/NetAdapter:multicastEnabled	Ljava/lang/Boolean;
    //   39: goto +10 -> 49
    //   42: aload_0
    //   43: getstatic 48	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
    //   46: putfield 9	com/dalsemi/onewire/adapter/NetAdapter:multicastEnabled	Ljava/lang/Boolean;
    //   49: aload_0
    //   50: getfield 9	com/dalsemi/onewire/adapter/NetAdapter:multicastEnabled	Ljava/lang/Boolean;
    //   53: invokevirtual 49	java/lang/Boolean:booleanValue	()Z
    //   56: ifeq +285 -> 341
    //   59: aload_0
    //   60: getfield 11	com/dalsemi/onewire/adapter/NetAdapter:datagramPort	I
    //   63: iconst_m1
    //   64: if_icmpne +37 -> 101
    //   67: aconst_null
    //   68: astore_2
    //   69: ldc 50
    //   71: invokestatic 18	com/dalsemi/onewire/OneWireAccessProvider:getProperty	(Ljava/lang/String;)Ljava/lang/String;
    //   74: astore_2
    //   75: goto +4 -> 79
    //   78: astore_3
    //   79: aload_2
    //   80: ifnonnull +13 -> 93
    //   83: aload_0
    //   84: sipush 6163
    //   87: putfield 11	com/dalsemi/onewire/adapter/NetAdapter:datagramPort	I
    //   90: goto +11 -> 101
    //   93: aload_0
    //   94: aload_2
    //   95: invokestatic 51	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   98: putfield 11	com/dalsemi/onewire/adapter/NetAdapter:datagramPort	I
    //   101: aload_0
    //   102: getfield 10	com/dalsemi/onewire/adapter/NetAdapter:multicastGroup	Ljava/lang/String;
    //   105: ifnonnull +33 -> 138
    //   108: aconst_null
    //   109: astore_2
    //   110: ldc 52
    //   112: invokestatic 18	com/dalsemi/onewire/OneWireAccessProvider:getProperty	(Ljava/lang/String;)Ljava/lang/String;
    //   115: astore_2
    //   116: goto +4 -> 120
    //   119: astore_3
    //   120: aload_2
    //   121: ifnonnull +12 -> 133
    //   124: aload_0
    //   125: ldc 53
    //   127: putfield 10	com/dalsemi/onewire/adapter/NetAdapter:multicastGroup	Ljava/lang/String;
    //   130: goto +8 -> 138
    //   133: aload_0
    //   134: aload_2
    //   135: putfield 10	com/dalsemi/onewire/adapter/NetAdapter:multicastGroup	Ljava/lang/String;
    //   138: aconst_null
    //   139: astore_2
    //   140: aconst_null
    //   141: astore_3
    //   142: new 54	java/net/MulticastSocket
    //   145: dup
    //   146: aload_0
    //   147: getfield 11	com/dalsemi/onewire/adapter/NetAdapter:datagramPort	I
    //   150: invokespecial 55	java/net/MulticastSocket:<init>	(I)V
    //   153: astore_2
    //   154: aload_0
    //   155: getfield 10	com/dalsemi/onewire/adapter/NetAdapter:multicastGroup	Ljava/lang/String;
    //   158: invokestatic 56	java/net/InetAddress:getByName	(Ljava/lang/String;)Ljava/net/InetAddress;
    //   161: astore_3
    //   162: aload_2
    //   163: aload_3
    //   164: invokevirtual 57	java/net/MulticastSocket:joinGroup	(Ljava/net/InetAddress;)V
    //   167: iconst_1
    //   168: invokestatic 58	com/dalsemi/onewire/utils/Convert:toByteArray	(I)[B
    //   171: astore 4
    //   173: new 59	java/net/DatagramPacket
    //   176: dup
    //   177: aload 4
    //   179: iconst_4
    //   180: aload_3
    //   181: aload_0
    //   182: getfield 11	com/dalsemi/onewire/adapter/NetAdapter:datagramPort	I
    //   185: invokespecial 60	java/net/DatagramPacket:<init>	([BILjava/net/InetAddress;I)V
    //   188: astore 5
    //   190: aload_2
    //   191: aload 5
    //   193: invokevirtual 61	java/net/DatagramSocket:send	(Ljava/net/DatagramPacket;)V
    //   196: aload_2
    //   197: sipush 500
    //   200: invokevirtual 62	java/net/DatagramSocket:setSoTimeout	(I)V
    //   203: bipush 32
    //   205: newarray byte
    //   207: astore 6
    //   209: goto +3 -> 212
    //   212: new 59	java/net/DatagramPacket
    //   215: dup
    //   216: aload 6
    //   218: aload 6
    //   220: arraylength
    //   221: invokespecial 63	java/net/DatagramPacket:<init>	([BI)V
    //   224: astore 7
    //   226: aload_2
    //   227: aload 7
    //   229: invokevirtual 64	java/net/DatagramSocket:receive	(Ljava/net/DatagramPacket;)V
    //   232: aload 7
    //   234: invokevirtual 65	java/net/DatagramPacket:getLength	()I
    //   237: istore 8
    //   239: aload 7
    //   241: invokevirtual 66	java/net/DatagramPacket:getData	()[B
    //   244: astore 9
    //   246: iload 8
    //   248: iconst_5
    //   249: if_icmpne +55 -> 304
    //   252: aload 9
    //   254: iconst_4
    //   255: baload
    //   256: iconst_m1
    //   257: if_icmpne +47 -> 304
    //   260: aload 9
    //   262: iconst_0
    //   263: iconst_4
    //   264: invokestatic 67	com/dalsemi/onewire/utils/Convert:toInt	([BII)I
    //   267: istore 10
    //   269: aload_1
    //   270: new 33	java/lang/StringBuffer
    //   273: dup
    //   274: invokespecial 34	java/lang/StringBuffer:<init>	()V
    //   277: aload 7
    //   279: invokevirtual 68	java/net/DatagramPacket:getAddress	()Ljava/net/InetAddress;
    //   282: invokevirtual 69	java/net/InetAddress:getHostName	()Ljava/lang/String;
    //   285: invokevirtual 36	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   288: ldc 70
    //   290: invokevirtual 36	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   293: iload 10
    //   295: invokevirtual 71	java/lang/StringBuffer:append	(I)Ljava/lang/StringBuffer;
    //   298: invokevirtual 38	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   301: invokevirtual 72	java/util/Vector:addElement	(Ljava/lang/Object;)V
    //   304: goto -92 -> 212
    //   307: astore 4
    //   309: jsr +14 -> 323
    //   312: goto +29 -> 341
    //   315: astore 11
    //   317: jsr +6 -> 323
    //   320: aload 11
    //   322: athrow
    //   323: astore 12
    //   325: aload_2
    //   326: aload_3
    //   327: invokevirtual 74	java/net/MulticastSocket:leaveGroup	(Ljava/net/InetAddress;)V
    //   330: aload_2
    //   331: invokevirtual 75	java/net/DatagramSocket:close	()V
    //   334: goto +5 -> 339
    //   337: astore 13
    //   339: ret 12
    //   341: ldc 76
    //   343: astore_2
    //   344: iconst_0
    //   345: istore_3
    //   346: goto +38 -> 384
    //   349: new 33	java/lang/StringBuffer
    //   352: dup
    //   353: invokespecial 34	java/lang/StringBuffer:<init>	()V
    //   356: ldc 77
    //   358: invokevirtual 36	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   361: iload_3
    //   362: invokevirtual 71	java/lang/StringBuffer:append	(I)Ljava/lang/StringBuffer;
    //   365: invokevirtual 38	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   368: invokestatic 18	com/dalsemi/onewire/OneWireAccessProvider:getProperty	(Ljava/lang/String;)Ljava/lang/String;
    //   371: astore_2
    //   372: aload_2
    //   373: ifnull +8 -> 381
    //   376: aload_1
    //   377: aload_2
    //   378: invokevirtual 72	java/util/Vector:addElement	(Ljava/lang/Object;)V
    //   381: iinc 3 1
    //   384: aload_2
    //   385: ifnonnull -36 -> 349
    //   388: goto +4 -> 392
    //   391: astore_3
    //   392: aload_1
    //   393: invokevirtual 78	java/util/Vector:elements	()Ljava/util/Enumeration;
    //   396: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   17	23	26	java/lang/Throwable
    //   69	75	78	java/lang/Throwable
    //   110	116	119	java/lang/Throwable
    //   142	307	307	java/lang/Exception
    //   142	315	315	finally
    //   325	334	337	java/lang/Exception
    //   344	388	391	java/lang/Throwable } 
  public boolean selectPort(String portName) throws OneWireIOException, OneWireException { synchronized (this.conn)
    {
      Socket s = null;
      try
      {
        int port = 6161;

        int index = portName.indexOf(':');
        if (index >= 0)
        {
          int index2 = portName.indexOf(':', index + 1);
          if (index2 < 0)
          {
            port = Integer.parseInt(portName.substring(index + 1));

            resetSecret();
            this.useCustomSecret = false;
          }
          else
          {
            setSecret(portName.substring(index2 + 1));
            this.useCustomSecret = true;
            if (index < index2 - 1)
              port = Integer.parseInt(portName.substring(index + 1, index2));
          }
          portName = portName.substring(0, index);
        }
        else
        {
          resetSecret();
          this.useCustomSecret = false;
        }
        s = new Socket(portName, port);
      }
      catch (IOException ioe)
      {
        throw new OneWireIOException("Can't reach server: " + ioe.getMessage());
      }

      return selectPort(s);
    }
  }

  public boolean selectPort(Socket sock)
    throws OneWireIOException, OneWireException
  {
    boolean bSuccess = false;
    synchronized (this.conn)
    {
      NetAdapterConstants.Connection tmpConn = new NetAdapterConstants.Connection();
      tmpConn.sock = sock;
      try
      {
        tmpConn.input = new DataInputStream(sock.getInputStream());

        tmpConn.output = new DataOutputStream(new BufferedOutputStream(sock.getOutputStream()));

        int hostVersionUID = tmpConn.input.readInt();

        if (hostVersionUID == 1)
        {
          tmpConn.output.writeByte(-1);
          tmpConn.output.flush();

          byte[] chlg = new byte[8];
          tmpConn.input.read(chlg, 0, 8);

          int crc = CRC16.compute(this.netAdapterSecret, 0);
          crc = CRC16.compute(chlg, crc);

          tmpConn.output.writeInt(crc);
          tmpConn.output.flush();

          checkReturnValue(tmpConn);

          bSuccess = true;
        }
        else
        {
          tmpConn.output.writeByte(-16);
          tmpConn.output.flush();
          tmpConn = null;
        }
      }
      catch (IOException e)
      {
        bSuccess = false;
        tmpConn = null;
      }

      if (bSuccess)
      {
        this.portNameForReconnect = (sock.getInetAddress().getHostName() + ":" + sock.getPort());

        this.conn = tmpConn;
      }

    }

    return bSuccess;
  }

  public void freePort()
    throws OneWireException
  {
    try
    {
      synchronized (this.conn)
      {
        this.conn.output.writeByte(8);
        this.conn.output.flush();
        this.conn.sock.close();
        this.conn = NetAdapterConstants.EMPTY_CONNECTION;
      }
    }
    catch (Exception e)
    {
      throw new OneWireException("IO Error: " + e.getMessage());
    }
  }

  public String getPortName()
    throws OneWireException
  {
    synchronized (this.conn)
    {
      if (!adapterDetected())
        return "Not Connected";
      if (this.useCustomSecret) {
        return this.conn.sock.getInetAddress().getHostName() + ":" + this.conn.sock.getPort() + ":" + new String(this.netAdapterSecret);
      }

      return this.conn.sock.getInetAddress().getHostName() + ":" + this.conn.sock.getPort();
    }
  }

  public boolean canOverdrive()
    throws OneWireIOException, OneWireException
  {
    try
    {
      synchronized (this.conn)
      {
        this.conn.output.writeByte(47);
        this.conn.output.flush();

        checkReturnValue(this.conn);

        return this.conn.input.readBoolean();
      }
    }
    catch (IOException ioe) {
    }
    throw new OneWireException("IO Error: " + ioe.getMessage());
  }

  public boolean canHyperdrive()
    throws OneWireIOException, OneWireException
  {
    try
    {
      synchronized (this.conn)
      {
        this.conn.output.writeByte(46);
        this.conn.output.flush();

        checkReturnValue(this.conn);

        return this.conn.input.readBoolean();
      }
    }
    catch (IOException ioe) {
    }
    throw new OneWireException("IO Error: " + ioe.getMessage());
  }

  public boolean canFlex()
    throws OneWireIOException, OneWireException
  {
    try
    {
      synchronized (this.conn)
      {
        this.conn.output.writeByte(45);
        this.conn.output.flush();

        checkReturnValue(this.conn);

        return this.conn.input.readBoolean();
      }
    }
    catch (IOException ioe) {
    }
    throw new OneWireException("IO Error: " + ioe.getMessage());
  }

  public boolean canProgram()
    throws OneWireIOException, OneWireException
  {
    try
    {
      synchronized (this.conn)
      {
        this.conn.output.writeByte(48);
        this.conn.output.flush();

        checkReturnValue(this.conn);

        return this.conn.input.readBoolean();
      }
    }
    catch (IOException ioe) {
    }
    throw new OneWireException("IO Error: " + ioe.getMessage());
  }

  public boolean canDeliverPower()
    throws OneWireIOException, OneWireException
  {
    try
    {
      synchronized (this.conn)
      {
        this.conn.output.writeByte(43);
        this.conn.output.flush();

        checkReturnValue(this.conn);

        return this.conn.input.readBoolean();
      }
    }
    catch (IOException ioe) {
    }
    throw new OneWireException("IO Error: " + ioe.getMessage());
  }

  public boolean canDeliverSmartPower()
    throws OneWireIOException, OneWireException
  {
    try
    {
      synchronized (this.conn)
      {
        this.conn.output.writeByte(44);
        this.conn.output.flush();

        checkReturnValue(this.conn);

        return this.conn.input.readBoolean();
      }
    }
    catch (IOException ioe) {
    }
    throw new OneWireException("IO Error: " + ioe.getMessage());
  }

  public boolean canBreak()
    throws OneWireIOException, OneWireException
  {
    try
    {
      synchronized (this.conn)
      {
        this.conn.output.writeByte(42);
        this.conn.output.flush();

        checkReturnValue(this.conn);

        return this.conn.input.readBoolean();
      }
    }
    catch (IOException ioe) {
    }
    throw new OneWireException("IO Error: " + ioe.getMessage());
  }

  public boolean findFirstDevice()
    throws OneWireIOException, OneWireException
  {
    try
    {
      synchronized (this.conn)
      {
        this.conn.output.writeByte(33);
        this.conn.output.flush();

        checkReturnValue(this.conn);

        return this.conn.input.readBoolean();
      }
    }
    catch (IOException ioe) {
    }
    throw new OneWireException("IO Error: " + ioe.getMessage());
  }

  public boolean findNextDevice()
    throws OneWireIOException, OneWireException
  {
    try
    {
      synchronized (this.conn)
      {
        this.conn.output.writeByte(34);
        this.conn.output.flush();

        checkReturnValue(this.conn);

        return this.conn.input.readBoolean();
      }
    }
    catch (IOException ioe) {
    }
    throw new OneWireException("IO Error: " + ioe.getMessage());
  }

  public void getAddress(byte[] address)
  {
    try
    {
      synchronized (this.conn)
      {
        this.conn.output.writeByte(35);
        this.conn.output.flush();

        checkReturnValue(this.conn);

        this.conn.input.read(address, 0, 8);
      }
    }
    catch (Exception e)
    {
    }
  }

  public void setSearchOnlyAlarmingDevices()
  {
    try
    {
      synchronized (this.conn)
      {
        this.conn.output.writeByte(36);
        this.conn.output.flush();

        checkReturnValue(this.conn);
      }
    }
    catch (Exception e)
    {
    }
  }

  public void setNoResetSearch()
  {
    try
    {
      synchronized (this.conn)
      {
        this.conn.output.writeByte(37);
        this.conn.output.flush();

        checkReturnValue(this.conn);
      }
    }
    catch (Exception e)
    {
    }
  }

  public void setSearchAllDevices()
  {
    try
    {
      synchronized (this.conn)
      {
        this.conn.output.writeByte(38);
        this.conn.output.flush();

        checkReturnValue(this.conn);
      }
    }
    catch (Exception e)
    {
    }
  }

  public void targetAllFamilies()
  {
    try
    {
      synchronized (this.conn)
      {
        this.conn.output.writeByte(39);
        this.conn.output.flush();

        checkReturnValue(this.conn);
      }
    }
    catch (Exception e)
    {
    }
  }

  public void targetFamily(int family)
  {
    try
    {
      synchronized (this.conn)
      {
        this.conn.output.writeByte(40);
        this.conn.output.writeInt(1);
        this.conn.output.writeByte((byte)family);
        this.conn.output.flush();

        checkReturnValue(this.conn);
      }
    }
    catch (Exception e)
    {
    }
  }

  public void targetFamily(byte[] family)
  {
    try
    {
      synchronized (this.conn)
      {
        this.conn.output.writeByte(40);
        this.conn.output.writeInt(family.length);
        this.conn.output.write(family, 0, family.length);
        this.conn.output.flush();

        checkReturnValue(this.conn);
      }
    }
    catch (Exception e)
    {
    }
  }

  public void excludeFamily(int family)
  {
    try
    {
      synchronized (this.conn)
      {
        this.conn.output.writeByte(41);
        this.conn.output.writeInt(1);
        this.conn.output.writeByte((byte)family);
        this.conn.output.flush();

        checkReturnValue(this.conn);
      }
    }
    catch (Exception e)
    {
    }
  }

  public void excludeFamily(byte[] family)
  {
    try
    {
      synchronized (this.conn)
      {
        this.conn.output.writeByte(41);
        this.conn.output.writeInt(family.length);
        this.conn.output.write(family, 0, family.length);
        this.conn.output.flush();

        checkReturnValue(this.conn);
      }
    }
    catch (Exception e)
    {
    }
  }

  public boolean beginExclusive(boolean blocking)
    throws OneWireException
  {
    boolean bGotLocalBlock = false; boolean bGotServerBlock = false;
    if (blocking)
    {
      while (!beginExclusive())
        try {
          Thread.sleep(50L);
        } catch (Exception ) {
        }
      bGotLocalBlock = true;
    }
    else {
      bGotLocalBlock = beginExclusive();
    }
    try
    {
      synchronized (this.conn)
      {
        this.conn.output.writeByte(31);
        this.conn.output.writeBoolean(blocking);
        this.conn.output.flush();

        checkReturnValue(this.conn);

        bGotServerBlock = this.conn.input.readBoolean();
      }
    }
    catch (IOException ioe)
    {
      throw new OneWireException("IO Error: " + ioe.getMessage());
    }

    return (bGotLocalBlock) && (bGotServerBlock);
  }

  private boolean beginExclusive()
    throws OneWireException
  {
    synchronized (this.currentThreadHash)
    {
      int i;
      if (this.currentThreadHash == NOT_OWNED)
      {
        this.currentThreadHash = new Integer(Thread.currentThread().hashCode());

        return 1;
      }
      if (this.currentThreadHash.intValue() == Thread.currentThread().hashCode())
      {
        return 1;
      }

      return 0;
    }
  }

  public void endExclusive()
  {
    synchronized (this.currentThreadHash)
    {
      if ((this.currentThreadHash != NOT_OWNED) && (this.currentThreadHash.intValue() == Thread.currentThread().hashCode()))
      {
        this.currentThreadHash = NOT_OWNED;
        try
        {
          synchronized (this.conn)
          {
            this.conn.output.writeByte(32);
            this.conn.output.flush();

            checkReturnValue(this.conn);
          }
        }
        catch (Exception e)
        {
        }
      }
    }
  }

  public int reset()
    throws OneWireIOException, OneWireException
  {
    try
    {
      synchronized (this.conn)
      {
        this.conn.output.writeByte(16);
        this.conn.output.flush();

        checkReturnValue(this.conn);

        return this.conn.input.readInt();
      }
    }
    catch (IOException ioe) {
    }
    throw new OneWireException("IO Error: " + ioe.getMessage());
  }

  public void putBit(boolean bitValue)
    throws OneWireIOException, OneWireException
  {
    try
    {
      synchronized (this.conn)
      {
        this.conn.output.writeByte(17);

        this.conn.output.writeBoolean(bitValue);
        this.conn.output.flush();

        checkReturnValue(this.conn);
      }
    }
    catch (IOException ioe)
    {
      throw new OneWireException("IO Error: " + ioe.getMessage());
    }
  }

  public boolean getBit()
    throws OneWireIOException, OneWireException
  {
    try
    {
      synchronized (this.conn)
      {
        this.conn.output.writeByte(19);
        this.conn.output.flush();

        checkReturnValue(this.conn);

        return this.conn.input.readBoolean();
      }
    }
    catch (IOException ioe) {
    }
    throw new OneWireException("IO Error: " + ioe.getMessage());
  }

  public void putByte(int byteValue)
    throws OneWireIOException, OneWireException
  {
    try
    {
      synchronized (this.conn)
      {
        this.conn.output.writeByte(18);

        this.conn.output.writeByte(byteValue);
        this.conn.output.flush();

        checkReturnValue(this.conn);
      }
    }
    catch (IOException ioe)
    {
      throw new OneWireException("IO Error: " + ioe.getMessage());
    }
  }

  public int getByte()
    throws OneWireIOException, OneWireException
  {
    try
    {
      synchronized (this.conn)
      {
        this.conn.output.writeByte(20);
        this.conn.output.flush();

        checkReturnValue(this.conn);

        return this.conn.input.readByte() & 0xFF;
      }
    }
    catch (IOException ioe) {
    }
    throw new OneWireException("IO Error: " + ioe.getMessage());
  }

  public byte[] getBlock(int len)
    throws OneWireIOException, OneWireException
  {
    byte[] buffer = new byte[len];
    getBlock(buffer, 0, len);
    return buffer;
  }

  public void getBlock(byte[] arr, int len)
    throws OneWireIOException, OneWireException
  {
    getBlock(arr, 0, len);
  }

  public void getBlock(byte[] arr, int off, int len)
    throws OneWireIOException, OneWireException
  {
    try
    {
      synchronized (this.conn)
      {
        this.conn.output.writeByte(21);

        this.conn.output.writeInt(len);
        this.conn.output.flush();

        checkReturnValue(this.conn);

        this.conn.input.readFully(arr, off, len);
      }
    }
    catch (IOException ioe)
    {
      throw new OneWireException("IO Error: " + ioe.getMessage());
    }
  }

  public void dataBlock(byte[] dataBlock, int off, int len)
    throws OneWireIOException, OneWireException
  {
    try
    {
      synchronized (this.conn)
      {
        this.conn.output.writeByte(22);

        this.conn.output.writeInt(len);

        this.conn.output.write(dataBlock, off, len);
        this.conn.output.flush();

        checkReturnValue(this.conn);

        this.conn.input.readFully(dataBlock, off, len);
      }
    }
    catch (IOException ioe)
    {
      throw new OneWireException("IO Error: " + ioe.getMessage());
    }
  }

  public void setPowerDuration(int timeFactor)
    throws OneWireIOException, OneWireException
  {
    try
    {
      synchronized (this.conn)
      {
        this.conn.output.writeByte(23);

        this.conn.output.writeInt(timeFactor);
        this.conn.output.flush();

        checkReturnValue(this.conn);
      }
    }
    catch (IOException ioe)
    {
      throw new OneWireException("IO Error: " + ioe.getMessage());
    }
  }

  public boolean startPowerDelivery(int changeCondition)
    throws OneWireIOException, OneWireException
  {
    try
    {
      synchronized (this.conn)
      {
        this.conn.output.writeByte(24);

        this.conn.output.writeInt(changeCondition);
        this.conn.output.flush();

        checkReturnValue(this.conn);

        return this.conn.input.readBoolean();
      }
    }
    catch (IOException ioe) {
    }
    throw new OneWireException("IO Error: " + ioe.getMessage());
  }

  public void setProgramPulseDuration(int timeFactor)
    throws OneWireIOException, OneWireException
  {
    try
    {
      synchronized (this.conn)
      {
        this.conn.output.writeByte(25);

        this.conn.output.writeInt(timeFactor);
        this.conn.output.flush();

        checkReturnValue(this.conn);
      }
    }
    catch (IOException ioe)
    {
      throw new OneWireException("IO Error: " + ioe.getMessage());
    }
  }

  public boolean startProgramPulse(int changeCondition)
    throws OneWireIOException, OneWireException
  {
    try
    {
      synchronized (this.conn)
      {
        this.conn.output.writeByte(26);

        this.conn.output.writeInt(changeCondition);
        this.conn.output.flush();

        checkReturnValue(this.conn);

        return this.conn.input.readBoolean();
      }
    }
    catch (IOException ioe) {
    }
    throw new OneWireException("IO Error: " + ioe.getMessage());
  }

  public void startBreak()
    throws OneWireIOException, OneWireException
  {
    try
    {
      synchronized (this.conn)
      {
        this.conn.output.writeByte(27);
        this.conn.output.flush();

        checkReturnValue(this.conn);
      }
    }
    catch (IOException ioe)
    {
      throw new OneWireException("IO Error: ");
    }
  }

  public void setPowerNormal()
    throws OneWireIOException, OneWireException
  {
    try
    {
      synchronized (this.conn)
      {
        this.conn.output.writeByte(28);
        this.conn.output.flush();

        checkReturnValue(this.conn);
      }
    }
    catch (IOException ioe)
    {
      throw new OneWireException("IO Error: " + ioe.getMessage());
    }
  }

  public void setSpeed(int speed)
    throws OneWireIOException, OneWireException
  {
    try
    {
      synchronized (this.conn)
      {
        this.conn.output.writeByte(29);

        this.conn.output.writeInt(speed);
        this.conn.output.flush();

        checkReturnValue(this.conn);
      }
    }
    catch (IOException ioe)
    {
      throw new OneWireException("IO Error: " + ioe.getMessage());
    }
  }

  public int getSpeed()
  {
    try
    {
      synchronized (this.conn)
      {
        this.conn.output.writeByte(30);
        this.conn.output.flush();

        checkReturnValue(this.conn);

        return this.conn.input.readInt();
      }

    }
    catch (Exception e)
    {
    }

    return -1;
  }
}