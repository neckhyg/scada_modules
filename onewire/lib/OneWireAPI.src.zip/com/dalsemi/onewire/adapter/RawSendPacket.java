package com.dalsemi.onewire.adapter;

class RawSendPacket
{
  public StringBuffer buffer;
  public int returnLength;

  public RawSendPacket()
  {
    this.buffer = new StringBuffer();
    this.returnLength = 0;
  }
}