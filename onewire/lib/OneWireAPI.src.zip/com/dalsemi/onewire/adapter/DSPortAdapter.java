package com.dalsemi.onewire.adapter;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.container.OneWireContainer;
import com.dalsemi.onewire.utils.Address;
import java.io.PrintStream;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

public abstract class DSPortAdapter
{
  public static final int SPEED_REGULAR = 0;
  public static final int SPEED_FLEX = 1;
  public static final int SPEED_OVERDRIVE = 2;
  public static final int SPEED_HYPERDRIVE = 3;
  public static final char LEVEL_NORMAL = '\000';
  public static final char LEVEL_POWER_DELIVERY = '\001';
  public static final char LEVEL_BREAK = '\002';
  public static final char LEVEL_PROGRAM = '\003';
  public static final int RESET_NOPRESENCE = 0;
  public static final int RESET_PRESENCE = 1;
  public static final int RESET_ALARM = 2;
  public static final int RESET_SHORT = 3;
  public static final int CONDITION_NOW = 0;
  public static final int CONDITION_AFTER_BIT = 1;
  public static final int CONDITION_AFTER_BYTE = 2;
  public static final int DELIVERY_HALF_SECOND = 0;
  public static final int DELIVERY_ONE_SECOND = 1;
  public static final int DELIVERY_TWO_SECONDS = 2;
  public static final int DELIVERY_FOUR_SECONDS = 3;
  public static final int DELIVERY_SMART_DONE = 4;
  public static final int DELIVERY_INFINITE = 5;
  public static final int DELIVERY_CURRENT_DETECT = 6;
  public static final int DELIVERY_EPROM = 7;
  private Hashtable registeredOneWireContainerClasses = new Hashtable(5);
  private byte[] include;
  private byte[] exclude;

  public abstract String getAdapterName();

  public abstract String getPortTypeDescription();

  public abstract String getClassVersion();

  public abstract Enumeration getPortNames();

  public void registerOneWireContainerClass(int family, Class OneWireContainerClass)
    throws OneWireException
  {
    Class defaultibc = null;
    try
    {
      defaultibc = Class.forName("com.dalsemi.onewire.container.OneWireContainer");
    }
    catch (ClassNotFoundException e)
    {
      throw new OneWireException("Could not find OneWireContainer class");
    }

    Integer familyInt = new Integer(family);

    if (OneWireContainerClass == null)
    {
      this.registeredOneWireContainerClasses.remove(familyInt);
    }
    else if (defaultibc.isAssignableFrom(OneWireContainerClass))
    {
      this.registeredOneWireContainerClasses.put(familyInt, OneWireContainerClass);
    }
    else
    {
      throw new ClassCastException("Does not extend com.dalsemi.onewire.container.OneWireContainer");
    }
  }

  public abstract boolean selectPort(String paramString)
    throws OneWireIOException, OneWireException;

  public abstract void freePort()
    throws OneWireException;

  public abstract String getPortName()
    throws OneWireException;

  public abstract boolean adapterDetected()
    throws OneWireIOException, OneWireException;

  public String getAdapterVersion()
    throws OneWireIOException, OneWireException
  {
    return "<na>";
  }

  public String getAdapterAddress()
    throws OneWireIOException, OneWireException
  {
    return "<na>";
  }

  public boolean canOverdrive()
    throws OneWireIOException, OneWireException
  {
    return false;
  }

  public boolean canHyperdrive()
    throws OneWireIOException, OneWireException
  {
    return false;
  }

  public boolean canFlex()
    throws OneWireIOException, OneWireException
  {
    return false;
  }

  public boolean canProgram()
    throws OneWireIOException, OneWireException
  {
    return false;
  }

  public boolean canDeliverPower()
    throws OneWireIOException, OneWireException
  {
    return false;
  }

  public boolean canDeliverSmartPower()
    throws OneWireIOException, OneWireException
  {
    return false;
  }

  public boolean canBreak()
    throws OneWireIOException, OneWireException
  {
    return false;
  }

  public Enumeration getAllDeviceContainers()
    throws OneWireIOException, OneWireException
  {
    Vector ibutton_vector = new Vector();

    OneWireContainer temp_ibutton = getFirstDeviceContainer();

    if (temp_ibutton != null)
    {
      ibutton_vector.addElement(temp_ibutton);
      do
      {
        temp_ibutton = getNextDeviceContainer();

        if (temp_ibutton != null)
          ibutton_vector.addElement(temp_ibutton);
      }
      while (temp_ibutton != null);
    }

    return ibutton_vector.elements();
  }

  public OneWireContainer getFirstDeviceContainer()
    throws OneWireIOException, OneWireException
  {
    if (findFirstDevice() == true)
    {
      return getDeviceContainer();
    }

    return null;
  }

  public OneWireContainer getNextDeviceContainer()
    throws OneWireIOException, OneWireException
  {
    if (findNextDevice() == true)
    {
      return getDeviceContainer();
    }

    return null;
  }

  public abstract boolean findFirstDevice()
    throws OneWireIOException, OneWireException;

  public abstract boolean findNextDevice()
    throws OneWireIOException, OneWireException;

  public abstract void getAddress(byte[] paramArrayOfByte);

  public long getAddressAsLong()
  {
    byte[] address = new byte[8];

    getAddress(address);

    return Address.toLong(address);
  }

  public String getAddressAsString()
  {
    byte[] address = new byte[8];

    getAddress(address);

    return Address.toString(address);
  }

  public boolean isPresent(byte[] address)
    throws OneWireIOException, OneWireException
  {
    reset();
    putByte(240);

    return strongAccess(address);
  }

  public boolean isPresent(long address)
    throws OneWireIOException, OneWireException
  {
    return isPresent(Address.toByteArray(address));
  }

  public boolean isPresent(String address)
    throws OneWireIOException, OneWireException
  {
    return isPresent(Address.toByteArray(address));
  }

  public boolean isAlarming(byte[] address)
    throws OneWireIOException, OneWireException
  {
    reset();
    putByte(236);

    return strongAccess(address);
  }

  public boolean isAlarming(long address)
    throws OneWireIOException, OneWireException
  {
    return isAlarming(Address.toByteArray(address));
  }

  public boolean isAlarming(String address)
    throws OneWireIOException, OneWireException
  {
    return isAlarming(Address.toByteArray(address));
  }

  public boolean select(byte[] address)
    throws OneWireIOException, OneWireException
  {
    int rslt = reset();

    byte[] send_packet = new byte[9];

    send_packet[0] = 85;

    System.arraycopy(address, 0, send_packet, 1, 8);
    dataBlock(send_packet, 0, 9);

    return (rslt == 1) || (rslt == 2);
  }

  public boolean select(long address)
    throws OneWireIOException, OneWireException
  {
    return select(Address.toByteArray(address));
  }

  public boolean select(String address)
    throws OneWireIOException, OneWireException
  {
    return select(Address.toByteArray(address));
  }

  public void assertSelect(byte[] address)
    throws OneWireIOException, OneWireException
  {
    if (!select(address))
      throw new OneWireIOException("Device " + Address.toString(address) + " not present.");
  }

  public void assertSelect(long address)
    throws OneWireIOException, OneWireException
  {
    if (!select(Address.toByteArray(address)))
      throw new OneWireIOException("Device " + Address.toString(address) + " not present.");
  }

  public void assertSelect(String address)
    throws OneWireIOException, OneWireException
  {
    if (!select(Address.toByteArray(address)))
      throw new OneWireIOException("Device " + address + " not present.");
  }

  public abstract void setSearchOnlyAlarmingDevices();

  public abstract void setNoResetSearch();

  public abstract void setSearchAllDevices();

  public void targetAllFamilies()
  {
    this.include = null;
    this.exclude = null;
  }

  public void targetFamily(int family)
  {
    if ((this.include == null) || (this.include.length != 1)) {
      this.include = new byte[1];
    }
    this.include[0] = (byte)family;
  }

  public void targetFamily(byte[] family)
  {
    if ((this.include == null) || (this.include.length != family.length)) {
      this.include = new byte[family.length];
    }
    System.arraycopy(family, 0, this.include, 0, family.length);
  }

  public void excludeFamily(int family)
  {
    if ((this.exclude == null) || (this.exclude.length != 1)) {
      this.exclude = new byte[1];
    }
    this.exclude[0] = (byte)family;
  }

  public void excludeFamily(byte[] family)
  {
    if ((this.exclude == null) || (this.exclude.length != family.length)) {
      this.exclude = new byte[family.length];
    }
    System.arraycopy(family, 0, this.exclude, 0, family.length);
  }

  public abstract boolean beginExclusive(boolean paramBoolean)
    throws OneWireException;

  public abstract void endExclusive();

  public abstract void putBit(boolean paramBoolean)
    throws OneWireIOException, OneWireException;

  public abstract boolean getBit()
    throws OneWireIOException, OneWireException;

  public abstract void putByte(int paramInt)
    throws OneWireIOException, OneWireException;

  public abstract int getByte()
    throws OneWireIOException, OneWireException;

  public abstract byte[] getBlock(int paramInt)
    throws OneWireIOException, OneWireException;

  public abstract void getBlock(byte[] paramArrayOfByte, int paramInt)
    throws OneWireIOException, OneWireException;

  public abstract void getBlock(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws OneWireIOException, OneWireException;

  public abstract void dataBlock(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws OneWireIOException, OneWireException;

  public abstract int reset()
    throws OneWireIOException, OneWireException;

  public void setPowerDuration(int timeFactor)
    throws OneWireIOException, OneWireException
  {
    throw new OneWireException("Power delivery not supported by this adapter type");
  }

  public boolean startPowerDelivery(int changeCondition)
    throws OneWireIOException, OneWireException
  {
    throw new OneWireException("Power delivery not supported by this adapter type");
  }

  public void setProgramPulseDuration(int timeFactor)
    throws OneWireIOException, OneWireException
  {
    throw new OneWireException("Program pulse delivery not supported by this adapter type");
  }

  public boolean startProgramPulse(int changeCondition)
    throws OneWireIOException, OneWireException
  {
    throw new OneWireException("Program pulse delivery not supported by this adapter type");
  }

  public void startBreak()
    throws OneWireIOException, OneWireException
  {
    throw new OneWireException("Break delivery not supported by this adapter type");
  }

  public void setPowerNormal()
    throws OneWireIOException, OneWireException
  {
  }

  public void setSpeed(int speed)
    throws OneWireIOException, OneWireException
  {
    if (speed != 0)
      throw new OneWireException("Non-regular 1-Wire speed not supported by this adapter type");
  }

  public int getSpeed()
  {
    return 0;
  }

  public OneWireContainer getDeviceContainer(byte[] address)
  {
    int family_code = address[0] & 0x7F;
    String family_string = family_code < 16 ? ("0" + Integer.toHexString(family_code)).toUpperCase() : Integer.toHexString(family_code).toUpperCase();

    Class ibutton_class = null;

    if (!this.registeredOneWireContainerClasses.isEmpty())
    {
      Integer familyInt = new Integer(family_code);

      ibutton_class = (Class)this.registeredOneWireContainerClasses.get(familyInt);
    }

    if (ibutton_class == null)
    {
      try
      {
        ibutton_class = Class.forName("com.dalsemi.onewire.container.OneWireContainer" + family_string);
      }
      catch (Exception e)
      {
        ibutton_class = null;
      }

      if (ibutton_class == null)
      {
        try
        {
          ibutton_class = Class.forName("com.dalsemi.onewire.container.OneWireContainer");
        }
        catch (Exception e)
        {
          System.out.println("EXCEPTION: Unable to load OneWireContainer" + e);

          return null;
        }
      }

    }

    OneWireContainer new_ibutton;
    try
    {
      new_ibutton = (OneWireContainer)ibutton_class.newInstance();

      new_ibutton.setupContainer(this, address);
    }
    catch (Exception e)
    {
      System.out.println("EXCEPTION: Unable to instantiate OneWireContainer " + ibutton_class + ": " + e);

      e.printStackTrace();

      return null;
    }

    return new_ibutton;
  }

  public OneWireContainer getDeviceContainer(long address)
  {
    return getDeviceContainer(Address.toByteArray(address));
  }

  public OneWireContainer getDeviceContainer(String address)
  {
    return getDeviceContainer(Address.toByteArray(address));
  }

  public OneWireContainer getDeviceContainer()
  {
    byte[] address = new byte[8];

    getAddress(address);

    return getDeviceContainer(address);
  }

  protected boolean isValidFamily(byte[] address)
  {
    byte familyCode = address[0];

    if (this.exclude != null)
    {
      for (int i = 0; i < this.exclude.length; i++)
      {
        if (familyCode == this.exclude[i])
        {
          return false;
        }
      }
    }

    if (this.include != null)
    {
      for (int i = 0; i < this.include.length; i++)
      {
        if (familyCode == this.include[i])
        {
          return true;
        }
      }

      return false;
    }

    return true;
  }

  private boolean strongAccess(byte[] address)
    throws OneWireIOException, OneWireException
  {
    byte[] send_packet = new byte[24];

    for (int i = 0; i < 24; i++) {
      send_packet[i] = -1;
    }

    for (i = 0; i < 64; i++) {
      arrayWriteBit(arrayReadBit(i, address), (i + 1) * 3 - 1, send_packet);
    }

    dataBlock(send_packet, 0, 24);

    int cnt = 56; int goodbits = 0;

    for (i = 168; i < 192; i += 3)
    {
      int tst = arrayReadBit(i, send_packet) << 1 | arrayReadBit(i + 1, send_packet);

      int s = arrayReadBit(cnt++, address);

      if (tst == 3)
      {
        goodbits = 0;

        break;
      }

      if (((s == 1) && (tst == 2)) || ((s == 0) && (tst == 1))) {
        goodbits++;
      }
    }

    return goodbits >= 8;
  }

  private void arrayWriteBit(int state, int index, byte[] buf)
  {
    int nbyt = index >>> 3;
    int nbit = index - (nbyt << 3);

    if (state == 1)
    {
      int tmp21_19 = nbyt;
      byte[] tmp21_18 = buf; tmp21_18[tmp21_19] = (byte)(tmp21_18[tmp21_19] | 1 << nbit);
    }
    else
    {
      int tmp36_34 = nbyt;
      byte[] tmp36_33 = buf; tmp36_33[tmp36_34] = (byte)(tmp36_33[tmp36_34] & (1 << nbit ^ 0xFFFFFFFF));
    }
  }

  private int arrayReadBit(int index, byte[] buf)
  {
    int nbyt = index >>> 3;
    int nbit = index - (nbyt << 3);

    return buf[nbyt] >>> nbit & 0x1;
  }

  public boolean equals(Object o)
  {
    if ((o != null) && ((o instanceof DSPortAdapter)))
    {
      if ((o == this) || (o.toString().equals(toString())))
      {
        return true;
      }
    }
    return false;
  }

  public String toString()
  {
    try
    {
      return getAdapterName() + " " + getPortName();
    }
    catch (OneWireException owe) {
    }
    return getAdapterName() + " Unknown Port";
  }
}