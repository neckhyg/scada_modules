package com.dalsemi.onewire.adapter;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.utils.CRC8;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Enumeration;

public class LSerialAdapter extends DSPortAdapter
{
  private static final int NORMAL_SEARCH_CMD = 240;
  private static final int ALARM_SEARCH_CMD = 236;
  private static String classVersion = "0.00";
  private SerialService serial;
  private boolean adapterPresent;
  private int LastDiscrepancy;
  private int LastFamilyDiscrepancy;
  private boolean LastDevice;
  private byte[] CurrentDevice = new byte[8];
  boolean searchOnlyAlarmingButtons;
  private boolean skipResetOnSearch = false;

  private boolean resetSearch = true;
  private boolean haveLocalUse;
  private Object syncObject;
  private static boolean doDebugMessages = false;
  int currentPosition;

  public LSerialAdapter()
  {
    this.serial = null;
    this.adapterPresent = false;
    this.haveLocalUse = false;
    this.syncObject = new Object();
  }

  public String getAdapterName()
  {
    return "DS9097";
  }

  public String getPortTypeDescription()
  {
    return "serial communication port";
  }

  public String getClassVersion()
  {
    return classVersion;
  }

  public Enumeration getPortNames()
  {
    return SerialService.getSerialPortIdentifiers();
  }

  public boolean selectPort(String newPortName)
    throws OneWireIOException, OneWireException
  {
    this.serial = SerialService.getSerialService(newPortName);

    if (this.serial == null) {
      throw new OneWireException("DS9097EAdapter: selectPort(), Not such serial port: " + newPortName);
    }

    try
    {
      beginLocalExclusive();

      this.serial.openPort();
      this.serial.setBaudRate(115200);

      i = 1;
    }
    catch (IOException ioe)
    {
      int i;
      throw new OneWireIOException(ioe.toString());
    }
    finally
    {
      endLocalExclusive();
    }
  }

  public String getPortName()
    throws OneWireException
  {
    if (this.serial != null) {
      return this.serial.getPortName();
    }
    throw new OneWireException("DS9097EAdapter-getPortName, port not selected");
  }

  public void freePort()
    throws OneWireException
  {
    try
    {
      beginLocalExclusive();

      this.adapterPresent = false;

      this.serial.closePort();
    }
    catch (IOException ioe)
    {
      throw new OneWireException("Error closing serial port");
    }
    finally
    {
      endLocalExclusive();
    }
  }

  public boolean adapterDetected()
    throws OneWireIOException, OneWireException
  {
    if (!this.adapterPresent)
    {
      try
      {
        beginLocalExclusive();

        adapterPresent();
      }
      catch (OneWireIOException e)
      {
        System.err.println("DS9097EAdapter: Not detected " + e);
      }
      finally
      {
        endLocalExclusive();
      }
    }

    return this.adapterPresent;
  }

  public String getAdapterVersion()
    throws OneWireIOException, OneWireException
  {
    String version_string = "DS9097 adapter";

    return version_string;
  }

  public String getAdapterAddress()
    throws OneWireIOException, OneWireException
  {
    return "<no adapter address>";
  }

  public boolean findFirstDevice()
    throws OneWireIOException, OneWireException
  {
    this.resetSearch = true;

    return findNextDevice();
  }

  public boolean findNextDevice() throws OneWireIOException, OneWireException
  {
    try
    {
      beginLocalExclusive();
      int i;
      while (true) {
        boolean retval = search(this.resetSearch);

        if (!retval)
          break;
        this.resetSearch = false;

        if (isValidFamily(this.CurrentDevice)) {
          i = 1; jsr 23;
        }

      }

      this.resetSearch = true;

      return 0;
    }
    finally
    {
      endLocalExclusive();
    }
  }

  public void getAddress(byte[] address)
  {
    System.arraycopy(this.CurrentDevice, 0, address, 0, 8);
  }

  public void setAddress(byte[] address)
  {
    System.arraycopy(address, 0, this.CurrentDevice, 0, 8);
  }

  public void setSearchOnlyAlarmingDevices()
  {
    this.searchOnlyAlarmingButtons = true;
  }

  public void setNoResetSearch()
  {
    this.skipResetOnSearch = true;
  }

  public void setSearchAllDevices()
  {
    this.searchOnlyAlarmingButtons = false;
    this.skipResetOnSearch = false;
  }

  public boolean beginExclusive(boolean blocking)
    throws OneWireException
  {
    return this.serial.beginExclusive(blocking);
  }

  public void endExclusive()
  {
    this.serial.endExclusive();
  }

  private void beginLocalExclusive()
    throws OneWireException
  {
    if (this.serial == null) {
      throw new OneWireException("DS9097EAdapter: port not selected ");
    }

    if (this.serial.haveExclusive()) {
      return;
    }

    do
    {
      synchronized (this.syncObject)
      {
        this.haveLocalUse = this.serial.beginExclusive(false);
      }
      if (this.haveLocalUse) continue;
      try {
        Thread.sleep(50L);
      }
      catch (Exception e)
      {
      }
    }
    while (!this.haveLocalUse);
  }

  private void endLocalExclusive()
  {
    synchronized (this.syncObject)
    {
      if (this.haveLocalUse)
      {
        this.haveLocalUse = false;

        this.serial.endExclusive();
      }
    }
  }

  public void putBit(boolean bitValue)
    throws OneWireIOException, OneWireException
  {
    try
    {
      beginLocalExclusive();

      if (adapterDetected())
      {
        char send_byte;
        if (bitValue)
          send_byte = 'ÿ';
        else {
          send_byte = '\000';
        }
        this.serial.flush();

        this.serial.write(send_byte);
        char[] result = this.serial.readWithTimeout(1);

        if (result[0] != send_byte)
          throw new OneWireIOException("Error during putBit(), echo was incorrect");
      }
      else
      {
        throw new OneWireIOException("Error communicating with adapter");
      }
    }
    catch (IOException ioe)
    {
      throw new OneWireIOException(ioe.toString());
    }
    finally
    {
      endLocalExclusive(); }  } 
  // ERROR //
  public boolean getBit() throws OneWireIOException, OneWireException { // Byte code:
    //   0: aload_0
    //   1: invokespecial 23	com/dalsemi/onewire/adapter/LSerialAdapter:beginLocalExclusive	()V
    //   4: aload_0
    //   5: invokevirtual 56	com/dalsemi/onewire/adapter/LSerialAdapter:adapterDetected	()Z
    //   8: ifeq +49 -> 57
    //   11: aload_0
    //   12: getfield 5	com/dalsemi/onewire/adapter/LSerialAdapter:serial	Lcom/dalsemi/onewire/adapter/SerialService;
    //   15: invokevirtual 57	com/dalsemi/onewire/adapter/SerialService:flush	()V
    //   18: aload_0
    //   19: getfield 5	com/dalsemi/onewire/adapter/LSerialAdapter:serial	Lcom/dalsemi/onewire/adapter/SerialService;
    //   22: sipush 255
    //   25: invokevirtual 58	com/dalsemi/onewire/adapter/SerialService:write	(C)V
    //   28: aload_0
    //   29: getfield 5	com/dalsemi/onewire/adapter/LSerialAdapter:serial	Lcom/dalsemi/onewire/adapter/SerialService;
    //   32: iconst_1
    //   33: invokevirtual 59	com/dalsemi/onewire/adapter/SerialService:readWithTimeout	(I)[C
    //   36: astore_1
    //   37: aload_1
    //   38: iconst_0
    //   39: caload
    //   40: sipush 255
    //   43: if_icmpne +7 -> 50
    //   46: iconst_1
    //   47: goto +4 -> 51
    //   50: iconst_0
    //   51: istore_2
    //   52: jsr +34 -> 86
    //   55: iload_2
    //   56: ireturn
    //   57: new 28	com/dalsemi/onewire/adapter/OneWireIOException
    //   60: dup
    //   61: ldc 61
    //   63: invokespecial 30	com/dalsemi/onewire/adapter/OneWireIOException:<init>	(Ljava/lang/String;)V
    //   66: athrow
    //   67: astore_1
    //   68: new 28	com/dalsemi/onewire/adapter/OneWireIOException
    //   71: dup
    //   72: aload_1
    //   73: invokevirtual 29	java/lang/Throwable:toString	()Ljava/lang/String;
    //   76: invokespecial 30	com/dalsemi/onewire/adapter/OneWireIOException:<init>	(Ljava/lang/String;)V
    //   79: athrow
    //   80: astore_3
    //   81: jsr +5 -> 86
    //   84: aload_3
    //   85: athrow
    //   86: astore 4
    //   88: aload_0
    //   89: invokespecial 31	com/dalsemi/onewire/adapter/LSerialAdapter:endLocalExclusive	()V
    //   92: ret 4
    //
    // Exception table:
    //   from	to	target	type
    //   0	67	67	java/io/IOException
    //   0	80	80	finally } 
  public void putByte(int byteValue) throws OneWireIOException, OneWireException { byte[] temp_block = new byte[1];

    temp_block[0] = (byte)byteValue;

    dataBlock(temp_block, 0, 1);
  }

  public int getByte()
    throws OneWireIOException, OneWireException
  {
    byte[] temp_block = new byte[1];

    temp_block[0] = -1;

    dataBlock(temp_block, 0, 1);

    if (temp_block.length == 1) {
      return temp_block[0] & 0xFF;
    }
    throw new OneWireIOException("Error communicating with adapter");
  }

  public byte[] getBlock(int len)
    throws OneWireIOException, OneWireException
  {
    byte[] temp_block = new byte[len];

    for (int i = 0; i < len; i++) {
      temp_block[i] = -1;
    }
    getBlock(temp_block, len);

    return temp_block;
  }

  public void getBlock(byte[] arr, int len)
    throws OneWireIOException, OneWireException
  {
    getBlock(arr, 0, len);
  }

  public void getBlock(byte[] arr, int off, int len)
    throws OneWireIOException, OneWireException
  {
    for (int i = off; i < len; i++) {
      arr[i] = -1;
    }
    dataBlock(arr, off, len);
  }

  public void dataBlock(byte[] dataBlock, int off, int len)
    throws OneWireIOException, OneWireException
  {
    try
    {
      beginLocalExclusive();

      if (adapterDetected())
      {
        int t_off = off;
        int t_len = len;
        do
        {
          if (t_len > 128) {
            t_len = 128;
          }
          char[] send_block = constructSendBlock(dataBlock, t_off, t_len);

          this.serial.flush();

          this.serial.write(send_block);
          char[] raw_recv = this.serial.readWithTimeout(send_block.length);

          byte[] recv = interpretRecvBlock(raw_recv);

          System.arraycopy(recv, 0, dataBlock, t_off, t_len);

          t_off += t_len;
          t_len = off + len - t_off;
        }
        while (t_len > 0);
      }
      else
      {
        throw new OneWireIOException("Error communicating with adapter");
      }
    }
    catch (IOException ioe)
    {
      throw new OneWireIOException(ioe.toString());
    }
    finally
    {
      endLocalExclusive();
    }
  }

  public int reset()
    throws OneWireIOException, OneWireException
  {
    try
    {
      beginLocalExclusive();

      if (adapterDetected())
      {
        this.serial.flush();

        this.serial.sendBreak(1);

        c = this.serial.readWithTimeout(1);

        i = 1; jsr 67;
      }

      c = 0;
    }
    catch (IOException ioe)
    {
      char[] c;
      int i;
      return 0;
    }
    catch (OneWireIOException e)
    {
      if (doDebugMessages) {
        System.err.println("DS9097EAdapter: Not detected " + e);
      }
      return 0;
    }
    finally
    {
      endLocalExclusive();
    }
  }

  private boolean search(boolean resetSearch)
    throws OneWireIOException, OneWireException
  {
    int bit_number = 1;
    int last_zero = 0;
    int serial_byte_number = 0;
    int serial_byte_mask = 1;
    boolean next_result = false;
    int lastcrc8 = 0;

    if (resetSearch)
    {
      this.LastDiscrepancy = 0;
      this.LastDevice = false;
      this.LastFamilyDiscrepancy = 0;
    }

    if (!this.LastDevice)
    {
      if (!this.skipResetOnSearch)
      {
        if (reset() != 1)
        {
          this.LastDiscrepancy = 0;
          this.LastFamilyDiscrepancy = 0;
          return false;
        }

      }

      if (this.searchOnlyAlarmingButtons)
        putByte(236);
      else {
        putByte(240);
      }

      do
      {
        int bit_test = (getBit() ? 1 : 0) << 1;
        bit_test |= (getBit() ? 1 : 0);

        if (bit_test == 3)
          break;
        boolean search_direction;
        if (bit_test > 0) {
          search_direction = (bit_test & 0x1) != 1;
        }
        else
        {
          if (bit_number < this.LastDiscrepancy) {
            search_direction = (this.CurrentDevice[serial_byte_number] & serial_byte_mask) > 0;
          }
          else {
            search_direction = bit_number == this.LastDiscrepancy;
          }

          if (!search_direction) {
            last_zero = bit_number;
          }

          if (last_zero < 9) {
            this.LastFamilyDiscrepancy = last_zero;
          }

        }

        if (search_direction)
        {
          int tmp231_229 = serial_byte_number;
          byte[] tmp231_226 = this.CurrentDevice; tmp231_226[tmp231_229] = (byte)(tmp231_226[tmp231_229] | serial_byte_mask);
        }
        else
        {
          int tmp247_245 = serial_byte_number;
          byte[] tmp247_242 = this.CurrentDevice; tmp247_242[tmp247_245] = (byte)(tmp247_242[tmp247_245] & (serial_byte_mask ^ 0xFFFFFFFF));
        }

        putBit(search_direction);

        bit_number++;
        serial_byte_mask = serial_byte_mask <<= 1 & 0xFF;

        if (serial_byte_mask != 0) {
          continue;
        }
        lastcrc8 = CRC8.compute(this.CurrentDevice[serial_byte_number], lastcrc8);
        serial_byte_number++;
        serial_byte_mask = 1;
      }

      while (serial_byte_number < 8);

      if ((bit_number >= 65) && (lastcrc8 == 0))
      {
        this.LastDiscrepancy = last_zero;
        this.LastDevice = (this.LastDiscrepancy == 0);
        next_result = true;
      }

    }

    if ((!next_result) || (this.CurrentDevice[0] == 0))
    {
      this.LastDiscrepancy = 0;
      this.LastDevice = false;
      this.LastFamilyDiscrepancy = 0;
      next_result = false;
    }

    return next_result;
  }

  private boolean adapterPresent()
  {
    if (!this.adapterPresent)
    {
      char[] test_buf = { 'ÿ', '\000', 'ÿ', '\000', 'ÿ', '\000', 'ÿ', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', 'ã', 'Á', 'A', 'T', 'E', '0', '\r', 'A' };
      try
      {
        this.serial.flush();

        this.serial.sendBreak(1);

        char[] c = this.serial.readWithTimeout(1);

        this.serial.flush();
        this.serial.write(test_buf);

        char[] result = this.serial.readWithTimeout(test_buf.length);

        this.serial.flush();

        this.adapterPresent = true;
      }
      catch (IOException ioe)
      {
      }

    }

    return this.adapterPresent;
  }

  private char[] constructSendBlock(byte[] data, int off, int len)
  {
    int cnt = 0;
    char[] send_block = new char[len * 8];

    for (int i = 0; i < len; i++)
    {
      int shift_byte = data[(i + off)];

      for (int j = 0; j < 8; j++)
      {
        if ((shift_byte & 0x1) == 1)
          send_block[(cnt++)] = 'ÿ';
        else {
          send_block[(cnt++)] = '\000';
        }
        shift_byte >>>= 1;
      }
    }

    return send_block;
  }

  private byte[] interpretRecvBlock(char[] rawBlock)
  {
    int shift_byte = 0; int bit_cnt = 0; int byte_cnt = 0;
    byte[] recv_block = new byte[rawBlock.length / 8];

    for (int i = 0; i < rawBlock.length; i++)
    {
      shift_byte >>>= 1;

      if (rawBlock[i] == 'ÿ') {
        shift_byte |= 128;
      }
      bit_cnt++;

      if (bit_cnt != 8)
        continue;
      bit_cnt = 0;
      recv_block[(byte_cnt++)] = (byte)shift_byte;
      shift_byte = 0;
    }

    return recv_block;
  }
}