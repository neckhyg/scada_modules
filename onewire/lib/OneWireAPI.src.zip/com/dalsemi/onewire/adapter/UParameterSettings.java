package com.dalsemi.onewire.adapter;

class UParameterSettings
{
  public static final char PARAMETER_SLEW = '\020';
  public static final char PARAMETER_12VPULSE = ' ';
  public static final char PARAMETER_5VPULSE = '0';
  public static final char PARAMETER_WRITE1LOW = '@';
  public static final char PARAMETER_SAMPLEOFFSET = 'P';
  public static final char PARAMETER_BAUDRATE = 'p';
  public static final char SLEWRATE_15Vus = '\000';
  public static final char SLEWRATE_2p2Vus = '\002';
  public static final char SLEWRATE_1p65Vus = '\004';
  public static final char SLEWRATE_1p37Vus = '\006';
  public static final char SLEWRATE_1p1Vus = '\b';
  public static final char SLEWRATE_0p83Vus = '\n';
  public static final char SLEWRATE_0p7Vus = '\f';
  public static final char SLEWRATE_0p55Vus = '\016';
  public static final char TIME12V_32us = '\000';
  public static final char TIME12V_64us = '\002';
  public static final char TIME12V_128us = '\004';
  public static final char TIME12V_256us = '\006';
  public static final char TIME12V_512us = '\b';
  public static final char TIME12V_1024us = '\n';
  public static final char TIME12V_2048us = '\f';
  public static final char TIME12V_infinite = '\016';
  public static final char TIME5V_16p4ms = '\000';
  public static final char TIME5V_65p5ms = '\002';
  public static final char TIME5V_131ms = '\004';
  public static final char TIME5V_262ms = '\006';
  public static final char TIME5V_524ms = '\b';
  public static final char TIME5V_1p05s = '\n';
  public static final char TIME5V_2p10s = '\f';
  public static final char TIME5V_dynamic = '\f';
  public static final char TIME5V_infinite = '\016';
  public static final char WRITE1TIME_8us = '\000';
  public static final char WRITE1TIME_9us = '\002';
  public static final char WRITE1TIME_10us = '\004';
  public static final char WRITE1TIME_11us = '\006';
  public static final char WRITE1TIME_12us = '\b';
  public static final char WRITE1TIME_13us = '\n';
  public static final char WRITE1TIME_14us = '\f';
  public static final char WRITE1TIME_15us = '\016';
  public static final char SAMPLEOFFSET_TIME_4us = '\000';
  public static final char SAMPLEOFFSET_TIME_5us = '\002';
  public static final char SAMPLEOFFSET_TIME_6us = '\004';
  public static final char SAMPLEOFFSET_TIME_7us = '\006';
  public static final char SAMPLEOFFSET_TIME_8us = '\b';
  public static final char SAMPLEOFFSET_TIME_9us = '\n';
  public static final char SAMPLEOFFSET_TIME_10us = '\f';
  public static final char SAMPLEOFFSET_TIME_11us = '\016';
  public char pullDownSlewRate;
  public char pulse12VoltTime;
  public char pulse5VoltTime;
  public char write1LowTime;
  public char sampleOffsetTime;

  public UParameterSettings()
  {
    this.pullDownSlewRate = '\006';
    this.pulse12VoltTime = '\016';
    this.pulse5VoltTime = '\016';
    this.write1LowTime = '\004';
    this.sampleOffsetTime = '\b';
  }
}