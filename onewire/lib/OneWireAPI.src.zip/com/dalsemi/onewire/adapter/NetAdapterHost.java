package com.dalsemi.onewire.adapter;

import com.dalsemi.onewire.OneWireAccessProvider;
import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.utils.CRC16;
import com.dalsemi.onewire.utils.Convert;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Random;

public class NetAdapterHost
  implements Runnable, NetAdapterConstants
{
  protected static final Random rand = new Random();

  protected DSPortAdapter adapter = null;

  protected ServerSocket serverSocket = null;

  protected byte[] netAdapterSecret = null;

  protected volatile boolean hostStopped = false; protected volatile boolean hostRunning = false;

  protected boolean singleThreaded = true;

  protected Hashtable hashHandlers = null;

  protected MulticastListener multicastListener = null;

  protected int timeoutInSeconds = 30;

  public NetAdapterHost(DSPortAdapter adapter)
    throws IOException
  {
    this(adapter, 6161, false);
  }

  public NetAdapterHost(DSPortAdapter adapter, int listenPort)
    throws IOException
  {
    this(adapter, listenPort, false);
  }

  public NetAdapterHost(DSPortAdapter adapter, boolean multiThread)
    throws IOException
  {
    this(adapter, 6161, multiThread);
  }

  public NetAdapterHost(DSPortAdapter adapter, int listenPort, boolean multiThread)
    throws IOException
  {
    this.adapter = adapter;

    this.serverSocket = new ServerSocket(listenPort);

    this.singleThreaded = (!multiThread);
    if (multiThread)
    {
      this.hashHandlers = new Hashtable();
      this.timeoutInSeconds = 0;
    }

    String secret = OneWireAccessProvider.getProperty("NetAdapter.secret");
    if (secret != null)
      this.netAdapterSecret = secret.getBytes();
    else
      this.netAdapterSecret = "Adapter Secret Default".getBytes();
  }

  public NetAdapterHost(DSPortAdapter adapter, ServerSocket serverSock)
    throws IOException
  {
    this(adapter, serverSock, false);
  }

  public NetAdapterHost(DSPortAdapter adapter, ServerSocket serverSock, boolean multiThread)
    throws IOException
  {
    this.adapter = adapter;

    this.serverSocket = serverSock;

    this.singleThreaded = (!multiThread);
    if (multiThread)
    {
      this.hashHandlers = new Hashtable();
      this.timeoutInSeconds = 0;
    }

    String secret = OneWireAccessProvider.getProperty("NetAdapter.secret");
    if (secret != null)
      this.netAdapterSecret = secret.getBytes();
    else
      this.netAdapterSecret = "Adapter Secret Default".getBytes();
  }

  public void setSecret(String secret)
  {
    this.netAdapterSecret = secret.getBytes();
  }

  public void createMulticastListener()
    throws IOException, UnknownHostException
  {
    createMulticastListener(6163);
  }

  public void createMulticastListener(int port)
    throws IOException, UnknownHostException
  {
    String group = OneWireAccessProvider.getProperty("NetAdapter.MulticastGroup");

    if (group == null)
      group = "228.5.6.7";
    createMulticastListener(port, group);
  }

  public void createMulticastListener(int port, String group)
    throws IOException, UnknownHostException
  {
    if (this.multicastListener == null)
    {
      byte[] versionBytes = Convert.toByteArray(1);

      byte[] listenPortBytes = new byte[5];
      Convert.toByteArray(this.serverSocket.getLocalPort(), listenPortBytes, 0, 4);

      listenPortBytes[4] = -1;

      this.multicastListener = new MulticastListener(port, group, versionBytes, listenPortBytes);

      new Thread(this.multicastListener).start();
    }
  }

  public void run()
  {
    this.hostRunning = true;
    while (!this.hostStopped)
    {
      Socket sock = null;
      try
      {
        sock = this.serverSocket.accept();
        handleConnection(sock);
      }
      catch (IOException ioe1)
      {
        try
        {
          if (sock != null)
            sock.close();
        }
        catch (IOException ioe2) {
        }
      }
    }
    this.hostRunning = false;
  }

  public void handleConnection(Socket sock)
    throws IOException
  {
    SocketHandler sh = new SocketHandler(sock);
    if (this.singleThreaded)
    {
      sh.run();
    }
    else
    {
      Thread t = new Thread(sh);
      t.start();
      synchronized (this.hashHandlers)
      {
        this.hashHandlers.put(t, sh);
      }
    }
  }

  public void stopHost()
  {
    this.hostStopped = true;
    try
    {
      this.serverSocket.close();
    }
    catch (IOException ioe)
    {
    }

    int i = 0;
    while ((this.hostRunning) && (i++ < 100)) try {
        Thread.sleep(10L);
      } catch (Exception ) {
      } if (!this.singleThreaded)
    {
      synchronized (this.hashHandlers)
      {
        Enumeration e = this.hashHandlers.elements();
        while (e.hasMoreElements()) {
          ((SocketHandler)e.nextElement()).stopHandler();
        }
      }
    }
    if (this.multicastListener != null) {
      this.multicastListener.stopListener();
    }

    this.adapter.endExclusive();
  }

  private boolean sendVersionUID(NetAdapterConstants.Connection conn)
    throws IOException
  {
    conn.output.writeInt(1);
    conn.output.flush();

    byte retVal = conn.input.readByte();

    return retVal == -1;
  }

  private void processRequests(NetAdapterConstants.Connection conn)
    throws IOException
  {
    byte cmd = 0;

    cmd = conn.input.readByte();
    try
    {
      switch (cmd)
      {
      case 9:
        conn.output.writeByte(-1);
        conn.output.flush();
        break;
      case 8:
        close(conn);
        break;
      case 16:
        adapterReset(conn);
        break;
      case 17:
        adapterPutBit(conn);
        break;
      case 18:
        adapterPutByte(conn);
        break;
      case 19:
        adapterGetBit(conn);
        break;
      case 20:
        adapterGetByte(conn);
        break;
      case 21:
        adapterGetBlock(conn);
        break;
      case 22:
        adapterDataBlock(conn);
        break;
      case 23:
        adapterSetPowerDuration(conn);
        break;
      case 24:
        adapterStartPowerDelivery(conn);
        break;
      case 25:
        adapterSetProgramPulseDuration(conn);
        break;
      case 26:
        adapterStartProgramPulse(conn);
        break;
      case 27:
        adapterStartBreak(conn);
        break;
      case 28:
        adapterSetPowerNormal(conn);
        break;
      case 29:
        adapterSetSpeed(conn);
        break;
      case 30:
        adapterGetSpeed(conn);
        break;
      case 31:
        adapterBeginExclusive(conn);
        break;
      case 32:
        adapterEndExclusive(conn);
        break;
      case 33:
        adapterFindFirstDevice(conn);
        break;
      case 34:
        adapterFindNextDevice(conn);
        break;
      case 35:
        adapterGetAddress(conn);
        break;
      case 36:
        adapterSetSearchOnlyAlarmingDevices(conn);
        break;
      case 37:
        adapterSetNoResetSearch(conn);
        break;
      case 38:
        adapterSetSearchAllDevices(conn);
        break;
      case 39:
        adapterTargetAllFamilies(conn);
        break;
      case 40:
        adapterTargetFamily(conn);
        break;
      case 41:
        adapterExcludeFamily(conn);
        break;
      case 42:
        adapterCanBreak(conn);
        break;
      case 43:
        adapterCanDeliverPower(conn);
        break;
      case 44:
        adapterCanDeliverSmartPower(conn);
        break;
      case 45:
        adapterCanFlex(conn);
        break;
      case 46:
        adapterCanHyperdrive(conn);
        break;
      case 47:
        adapterCanOverdrive(conn);
        break;
      case 48:
        adapterCanProgram(conn);
      case 10:
      case 11:
      case 12:
      case 13:
      case 14:
      case 15:
      }
    } catch (OneWireException owe) {
      conn.output.writeByte(-16);
      conn.output.writeUTF(owe.toString());
      conn.output.flush();
    }
  }

  private void close(NetAdapterConstants.Connection conn)
  {
    try
    {
      if (conn.sock != null)
      {
        conn.sock.close();
      }
    }
    catch (IOException ioe)
    {
    }
    conn.sock = null;
    conn.input = null;
    conn.output = null;

    this.adapter.endExclusive();
  }

  private void adapterFindFirstDevice(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    boolean b = this.adapter.findFirstDevice();

    conn.output.writeByte(-1);
    conn.output.writeBoolean(b);
    conn.output.flush();
  }

  private void adapterFindNextDevice(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    boolean b = this.adapter.findNextDevice();

    conn.output.writeByte(-1);
    conn.output.writeBoolean(b);
    conn.output.flush();
  }

  private void adapterGetAddress(NetAdapterConstants.Connection conn)
    throws IOException
  {
    byte[] address = new byte[8];

    this.adapter.getAddress(address);

    conn.output.writeByte(-1);
    conn.output.write(address, 0, 8);
    conn.output.flush();
  }

  private void adapterSetSearchOnlyAlarmingDevices(NetAdapterConstants.Connection conn)
    throws IOException
  {
    this.adapter.setSearchOnlyAlarmingDevices();

    conn.output.writeByte(-1);
    conn.output.flush();
  }

  private void adapterSetNoResetSearch(NetAdapterConstants.Connection conn)
    throws IOException
  {
    this.adapter.setNoResetSearch();

    conn.output.writeByte(-1);
    conn.output.flush();
  }

  private void adapterSetSearchAllDevices(NetAdapterConstants.Connection conn)
    throws IOException
  {
    this.adapter.setSearchAllDevices();

    conn.output.writeByte(-1);
    conn.output.flush();
  }

  private void adapterTargetAllFamilies(NetAdapterConstants.Connection conn)
    throws IOException
  {
    this.adapter.targetAllFamilies();

    conn.output.writeByte(-1);
    conn.output.flush();
  }

  private void adapterTargetFamily(NetAdapterConstants.Connection conn)
    throws IOException
  {
    int len = conn.input.readInt();

    byte[] family = new byte[len];
    conn.input.readFully(family, 0, len);

    this.adapter.targetFamily(family);

    conn.output.writeByte(-1);
    conn.output.flush();
  }

  private void adapterExcludeFamily(NetAdapterConstants.Connection conn)
    throws IOException
  {
    int len = conn.input.readInt();

    byte[] family = new byte[len];
    conn.input.readFully(family, 0, len);

    this.adapter.excludeFamily(family);

    conn.output.writeByte(-1);
    conn.output.flush();
  }

  private void adapterBeginExclusive(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    boolean blocking = conn.input.readBoolean();

    boolean b = this.adapter.beginExclusive(blocking);

    conn.output.writeByte(-1);
    conn.output.writeBoolean(b);
    conn.output.flush();
  }

  private void adapterEndExclusive(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    this.adapter.endExclusive();

    conn.output.writeByte(-1);
    conn.output.flush();
  }

  private void adapterReset(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    int i = this.adapter.reset();

    conn.output.writeByte(-1);
    conn.output.writeInt(i);
    conn.output.flush();
  }

  private void adapterPutBit(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    boolean bit = conn.input.readBoolean();

    this.adapter.putBit(bit);

    conn.output.writeByte(-1);
    conn.output.flush();
  }

  private void adapterPutByte(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    byte b = conn.input.readByte();

    this.adapter.putByte(b);

    conn.output.writeByte(-1);
    conn.output.flush();
  }

  private void adapterGetBit(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    boolean bit = this.adapter.getBit();

    conn.output.writeByte(-1);
    conn.output.writeBoolean(bit);
    conn.output.flush();
  }

  private void adapterGetByte(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    int b = this.adapter.getByte();

    conn.output.writeByte(-1);
    conn.output.writeByte(b);
    conn.output.flush();
  }

  private void adapterGetBlock(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    int len = conn.input.readInt();

    byte[] b = this.adapter.getBlock(len);

    conn.output.writeByte(-1);
    conn.output.write(b, 0, len);
    conn.output.flush();
  }

  private void adapterDataBlock(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    int len = conn.input.readInt();

    byte[] b = new byte[len];
    conn.input.readFully(b, 0, len);

    this.adapter.dataBlock(b, 0, len);

    conn.output.writeByte(-1);
    conn.output.write(b, 0, len);
    conn.output.flush();
  }

  private void adapterSetPowerDuration(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    int timeFactor = conn.input.readInt();

    this.adapter.setPowerDuration(timeFactor);

    conn.output.writeByte(-1);
    conn.output.flush();
  }

  private void adapterStartPowerDelivery(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    int changeCondition = conn.input.readInt();

    boolean success = this.adapter.startPowerDelivery(changeCondition);

    conn.output.writeByte(-1);
    conn.output.writeBoolean(success);
    conn.output.flush();
  }

  private void adapterSetProgramPulseDuration(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    int timeFactor = conn.input.readInt();

    this.adapter.setProgramPulseDuration(timeFactor);

    conn.output.writeByte(-1);
    conn.output.flush();
  }

  private void adapterStartProgramPulse(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    int changeCondition = conn.input.readInt();

    boolean success = this.adapter.startProgramPulse(changeCondition);

    conn.output.writeByte(-1);
    conn.output.writeBoolean(success);
    conn.output.flush();
  }

  private void adapterStartBreak(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    this.adapter.startBreak();

    conn.output.writeByte(-1);
    conn.output.flush();
  }

  private void adapterSetPowerNormal(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    this.adapter.setPowerNormal();

    conn.output.writeByte(-1);
    conn.output.flush();
  }

  private void adapterSetSpeed(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    int speed = conn.input.readInt();

    this.adapter.setSpeed(speed);

    conn.output.writeByte(-1);
    conn.output.flush();
  }

  private void adapterGetSpeed(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    int speed = this.adapter.getSpeed();

    conn.output.writeByte(-1);
    conn.output.writeInt(speed);
    conn.output.flush();
  }

  private void adapterCanOverdrive(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    boolean b = this.adapter.canOverdrive();

    conn.output.writeByte(-1);
    conn.output.writeBoolean(b);
    conn.output.flush();
  }

  private void adapterCanHyperdrive(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    boolean b = this.adapter.canHyperdrive();

    conn.output.writeByte(-1);
    conn.output.writeBoolean(b);
    conn.output.flush();
  }

  private void adapterCanFlex(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    boolean b = this.adapter.canFlex();

    conn.output.writeByte(-1);
    conn.output.writeBoolean(b);
    conn.output.flush();
  }

  private void adapterCanProgram(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    boolean b = this.adapter.canProgram();

    conn.output.writeByte(-1);
    conn.output.writeBoolean(b);
    conn.output.flush();
  }

  private void adapterCanDeliverPower(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    boolean b = this.adapter.canDeliverPower();

    conn.output.writeByte(-1);
    conn.output.writeBoolean(b);
    conn.output.flush();
  }

  private void adapterCanDeliverSmartPower(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    boolean b = this.adapter.canDeliverSmartPower();

    conn.output.writeByte(-1);
    conn.output.writeBoolean(b);
    conn.output.flush();
  }

  private void adapterCanBreak(NetAdapterConstants.Connection conn)
    throws IOException, OneWireException
  {
    boolean b = this.adapter.canBreak();

    conn.output.writeByte(-1);
    conn.output.writeBoolean(b);
    conn.output.flush();
  }

  public static void main(String[] args)
    throws Exception
  {
    DSPortAdapter adapter = OneWireAccessProvider.getDefaultAdapter();

    NetAdapterHost host = new NetAdapterHost(adapter, true);

    System.out.println("Starting Multicast Listener");
    host.createMulticastListener();

    System.out.println("Starting NetAdapter Host");
    new Thread(host).start();
  }

  private class SocketHandler
    implements Runnable
  {
    private NetAdapterConstants.Connection conn;
    private volatile boolean handlerRunning = false;

    public SocketHandler(Socket sock)
      throws IOException
    {
      sock.setSoTimeout(NetAdapterHost.this.timeoutInSeconds * 1000);

      this.conn = new NetAdapterConstants.Connection();
      this.conn.sock = sock;
      this.conn.input = new DataInputStream(this.conn.sock.getInputStream());

      this.conn.output = new DataOutputStream(new BufferedOutputStream(this.conn.sock.getOutputStream()));

      if (!NetAdapterHost.this.sendVersionUID(this.conn))
      {
        throw new IOException("send version failed");
      }

      byte[] chlg = new byte[8];
      NetAdapterHost.rand.nextBytes(chlg);
      this.conn.output.write(chlg);
      this.conn.output.flush();

      int crc = CRC16.compute(NetAdapterHost.this.netAdapterSecret, 0);
      crc = CRC16.compute(chlg, crc);
      int answer = this.conn.input.readInt();
      if (answer != crc)
      {
        this.conn.output.writeByte(-16);
        this.conn.output.writeUTF("Client Authentication Failed");
        this.conn.output.flush();
        throw new IOException("authentication failed");
      }

      this.conn.output.writeByte(-1);
      this.conn.output.flush();
    }

    public void run()
    {
      this.handlerRunning = true;
      try
      {
        do
        {
          NetAdapterHost.this.processRequests(this.conn);

          if (NetAdapterHost.this.hostStopped) break; 
        }while (this.conn.sock != null);
      }
      catch (Throwable )
      {
        NetAdapterHost.this.close(this.conn);
      }
      this.handlerRunning = false;

      if ((!NetAdapterHost.this.hostStopped) && (!NetAdapterHost.this.singleThreaded))
      {
        synchronized (NetAdapterHost.this.hashHandlers)
        {
          NetAdapterHost.this.hashHandlers.remove(Thread.currentThread());
        }
      }
    }

    public void stopHandler()
    {
      int i = 0;
      int timeout = 3000;
      while ((this.handlerRunning) && (i++ < timeout)) try {
          Thread.sleep(10L);
        }
        catch (Exception e)
        {
        }
    }
  }
}