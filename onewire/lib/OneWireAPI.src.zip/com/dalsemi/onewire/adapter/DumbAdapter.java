package com.dalsemi.onewire.adapter;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.container.OneWireContainer;
import com.dalsemi.onewire.utils.Address;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

public class DumbAdapter extends DSPortAdapter
{
  int containers_index = 0;

  private Vector containers = new Vector();

  private Hashtable registeredOneWireContainerClasses = new Hashtable(5);
  private byte[] include;
  private byte[] exclude;
  private int sp = 0;

  public void addContainer(OneWireContainer c)
  {
    synchronized (this.containers)
    {
      this.containers.addElement(c);
    }
  }

  public void removeContainer(OneWireContainer c)
  {
    synchronized (this.containers)
    {
      this.containers.removeElement(c);
    }
  }

  public String getAdapterName()
  {
    return "DumbAdapter";
  }

  public String getPortTypeDescription()
  {
    return "Virtual Emulated Port";
  }

  public String getClassVersion()
  {
    return "0.00";
  }

  public Enumeration getPortNames()
  {
    Vector portNames = new Vector();
    portNames.addElement("NULL0");
    return portNames.elements();
  }

  public void registerOneWireContainerClass(int family, Class OneWireContainerClass)
  {
  }

  public boolean selectPort(String portName)
  {
    return true;
  }

  public void freePort()
  {
  }

  public String getPortName()
  {
    return "NULL0";
  }

  public boolean adapterDetected()
  {
    return true;
  }

  public boolean canOverdrive()
  {
    return true;
  }

  public boolean canHyperdrive()
  {
    return true;
  }

  public boolean canFlex()
  {
    return true;
  }

  public boolean canProgram()
  {
    return true;
  }

  public boolean canDeliverPower()
  {
    return true;
  }

  public boolean canDeliverSmartPower()
  {
    return true;
  }

  public boolean canBreak()
  {
    return true;
  }

  public Enumeration getAllDeviceContainers()
  {
    Vector copy_vector = new Vector();
    synchronized (this.containers)
    {
      for (int i = 0; i < this.containers.size(); i++)
      {
        copy_vector.addElement(this.containers.elementAt(i));
      }
    }
    return copy_vector.elements();
  }

  public OneWireContainer getFirstDeviceContainer()
  {
    synchronized (this.containers)
    {
      OneWireContainer localOneWireContainer;
      if (this.containers.size() > 0)
      {
        this.containers_index = 1;
        return (OneWireContainer)this.containers.elementAt(0);
      }

      return null;
    }
  }

  public OneWireContainer getNextDeviceContainer()
  {
    synchronized (this.containers)
    {
      OneWireContainer localOneWireContainer;
      if (this.containers.size() > this.containers_index)
      {
        this.containers_index += 1;
        return (OneWireContainer)this.containers.elementAt(this.containers_index - 1);
      }

      return null;
    }
  }

  public boolean findFirstDevice()
  {
    synchronized (this.containers)
    {
      int i;
      if (this.containers.size() > 0)
      {
        this.containers_index = 1;
        return 1;
      }

      return 0;
    }
  }

  public boolean findNextDevice()
  {
    synchronized (this.containers)
    {
      int i;
      if (this.containers.size() > this.containers_index)
      {
        this.containers_index += 1;
        return 1;
      }

      return 0;
    }
  }

  public void getAddress(byte[] address)
  {
    OneWireContainer temp = (OneWireContainer)this.containers.elementAt(this.containers_index - 1);
    if (temp != null)
    {
      System.arraycopy(temp.getAddress(), 0, address, 0, 8);
    }
  }

  public long getAddressAsLong()
  {
    byte[] address = new byte[8];

    getAddress(address);

    return Address.toLong(address);
  }

  public String getAddressAsString()
  {
    byte[] address = new byte[8];

    getAddress(address);

    return Address.toString(address);
  }

  public boolean isPresent(byte[] address)
  {
    return isPresent(Address.toLong(address));
  }

  public boolean isPresent(long address)
  {
    synchronized (this.containers)
    {
      for (int i = 0; i < this.containers.size(); i++)
      {
        OneWireContainer temp = (OneWireContainer)this.containers.elementAt(i);
        long addr = temp.getAddressAsLong();
        if (addr == address)
          return 1;
      }
    }
    return false;
  }

  public boolean isPresent(String address)
  {
    return isPresent(Address.toByteArray(address));
  }

  public boolean isAlarming(byte[] address)
  {
    return false;
  }

  public boolean isAlarming(long address)
  {
    return isAlarming(Address.toByteArray(address));
  }

  public boolean isAlarming(String address)
  {
    return isAlarming(Address.toByteArray(address));
  }

  public boolean select(byte[] address)
  {
    return isPresent(address);
  }

  public boolean select(long address)
    throws OneWireIOException, OneWireException
  {
    return select(Address.toByteArray(address));
  }

  public boolean select(String address)
    throws OneWireIOException, OneWireException
  {
    return select(Address.toByteArray(address));
  }

  public void setSearchOnlyAlarmingDevices()
  {
  }

  public void setNoResetSearch()
  {
  }

  public void setSearchAllDevices()
  {
  }

  public void targetAllFamilies()
  {
    this.include = null;
    this.exclude = null;
  }

  public void targetFamily(int family)
  {
    if ((this.include == null) || (this.include.length != 1)) {
      this.include = new byte[1];
    }
    this.include[0] = (byte)family;
  }

  public void targetFamily(byte[] family)
  {
    if ((this.include == null) || (this.include.length != family.length)) {
      this.include = new byte[family.length];
    }
    System.arraycopy(family, 0, this.include, 0, family.length);
  }

  public void excludeFamily(int family)
  {
    if ((this.exclude == null) || (this.exclude.length != 1)) {
      this.exclude = new byte[1];
    }
    this.exclude[0] = (byte)family;
  }

  public void excludeFamily(byte[] family)
  {
    if ((this.exclude == null) || (this.exclude.length != family.length)) {
      this.exclude = new byte[family.length];
    }
    System.arraycopy(family, 0, this.exclude, 0, family.length);
  }

  public boolean beginExclusive(boolean blocking)
  {
    return true;
  }

  public void endExclusive()
  {
  }

  public void putBit(boolean bitValue)
  {
  }

  public boolean getBit()
  {
    return true;
  }

  public void putByte(int byteValue)
  {
  }

  public int getByte()
  {
    return 255;
  }

  public byte[] getBlock(int len)
  {
    return new byte[len];
  }

  public void getBlock(byte[] arr, int len)
  {
  }

  public void getBlock(byte[] arr, int off, int len)
  {
  }

  public void dataBlock(byte[] dataBlock, int off, int len)
  {
  }

  public int reset()
  {
    if (this.containers.size() > 0)
      return 1;
    return 0;
  }

  public void setPowerDuration(int timeFactor)
  {
  }

  public boolean startPowerDelivery(int changeCondition)
  {
    return true;
  }

  public void setProgramPulseDuration(int timeFactor)
  {
  }

  public boolean startProgramPulse(int changeCondition)
  {
    return true;
  }

  public void startBreak()
  {
  }

  public void setPowerNormal()
  {
  }

  public void setSpeed(int speed)
  {
    this.sp = speed;
  }

  public int getSpeed()
  {
    return this.sp;
  }

  public OneWireContainer getDeviceContainer(byte[] address)
  {
    long addr = Address.toLong(address);
    synchronized (this.containers)
    {
      for (int i = 0; i < this.containers.size(); i++)
      {
        if (((OneWireContainer)this.containers.elementAt(i)).getAddressAsLong() == addr)
          return (OneWireContainer)this.containers.elementAt(i);
      }
    }
    return null;
  }

  public OneWireContainer getDeviceContainer(long address)
  {
    return getDeviceContainer(Address.toByteArray(address));
  }

  public OneWireContainer getDeviceContainer(String address)
  {
    return getDeviceContainer(Address.toByteArray(address));
  }

  public OneWireContainer getDeviceContainer()
  {
    byte[] address = new byte[8];

    getAddress(address);

    return getDeviceContainer(address);
  }

  protected boolean isValidFamily(byte[] address)
  {
    byte familyCode = address[0];

    if (this.exclude != null)
    {
      for (int i = 0; i < this.exclude.length; i++)
      {
        if (familyCode == this.exclude[i])
        {
          return false;
        }
      }
    }

    if (this.include != null)
    {
      for (int i = 0; i < this.include.length; i++)
      {
        if (familyCode == this.include[i])
        {
          return true;
        }
      }

      return false;
    }

    return true;
  }
}