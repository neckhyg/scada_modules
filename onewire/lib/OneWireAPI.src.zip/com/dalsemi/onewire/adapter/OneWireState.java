package com.dalsemi.onewire.adapter;

class OneWireState
{
  public char oneWireSpeed;
  public char oneWireLevel;
  public boolean canProgram;
  public boolean levelChangeOnNextBit;
  public boolean levelChangeOnNextByte;
  public char primedLevelValue;
  public int levelTimeFactor;
  public int searchLastDiscrepancy;
  public int searchFamilyLastDiscrepancy;
  public boolean searchLastDevice;
  public byte[] ID;
  public byte[] searchIncludeFamilies;
  public byte[] searchExcludeFamilies;
  public boolean searchOnlyAlarmingButtons;
  public boolean skipResetOnSearch;

  public OneWireState()
  {
    this.oneWireSpeed = '\000';
    this.oneWireLevel = '\000';

    this.levelChangeOnNextBit = false;
    this.levelChangeOnNextByte = false;
    this.primedLevelValue = '\000';
    this.levelTimeFactor = 5;

    this.canProgram = false;

    this.searchIncludeFamilies = new byte[0];
    this.searchExcludeFamilies = new byte[0];
    this.searchOnlyAlarmingButtons = false;
    this.skipResetOnSearch = false;

    this.ID = new byte[8];

    this.searchLastDiscrepancy = 0;
    this.searchFamilyLastDiscrepancy = 0;
    this.searchLastDevice = false;
  }
}