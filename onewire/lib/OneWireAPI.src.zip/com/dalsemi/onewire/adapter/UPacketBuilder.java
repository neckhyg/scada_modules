package com.dalsemi.onewire.adapter;

import com.dalsemi.onewire.OneWireAccessProvider;
import com.dalsemi.onewire.utils.Address;
import java.io.PrintStream;
import java.util.Enumeration;
import java.util.Vector;

class UPacketBuilder
{
  public static final int OPERATION_BYTE = 0;
  public static final int OPERATION_SEARCH = 1;
  public static final char MAX_BYTES_STREAMED = '@';
  public static final char FUNCTION_BIT = '';
  public static final char FUNCTION_SEARCHON = '±';
  public static final char FUNCTION_SEARCHOFF = '¡';
  public static final char FUNCTION_RESET = 'Á';
  public static final char FUNCTION_5VPULSE_NOW = 'í';
  public static final char FUNCTION_12VPULSE_NOW = 'ý';
  public static final char FUNCTION_5VPULSE_ARM = 'ï';
  public static final char FUNCTION_STOP_PULSE = 'ñ';
  public static final char BIT_ONE = '\020';
  public static final char BIT_ZERO = '\000';
  public static final char PRIME5V_TRUE = '\002';
  public static final char PRIME5V_FALSE = '\000';
  public static final char CONFIG_MASK = '\001';
  public static final char RESPONSE_RESET_MASK = '\003';
  public static final char RESPONSE_RESET_SHORT = '\000';
  public static final char RESPONSE_RESET_PRESENCE = '\001';
  public static final char RESPONSE_RESET_ALARM = '\002';
  public static final char RESPONSE_RESET_NOPRESENCE = '\003';
  public static final char RESPONSE_BIT_MASK = '\003';
  public static final char RESPONSE_BIT_ONE = '\003';
  public static final char RESPONSE_BIT_ZERO = '\000';
  public static boolean doDebugMessages = false;
  private UAdapterState uState;
  protected int totalReturnLength;
  protected RawSendPacket packet;
  protected Vector packetsVector;
  protected boolean bitsOnly;

  public UPacketBuilder(UAdapterState startUState)
  {
    this.uState = startUState;

    this.packet = new RawSendPacket();

    this.packetsVector = new Vector();

    restart();

    this.bitsOnly = (System.getProperty("os.name").indexOf("SunOS") != -1);

    String bits = OneWireAccessProvider.getProperty("onewire.serial.forcebitsonly");
    if (bits != null)
    {
      if (bits.indexOf("true") != -1)
        this.bitsOnly = true;
      else if (bits.indexOf("false") != -1)
        this.bitsOnly = false;
    }
  }

  public void restart()
  {
    this.packetsVector.removeAllElements();

    this.packet.buffer.setLength(0);

    this.packet.returnLength = 0;

    this.totalReturnLength = 0;
  }

  public void newPacket()
  {
    this.packetsVector.addElement(this.packet);

    this.packet = new RawSendPacket();
  }

  public Enumeration getPackets()
  {
    if (this.packet.buffer.length() > 0) {
      newPacket();
    }
    return this.packetsVector.elements();
  }

  public int oneWireReset()
  {
    setToCommandMode();

    this.packet.buffer.append((char)(0xC1 | this.uState.uSpeedMode));

    this.totalReturnLength += 1;
    this.packet.returnLength += 1;

    if (!this.uState.streamResets) {
      newPacket();
    }

    if ((this.uState.longAlarmCheck) && ((this.uState.uSpeedMode == 0) || (this.uState.uSpeedMode == '\004')))
    {
      newPacket();
    }
    return this.totalReturnLength - 1;
  }

  public int dataBytes(char[] dataBytesValue)
  {
    if (!this.bitsOnly) {
      setToDataMode();
    }

    if (doDebugMessages) {
      System.out.println("DEBUG: UPacketbuilder-dataBytes[] length " + dataBytesValue.length);
    }

    int ret_value = this.totalReturnLength;

    for (int i = 0; i < dataBytesValue.length; i++)
    {
      if (this.bitsOnly)
      {
        char byte_value = dataBytesValue[i];
        for (int j = 0; j < 8; j++)
        {
          dataBit((byte_value & 0x1) == '\001', false);
          byte_value = (char)(byte_value >>> '\001');
        }

      }
      else
      {
        this.packet.buffer.append(dataBytesValue[i]);

        if (doDebugMessages) {
          System.out.println("DEBUG: UPacketbuilder-dataBytes[] byte[" + Integer.toHexString(dataBytesValue[i] & 0xFF) + "]");
        }

        if (((char)(dataBytesValue[i] & 0xFF) == 'ã') || (((char)(dataBytesValue[i] & 0xFF) == 'ó') && (this.uState.revision == '\004')))
        {
          this.packet.buffer.append(dataBytesValue[i]);
        }

        this.totalReturnLength += 1;
        this.packet.returnLength += 1;

        if (doDebugMessages) {
          System.out.println("DEBUG: UPacketbuilder-dataBytes[] returnlength " + this.packet.returnLength + " bufferLength " + this.packet.buffer.length());
        }

        if ((this.packet.buffer.length() <= 64) && (this.uState.streamBytes))
          continue;
        newPacket();
      }
    }

    return ret_value;
  }

  public int dataBytes(byte[] dataBytesValue, int off, int len)
  {
    char[] temp_ch = new char[len];

    for (int i = 0; i < len; i++) {
      temp_ch[i] = (char)dataBytesValue[(off + i)];
    }
    return dataBytes(temp_ch);
  }

  public int dataByte(char dataByteValue)
  {
    char[] temp_char_array = new char[1];

    temp_char_array[0] = dataByteValue;

    if (doDebugMessages) {
      System.out.println("DEBUG: UPacketbuilder-dataBytes [" + Integer.toHexString(dataByteValue & 0xFF) + "]");
    }

    return dataBytes(temp_char_array);
  }

  public int primedDataByte(byte dataByteValue)
  {
    int start_offset = 0;

    for (int i = 0; i < 8; i++)
    {
      int offset = dataBit((dataByteValue & 0x1) == 1, i == 7);
      dataByteValue = (byte)(dataByteValue >>> 1);

      if (i == 0) {
        start_offset = offset;
      }
    }
    return start_offset;
  }

  public int dataBit(boolean dataBit, boolean strong5V)
  {
    setToCommandMode();

    this.packet.buffer.append((char)(0x81 | this.uState.uSpeedMode | (dataBit ? '\020' : '\000') | (strong5V ? '\002' : '\000')));

    this.totalReturnLength += 1;
    this.packet.returnLength += 1;

    if ((this.packet.buffer.length() > 64) || (!this.uState.streamBits)) {
      newPacket();
    }
    return this.totalReturnLength - 1;
  }

  public int search(OneWireState mState)
  {
    setToCommandMode();

    this.packet.buffer.append((char)(0xB1 | this.uState.uSpeedMode));

    setToDataMode();

    char[] search_sequence = new char[16];

    char[] id = new char[8];

    for (int i = 0; i < 8; i++) {
      id[i] = (char)(mState.ID[i] & 0xFF);
    }

    for (int i = 0; i < 16; i++) {
      search_sequence[i] = '\000';
    }

    if (doDebugMessages) {
      System.out.println("DEBUG: UPacketbuilder-search [" + Integer.toHexString(id.length) + "]");
    }

    if (mState.searchLastDiscrepancy != 255)
    {
      for (int i = 0; i < 64; i++)
      {
        if (i < mState.searchLastDiscrepancy - 1) {
          bitWrite(search_sequence, i * 2 + 1, bitRead(id, i));
        }
        else if (i == mState.searchLastDiscrepancy - 1) {
          bitWrite(search_sequence, i * 2 + 1, true);
        }

      }

    }

    int return_position = this.totalReturnLength;

    this.packet.buffer.append(search_sequence);

    setToCommandMode();

    this.packet.buffer.append((char)(0xA1 | this.uState.uSpeedMode));

    this.totalReturnLength += 16;
    this.packet.returnLength += 16;

    return return_position;
  }

  public void setSpeed()
  {
    setToCommandMode();

    this.packet.buffer.append((char)(0xA1 | this.uState.uSpeedMode));
  }

  public void setToCommandMode()
  {
    if (!this.uState.inCommandMode)
    {
      this.packet.buffer.append('ã');

      this.uState.inCommandMode = true;
    }
  }

  public void setToDataMode()
  {
    if (this.uState.inCommandMode)
    {
      this.packet.buffer.append('á');

      this.uState.inCommandMode = false;
    }
  }

  public int getParameter(int parameter)
  {
    setToCommandMode();

    this.packet.buffer.append((char)(0x1 | parameter >> 3));

    this.totalReturnLength += 1;
    this.packet.returnLength += 1;

    if (this.packet.buffer.length() > 64) {
      newPacket();
    }
    return this.totalReturnLength - 1;
  }

  public int setParameter(char parameter, char parameterValue)
  {
    setToCommandMode();

    this.packet.buffer.append((char)(0x1 | parameter | parameterValue));

    this.totalReturnLength += 1;
    this.packet.returnLength += 1;

    if (this.packet.buffer.length() > 64) {
      newPacket();
    }
    return this.totalReturnLength - 1;
  }

  public int sendCommand(char command, boolean expectResponse)
  {
    setToCommandMode();

    this.packet.buffer.append(command);

    if (expectResponse)
    {
      this.totalReturnLength += 1;
      this.packet.returnLength += 1;
    }

    if (this.packet.buffer.length() > 64) {
      newPacket();
    }
    return this.totalReturnLength - 1;
  }

  public void interpretDataBytes(char[] dataByteResponse, int responseOffset, byte[] result, int offset, int len)
  {
    for (int i = 0; i < len; i++)
    {
      if (this.bitsOnly)
      {
        int temp_offset = responseOffset + 8 * i;

        if (doDebugMessages) {
          System.out.println("DEBUG: UPacketbuilder-interpretDataBytes[] responseOffset " + responseOffset + " offset " + offset + " lenbuf " + dataByteResponse.length);
        }

        char result_byte = '\000';
        for (int j = 0; j < 8; j++)
        {
          result_byte = (char)(result_byte >>> '\001');

          if (interpretOneWireBit(dataByteResponse[(temp_offset + j)])) {
            result_byte = (char)(result_byte | 0x80);
          }
        }
        result[(offset + i)] = (byte)(result_byte & 0xFF);
      }
      else {
        result[(offset + i)] = (byte)dataByteResponse[(responseOffset + i)];
      }
    }
  }

  public int interpretOneWireReset(char resetResponse)
  {
    if ((resetResponse & 0xC0) == 'À')
    {
      this.uState.revision = (char)(0x1C & resetResponse);

      this.uState.programVoltageAvailable = ((0x20 & resetResponse) != 0);

      if (doDebugMessages) {
        System.out.println("DEBUG: UPacketbuilder-reset response " + Integer.toHexString(resetResponse & 0xFF));
      }

      switch (resetResponse & 0x3)
      {
      case '\000':
        return 3;
      case '\001':
        if (this.uState.longAlarmCheck)
        {
          if (this.uState.lastAlarmCount++ > 3000) {
            this.uState.longAlarmCheck = false;
          }
        }
        return 1;
      case '\002':
        this.uState.longAlarmCheck = true;
        this.uState.lastAlarmCount = 0;

        return 2;
      case '\003':
      }
      return 0;
    }

    return 0;
  }

  public boolean interpretOneWireBit(char bitResponse)
  {
    return (bitResponse & 0x3) == '\003';
  }

  public boolean interpretSearch(OneWireState mState, char[] searchResponse, int responseOffset)
  {
    char[] temp_id = new char[8];

    int bit_offset = responseOffset * 8;

    int temp_last_descrepancy = 255;
    int temp_last_family_descrepancy = 0;

    for (int i = 0; i < 64; i++)
    {
      bitWrite(temp_id, i, bitRead(searchResponse, i * 2 + 1 + bit_offset));

      if ((!bitRead(searchResponse, i * 2 + bit_offset)) || (bitRead(searchResponse, i * 2 + 1 + bit_offset))) {
        continue;
      }
      temp_last_descrepancy = i + 1;

      if (i < 8) {
        temp_last_family_descrepancy = i + 1;
      }

    }

    byte[] id = new byte[8];

    for (int i = 0; i < 8; i++) {
      id[i] = (byte)temp_id[i];
    }

    if ((!Address.isValid(id)) || (temp_last_descrepancy == 63) || (temp_id[0] == 0))
    {
      return false;
    }

    if ((temp_last_descrepancy == mState.searchLastDiscrepancy) || (temp_last_descrepancy == 255))
    {
      mState.searchLastDevice = true;
    }

    for (int i = 0; i < 8; i++) {
      mState.ID[i] = (byte)temp_id[i];
    }

    mState.searchLastDiscrepancy = temp_last_descrepancy;
    mState.searchFamilyLastDiscrepancy = temp_last_family_descrepancy;

    return true;
  }

  public byte interpretPrimedByte(char[] primedDataResponse, int responseOffset)
  {
    char result_byte = '\000';

    for (int i = 0; i < 8; i++)
    {
      result_byte = (char)(result_byte >>> '\001');

      if (interpretOneWireBit(primedDataResponse[(responseOffset + i)])) {
        result_byte = (char)(result_byte | 0x80);
      }
    }
    return (byte)(result_byte & 0xFF);
  }

  public static int getDesiredBaud(int operation, int owSpeed, int maxBaud)
  {
    int baud = 9600;

    switch (operation)
    {
    case 0:
      if (owSpeed == 2)
        baud = 115200;
      else
        baud = 9600;
      break;
    case 1:
      if (owSpeed == 2)
        baud = 57600;
      else {
        baud = 9600;
      }
    }

    if (baud > maxBaud) {
      baud = maxBaud;
    }
    return baud;
  }

  public boolean bitRead(char[] bitBuffer, int address)
  {
    int byte_number = address / 8;
    int bit_number = address - byte_number * 8;

    return (char)(bitBuffer[byte_number] >> bit_number & 0x1) == '\001';
  }

  public void bitWrite(char[] bitBuffer, int address, boolean newBitState)
  {
    int byte_number = address / 8;
    int bit_number = address - byte_number * 8;

    if (newBitState)
    {
      int tmp22_20 = byte_number;
      char[] tmp22_19 = bitBuffer; tmp22_19[tmp22_20] = (char)(tmp22_19[tmp22_20] | (char)(1 << bit_number));
    }
    else
    {
      int tmp38_36 = byte_number;
      char[] tmp38_35 = bitBuffer; tmp38_35[tmp38_36] = (char)(tmp38_35[tmp38_36] & (char)(1 << bit_number ^ 0xFFFFFFFF));
    }
  }
}