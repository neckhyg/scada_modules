package com.dalsemi.onewire.adapter;

import com.dalsemi.onewire.OneWireException;
import java.io.File;
import java.io.PrintStream;
import java.util.Enumeration;
import java.util.Vector;

public class TMEXAdapter extends DSPortAdapter
{
  private static boolean driverLoaded = false;
  protected int portType;
  protected byte[] RomDta = new byte[8];

  private boolean doAlarmSearch = false;

  private boolean resetSearch = true;

  private boolean skipResetOnSearch = false;

  public TMEXAdapter()
    throws ClassNotFoundException
  {
    if (!driverLoaded) {
      throw new ClassNotFoundException("native driver 'ibtmjava.dll' not loaded");
    }

    this.portType = getDefaultTypeNumber();

    if (!setPortType_Native(this.portType))
      throw new ClassNotFoundException("TMEX adapter type does not exist");
  }

  public TMEXAdapter(int newPortType)
    throws ClassNotFoundException
  {
    this.portType = newPortType;

    if (!driverLoaded) {
      throw new ClassNotFoundException("native driver 'ibtmjava.dll' not loaded");
    }

    if (!setPortType_Native(this.portType))
      throw new ClassNotFoundException("TMEX adapter type does not exist");
  }

  protected void finalize()
  {
    cleanup_Native();
  }

  public native String getAdapterName();

  public native String getPortTypeDescription();

  public String getClassVersion()
  {
    return new String("0.01, native: " + getVersion_Native());
  }

  public Enumeration getPortNames()
  {
    Vector portVector = new Vector();
    String header = getPortNameHeader_Native();

    for (int i = 0; i < 16; i++) {
      portVector.addElement(new String(header + Integer.toString(i)));
    }
    return portVector.elements();
  }

  public native boolean selectPort(String paramString)
    throws OneWireIOException, OneWireException;

  public native void freePort()
    throws OneWireException;

  public native String getPortName()
    throws OneWireException;

  public native boolean adapterDetected()
    throws OneWireIOException, OneWireException;

  public native String getAdapterVersion()
    throws OneWireIOException, OneWireException;

  public String getAdapterAddress()
    throws OneWireIOException, OneWireException
  {
    return "<na>";
  }

  public native boolean canOverdrive()
    throws OneWireIOException, OneWireException;

  public native boolean canHyperdrive()
    throws OneWireIOException, OneWireException;

  public native boolean canFlex()
    throws OneWireIOException, OneWireException;

  public native boolean canProgram()
    throws OneWireIOException, OneWireException;

  public native boolean canDeliverPower()
    throws OneWireIOException, OneWireException;

  public native boolean canDeliverSmartPower()
    throws OneWireIOException, OneWireException;

  public native boolean canBreak()
    throws OneWireIOException, OneWireException;

  public boolean findFirstDevice()
    throws OneWireIOException, OneWireException
  {
    this.resetSearch = true;

    return findNextDevice();
  }

  public boolean findNextDevice()
    throws OneWireIOException, OneWireException
  {
    while (true)
    {
      boolean retval = romSearch_Native(this.skipResetOnSearch, this.resetSearch, this.doAlarmSearch, this.RomDta);

      if (!retval)
        break;
      this.resetSearch = false;

      if (isValidFamily(this.RomDta)) {
        return true;
      }

    }

    this.resetSearch = true;

    return false;
  }

  public void getAddress(byte[] address)
  {
    System.arraycopy(this.RomDta, 0, address, 0, 8);
  }

  public native boolean isPresent(byte[] paramArrayOfByte)
    throws OneWireIOException, OneWireException;

  public native boolean isAlarming(byte[] paramArrayOfByte)
    throws OneWireIOException, OneWireException;

  public native boolean select(byte[] paramArrayOfByte)
    throws OneWireIOException, OneWireException;

  public void setSearchOnlyAlarmingDevices()
  {
    this.doAlarmSearch = true;
  }

  public void setNoResetSearch()
  {
    this.skipResetOnSearch = true;
  }

  public void setSearchAllDevices()
  {
    this.doAlarmSearch = false;
    this.skipResetOnSearch = false;
  }

  public native boolean beginExclusive(boolean paramBoolean)
    throws OneWireException;

  public native void endExclusive();

  public void putBit(boolean bitValue)
    throws OneWireIOException, OneWireException
  {
    if (dataBit_Native(bitValue) != bitValue)
      throw new OneWireIOException("Error during putBit()");
  }

  public boolean getBit()
    throws OneWireIOException, OneWireException
  {
    return dataBit_Native(true);
  }

  public void putByte(int byteValue)
    throws OneWireIOException, OneWireException
  {
    if (dataByte_Native(byteValue & 0xFF) != (0xFF & byteValue))
      throw new OneWireIOException("Error during putByte(), echo was incorrect ");
  }

  public int getByte()
    throws OneWireIOException, OneWireException
  {
    return dataByte_Native(255);
  }

  public byte[] getBlock(int len)
    throws OneWireIOException, OneWireException
  {
    byte[] barr = new byte[len];

    getBlock(barr, 0, len);

    return barr;
  }

  public void getBlock(byte[] arr, int len)
    throws OneWireIOException, OneWireException
  {
    getBlock(arr, 0, len);
  }

  public native void getBlock(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws OneWireIOException, OneWireException;

  public native void dataBlock(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws OneWireIOException, OneWireException;

  public native int reset()
    throws OneWireIOException, OneWireException;

  public void setPowerDuration(int timeFactor)
    throws OneWireIOException, OneWireException
  {
    if (timeFactor != 5)
      throw new OneWireException("No support for other than infinite power duration");
  }

  public native boolean startPowerDelivery(int paramInt)
    throws OneWireIOException, OneWireException;

  public void setProgramPulseDuration(int timeFactor)
    throws OneWireIOException, OneWireException
  {
    if (timeFactor != 7)
      throw new OneWireException("Only support EPROM length program pulse duration");
  }

  public native boolean startProgramPulse(int paramInt)
    throws OneWireIOException, OneWireException;

  public native void startBreak()
    throws OneWireIOException, OneWireException;

  public native void setPowerNormal()
    throws OneWireIOException, OneWireException;

  public native void setSpeed(int paramInt)
    throws OneWireIOException, OneWireException;

  public native int getSpeed();

  public boolean setTMEXPortType(int newPortType)
  {
    this.portType = newPortType;

    return setPortType_Native(this.portType);
  }

  public static native void CleanUpByThread(Thread paramThread);

  public static native String getDefaultAdapterName();

  public static native String getDefaultPortName();

  private static native int getDefaultTypeNumber();

  private native boolean setPortType_Native(int paramInt);

  private native boolean dataBit_Native(boolean paramBoolean)
    throws OneWireIOException, OneWireException;

  private native int dataByte_Native(int paramInt)
    throws OneWireIOException, OneWireException;

  private native String getVersion_Native();

  private native boolean romSearch_Native(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, byte[] paramArrayOfByte)
    throws OneWireIOException, OneWireException;

  private native String getPortNameHeader_Native();

  private native void cleanup_Native();

  static
  {
    driverLoaded = false;

    if ((System.getProperty("os.arch").indexOf("86") != -1) && (System.getProperty("os.name").indexOf("Windows") != -1))
    {
      int index = 0; int last_index = 0;
      String search_path = System.getProperty("java.library.path");

      boolean tmex_loaded = false;

      if (search_path != null)
      {
        do
        {
          index = search_path.indexOf(File.pathSeparatorChar, last_index);

          if (index > -1)
          {
            String path = search_path.substring(last_index, index);

            File file = new File(path + File.separator + "IBFS32.DLL");

            if (file.exists())
            {
              tmex_loaded = true;

              break;
            }
          }

          last_index = index + 1;
        }
        while (index > -1);
      }
      else
      {
        tmex_loaded = true;
      }
      if (tmex_loaded)
      {
        try
        {
          System.loadLibrary("ibtmjava");

          driverLoaded = true;
        }
        catch (UnsatisfiedLinkError e)
        {
          if (search_path != null)
          {
            System.err.println("Could not load Java to TMEX-native bridge driver: ibtmjava.dll");
          }
          else
          {
            System.err.println("Native drivers not found, download iButton-TMEX RTE Win32 from www.ibutton.com");
          }
        }
      }
      else
      {
        System.err.println("Native drivers not found, download iButton-TMEX RTE Win32 from www.ibutton.com");
      }
    }
  }
}