package com.dalsemi.onewire.adapter;

class UAdapterState
{
  public static final char BAUD_9600 = '\000';
  public static final char BAUD_19200 = '\002';
  public static final char BAUD_57600 = '\004';
  public static final char BAUD_115200 = '\006';
  public static final char USPEED_REGULAR = '\000';
  public static final char USPEED_FLEX = '\004';
  public static final char USPEED_OVERDRIVE = '\b';
  public static final char USPEED_PULSE = '\f';
  public static final char MODE_DATA = 'á';
  public static final char MODE_COMMAND = 'ã';
  public static final char MODE_STOP_PULSE = 'ñ';
  public static final char MODE_SPECIAL = 'ó';
  public static final char CHIP_VERSION1 = '\004';
  public static final char CHIP_VERSION_MASK = '\034';
  public static final char PROGRAM_VOLTAGE_MASK = ' ';
  public static final int MAX_ALARM_COUNT = 3000;
  public UParameterSettings[] uParameters;
  public OneWireState oneWireState;
  public boolean streamBits;
  public boolean streamBytes;
  public boolean streamSearches;
  public boolean streamResets;
  public char ubaud;
  public char uSpeedMode;
  public boolean programVoltageAvailable;
  public boolean inCommandMode;
  public char revision;
  protected boolean longAlarmCheck;
  protected int lastAlarmCount;

  public UAdapterState(OneWireState newOneWireState)
  {
    this.oneWireState = newOneWireState;

    this.ubaud = '\000';
    this.uSpeedMode = '\004';
    this.revision = '\000';
    this.inCommandMode = true;
    this.streamBits = true;
    this.streamBytes = true;
    this.streamSearches = true;
    this.streamResets = false;
    this.programVoltageAvailable = false;
    this.longAlarmCheck = false;
    this.lastAlarmCount = 0;

    this.uParameters = new UParameterSettings[4];
    this.uParameters[0] = new UParameterSettings();
    this.uParameters[1] = new UParameterSettings();
    this.uParameters[2] = new UParameterSettings();
    this.uParameters[3] = new UParameterSettings();

    this.uParameters[1].pullDownSlewRate = '\n';

    this.uParameters[1].write1LowTime = '\b';

    this.uParameters[1].sampleOffsetTime = '\f';
  }
}