package com.dalsemi.onewire.adapter;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.net.UnknownHostException;

public class MulticastListener
  implements Runnable
{
  private static final boolean DEBUG = false;
  private static final int timeoutInSeconds = 3;
  private MulticastSocket socket = null;
  private byte[] expectedMessage;
  private byte[] returnMessage;
  private volatile boolean listenerStopped = false;

  private volatile boolean listenerRunning = false;

  public MulticastListener(int multicastPort, String multicastGroup, byte[] expectedMessage, byte[] returnMessage)
    throws IOException, UnknownHostException
  {
    this.expectedMessage = expectedMessage;
    this.returnMessage = returnMessage;

    this.socket = new MulticastSocket(multicastPort);

    this.socket.setSoTimeout(3000);

    InetAddress group = InetAddress.getByName(multicastGroup);
    this.socket.joinGroup(group);
  }

  public void run()
  {
    byte[] receiveBuffer = new byte[this.expectedMessage.length];

    this.listenerRunning = true;
    while (!this.listenerStopped)
    {
      try
      {
        DatagramPacket inPacket = new DatagramPacket(receiveBuffer, receiveBuffer.length);

        this.socket.receive(inPacket);

        int length = inPacket.getLength();

        if (length == this.expectedMessage.length)
        {
          boolean dataMatch = true;
          for (int i = 0; (dataMatch) && (i < length); i++)
          {
            dataMatch = this.expectedMessage[i] == receiveBuffer[i];
          }

          if (dataMatch)
          {
            DatagramPacket outPacket = new DatagramPacket(this.returnMessage, this.returnMessage.length, inPacket.getAddress(), inPacket.getPort());

            this.socket.send(outPacket);
          }
        }
      } catch (IOException ioe) {
      }
    }
    this.listenerRunning = false;
  }

  public void stopListener()
  {
    this.listenerStopped = true;
    int i = 0;
    int timeout = 300;
    while ((this.listenerRunning) && (i++ < timeout)) try {
        Thread.sleep(10L);
      }
      catch (Exception e)
      {
      }
  }
}