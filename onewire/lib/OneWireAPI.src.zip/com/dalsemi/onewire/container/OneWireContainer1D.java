package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import com.dalsemi.onewire.utils.CRC16;
import java.util.Enumeration;
import java.util.Vector;

public class OneWireContainer1D extends OneWireContainer
{
  private static final byte READ_MEMORY_COMMAND = -91;
  private byte[] buffer = new byte[14];

  public OneWireContainer1D()
  {
  }

  public OneWireContainer1D(DSPortAdapter sourceAdapter, byte[] newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public OneWireContainer1D(DSPortAdapter sourceAdapter, long newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public OneWireContainer1D(DSPortAdapter sourceAdapter, String newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public String getName()
  {
    return "DS2423";
  }

  public String getDescription()
  {
    return "1-Wire counter with 4096 bits of read/write, nonvolatile memory.  Memory is partitioned into sixteen pages of 256 bits each.  256 bit scratchpad ensures data transfer integrity.  Has overdrive mode.  Last four pages each have 32 bit read-only non rolling-over counter.  The first two counters increment on a page write cycle and the second two have active-low external triggers.";
  }

  public int getMaxSpeed()
  {
    return 2;
  }

  public Enumeration getMemoryBanks()
  {
    Vector bank_vector = new Vector(4);

    MemoryBankScratchEx scratch = new MemoryBankScratchEx(this);

    bank_vector.addElement(scratch);

    MemoryBankNVCRC nv = new MemoryBankNVCRC(this, scratch);

    nv.numberPages = 12;
    nv.size = 384;
    nv.extraInfoLength = 8;
    nv.readContinuePossible = false;
    nv.numVerifyBytes = 8;

    bank_vector.addElement(nv);

    nv = new MemoryBankNVCRC(this, scratch);
    nv.numberPages = 2;
    nv.size = 64;
    nv.bankDescription = "Memory with write cycle counter";
    nv.startPhysicalAddress = 384;
    nv.extraInfo = true;
    nv.extraInfoDescription = "Write cycle counter";
    nv.extraInfoLength = 8;
    nv.readContinuePossible = false;
    nv.numVerifyBytes = 8;

    bank_vector.addElement(nv);

    nv = new MemoryBankNVCRC(this, scratch);
    nv.numberPages = 2;
    nv.size = 64;
    nv.bankDescription = "Memory with externally triggered counter";
    nv.startPhysicalAddress = 448;
    nv.extraInfo = true;
    nv.extraInfoDescription = "Externally triggered counter";
    nv.extraInfoLength = 8;

    bank_vector.addElement(nv);

    return bank_vector.elements();
  }

  public long readCounter(int counterPage)
    throws OneWireIOException, OneWireException
  {
    if ((counterPage < 12) || (counterPage > 15)) {
      throw new OneWireException("OneWireContainer1D-invalid counter page");
    }

    if (this.adapter.select(this.address))
    {
      this.buffer[0] = -91;
      int crc16 = CRC16.compute(-91);

      int address = (counterPage << 5) + 31;

      this.buffer[1] = (byte)address;
      crc16 = CRC16.compute(this.buffer[1], crc16);
      this.buffer[2] = (byte)(address >>> 8);
      crc16 = CRC16.compute(this.buffer[2], crc16);

      for (int i = 3; i < 14; i++) {
        this.buffer[i] = -1;
      }

      this.adapter.dataBlock(this.buffer, 0, 14);

      if (CRC16.compute(this.buffer, 3, 11, crc16) == 45057)
      {
        long return_count = 0L;

        for (int i = 4; i >= 1; i--)
        {
          return_count <<= 8;
          return_count |= this.buffer[(i + 3)] & 0xFF;
        }

        return return_count;
      }

    }

    throw new OneWireIOException("OneWireContainer1D-device not present");
  }
}