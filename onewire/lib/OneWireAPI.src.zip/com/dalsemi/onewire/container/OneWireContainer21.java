package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import com.dalsemi.onewire.utils.Convert;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.Vector;

public class OneWireContainer21 extends OneWireContainer
  implements TemperatureContainer, ClockContainer
{
  private static final byte FAMILY_CODE = 33;
  private boolean doSpeedEnable = true;
  private static final byte WRITE_SCRATCHPAD_COMMAND = 15;
  private static final byte READ_SCRATCHPAD_COMMAND = -86;
  private static final byte COPY_SCRATCHPAD_COMMAND = 85;
  private static final byte READ_MEMORY_CRC_COMMAND = -91;
  private static final byte CLEAR_MEMORY_COMMAND = 60;
  private static final byte CONVERT_TEMPERATURE_COMMAND = 68;
  private MemoryBankScratchCRC scratch;
  private MemoryBankNVCRC register;
  private MemoryBankNVCRC alarm;
  private MemoryBankNVCRC histogram;
  private MemoryBankNVCRC log;
  private byte[] read_log_buffer = new byte[2048];

  private boolean updatertc = false;

  private String partNumber = "DS1921";

  private double temperatureRangeLow = -40.0D;
  private double temperatureRangeHigh = 85.0D;

  private double temperatureResolution = 0.5D;

  private double temperatureOperatingRangeLow = -40.0D;
  private double temperatureOperatingRangeHigh = 85.0D;

  private boolean isDS1921HZ = false;
  public static final int STATUS_REGISTER = 532;
  public static final int CONTROL_REGISTER = 526;
  public static final byte ONCE_PER_SECOND = 31;
  public static final byte ONCE_PER_MINUTE = 23;
  public static final byte ONCE_PER_HOUR = 19;
  public static final byte ONCE_PER_DAY = 17;
  public static final byte ONCE_PER_WEEK = 16;
  public static final byte TEMPERATURE_LOW_ALARM = 4;
  public static final byte TEMPERATURE_HIGH_ALARM = 2;
  public static final byte TIMER_ALARM = 1;
  public static final byte TIMER_ALARM_SEARCH_FLAG = 1;
  public static final byte TEMP_HIGH_SEARCH_FLAG = 2;
  public static final byte TEMP_LOW_SEARCH_FLAG = 4;
  public static final byte ROLLOVER_ENABLE_FLAG = 8;
  public static final byte MISSION_ENABLE_FLAG = 16;
  public static final byte MEMORY_CLEAR_ENABLE_FLAG = 64;
  public static final byte OSCILLATOR_ENABLE_FLAG = -128;
  public static final byte TIMER_ALARM_FLAG = 1;
  public static final byte TEMPERATURE_HIGH_FLAG = 2;
  public static final byte TEMPERATURE_LOW_FLAG = 4;
  public static final byte SAMPLE_IN_PROGRESS_FLAG = 16;
  public static final byte MISSION_IN_PROGRESS_FLAG = 32;
  public static final byte MEMORY_CLEARED_FLAG = 64;
  public static final byte TEMP_CORE_BUSY_FLAG = -128;

  public OneWireContainer21()
  {
    initMem();
  }

  public OneWireContainer21(DSPortAdapter sourceAdapter, byte[] newAddress)
  {
    super(sourceAdapter, newAddress);

    initMem();
  }

  public OneWireContainer21(DSPortAdapter sourceAdapter, long newAddress)
  {
    super(sourceAdapter, newAddress);

    initMem();
  }

  public OneWireContainer21(DSPortAdapter sourceAdapter, String newAddress)
  {
    super(sourceAdapter, newAddress);

    initMem();
  }

  public void setupContainer(DSPortAdapter sourceAdapter, byte[] newAddress)
  {
    super.setupContainer(sourceAdapter, newAddress);
    setThermochronVariables();
  }

  public void setupContainer(DSPortAdapter sourceAdapter, long newAddress)
  {
    super.setupContainer(sourceAdapter, newAddress);
    setThermochronVariables();
  }

  public void setupContainer(DSPortAdapter sourceAdapter, String newAddress)
  {
    super.setupContainer(sourceAdapter, newAddress);
    setThermochronVariables();
  }

  public Enumeration getMemoryBanks()
  {
    Vector bank_vector = new Vector(6);

    bank_vector.addElement(this.scratch);

    bank_vector.addElement(new MemoryBankNVCRC(this, this.scratch));

    bank_vector.addElement(this.register);

    bank_vector.addElement(this.alarm);

    bank_vector.addElement(this.histogram);

    bank_vector.addElement(this.log);

    return bank_vector.elements();
  }

  private void initMem()
  {
    this.scratch = new MemoryBankScratchCRC(this);

    this.register = new MemoryBankNVCRC(this, this.scratch);
    this.register.numberPages = 1;
    this.register.size = 32;
    this.register.bankDescription = "Register control";
    this.register.startPhysicalAddress = 512;
    this.register.generalPurposeMemory = false;

    this.alarm = new MemoryBankNVCRC(this, this.scratch);
    this.alarm.numberPages = 3;
    this.alarm.size = 96;
    this.alarm.bankDescription = "Alarm time stamps";
    this.alarm.startPhysicalAddress = 544;
    this.alarm.generalPurposeMemory = false;
    this.alarm.readOnly = true;
    this.alarm.readWrite = false;

    this.histogram = new MemoryBankNVCRC(this, this.scratch);
    this.histogram.numberPages = 4;
    this.histogram.size = 128;
    this.histogram.bankDescription = "Temperature Histogram";
    this.histogram.startPhysicalAddress = 2048;
    this.histogram.generalPurposeMemory = false;
    this.histogram.readOnly = true;
    this.histogram.readWrite = false;

    this.log = new MemoryBankNVCRC(this, this.scratch);
    this.log.numberPages = 64;
    this.log.size = 2048;
    this.log.bankDescription = "Temperature log";
    this.log.startPhysicalAddress = 4096;
    this.log.generalPurposeMemory = false;
    this.log.readOnly = true;
    this.log.readWrite = false;
  }

  private void setThermochronVariables()
  {
    byte[] address = getAddress();
    int rangeCode = (address[6] & 0xFF) << 4 | (address[5] & 0xFF) >> 4;

    switch (rangeCode)
    {
    case 844:
      this.partNumber = "DS1921L-F51";
      this.temperatureRangeLow = -40.0D;
      this.temperatureRangeHigh = 85.0D;
      this.temperatureResolution = 0.5D;
      this.temperatureOperatingRangeLow = -10.0D;
      this.temperatureOperatingRangeHigh = 85.0D;
      this.isDS1921HZ = false;
      break;
    case 596:
      this.partNumber = "DS1921L-F52";
      this.temperatureRangeLow = -40.0D;
      this.temperatureRangeHigh = 85.0D;
      this.temperatureResolution = 0.5D;
      this.temperatureOperatingRangeLow = -20.0D;
      this.temperatureOperatingRangeHigh = 85.0D;
      this.isDS1921HZ = false;
      break;
    case 348:
      this.partNumber = "DS1921L-F53";
      this.temperatureRangeLow = -40.0D;
      this.temperatureRangeHigh = 85.0D;
      this.temperatureResolution = 0.5D;
      this.temperatureOperatingRangeLow = -30.0D;
      this.temperatureOperatingRangeHigh = 85.0D;
      this.isDS1921HZ = false;
      break;
    case 1266:
      this.partNumber = "DS1921H-F5";
      this.temperatureRangeLow = 15.0D;
      this.temperatureRangeHigh = 46.0D;
      this.temperatureResolution = 0.125D;
      this.temperatureOperatingRangeLow = -40.0D;
      this.temperatureOperatingRangeHigh = 85.0D;
      this.isDS1921HZ = true;
      break;
    case 946:
      this.partNumber = "DS1921Z-F5";
      this.temperatureRangeLow = -5.0D;
      this.temperatureRangeHigh = 26.0D;
      this.temperatureResolution = 0.125D;
      this.temperatureOperatingRangeLow = -40.0D;
      this.temperatureOperatingRangeHigh = 85.0D;
      this.isDS1921HZ = true;
      break;
    default:
      long lower36bits = (address[5] & 0xF) << 32 | (address[4] & 0xFF) << 24 | (address[3] & 0xFF) << 16 | (address[2] & 0xFF) << 8 | address[1] & 0xFF;

      if (lower36bits >= 1048576L)
        this.partNumber = "DS1921G-F5";
      else {
        this.partNumber = "DS1921L-PROTO";
      }
      this.temperatureRangeLow = -40.0D;
      this.temperatureRangeHigh = 85.0D;
      this.temperatureResolution = 0.5D;
      this.temperatureOperatingRangeLow = -40.0D;
      this.temperatureOperatingRangeHigh = 85.0D;
      this.isDS1921HZ = false;
    }
  }

  private int[] getDate(int timeReg, byte[] state)
  {
    int[] result = new int[3];

    timeReg &= 31;

    byte lower = state[(timeReg++)];
    byte upper = (byte)(lower >>> 4 & 0xF);
    lower = (byte)(lower & 0xF);
    result[2] = (10 * upper + lower);

    lower = state[(timeReg++)];
    upper = (byte)(lower >>> 4 & 0xF);
    lower = (byte)(lower & 0xF);

    byte century = (byte)(upper >>> 3 & 0x1);

    upper = (byte)(upper & 0x1);
    result[1] = (lower + upper * 10);

    result[0] = (1900 + century * 100);
    lower = state[(timeReg++)];
    upper = (byte)(lower >>> 4 & 0xF);
    lower = (byte)(lower & 0xF);
    result[0] += upper * 10 + lower;

    return result;
  }

  private int[] getTime(int timeReg, byte[] state)
  {
    int[] result = new int[3];

    timeReg &= 31;

    byte lower = state[(timeReg++)];
    byte upper = (byte)(lower >>> 4 & 0x7);
    lower = (byte)(lower & 0xF);
    result[0] = (lower + upper * 10);

    lower = state[(timeReg++)];
    upper = (byte)(lower >>> 4 & 0x7);
    lower = (byte)(lower & 0xF);
    result[1] = (lower + upper * 10);

    lower = state[(timeReg++)];
    upper = (byte)(lower >>> 4 & 0x7);
    lower = (byte)(lower & 0xF);
    int hours;
    if (upper >>> 2 != 0)
    {
      byte PM = (byte)(upper << 6 >>> 7 & 0x1);

      upper = (byte)(upper & 0x1);
      hours = upper * 10 + PM * 12;
    }
    else {
      hours = upper * 10;
    }
    hours += lower;
    result[2] = hours;

    return result;
  }

  private void setTime(int timeReg, int hours, int minutes, int seconds, boolean AMPM, byte[] state)
  {
    byte upper = (byte)(seconds / 10);
    upper = (byte)(upper << 4 & 0xF0);
    byte lower = (byte)(seconds % 10);
    lower = (byte)(lower & 0xF);
    state[(timeReg & 0x1F)] = (byte)(upper | lower);

    timeReg++;

    upper = (byte)(minutes / 10);
    upper = (byte)(upper << 4 & 0xF0);
    lower = (byte)(minutes % 10);
    lower = (byte)(lower & 0xF);
    state[(timeReg & 0x1F)] = (byte)(upper | lower);

    timeReg++;

    if (AMPM)
    {
      upper = 4;

      if (hours > 11) {
        upper = (byte)(upper | 0x2);
      }

      if ((hours % 12 == 0) || (hours % 12 > 9)) {
        upper = (byte)(upper | 0x1);
      }
      if (hours > 12) {
        hours -= 12;
      }
      if (hours == 0)
        lower = 2;
      else
        lower = (byte)(hours % 10 & 0xF);
    }
    else
    {
      upper = (byte)(hours / 10);
      lower = (byte)(hours % 10);
    }

    upper = (byte)(upper << 4 & 0xF0);
    lower = (byte)(lower & 0xF);
    state[(timeReg & 0x1F)] = (byte)(upper | lower);

    timeReg++;
  }

  private void setDate(int year, int month, int day, byte[] state)
  {
    byte upper = (byte)(day / 10);
    upper = (byte)(upper << 4 & 0xF0);
    byte lower = (byte)(day % 10);
    lower = (byte)(lower & 0xF);
    state[4] = (byte)(upper | lower);

    upper = (byte)(month / 10);
    upper = (byte)(upper << 4 & 0xF0);
    lower = (byte)(month % 10);
    lower = (byte)(lower & 0xF);

    if (year > 1999)
    {
      upper = (byte)(upper | 0x80);

      year -= 2000;
    }
    else {
      year -= 1900;
    }
    state[5] = (byte)(upper | lower);

    upper = (byte)(year / 10);
    upper = (byte)(upper << 4 & 0xF0);
    lower = (byte)(year % 10);
    lower = (byte)(lower & 0xF);
    state[6] = (byte)(upper | lower);
  }

  public int getMaxSpeed()
  {
    return 2;
  }

  public String getName()
  {
    return this.partNumber;
  }

  public String getAlternateNames()
  {
    return "Thermochron";
  }

  public String getDescription()
  {
    String characteristics = "";
    if (this.partNumber != "DS1921")
    {
      String strPhysicalRange = Convert.toString(getPhysicalRangeLowTemperature(), 1) + " to " + Convert.toString(getPhysicalRangeHighTemperature(), 1) + " degrees Celsius.";

      String strOperatingRange = Convert.toString(getOperatingRangeLowTemperature(), 1) + " to " + Convert.toString(getOperatingRangeHighTemperature(), 1) + " degrees Celsius.";

      characteristics = " The operating range for this device is:  " + strOperatingRange + " The physical range for this device is:  " + strPhysicalRange + " The resolution is " + Convert.toString(getTemperatureResolution(), 3) + " degrees Celsius, and the histogram bin width is " + Convert.toString(getHistogramBinWidth(), 3) + " degrees Celsius.";
    }

    String returnString = "Rugged, self-sufficient 1-Wire device that, once setup for a mission, will measure the temperature and record the result in a protected memory section. It stores up to 2048 temperature measurements and will take measurements at a user-specified rate. The thermochron also records the number of times the temperature falls on a given degree range (temperature bin), and stores the data in histogram format." + characteristics;

    return returnString;
  }

  public synchronized void setSpeedCheck(boolean doSpeedCheck)
  {
    this.doSpeedEnable = doSpeedCheck;
  }

  public double getPhysicalRangeLowTemperature()
  {
    return this.temperatureRangeLow;
  }

  public double getPhysicalRangeHighTemperature()
  {
    return this.temperatureRangeHigh;
  }

  public double getOperatingRangeLowTemperature()
  {
    return this.temperatureOperatingRangeLow;
  }

  public double getOperatingRangeHighTemperature()
  {
    return this.temperatureOperatingRangeHigh;
  }

  public double getTemperatureResolution()
  {
    return this.temperatureResolution;
  }

  public double getHistogramLowTemperature()
  {
    double lowTemp = getPhysicalRangeLowTemperature();
    if (this.isDS1921HZ) lowTemp -= getTemperatureResolution() * 4.0D;
    return lowTemp;
  }

  public double getHistogramBinWidth()
  {
    return getTemperatureResolution() * 4.0D;
  }

  public double decodeTemperature(byte tempByte)
  {
    double decodedTemperature = 0.0D;
    if (this.isDS1921HZ)
    {
      decodedTemperature = (tempByte & 0xFF) * this.temperatureResolution;
      decodedTemperature += this.temperatureRangeLow - 4.0D * this.temperatureResolution;
    }
    else
    {
      decodedTemperature = (tempByte & 0xFF) / 2.0D - 40.0D;
    }
    return decodedTemperature;
  }

  public byte encodeTemperature(double temperature)
  {
    byte encodedTemperature = 0;
    if (this.isDS1921HZ)
    {
      double result = (temperature - this.temperatureRangeLow) / this.temperatureResolution + 4.0D;
      encodedTemperature = (byte)((int)result & 0xFF);
    }
    else
    {
      encodedTemperature = (byte)((int)(2.0D * temperature) + 80 & 0xFF);
    }
    return encodedTemperature;
  }

  public void writeByte(int memAddr, byte source)
    throws OneWireIOException, OneWireException
  {
    byte[] buffer = new byte[5];

    byte msbAddress = (byte)(memAddr >>> 8 & 0xFF);
    byte lsbAddress = (byte)(memAddr & 0xFF);

    if ((msbAddress > 31) || (msbAddress < 0)) {
      throw new IllegalArgumentException("OneWireContainer21-Address for write out of range.");
    }

    if (this.doSpeedEnable) {
      doSpeed();
    }
    if (this.adapter.select(this.address))
    {
      buffer[0] = 15;
      buffer[1] = lsbAddress;
      buffer[2] = msbAddress;
      buffer[3] = source;

      this.adapter.dataBlock(buffer, 0, 4);

      this.adapter.select(this.address);

      buffer[0] = -86;

      for (int i = 1; i < 5; i++) {
        buffer[i] = -1;
      }
      this.adapter.dataBlock(buffer, 0, 5);

      if (buffer[4] != source) {
        throw new OneWireIOException("OneWireContainer21-Error writing data byte.");
      }

      this.adapter.select(this.address);

      buffer[0] = 85;

      buffer[4] = -1;

      this.adapter.dataBlock(buffer, 0, 5);

      if ((buffer[4] != -86) && (buffer[4] != 85))
        throw new OneWireIOException("OneWireContainer21-Error writing data byte.");
    }
    else
    {
      throw new OneWireException("OneWireContainer21-Device not present.");
    }
  }

  public byte readByte(int memAddr)
    throws OneWireIOException, OneWireException
  {
    byte[] buffer = new byte[4];

    byte msbAddress = (byte)(memAddr >> 8 & 0xFF);
    byte lsbAddress = (byte)(memAddr & 0xFF);

    if ((msbAddress > 31) || (msbAddress < 0)) {
      throw new IllegalArgumentException("OneWireContainer21-Address for read out of range.");
    }

    if (this.doSpeedEnable) {
      doSpeed();
    }
    if (this.adapter.select(this.address))
    {
      buffer[0] = -91;
      buffer[1] = lsbAddress;
      buffer[2] = msbAddress;
      buffer[3] = -1;

      this.adapter.dataBlock(buffer, 0, 4);

      return buffer[3];
    }

    throw new OneWireException("OneWireContainer21-Device not present.");
  }

  public boolean getFlag(int register, byte bitMask)
    throws OneWireIOException, OneWireException
  {
    return (readByte(register) & bitMask) != 0;
  }

  public boolean getFlag(int register, byte bitMask, byte[] state)
  {
    return (state[(register & 0x1F)] & bitMask) != 0;
  }

  public void setFlag(int register, byte bitMask, boolean flagValue)
    throws OneWireIOException, OneWireException
  {
    if (getFlag(532, 32)) {
      throw new OneWireIOException("OneWireContainer21-Cannot write to register while mission is in progress.");
    }

    byte flags = readByte(register);

    if (flagValue)
      flags = (byte)(flags | bitMask);
    else {
      flags = (byte)(flags & (bitMask ^ 0xFFFFFFFF));
    }

    writeByte(register, flags);
  }

  public void setFlag(int register, byte bitMask, boolean flagValue, byte[] state)
  {
    register &= 31;

    byte flags = state[register];

    if (flagValue)
      flags = (byte)(flags | bitMask);
    else {
      flags = (byte)(flags & (bitMask ^ 0xFFFFFFFF));
    }

    state[register] = flags;
  }

  public void enableMission(int sampleRate)
    throws OneWireIOException, OneWireException
  {
    if ((sampleRate > 255) || (sampleRate < 0)) {
      throw new IllegalArgumentException("OneWireContainer21-Sample rate must be 255 minutes or less");
    }

    if (getFlag(532, 32)) {
      throw new OneWireIOException("OneWireContainer30-Unable to start mission (Mission already in Progress)");
    }

    byte controlReg = readByte(526);

    controlReg = (byte)(controlReg & 0xEF);

    writeByte(526, controlReg);

    writeByte(525, (byte)(sampleRate & 0xFF));
  }

  public void disableMission()
    throws OneWireIOException, OneWireException
  {
    byte statusReg = readByte(532);

    statusReg = (byte)(statusReg & 0xDF);

    writeByte(532, statusReg);
  }

  public void setMissionStartDelay(int missionStartDelay, byte[] state)
  {
    state[18] = (byte)missionStartDelay;
    state[19] = (byte)(missionStartDelay >> 8);
  }

  public void clearMemory()
    throws OneWireIOException, OneWireException
  {
    byte[] state = readDevice();
    if (isClockRunning(state))
    {
      setClockRunEnable(true, state);
      writeDevice(state);
      try
      {
        Thread.sleep(751L);
      }
      catch (InterruptedException ie)
      {
      }
    }
    setFlag(526, 64, true);

    if (this.doSpeedEnable) {
      doSpeed();
    }
    this.adapter.reset();

    if (this.adapter.select(this.address))
    {
      this.adapter.putByte(60);
      try
      {
        Thread.sleep(5L);
      }
      catch (Exception e)
      {
      }
    }
    else
    {
      throw new OneWireException("OneWireContainer21-Device not found.");
    }
  }

  public Calendar getAlarmTime(byte[] state)
  {
    int[] time = getTime(519, state);
    Calendar result = Calendar.getInstance();
    result.set(1, 0);
    result.set(2, 0);
    result.set(5, 0);
    result.set(11, time[2]);
    result.set(12, time[1]);
    result.set(13, time[0]);

    byte dayOfWeek = (byte)(state[10] & 0x7);

    result.set(5, dayOfWeek);

    return result;
  }

  public void setClockAlarm(int hours, int minutes, int seconds, int day, int alarmFrequency, byte[] state)
  {
    setTime(519, hours, minutes, seconds, false, state);

    state[10] = (byte)day;

    int number_0_msb = 0;

    switch (alarmFrequency)
    {
    case 31:
      number_0_msb = 0;
      break;
    case 23:
      number_0_msb = 1;
      break;
    case 19:
      number_0_msb = 2;
      break;
    case 17:
      number_0_msb = 3;
      break;
    case 16:
    default:
      number_0_msb = 4;
    }

    for (int i = 7; i < 11; i++)
    {
      if (number_0_msb > 0)
      {
        number_0_msb--;

        state[i] = (byte)(state[i] & 0x7F);
      }
      else {
        state[i] = (byte)(state[i] | 0x80);
      }
    }
  }

  public int getSampleRate(byte[] state)
  {
    return 0xFF & state[13];
  }

  public int getMissionSamplesCounter(byte[] state)
  {
    byte low = state[26];
    byte medium = state[27];
    byte high = state[28];

    return high << 16 & 0xFF0000 | medium << 8 & 0xFF00 | low & 0xFF;
  }

  public int getDeviceSamplesCounter(byte[] state)
  {
    byte low = state[29];
    byte medium = state[30];
    byte high = state[31];

    return high << 16 & 0xFF0000 | medium << 8 & 0xFF00 | low & 0xFF;
  }

  public Calendar getMissionTimeStamp(byte[] state)
  {
    int[] time_result = getTime(532, state);
    int[] date_result = getDate(535, state);
    int year = date_result[0] % 100;

    int numberOfCounts = getMissionSamplesCounter(state);
    int timeBetweenCounts = getSampleRate(state);
    int yearsSinceMissionStart = numberOfCounts * timeBetweenCounts / 525600;

    int[] offset_result = getDate(516, state);
    int result_year = offset_result[0];

    if (result_year - yearsSinceMissionStart > 1999)
      year += 2000;
    else {
      year += 1900;
    }

    if (year > result_year) {
      year -= 100;
    }
    Calendar result = Calendar.getInstance();
    result.set(1, year);
    result.set(2, date_result[1] - 1);
    result.set(5, date_result[2]);
    result.set(11, time_result[2]);
    result.set(12, time_result[1]);

    result.set(13, 0);

    return result;
  }

  public long getFirstLogOffset(byte[] state)
  {
    long counter = getMissionSamplesCounter(state);

    if ((counter < 2049L) || (!getFlag(526, 8, state)))
    {
      return 0L;
    }

    counter -= 2048L;

    int rate = getSampleRate(state);

    counter = counter * rate * 1000L * 60L;

    return counter;
  }

  public synchronized byte[] getTemperatureLog(byte[] state)
    throws OneWireIOException, OneWireException
  {
    int numberOfReadings = getMissionSamplesCounter(state);

    int offsetDepth = 0;

    if ((getFlag(526, 8, state)) && (numberOfReadings > 2048))
    {
      offsetDepth = numberOfReadings % 2048;
    }

    if (numberOfReadings > 2048) {
      numberOfReadings = 2048;
    }
    byte[] result = new byte[numberOfReadings];

    int offset = 0;

    while (offset < numberOfReadings)
    {
      this.log.readPageCRC(offset >> 5, false, this.read_log_buffer, offset);

      offset += 32;
    }

    System.arraycopy(this.read_log_buffer, offsetDepth, result, 0, numberOfReadings - offsetDepth);

    System.arraycopy(this.read_log_buffer, 0, result, numberOfReadings - offsetDepth, offsetDepth);

    return result;
  }

  public int[] getTemperatureHistogram()
    throws OneWireIOException, OneWireException
  {
    int[] result;
    if (this.isDS1921HZ)
      result = new int[64];
    else
      result = new int[63];
    byte[] buffer = new byte[''];

    int offset = 0;

    while (offset < 128)
    {
      this.histogram.readPageCRC(offset >> 5, false, buffer, offset);

      offset += 32;
    }

    int i = 0; int j = 0;

    while (i < result.length)
    {
      result[i] = (buffer[j] & 0xFF | buffer[(j + 1)] << 8 & 0xFF00);

      i++;

      j += 2;
    }

    return result;
  }

  public boolean getAlarmStatus(byte alarmBit, byte[] state)
  {
    return (state[20] & alarmBit) != 0;
  }

  public byte[] getAlarmHistory(byte alarmBit)
    throws OneWireIOException, OneWireException
  {
    int counter = 0;
    byte[] temp_data = new byte[96];
    int offset = 0;

    while (offset < 96)
    {
      this.alarm.readPageCRC(offset >> 5, false, temp_data, offset);

      offset += 32;
    }

    if (alarmBit == 4)
      offset = 0;
    else {
      offset = 48;
    }

    while ((counter < 12) && (counter * 4 + 3 + offset < temp_data.length) && (temp_data[(counter * 4 + 3 + offset)] != 0)) {
      counter++;
    }
    byte[] data = new byte[counter << 2];

    System.arraycopy(temp_data, offset, data, 0, counter << 2);

    return data;
  }

  public byte[] readDevice()
    throws OneWireIOException, OneWireException
  {
    byte[] buffer = new byte[32];

    this.register.readPageCRC(0, false, buffer, 0);

    return buffer;
  }

  public void writeDevice(byte[] state)
    throws OneWireIOException, OneWireException
  {
    if (getFlag(532, 32)) {
      throw new OneWireIOException("OneWireContainer21-Cannot write to registers while mission is in progress.");
    }

    int start = this.updatertc ? 0 : 7;

    this.register.write(start, state, start, 20 - start);

    synchronized (this)
    {
      this.updatertc = false;
    }
  }

  public boolean hasTemperatureAlarms()
  {
    return true;
  }

  public boolean hasSelectableTemperatureResolution()
  {
    return false;
  }

  public double[] getTemperatureResolutions()
  {
    double[] d = new double[1];

    d[0] = this.temperatureResolution;

    return d;
  }

  public double getTemperatureAlarmResolution()
  {
    return 1.5D;
  }

  public double getMaxTemperature()
  {
    return getOperatingRangeHighTemperature();
  }

  public double getMinTemperature()
  {
    return getOperatingRangeLowTemperature();
  }

  public void doTemperatureConvert(byte[] state)
    throws OneWireIOException, OneWireException
  {
    if (getFlag(532, 32)) {
      throw new OneWireIOException("OneWireContainer21-Cant force temperature read during a mission.");
    }

    if (this.doSpeedEnable) {
      doSpeed();
    }
    this.adapter.reset();

    if (this.adapter.select(this.address))
    {
      this.adapter.putByte(68);
      try
      {
        Thread.sleep(750L);
      }
      catch (InterruptedException e)
      {
      }
      state[17] = readByte(529);
    }
    else {
      throw new OneWireException("OneWireContainer21-Device not found!");
    }
  }

  public double getTemperature(byte[] state)
  {
    return decodeTemperature(state[17]);
  }

  public double getTemperatureAlarm(int alarmType, byte[] state)
  {
    if ((alarmType == 2) || (alarmType == 1)) {
      return decodeTemperature(state[12]);
    }
    return decodeTemperature(state[11]);
  }

  public double getTemperatureResolution(byte[] state)
  {
    return this.temperatureResolution;
  }

  public void setTemperatureAlarm(int alarmType, double alarmValue, byte[] state)
  {
    double histogramLow = getHistogramLowTemperature();
    double histogramHigh = getPhysicalRangeHighTemperature() + (getHistogramBinWidth() - getTemperatureResolution());
    byte alarm = encodeTemperature(alarmValue);

    if (this.isDS1921HZ)
    {
      if (alarmValue < histogramLow) {
        alarm = 0;
      }
      if (alarmValue > histogramHigh)
        alarm = -1;
    }
    else
    {
      if (alarmValue < -40.0D) {
        alarm = 0;
      }
      if (alarmValue > 85.0D) {
        alarm = -6;
      }
    }
    if ((alarmType == 2) || (alarmType == 1))
    {
      state[12] = alarm;
    }
    else
    {
      state[11] = alarm;
    }
  }

  public void setTemperatureResolution(double resolution, byte[] state)
    throws OneWireException
  {
    throw new OneWireException("Selectable Temperature Resolution Not Supported");
  }

  public boolean hasClockAlarm()
  {
    return true;
  }

  public boolean canDisableClock()
  {
    return true;
  }

  public long getClockResolution()
  {
    return 1000L;
  }

  public long getClock(byte[] state)
  {
    int[] time = getTime(512, state);
    int[] date = getDate(516, state);

    Calendar result = Calendar.getInstance();
    result.set(1, date[0]);
    result.set(2, date[1] - 1);
    result.set(5, date[2]);
    result.set(11, time[2]);
    result.set(12, time[1]);
    result.set(13, time[0]);

    return result.getTime().getTime();
  }

  public long getClockAlarm(byte[] state)
  {
    int[] time = getTime(512, state);
    int[] date = getDate(516, state);

    Calendar c = Calendar.getInstance();
    c.set(1, date[0]);
    c.set(2, date[1] - 1);
    c.set(5, date[2]);
    c.set(11, time[2]);
    c.set(12, time[1]);
    c.set(13, time[0]);

    int time_into_day = time[0] + 60 * time[1] + 3600 * time[2];

    int[] a_time = getTime(519, state);

    int a_time_into_day = a_time[0] + 60 * a_time[1] + 3600 * a_time[2];

    byte dayOfWeek = (byte)(state[10] & 0x7);

    if (dayOfWeek == 0) {
      dayOfWeek = (byte)(dayOfWeek + 1);
    }
    byte MS = (byte)(state[7] >>> 7 & 0x1);
    byte MM = (byte)(state[8] >>> 7 & 0x1);
    byte MH = (byte)(state[9] >>> 7 & 0x1);
    byte MD = (byte)(state[10] >>> 7 & 0x1);

    long temp_time = 0L;
    int MILLIS_PER_DAY = 86400000;

    switch (MS + MM + MH + MD)
    {
    case 4:
      c.add(13, 1);
      break;
    case 3:
      if (a_time_into_day >= time_into_day) {
        c.add(12, 1);
      }
      c.set(13, a_time[0]);
      break;
    case 2:
      if (a_time_into_day >= time_into_day) {
        c.add(11, 1);
      }
      c.set(13, a_time[0]);
      c.set(12, a_time[1]);
      break;
    case 1:
      c.set(13, a_time[0]);
      c.set(12, a_time[1]);
      c.set(11, a_time[2]);

      if (a_time_into_day >= time_into_day) break;
      c.add(5, 1); break;
    case 0:
    default:
      c.set(13, a_time[0]);
      c.set(12, a_time[1]);

      c.set(11, a_time[2]);

      temp_time = c.getTime().getTime();

      if (dayOfWeek == c.get(7))
      {
        if (a_time_into_day < time_into_day) {
          temp_time += 7 * MILLIS_PER_DAY;
        }

      }
      else
      {
        int cdayofweek = c.get(7);

        while (dayOfWeek % 7 != cdayofweek++ % 7)
        {
          temp_time += MILLIS_PER_DAY;
        }

      }

      return temp_time;
    }

    return c.getTime().getTime();
  }

  public boolean isClockAlarming(byte[] state)
  {
    return (state[20] & 0x1) != 0;
  }

  public boolean isClockAlarmEnabled(byte[] state)
  {
    return (state[14] & 0x1) != 0;
  }

  public boolean isClockRunning(byte[] state)
  {
    return (state[14] & 0xFFFFFF80) == 0;
  }

  public void setClock(long time, byte[] state)
  {
    Date x = new Date(time);
    Calendar d = Calendar.getInstance();

    d.setTime(x);
    setTime(512, d.get(11), d.get(12), d.get(13), false, state);

    setDate(d.get(1), d.get(2) + 1, d.get(5), state);

    synchronized (this)
    {
      this.updatertc = true;
    }
  }

  public void setClockAlarm(long time, byte[] state)
    throws OneWireException
  {
    throw new OneWireException("Cannot set the DS1921 Clock Alarm through the Clock interface.");
  }

  public void setClockRunEnable(boolean runEnable, byte[] state)
  {
    setFlag(526, -128, !runEnable, state);
  }

  public void setClockAlarmEnable(boolean alarmEnable, byte[] state)
  {
    setFlag(526, 1, alarmEnable, state);
  }
}