package com.dalsemi.onewire.container;

import com.dalsemi.onewire.adapter.DSPortAdapter;
import java.util.Enumeration;
import java.util.Vector;

public class OneWireContainer0A extends OneWireContainer
{
  public OneWireContainer0A()
  {
  }

  public OneWireContainer0A(DSPortAdapter sourceAdapter, byte[] newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public OneWireContainer0A(DSPortAdapter sourceAdapter, long newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public OneWireContainer0A(DSPortAdapter sourceAdapter, String newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public String getName()
  {
    return "DS1995";
  }

  public String getDescription()
  {
    return "16384 bit read/write nonvolatile memory partitioned into sixty-four pages of 256 bits each.";
  }

  public int getMaxSpeed()
  {
    return 2;
  }

  public Enumeration getMemoryBanks()
  {
    Vector bank_vector = new Vector(2);

    MemoryBankScratch scratch = new MemoryBankScratch(this);

    bank_vector.addElement(scratch);

    MemoryBankNV nv = new MemoryBankNV(this, scratch);

    nv.numberPages = 64;
    nv.size = 2048;

    bank_vector.addElement(nv);

    return bank_vector.elements();
  }
}