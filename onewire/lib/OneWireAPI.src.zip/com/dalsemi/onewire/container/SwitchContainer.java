package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;

public abstract interface SwitchContainer extends OneWireSensor
{
  public abstract boolean isHighSideSwitch();

  public abstract boolean hasActivitySensing();

  public abstract boolean hasLevelSensing();

  public abstract boolean hasSmartOn();

  public abstract boolean onlySingleChannelOn();

  public abstract int getNumberChannels(byte[] paramArrayOfByte);

  public abstract boolean getLevel(int paramInt, byte[] paramArrayOfByte)
    throws OneWireException;

  public abstract boolean getLatchState(int paramInt, byte[] paramArrayOfByte);

  public abstract boolean getSensedActivity(int paramInt, byte[] paramArrayOfByte)
    throws OneWireException;

  public abstract void setLatchState(int paramInt, boolean paramBoolean1, boolean paramBoolean2, byte[] paramArrayOfByte);

  public abstract void clearActivity()
    throws OneWireException;
}