package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.OneWireIOException;

abstract interface ScratchPad
{
  public abstract void readScratchpad(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2)
    throws OneWireIOException, OneWireException;

  public abstract void writeScratchpad(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3)
    throws OneWireIOException, OneWireException;

  public abstract void copyScratchpad(int paramInt1, int paramInt2)
    throws OneWireIOException, OneWireException;

  public abstract int getExtraInfoLength();

  public abstract void checkSpeed()
    throws OneWireIOException, OneWireException;

  public abstract void forceVerify();
}