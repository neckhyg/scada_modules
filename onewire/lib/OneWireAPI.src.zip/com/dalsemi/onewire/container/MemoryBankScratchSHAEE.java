package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import com.dalsemi.onewire.utils.CRC16;
import com.dalsemi.onewire.utils.SHA;

public class MemoryBankScratchSHAEE extends MemoryBankScratchEx
{
  private static final boolean DEBUG = false;
  public static final byte LOAD_FIRST_SECRET = 90;
  public static final byte COMPUTE_NEXT_SECRET = 51;
  public static final byte REFRESH_SCRATCHPAD = -93;
  private final byte[] MT_buffer = new byte[64];

  private final byte[] MAC_buffer = new byte[20];

  private final byte[] page_data_buffer = new byte[32];

  private final byte[] scratchpad_buffer = new byte[8];

  private final byte[] copy_scratchpad_buffer = new byte[4];

  private final byte[] read_scratchpad_buffer = new byte[14];

  protected static final byte[] ffBlock = OneWireContainer33.ffBlock;

  protected static final byte[] zeroBlock = OneWireContainer33.zeroBlock;

  protected OneWireContainer33 owc33 = null;

  public MemoryBankScratchSHAEE(OneWireContainer33 ibutton)
  {
    super(ibutton);

    this.owc33 = ibutton;

    this.bankDescription = "Scratchpad with CRC and 'Copy Scratchpad w/ SHA MAC'";
    this.pageAutoCRC = true;
    this.startPhysicalAddress = 0;
    this.size = 8;
    this.numberPages = 1;
    this.pageLength = 8;
    this.maxPacketDataLength = 5;
    this.extraInfo = true;
    this.extraInfoLength = 3;

    this.COPY_SCRATCHPAD_COMMAND = 85;
  }

  public void readPageCRC(int page, boolean readContinue, byte[] readBuf, int offset)
    throws OneWireIOException, OneWireException
  {
    readPageCRC(page, readContinue, readBuf, offset, null);
  }

  public void readPageCRC(int page, boolean readContinue, byte[] readBuf, int offset, byte[] extraInfo)
    throws OneWireIOException, OneWireException
  {
    if (!this.pageAutoCRC) {
      throw new OneWireException("Read page with CRC not supported in this memory bank");
    }

    if (!readContinue) {
      checkSpeed();
    }

    if (page > this.numberPages) {
      throw new OneWireException("Read exceeds memory bank end");
    }

    readScratchpad(readBuf, offset, this.pageLength, extraInfo);
  }

  public void readScratchpad(byte[] readBuf, int offset, int len, byte[] extraInfo)
    throws OneWireIOException, OneWireException
  {
    synchronized (this.read_scratchpad_buffer)
    {
      int num_crc = 0;

      checkSpeed();

      if (!this.ib.adapter.select(this.ib.address))
      {
        forceVerify();

        throw new OneWireIOException("Device select failed");
      }

      this.read_scratchpad_buffer[0] = -86;

      System.arraycopy(ffBlock, 0, this.read_scratchpad_buffer, 1, this.read_scratchpad_buffer.length - 1);

      this.ib.adapter.dataBlock(this.read_scratchpad_buffer, 0, this.read_scratchpad_buffer.length);

      int addr = this.read_scratchpad_buffer[1];

      addr = (addr | this.read_scratchpad_buffer[2] << 8 & 0xFF00) & 0xFFFF;

      num_crc = this.pageLength + 3 + this.extraInfoLength;

      if (len == this.pageLength)
      {
        if (CRC16.compute(this.read_scratchpad_buffer, 0, num_crc, 0) != 45057)
        {
          forceVerify();

          throw new OneWireIOException("Invalid CRC16 read from device");
        }

      }

      if (extraInfo != null) {
        System.arraycopy(this.read_scratchpad_buffer, 1, extraInfo, 0, this.extraInfoLength);
      }

      System.arraycopy(this.read_scratchpad_buffer, this.extraInfoLength + 1, readBuf, offset, len);
    }
  }

  public void copyScratchpad(int addr, int len)
    throws OneWireIOException, OneWireException
  {
    synchronized (this.scratchpad_buffer)
    {
      readScratchpad(this.scratchpad_buffer, 0, 8, null);
      copyScratchpad(addr, this.scratchpad_buffer, 0);
    }
  }

  public void copyScratchpad(int addr, byte[] scratchpad, int offset)
    throws OneWireIOException, OneWireException
  {
    synchronized (this.page_data_buffer)
    {
      readMemory(addr & 0xE0, false, this.page_data_buffer, 0, 32);

      writeScratchpad(addr, scratchpad, offset, 8);

      copyScratchpad(addr, scratchpad, offset, this.page_data_buffer, 0);
    }
  }

  public void copyScratchpad(int addr, byte[] scratchpad, int scratchpadOffset, byte[] pageData, int pageDataOffset)
    throws OneWireIOException, OneWireException
  {
    synchronized (this.MT_buffer)
    {
      this.owc33.getContainerSecret(this.MT_buffer, 0);
      System.arraycopy(this.MT_buffer, 4, this.MT_buffer, 48, 4);

      System.arraycopy(pageData, pageDataOffset, this.MT_buffer, 4, 28);

      System.arraycopy(scratchpad, scratchpadOffset, this.MT_buffer, 32, 8);

      this.MT_buffer[40] = (byte)((addr & 0xE0) >>> 5);
      System.arraycopy(this.owc33.getAddress(), 0, this.MT_buffer, 41, 7);
      System.arraycopy(ffBlock, 0, this.MT_buffer, 52, 3);

      this.MT_buffer[55] = -128;
      System.arraycopy(zeroBlock, 0, this.MT_buffer, 56, 6);
      this.MT_buffer[62] = 1;
      this.MT_buffer[63] = -72;

      synchronized (this.MAC_buffer)
      {
        SHA.ComputeSHA(this.MT_buffer, this.MAC_buffer, 0);
        copyScratchpadWithMAC(addr, this.MAC_buffer, 0);
      }
    }
  }

  public void copyScratchpadWithMAC(int addr, byte[] authMAC, int authOffset)
    throws OneWireIOException, OneWireException
  {
    synchronized (this.copy_scratchpad_buffer)
    {
      byte[] send_block = this.copy_scratchpad_buffer;

      checkSpeed();

      if (this.ib.adapter.select(this.ib.getAddress()))
      {
        send_block[3] = 95;

        send_block[2] = (byte)(addr >> 8 & 0xFF);

        send_block[1] = (byte)(addr & 0xFF);

        send_block[0] = this.COPY_SCRATCHPAD_COMMAND;

        this.ib.adapter.dataBlock(send_block, 0, 4);
        try
        {
          Thread.sleep(2L);
        }
        catch (InterruptedException e)
        {
        }
        this.ib.adapter.dataBlock(authMAC, authOffset, 19);

        this.ib.adapter.setPowerDuration(5);
        this.ib.adapter.startPowerDelivery(2);
        this.ib.adapter.putByte(authMAC[(authOffset + 19)]);
        try
        {
          Thread.sleep(12L);
        }
        catch (InterruptedException e) {
        }
        this.ib.adapter.setPowerNormal();

        byte test = (byte)this.ib.adapter.getByte();

        if ((test != -86) && (test != 85))
        {
          if (test == -1)
            throw new OneWireException("That area of memory is write-protected.");
          if (test == 0)
            throw new OneWireIOException("Error due to not matching MAC.");
        }
      }
      else {
        throw new OneWireIOException("Device select failed.");
      }
    }
  }

  public void writeScratchpad(int addr, byte[] writeBuf, int offset, int len)
    throws OneWireIOException, OneWireException
  {
    checkSpeed();

    super.writeScratchpad(addr, writeBuf, offset, len);
  }

  public void write(int addr, byte[] writeBuf, int offset, int len)
    throws OneWireIOException, OneWireException
  {
    writeScratchpad(addr, writeBuf, offset, len);
  }

  public void loadFirstSecret(int addr, byte[] data, int offset)
    throws OneWireIOException, OneWireException
  {
    writeScratchpad(addr, data, offset, 8);
    loadFirstSecret(addr);
  }

  public void loadFirstSecret(int addr)
    throws OneWireIOException, OneWireException
  {
    byte[] send_block = new byte[4];

    checkSpeed();

    if (this.ib.adapter.select(this.ib.getAddress()))
    {
      send_block[0] = 90;
      send_block[1] = (byte)(addr & 0xFF);
      send_block[2] = (byte)(addr >>> 8 & 0xFF);
      send_block[3] = 95;

      this.ib.adapter.dataBlock(send_block, 0, 3);

      this.ib.adapter.setPowerDuration(5);
      this.ib.adapter.startPowerDelivery(2);
      this.ib.adapter.putByte(send_block[3]);
      try
      {
        Thread.sleep(20L);
      }
      catch (InterruptedException e) {
      }
      this.ib.adapter.setPowerNormal();

      byte test = (byte)this.ib.adapter.getByte();

      if ((test != -86) && (test != 85)) {
        throw new OneWireException("Error due to invalid load.");
      }

      if (addr == 128)
      {
        byte[] secret = new byte[8];
        readScratchpad(secret, 0, 8, null);
        this.owc33.setContainerSecret(secret, 0);
      }
    }
    else {
      throw new OneWireIOException("Device select failed.");
    }
  }

  public void computeNextSecret(int addr)
    throws OneWireIOException, OneWireException
  {
    byte[] send_block = new byte[3];
    byte[] scratch = new byte[8];
    byte[] next_secret = null;

    if (this.owc33.isContainerSecretSet())
    {
      byte[] memory = new byte[32];
      byte[] secret = new byte[8];
      byte[] MT = new byte[64];

      readMemory(addr & 0xE0, false, memory, 0, 32);

      this.owc33.getContainerSecret(secret, 0);

      System.arraycopy(secret, 0, MT, 0, 4);
      System.arraycopy(memory, 0, MT, 4, 32);
      System.arraycopy(ffBlock, 0, MT, 36, 4);
      readScratchpad(MT, 40, 8, null);
      MT[40] = (byte)(MT[40] & 0x3F);
      System.arraycopy(secret, 4, MT, 48, 4);
      System.arraycopy(ffBlock, 0, MT, 52, 3);

      MT[55] = -128;
      System.arraycopy(zeroBlock, 0, MT, 56, 6);
      MT[62] = 1;
      MT[63] = -72;

      int[] AtoE = new int[5];
      SHA.ComputeSHA(MT, AtoE);

      int temp = AtoE[4]; for (int i = 0; i < 4; i++)
      {
        secret[i] = (byte)(temp & 0xFF);
        temp >>= 8;
      }

      int temp = AtoE[3]; for (int i = 4; i < 8; i++)
      {
        secret[i] = (byte)(temp & 0xFF);
        temp >>= 8;
      }
      next_secret = secret;
    }

    checkSpeed();

    if (this.ib.adapter.select(this.ib.getAddress()))
    {
      send_block[0] = 51;

      send_block[1] = (byte)(addr & 0xFF);

      send_block[2] = (byte)((addr & 0xFFFF) >>> 8 & 0xFF);

      this.ib.adapter.dataBlock(send_block, 0, 2);

      this.ib.adapter.setPowerDuration(5);
      this.ib.adapter.startPowerDelivery(2);
      this.ib.adapter.putByte(send_block[2]);
      try
      {
        Thread.sleep(14L);
      }
      catch (InterruptedException e) {
      }
      this.ib.adapter.setPowerNormal();

      readScratchpad(scratch, 0, 8, null);
      for (int i = 0; i < 8; i++)
      {
        if (scratch[i] == -86)
          continue;
        throw new OneWireIOException("Next secret not calculated.");
      }

      if (next_secret != null)
      {
        this.owc33.setContainerSecret(next_secret, 0);
      }
    }
    else {
      throw new OneWireIOException("Device select failed.");
    }
  }

  public void computeNextSecret(int addr, byte[] partialsecret, int offset)
    throws OneWireIOException, OneWireException
  {
    byte[] send_block = new byte[3];
    byte[] scratch = new byte[8];
    byte[] next_secret = null;

    writeScratchpad(addr, partialsecret, 0, 8);

    if (this.owc33.isContainerSecretSet())
    {
      byte[] memory = new byte[32];
      byte[] secret = new byte[8];
      byte[] MT = new byte[64];

      readMemory(addr & 0xE0, false, memory, 0, 32);

      this.owc33.getContainerSecret(secret, 0);

      System.arraycopy(secret, 0, MT, 0, 4);
      System.arraycopy(memory, 0, MT, 4, 32);
      System.arraycopy(ffBlock, 0, MT, 36, 4);
      MT[40] = (byte)(partialsecret[0] & 0x3F);
      System.arraycopy(partialsecret, 1, MT, 41, 7);
      System.arraycopy(secret, 4, MT, 48, 4);
      System.arraycopy(ffBlock, 0, MT, 52, 3);

      MT[55] = -128;
      System.arraycopy(zeroBlock, 0, MT, 56, 6);
      MT[62] = 1;
      MT[63] = -72;

      int[] AtoE = new int[5];
      SHA.ComputeSHA(MT, AtoE);

      int temp = AtoE[4]; for (int i = 0; i < 4; i++)
      {
        secret[i] = (byte)(temp & 0xFF);
        temp >>= 8;
      }

      int temp = AtoE[3]; for (int i = 4; i < 8; i++)
      {
        secret[i] = (byte)(temp & 0xFF);
        temp >>= 8;
      }
      next_secret = secret;
    }

    if (this.ib.adapter.select(this.ib.getAddress()))
    {
      send_block[0] = 51;

      send_block[1] = (byte)(addr & 0xFF);

      send_block[2] = (byte)((addr & 0xFFFF) >>> 8 & 0xFF);

      this.ib.adapter.dataBlock(send_block, 0, 2);

      this.ib.adapter.setPowerDuration(5);
      this.ib.adapter.startPowerDelivery(2);
      this.ib.adapter.putByte(send_block[2]);
      try
      {
        Thread.sleep(14L);
      }
      catch (InterruptedException e) {
      }
      this.ib.adapter.setPowerNormal();

      readScratchpad(scratch, 0, 8, null);
      for (int i = 0; i < 8; i++)
      {
        if (scratch[i] == -86)
          continue;
        throw new OneWireIOException("Next secret not calculated.");
      }

      if (next_secret != null)
      {
        this.owc33.setContainerSecret(next_secret, 0);
      }
    }
    else {
      throw new OneWireIOException("Device select failed.");
    }
  }

  public void refreshScratchpad(int addr)
    throws OneWireIOException, OneWireException
  {
    checkSpeed();

    if (this.ib.adapter.select(this.ib.getAddress()))
    {
      byte[] send_block = new byte[13];

      send_block[0] = -93;
      send_block[1] = (byte)(addr & 0xFF);
      send_block[2] = (byte)(addr >>> 8 & 0xFF);
      for (int i = 3; i < 11; i++)
        send_block[i] = 0;
      send_block[11] = -1;
      send_block[12] = -1;

      this.ib.adapter.dataBlock(send_block, 0, 13);

      if (CRC16.compute(send_block, 0, 13, 0) != 45057)
      {
        throw new OneWireException("Bad CRC16 on Refresh Scratchpad");
      }

    }
    else
    {
      throw new OneWireIOException("Device select failed.");
    }
  }

  private void readMemory(int startAddr, boolean readContinue, byte[] readBuf, int offset, int len)
    throws OneWireIOException, OneWireException
  {
    if (!readContinue) {
      checkSpeed();
    }

    if (!readContinue)
    {
      if (!this.ib.adapter.select(this.ib.getAddress())) {
        throw new OneWireIOException("Device select failed.");
      }

      readBuf[offset] = -16;
      readBuf[(offset + 1)] = (byte)(startAddr & 0xFF);
      readBuf[(offset + 2)] = (byte)((startAddr & 0xFFFF) >>> 8 & 0xFF);

      this.ib.adapter.dataBlock(readBuf, offset, 3);
    }

    int pgs = len / 32;
    int extra = len % 32;

    for (int i = 0; i < pgs; i++) {
      System.arraycopy(ffBlock, 0, readBuf, offset + i * 32, 32);
    }
    if (extra > 0) {
      System.arraycopy(ffBlock, 0, readBuf, offset + pgs * 32, extra);
    }

    this.ib.adapter.dataBlock(readBuf, offset, len);
  }

  private static final void msWait(long ms)
  {
    try
    {
      Thread.sleep(ms);
    }
    catch (InterruptedException ie)
    {
    }
  }
}