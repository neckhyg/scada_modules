package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import com.dalsemi.onewire.utils.CRC16;
import com.dalsemi.onewire.utils.CRC8;

class MemoryBankEPROM
  implements OTPMemoryBank
{
  public static final byte READ_MEMORY_COMMAND = -16;
  public static final byte MAIN_READ_PAGE_COMMAND = -91;
  public static final byte STATUS_READ_PAGE_COMMAND = -86;
  public static final byte MAIN_WRITE_COMMAND = 15;
  public static final byte STATUS_WRITE_COMMAND = 85;
  protected OneWireContainer ib;
  protected byte READ_PAGE_WITH_CRC;
  protected int numCRCBytes;
  protected boolean crcAfterAddress;
  protected boolean normalReadCRC;
  protected byte WRITE_MEMORY_COMMAND;
  protected byte[] ffBlock;
  protected boolean doSetSpeed;
  protected int size;
  protected String bankDescription;
  protected boolean generalPurposeMemory;
  protected boolean readWrite;
  protected boolean writeOnce;
  protected boolean readOnly;
  protected boolean nonVolatile;
  protected boolean programPulse;
  protected boolean powerDelivery;
  protected int startPhysicalAddress;
  protected boolean writeVerification;
  protected int numberPages;
  protected int pageLength;
  protected int maxPacketDataLength;
  protected boolean pageAutoCRC;
  protected boolean extraInfo;
  protected int extraInfoLength;
  protected String extraInfoDescription;
  protected boolean redirectPage;
  protected boolean lockPage;
  protected boolean lockRedirectPage;
  protected PagedMemoryBank mbLock;
  protected PagedMemoryBank mbRedirect;
  protected PagedMemoryBank mbLockRedirect;
  protected int lockOffset;
  protected int redirectOffset;
  protected int lockRedirectOffset;

  public MemoryBankEPROM(OneWireContainer ibutton)
  {
    this.ib = ibutton;

    this.mbLock = null;
    this.mbRedirect = null;
    this.mbLockRedirect = null;
    this.lockOffset = 0;
    this.redirectOffset = 0;
    this.lockRedirectOffset = 0;

    this.generalPurposeMemory = true;
    this.bankDescription = "Main Memory";
    this.numberPages = 64;
    this.size = 2048;
    this.pageLength = 32;
    this.maxPacketDataLength = 29;
    this.readWrite = false;
    this.writeOnce = true;
    this.readOnly = false;
    this.nonVolatile = true;
    this.pageAutoCRC = true;
    this.redirectPage = false;
    this.lockPage = false;
    this.lockRedirectPage = false;
    this.programPulse = true;
    this.powerDelivery = false;
    this.extraInfo = true;
    this.extraInfoLength = 1;
    this.extraInfoDescription = "Inverted redirection page";
    this.writeVerification = true;
    this.startPhysicalAddress = 0;
    this.READ_PAGE_WITH_CRC = -91;
    this.WRITE_MEMORY_COMMAND = 15;
    this.numCRCBytes = 2;
    this.crcAfterAddress = true;
    this.normalReadCRC = false;
    this.doSetSpeed = true;

    this.ffBlock = new byte[50];

    for (int i = 0; i < 50; i++)
      this.ffBlock[i] = -1;
  }

  public String getBankDescription()
  {
    return this.bankDescription;
  }

  public boolean isGeneralPurposeMemory()
  {
    return this.generalPurposeMemory;
  }

  public boolean isReadWrite()
  {
    return this.readWrite;
  }

  public boolean isWriteOnce()
  {
    return this.writeOnce;
  }

  public boolean isReadOnly()
  {
    return this.readOnly;
  }

  public boolean isNonVolatile()
  {
    return this.nonVolatile;
  }

  public boolean needsProgramPulse()
  {
    return this.programPulse;
  }

  public boolean needsPowerDelivery()
  {
    return this.powerDelivery;
  }

  public int getStartPhysicalAddress()
  {
    return this.startPhysicalAddress;
  }

  public int getSize()
  {
    return this.size;
  }

  public int getNumberPages()
  {
    return this.numberPages;
  }

  public int getPageLength()
  {
    return this.pageLength;
  }

  public int getMaxPacketDataLength()
  {
    return this.maxPacketDataLength;
  }

  public boolean hasPageAutoCRC()
  {
    return this.pageAutoCRC;
  }

  /** @deprecated */
  public boolean haveExtraInfo()
  {
    return this.extraInfo;
  }

  public boolean hasExtraInfo()
  {
    return this.extraInfo;
  }

  public int getExtraInfoLength()
  {
    return this.extraInfoLength;
  }

  public String getExtraInfoDescription()
  {
    return this.extraInfoDescription;
  }

  public void setWriteVerification(boolean doReadVerf)
  {
    this.writeVerification = doReadVerf;
  }

  public boolean canRedirectPage()
  {
    return this.redirectPage;
  }

  public boolean canLockPage()
  {
    return this.lockPage;
  }

  public boolean canLockRedirectPage()
  {
    return this.lockRedirectPage;
  }

  public void read(int startAddr, boolean readContinue, byte[] readBuf, int offset, int len)
    throws OneWireIOException, OneWireException
  {
    if (startAddr + len > this.pageLength * this.numberPages) {
      throw new OneWireException("Read exceeds memory bank end");
    }

    if (!readContinue) {
      checkSpeed();
    }

    if (this.READ_PAGE_WITH_CRC == -86)
    {
      int start_pg = startAddr / this.pageLength;
      int end_pg = (startAddr + len) / this.pageLength - 1;

      if ((startAddr + len) % this.pageLength > 0) {
        end_pg++;
      }
      byte[] raw_buf = new byte[(end_pg - start_pg + 1) * this.pageLength];

      for (int pg = start_pg; pg <= end_pg; pg++) {
        readPageCRC(pg, pg != start_pg, raw_buf, (pg - start_pg) * this.pageLength, null, 0);
      }

      System.arraycopy(raw_buf, startAddr % this.pageLength, readBuf, offset, len);
    }
    else
    {
      if (!readContinue)
      {
        if (!this.ib.adapter.select(this.ib.address))
        {
          forceVerify();

          throw new OneWireIOException("Device select failed");
        }

        byte[] raw_buf = new byte[4];

        raw_buf[0] = -16;
        raw_buf[1] = (byte)(startAddr + this.startPhysicalAddress & 0xFF);

        raw_buf[2] = (byte)((startAddr + this.startPhysicalAddress & 0xFFFF) >>> 8 & 0xFF);

        raw_buf[3] = -1;

        int num_bytes = this.normalReadCRC ? 4 : 3;

        this.ib.adapter.dataBlock(raw_buf, 0, num_bytes);
      }

      int pgs = len / this.pageLength;
      int extra = len % this.pageLength;

      for (int i = 0; i < pgs; i++) {
        System.arraycopy(this.ffBlock, 0, readBuf, offset + i * this.pageLength, this.pageLength);
      }
      System.arraycopy(this.ffBlock, 0, readBuf, offset + pgs * this.pageLength, extra);

      this.ib.adapter.dataBlock(readBuf, offset, len);
    }
  }

  public void write(int startAddr, byte[] writeBuf, int offset, int len)
    throws OneWireIOException, OneWireException
  {
    if (len == 0) {
      return;
    }

    if (!this.ib.adapter.canProgram()) {
      throw new OneWireException("Program voltage required but not available");
    }

    if (isReadOnly()) {
      throw new OneWireException("Trying to write read-only memory bank");
    }

    if (startAddr + len > this.pageLength * this.numberPages) {
      throw new OneWireException("Write exceeds memory bank end");
    }

    this.ib.adapter.setProgramPulseDuration(7);

    checkSpeed();

    boolean write_continue = false;

    for (int i = 0; i < len; i++)
    {
      byte result = programByte(startAddr + i + this.startPhysicalAddress, writeBuf[(offset + i)], write_continue);

      if (!this.writeVerification)
        continue;
      if (result == writeBuf[(offset + i)]) {
        write_continue = true;
      }
      else {
        forceVerify();

        throw new OneWireIOException("Read back byte on EPROM programming did not match");
      }
    }
  }

  public void readPage(int page, boolean readContinue, byte[] readBuf, int offset)
    throws OneWireIOException, OneWireException
  {
    if (this.pageAutoCRC) {
      readPageCRC(page, readContinue, readBuf, offset, null, this.extraInfoLength);
    }
    else
      read(page * this.pageLength, readContinue, readBuf, offset, this.pageLength);
  }

  public void readPage(int page, boolean readContinue, byte[] readBuf, int offset, byte[] extraInfo)
    throws OneWireIOException, OneWireException
  {
    if (!this.extraInfo) {
      throw new OneWireException("Read extra information not supported on this memory bank");
    }

    readPageCRC(page, readContinue, readBuf, offset, extraInfo, this.extraInfoLength);
  }

  public int readPagePacket(int page, boolean readContinue, byte[] readBuf, int offset, byte[] extraInfo)
    throws OneWireIOException, OneWireException
  {
    byte[] raw_buf = new byte[this.pageLength];

    if (!this.extraInfo) {
      throw new OneWireException("Read extra information not supported on this memory bank");
    }

    readPageCRC(page, readContinue, raw_buf, 0, extraInfo, this.extraInfoLength);

    if ((raw_buf[0] & 0xFF) > this.maxPacketDataLength)
    {
      forceVerify();

      throw new OneWireIOException("Invalid length in packet");
    }

    if (CRC16.compute(raw_buf, 0, raw_buf[0] + 3, page) == 45057)
    {
      System.arraycopy(raw_buf, 1, readBuf, offset, raw_buf[0]);

      return raw_buf[0];
    }

    forceVerify();

    throw new OneWireIOException("Invalid CRC16 in packet read");
  }

  public int readPagePacket(int page, boolean readContinue, byte[] readBuf, int offset)
    throws OneWireIOException, OneWireException
  {
    byte[] raw_buf = new byte[this.pageLength];

    readPageCRC(page, readContinue, raw_buf, 0, null, this.extraInfoLength);

    if ((raw_buf[0] & 0xFF) > this.maxPacketDataLength)
    {
      forceVerify();

      throw new OneWireIOException("Invalid length in packet");
    }

    if (CRC16.compute(raw_buf, 0, raw_buf[0] + 3, page) == 45057)
    {
      System.arraycopy(raw_buf, 1, readBuf, offset, raw_buf[0]);

      return raw_buf[0];
    }

    forceVerify();

    throw new OneWireIOException("Invalid CRC16 in packet read");
  }

  public void writePagePacket(int page, byte[] writeBuf, int offset, int len)
    throws OneWireIOException, OneWireException
  {
    if (len > this.maxPacketDataLength) {
      throw new OneWireIOException("Length of packet requested exceeds page size");
    }

    if (!this.generalPurposeMemory) {
      throw new OneWireException("Current bank is not general purpose memory");
    }

    byte[] raw_buf = new byte[len + 3];

    raw_buf[0] = (byte)len;

    System.arraycopy(writeBuf, offset, raw_buf, 1, len);

    int crc = CRC16.compute(raw_buf, 0, len + 1, page);

    raw_buf[(len + 1)] = (byte)((crc ^ 0xFFFFFFFF) & 0xFF);
    raw_buf[(len + 2)] = (byte)(((crc ^ 0xFFFFFFFF) & 0xFFFF) >>> 8 & 0xFF);

    write(page * this.pageLength, raw_buf, 0, len + 3);
  }

  public void readPageCRC(int page, boolean readContinue, byte[] readBuf, int offset)
    throws OneWireIOException, OneWireException
  {
    readPageCRC(page, readContinue, readBuf, offset, null, this.extraInfoLength);
  }

  public void readPageCRC(int page, boolean readContinue, byte[] readBuf, int offset, byte[] extraInfo)
    throws OneWireIOException, OneWireException
  {
    readPageCRC(page, readContinue, readBuf, offset, extraInfo, this.extraInfoLength);
  }

  public void lockPage(int page)
    throws OneWireIOException, OneWireException
  {
    int nbyt = page >>> 3;
    int nbit = page - (nbyt << 3);
    byte[] wr_byte = new byte[1];

    wr_byte[0] = (byte)(1 << nbit ^ 0xFFFFFFFF);

    this.mbLock.setWriteVerification(false);

    this.mbLock.write(nbyt + this.lockOffset, wr_byte, 0, 1);

    if (!isPageLocked(page))
    {
      forceVerify();

      throw new OneWireIOException("Read back from write incorrect, could not lock page");
    }
  }

  public boolean isPageLocked(int page)
    throws OneWireIOException, OneWireException
  {
    int pg_len = this.mbLock.getPageLength();
    int read_pg = (page + this.lockOffset) / (pg_len * 8);

    byte[] read_buf = new byte[pg_len];

    this.mbLock.readPageCRC(read_pg, false, read_buf, 0);

    int index = page + this.lockOffset - read_pg * 8 * pg_len;
    int nbyt = index >>> 3;
    int nbit = index - (nbyt << 3);

    return (read_buf[nbyt] >>> nbit & 0x1) != 1;
  }

  public void redirectPage(int page, int newPage)
    throws OneWireIOException, OneWireException
  {
    byte[] wr_byte = new byte[1];

    wr_byte[0] = (byte)(newPage ^ 0xFFFFFFFF);

    this.mbRedirect.setWriteVerification(true);

    this.mbRedirect.write(page + this.redirectOffset, wr_byte, 0, 1);
  }

  /** @deprecated */
  public int isPageRedirected(int page)
    throws OneWireIOException, OneWireException
  {
    int pg_len = this.mbRedirect.getPageLength();
    int read_pg = (page + this.redirectOffset) / pg_len;

    byte[] read_buf = new byte[pg_len];

    this.mbRedirect.readPageCRC(read_pg, false, read_buf, 0);

    return (read_buf[((page + this.redirectOffset) % pg_len)] ^ 0xFFFFFFFF) & 0xFF;
  }

  public int getRedirectedPage(int page)
    throws OneWireIOException, OneWireException
  {
    int pg_len = this.mbRedirect.getPageLength();
    int read_pg = (page + this.redirectOffset) / pg_len;

    byte[] read_buf = new byte[pg_len];

    this.mbRedirect.readPageCRC(read_pg, false, read_buf, 0);

    return (read_buf[((page + this.redirectOffset) % pg_len)] ^ 0xFFFFFFFF) & 0xFF;
  }

  public void lockRedirectPage(int page)
    throws OneWireIOException, OneWireException
  {
    int nbyt = page >>> 3;
    int nbit = page - (nbyt << 3);
    byte[] wr_byte = new byte[1];

    wr_byte[0] = (byte)(1 << nbit ^ 0xFFFFFFFF);

    this.mbLockRedirect.setWriteVerification(false);

    this.mbLockRedirect.write(nbyt + this.lockRedirectOffset, wr_byte, 0, 1);

    if (!isRedirectPageLocked(page))
    {
      forceVerify();

      throw new OneWireIOException("Read back from write incorrect, could not lock redirect byte");
    }
  }

  public boolean isRedirectPageLocked(int page)
    throws OneWireIOException, OneWireException
  {
    int pg_len = this.mbLockRedirect.getPageLength();
    int read_pg = (page + this.lockRedirectOffset) / (pg_len * 8);

    byte[] read_buf = new byte[pg_len];

    this.mbLockRedirect.readPageCRC(read_pg, false, read_buf, 0);

    int index = page + this.lockRedirectOffset - read_pg * 8 * pg_len;
    int nbyt = index >>> 3;
    int nbit = index - (nbyt << 3);

    return (read_buf[nbyt] >>> nbit & 0x1) != 1;
  }

  protected void readPageCRC(int page, boolean readContinue, byte[] readBuf, int offset, byte[] extraInfo, int extraLength)
    throws OneWireIOException, OneWireException
  {
    int len = 0; int lastcrc = 0;
    byte[] raw_buf = new byte[this.pageLength + this.numCRCBytes];

    if (!this.pageAutoCRC) {
      throw new OneWireException("Read page with CRC not supported in this memory bank");
    }

    if (!readContinue) {
      checkSpeed();
    }

    if (page > this.numberPages) {
      throw new OneWireException("Read exceeds memory bank end");
    }

    if (!readContinue)
    {
      if (!this.ib.adapter.select(this.ib.address))
      {
        forceVerify();

        throw new OneWireIOException("Device select failed");
      }

      len = 3 + this.extraInfoLength;

      if (this.crcAfterAddress) {
        len += this.numCRCBytes;
      }
      System.arraycopy(this.ffBlock, 0, raw_buf, 0, len);

      raw_buf[0] = this.READ_PAGE_WITH_CRC;

      int addr = page * this.pageLength + this.startPhysicalAddress;

      raw_buf[1] = (byte)(addr & 0xFF);
      raw_buf[2] = (byte)((addr & 0xFFFF) >>> 8 & 0xFF);

      this.ib.adapter.dataBlock(raw_buf, 0, len);
    }
    else if (this.extraInfoLength > 0)
    {
      len = this.extraInfoLength + this.numCRCBytes;

      System.arraycopy(this.ffBlock, 0, raw_buf, 0, len);

      this.ib.adapter.dataBlock(raw_buf, 0, len);
    }

    if (this.numCRCBytes == 2)
      lastcrc = CRC16.compute(raw_buf, 0, len, 0);
    else {
      lastcrc = CRC8.compute(raw_buf, 0, len, 0);
    }
    if ((this.extraInfoLength > 0) || (this.crcAfterAddress))
    {
      if (this.numCRCBytes == 2)
      {
        if (lastcrc != 45057)
        {
          forceVerify();

          throw new OneWireIOException("Invalid CRC16 read from device");
        }

      }
      else if (lastcrc != 0)
      {
        forceVerify();

        throw new OneWireIOException("Invalid CRC8 read from device");
      }

      lastcrc = 0;

      if ((this.extraInfoLength > 0) && (extraInfo != null)) {
        System.arraycopy(raw_buf, len - this.extraInfoLength - this.numCRCBytes, extraInfo, 0, extraLength);
      }

    }

    System.arraycopy(this.ffBlock, 0, raw_buf, 0, raw_buf.length);

    this.ib.adapter.dataBlock(raw_buf, 0, raw_buf.length);

    if (this.numCRCBytes == 2)
    {
      if (CRC16.compute(raw_buf, 0, raw_buf.length, lastcrc) != 45057)
      {
        forceVerify();

        throw new OneWireIOException("Invalid CRC16 read from device");
      }

    }
    else if (CRC8.compute(raw_buf, 0, raw_buf.length, lastcrc) != 0)
    {
      forceVerify();

      throw new OneWireIOException("Invalid CRC8 read from device");
    }

    System.arraycopy(raw_buf, 0, readBuf, offset, this.pageLength);
  }

  protected byte programByte(int addr, byte data, boolean writeContinue)
    throws OneWireIOException, OneWireException
  {
    int lastcrc = 0;

    if (!writeContinue)
    {
      if (!this.ib.adapter.select(this.ib.address))
      {
        forceVerify();

        throw new OneWireIOException("device not present");
      }

      byte[] raw_buf = new byte[6];

      System.arraycopy(this.ffBlock, 0, raw_buf, 0, raw_buf.length);

      raw_buf[0] = this.WRITE_MEMORY_COMMAND;
      raw_buf[1] = (byte)(addr & 0xFF);
      raw_buf[2] = (byte)((addr & 0xFFFF) >>> 8 & 0xFF);
      raw_buf[3] = data;
      int len;
      if (this.numCRCBytes == 2)
      {
        lastcrc = CRC16.compute(raw_buf, 0, 4, 0);
        len = 6;
      }
      else
      {
        lastcrc = CRC8.compute(raw_buf, 0, 4, 0);
        len = 5;
      }

      this.ib.adapter.dataBlock(raw_buf, 0, len);

      if (this.numCRCBytes == 2)
      {
        if (CRC16.compute(raw_buf, 4, 2, lastcrc) != 45057)
        {
          forceVerify();

          throw new OneWireIOException("Invalid CRC16 read from device");
        }

      }
      else if (CRC8.compute(raw_buf, 4, 1, lastcrc) != 0)
      {
        forceVerify();

        throw new OneWireIOException("Invalid CRC8 read from device");
      }

    }
    else
    {
      this.ib.adapter.putByte(data);

      if (this.numCRCBytes == 2)
      {
        lastcrc = CRC16.compute(data, addr);
        lastcrc = CRC16.compute(this.ib.adapter.getByte(), lastcrc);

        if (CRC16.compute(this.ib.adapter.getByte(), lastcrc) != 45057)
        {
          forceVerify();

          throw new OneWireIOException("Invalid CRC16 read from device");
        }
      }
      else
      {
        lastcrc = CRC8.compute(data, addr);

        if (CRC8.compute(this.ib.adapter.getByte(), lastcrc) != 0)
        {
          forceVerify();

          throw new OneWireIOException("Invalid CRC8 read from device");
        }
      }

    }

    this.ib.adapter.startProgramPulse(0);

    return (byte)this.ib.adapter.getByte();
  }

  public void checkSpeed()
    throws OneWireIOException, OneWireException
  {
    synchronized (this)
    {
      if (this.doSetSpeed)
      {
        this.ib.doSpeed();

        this.doSetSpeed = false;
      }
    }
  }

  public void forceVerify()
  {
    synchronized (this)
    {
      this.doSetSpeed = true;
    }
  }
}