package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.OneWireIOException;

public abstract interface PagedMemoryBank extends MemoryBank
{
  public abstract int getNumberPages();

  public abstract int getPageLength();

  public abstract int getMaxPacketDataLength();

  public abstract boolean hasPageAutoCRC();

  /** @deprecated */
  public abstract boolean haveExtraInfo();

  public abstract boolean hasExtraInfo();

  public abstract int getExtraInfoLength();

  public abstract String getExtraInfoDescription();

  public abstract void readPage(int paramInt1, boolean paramBoolean, byte[] paramArrayOfByte, int paramInt2)
    throws OneWireIOException, OneWireException;

  public abstract void readPage(int paramInt1, boolean paramBoolean, byte[] paramArrayOfByte1, int paramInt2, byte[] paramArrayOfByte2)
    throws OneWireIOException, OneWireException;

  public abstract int readPagePacket(int paramInt1, boolean paramBoolean, byte[] paramArrayOfByte, int paramInt2)
    throws OneWireIOException, OneWireException;

  public abstract int readPagePacket(int paramInt1, boolean paramBoolean, byte[] paramArrayOfByte1, int paramInt2, byte[] paramArrayOfByte2)
    throws OneWireIOException, OneWireException;

  public abstract void writePagePacket(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3)
    throws OneWireIOException, OneWireException;

  public abstract void readPageCRC(int paramInt1, boolean paramBoolean, byte[] paramArrayOfByte, int paramInt2)
    throws OneWireIOException, OneWireException;

  public abstract void readPageCRC(int paramInt1, boolean paramBoolean, byte[] paramArrayOfByte1, int paramInt2, byte[] paramArrayOfByte2)
    throws OneWireIOException, OneWireException;
}