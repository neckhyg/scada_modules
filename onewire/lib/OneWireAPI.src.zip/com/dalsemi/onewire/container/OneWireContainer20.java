package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import com.dalsemi.onewire.utils.Bit;
import com.dalsemi.onewire.utils.CRC16;
import com.dalsemi.onewire.utils.Convert;
import java.util.Enumeration;
import java.util.Vector;

public class OneWireContainer20 extends OneWireContainer
  implements ADContainer
{
  public static final int BITMAP_OFFSET = 24;
  public static final int ALARM_OFFSET = 8;
  public static final int EXPOWER_OFFSET = 20;
  public static final int CHANNELA = 0;
  public static final int CHANNELB = 1;
  public static final int CHANNELC = 2;
  public static final int CHANNELD = 3;
  public static final int NO_PRESET = 0;
  public static final int PRESET_TO_ZEROS = 1;
  public static final int PRESET_TO_ONES = 2;
  public static final int NUM_CHANNELS = 4;
  private static final byte CONVERT_COMMAND = 60;
  private MemoryBankAD readout;
  private Vector regs;

  public OneWireContainer20()
  {
    initMem();
  }

  public OneWireContainer20(DSPortAdapter sourceAdapter, byte[] newAddress)
  {
    super(sourceAdapter, newAddress);

    initMem();
  }

  public OneWireContainer20(DSPortAdapter sourceAdapter, long newAddress)
  {
    super(sourceAdapter, newAddress);

    initMem();
  }

  public OneWireContainer20(DSPortAdapter sourceAdapter, String newAddress)
  {
    super(sourceAdapter, newAddress);

    initMem();
  }

  public String getName()
  {
    return "DS2450";
  }

  public String getAlternateNames()
  {
    return "1-Wire Quad A/D Converter";
  }

  public String getDescription()
  {
    return "Four high-impedance inputs for measurement of analog voltages.  User programable input range.  Very low power.  Built-in multidrop controller.  Channels not used as input can be configured as outputs through the use of open drain digital outputs. Capable of use of Overdrive for fast data transfer. Uses on-chip 16-bit CRC-generator to guarantee good data.";
  }

  public int getMaxSpeed()
  {
    return 2;
  }

  public Enumeration getMemoryBanks()
  {
    Vector bank_vector = new Vector(4);

    bank_vector.addElement(this.readout);

    for (int i = 0; i < 3; i++) {
      bank_vector.addElement(this.regs.elementAt(i));
    }
    return bank_vector.elements();
  }

  public int getNumberADChannels()
  {
    return 4;
  }

  public boolean hasADAlarms()
  {
    return true;
  }

  public double[] getADRanges(int channel)
  {
    double[] ranges = new double[2];

    ranges[0] = 5.12D;
    ranges[1] = 2.56D;

    return ranges;
  }

  public double[] getADResolutions(int channel, double range)
  {
    double[] res = new double[16];

    for (int i = 0; i < 16; i++) {
      res[i] = (range / (1 << i + 1));
    }
    return res;
  }

  public boolean canADMultiChannelRead()
  {
    return true;
  }

  public byte[] readDevice()
    throws OneWireIOException, OneWireException
  {
    byte[] read_buf = new byte[27];

    for (int i = 0; i < 3; i++)
    {
      MemoryBankAD mb = (MemoryBankAD)this.regs.elementAt(i);

      mb.readPageCRC(0, i != 0, read_buf, i * 8);
    }

    read_buf[24] = 0;
    read_buf[25] = 0;
    read_buf[26] = 0;

    return read_buf;
  }

  public void writeDevice(byte[] state)
    throws OneWireIOException, OneWireException
  {
    for (int i = 0; i < 4; i++)
    {
      int index = i * 2 + 1;

      if ((state[index] & 0xFFFFFFB0) == 0)
        continue;
      int tmp27_25 = index;
      byte[] tmp27_24 = state; tmp27_24[tmp27_25] = (byte)(tmp27_24[tmp27_25] & 0xF);

      Bit.arrayWriteBit(1, index, 24, state);
    }

    state[26] = (byte)(state[26] & 0x10);

    for (int bank = 0; bank < 3; bank++)
    {
      int start_offset = 0;
      int len = 0;
      boolean got_block = false;
      MemoryBankAD mb = (MemoryBankAD)this.regs.elementAt(bank);

      for (i = 0; i < 8; i++)
      {
        if (Bit.arrayReadBit(bank * 8 + i, 24, state) == 1)
        {
          if (got_block) {
            len++;
          }
          else
          {
            got_block = true;
            start_offset = i;
            len = 1;
          }

          if (i == 7)
            mb.write(start_offset, state, bank * 8 + start_offset, len);
        } else {
          if (!got_block)
          {
            continue;
          }
          mb.write(start_offset, state, bank * 8 + start_offset, len);

          got_block = false;
        }
      }

    }

    state[24] = 0;
    state[25] = 0;
    state[26] = 0;
  }

  public double[] getADVoltage(byte[] state)
    throws OneWireIOException, OneWireException
  {
    byte[] read_buf = new byte[8];
    double[] ret_dbl = new double[4];

    this.readout.readPageCRC(0, false, read_buf, 0);

    for (int ch = 0; ch < 4; ch++)
    {
      ret_dbl[ch] = interpretVoltage(Convert.toLong(read_buf, ch * 2, 2), getADRange(ch, state));
    }

    return ret_dbl;
  }

  public double getADVoltage(int channel, byte[] state)
    throws OneWireIOException, OneWireException
  {
    if ((channel < 0) || (channel > 3)) {
      throw new IllegalArgumentException("Invalid channel number");
    }

    byte[] read_buf = new byte[8];

    this.readout.readPageCRC(0, false, read_buf, 0);

    return interpretVoltage(Convert.toLong(read_buf, channel * 2, 2), getADRange(channel, state));
  }

  public void doADConvert(int channel, byte[] state)
    throws OneWireIOException, OneWireException
  {
    doADConvert(channel, 1, state);
  }

  public void doADConvert(boolean[] doConvert, byte[] state)
    throws OneWireIOException, OneWireException
  {
    int[] presets = new int[4];

    for (int i = 0; i < 4; i++) {
      presets[i] = 1;
    }
    doADConvert(doConvert, presets, state);
  }

  public void doADConvert(int channel, int preset, byte[] state)
    throws OneWireIOException, OneWireException, IllegalArgumentException
  {
    if ((channel < 0) || (channel > 3)) {
      throw new IllegalArgumentException("Invalid channel number");
    }

    doADConvert((byte)(1 << channel), (byte)(preset << channel), 1440, state);
  }

  public void doADConvert(boolean[] doConvert, int[] preset, byte[] state)
    throws OneWireIOException, OneWireException
  {
    byte input_select_mask = 0;
    byte read_out_control = 0;
    int time = 160;

    for (int ch = 3; ch >= 0; ch--)
    {
      input_select_mask = (byte)(input_select_mask << 1);

      if (doConvert[ch] != 0) {
        input_select_mask = (byte)(input_select_mask | 0x1);
      }

      read_out_control = (byte)(read_out_control << 2);

      if (preset[ch] == 1)
        read_out_control = (byte)(read_out_control | 0x1);
      else if (preset[ch] == 2) {
        read_out_control = (byte)(read_out_control | 0x2);
      }

      time = (int)(time + 80.0D * getADResolution(ch, state));
    }

    doADConvert(input_select_mask, read_out_control, time, state);
  }

  public double getADAlarm(int channel, int alarmType, byte[] state)
  {
    if ((channel < 0) || (channel > 3)) {
      throw new IllegalArgumentException("Invalid channel number");
    }

    long temp_long = (state[(8 + channel * 2 + alarmType)] & 0xFF) << 8;

    return interpretVoltage(temp_long, getADRange(channel, state));
  }

  public boolean getADAlarmEnable(int channel, int alarmType, byte[] state)
  {
    if ((channel < 0) || (channel > 3)) {
      throw new IllegalArgumentException("Invalid channel number");
    }
    return Bit.arrayReadBit(2 + alarmType, channel * 2 + 1, state) == 1;
  }

  public boolean hasADAlarmed(int channel, int alarmType, byte[] state)
  {
    if ((channel < 0) || (channel > 3)) {
      throw new IllegalArgumentException("Invalid channel number");
    }
    return Bit.arrayReadBit(4 + alarmType, channel * 2 + 1, state) == 1;
  }

  public double getADResolution(int channel, byte[] state)
  {
    if ((channel < 0) || (channel > 3)) {
      throw new IllegalArgumentException("Invalid channel number");
    }
    int res = state[(channel * 2)] & 0xF;

    if (res == 0) {
      res = 16;
    }
    return getADRange(channel, state) / (1 << res);
  }

  public double getADRange(int channel, byte[] state)
  {
    if ((channel < 0) || (channel > 3)) {
      throw new IllegalArgumentException("Invalid channel number");
    }
    return Bit.arrayReadBit(0, channel * 2 + 1, state) == 1 ? 5.12D : 2.56D;
  }

  public boolean isOutputEnabled(int channel, byte[] state)
    throws IllegalArgumentException
  {
    if ((channel < 0) || (channel > 3)) {
      throw new IllegalArgumentException("Invalid channel number");
    }
    return Bit.arrayReadBit(7, channel * 2, state) == 1;
  }

  public boolean getOutputState(int channel, byte[] state)
    throws IllegalArgumentException
  {
    if ((channel < 0) || (channel > 3)) {
      throw new IllegalArgumentException("Invalid channel number");
    }
    return Bit.arrayReadBit(6, channel * 2, state) == 1;
  }

  public boolean getDevicePOR(byte[] state)
  {
    return Bit.arrayReadBit(7, 1, state) == 1;
  }

  public boolean isPowerExternal(byte[] state)
  {
    return state[20] != 0;
  }

  public void setADAlarm(int channel, int alarmType, double alarm, byte[] state)
  {
    if ((channel < 0) || (channel > 3)) {
      throw new IllegalArgumentException("Invalid channel number");
    }
    int offset = 8 + channel * 2 + alarmType;

    state[offset] = (byte)(voltageToInt(alarm, getADRange(channel, state)) >>> 8 & 0xFF);

    Bit.arrayWriteBit(1, offset, 24, state);
  }

  public void setADAlarmEnable(int channel, int alarmType, boolean alarmEnable, byte[] state)
  {
    if ((channel < 0) || (channel > 3)) {
      throw new IllegalArgumentException("Invalid channel number");
    }

    Bit.arrayWriteBit(alarmEnable ? 1 : 0, 2 + alarmType, channel * 2 + 1, state);

    Bit.arrayWriteBit(1, channel * 2 + 1, 24, state);
  }

  public void setADResolution(int channel, double resolution, byte[] state)
  {
    if ((channel < 0) || (channel > 3)) {
      throw new IllegalArgumentException("Invalid channel number");
    }

    int div = (int)(getADRange(channel, state) / resolution);
    int res_bits = 0;
    do
    {
      div >>>= 1;

      res_bits++;
    }
    while (div != 0);

    res_bits--;

    if (res_bits == 16) {
      res_bits = 0;
    }

    if ((res_bits < 0) || (res_bits > 15))
      throw new IllegalArgumentException("Invalid resolution");
    int tmp88_87 = (channel * 2);
    byte[] tmp88_83 = state; tmp88_83[tmp88_87] = (byte)(tmp88_83[tmp88_87] & 0xFFFFFFF0);
    int tmp100_99 = (channel * 2);
    byte[] tmp100_95 = state; tmp100_95[tmp100_99] = (byte)(tmp100_95[tmp100_99] | (tmp88_87 == 16 ? 0 : (byte)tmp88_87));

    Bit.arrayWriteBit(1, channel * 2, 24, state);
  }

  public void setADRange(int channel, double range, byte[] state)
  {
    if ((channel < 0) || (channel > 3))
      throw new IllegalArgumentException("Invalid channel number");
    int range_bit;
    if (((range > 5.0D ? 1 : 0) & (range < 5.3D ? 1 : 0)) != 0)
      range_bit = 1;
    else if (((range > 2.4D ? 1 : 0) & (range < 2.7D ? 1 : 0)) != 0)
      range_bit = 0;
    else {
      throw new IllegalArgumentException("Invalid range");
    }

    Bit.arrayWriteBit(range_bit, 0, channel * 2 + 1, state);

    Bit.arrayWriteBit(1, channel * 2 + 1, 24, state);
  }

  public void setOutput(int channel, boolean outputEnable, boolean outputState, byte[] state)
  {
    if ((channel < 0) || (channel > 3)) {
      throw new IllegalArgumentException("Invalid channel number");
    }

    Bit.arrayWriteBit(outputEnable ? 1 : 0, 7, channel * 2, state);

    if (outputEnable) {
      Bit.arrayWriteBit(outputState ? 1 : 0, 6, channel * 2, state);
    }

    Bit.arrayWriteBit(1, channel * 2, 24, state);
  }

  public void setPower(boolean external, byte[] state)
  {
    state[20] = (external ? 64 : 0);

    Bit.arrayWriteBit(1, 20, 24, state);
  }

  public static double interpretVoltage(long rawVoltage, double range)
  {
    return rawVoltage / 65535.0D * range;
  }

  public static int voltageToInt(double voltage, double range)
  {
    return (int)(voltage * 65535.0D / range);
  }

  private void initMem()
  {
    this.readout = new MemoryBankAD(this);

    this.regs = new Vector(3);

    MemoryBankAD temp_mb = new MemoryBankAD(this);

    temp_mb.bankDescription = "A/D Control and Status";
    temp_mb.generalPurposeMemory = false;
    temp_mb.startPhysicalAddress = 8;
    temp_mb.readWrite = true;
    temp_mb.readOnly = false;

    this.regs.addElement(temp_mb);

    temp_mb = new MemoryBankAD(this);
    temp_mb.bankDescription = "A/D Alarm Settings";
    temp_mb.generalPurposeMemory = false;
    temp_mb.startPhysicalAddress = 16;
    temp_mb.readWrite = true;
    temp_mb.readOnly = false;

    this.regs.addElement(temp_mb);

    temp_mb = new MemoryBankAD(this);
    temp_mb.bankDescription = "A/D Calibration";
    temp_mb.generalPurposeMemory = false;
    temp_mb.startPhysicalAddress = 24;
    temp_mb.readWrite = true;
    temp_mb.readOnly = false;

    this.regs.addElement(temp_mb);
  }

  private void doADConvert(byte inputSelectMask, byte readOutControl, int timeUs, byte[] state)
    throws OneWireIOException, OneWireException
  {
    if (inputSelectMask == 0)
    {
      throw new IllegalArgumentException("No conversion will take place.  No channel selected.");
    }

    byte[] raw_buf = new byte[5];

    raw_buf[0] = 60;
    raw_buf[1] = inputSelectMask;
    raw_buf[2] = readOutControl;
    raw_buf[3] = -1;
    raw_buf[4] = -1;

    int crc16 = CRC16.compute(raw_buf, 0, 3, 0);

    if (this.adapter.select(this.address))
    {
      if (isPowerExternal(state))
      {
        this.adapter.dataBlock(raw_buf, 0, 5);
        try
        {
          Thread.sleep(timeUs / 1000 + 10);
        }
        catch (InterruptedException e)
        {
        }

        crc16 = CRC16.compute(raw_buf, 3, 2, crc16);
      }
      else
      {
        this.adapter.dataBlock(raw_buf, 0, 4);

        this.adapter.setPowerDuration(5);
        this.adapter.startPowerDelivery(2);

        raw_buf[4] = (byte)this.adapter.getByte();
        crc16 = CRC16.compute(raw_buf, 3, 2, crc16);
        try
        {
          Thread.sleep(timeUs / 1000 + 1);
        }
        catch (InterruptedException e)
        {
        }

        this.adapter.setPowerNormal();
      }
    }
    else {
      throw new OneWireException("OneWireContainer20 - Device not found.");
    }

    if (crc16 != 45057) {
      throw new OneWireIOException("OneWireContainer20 - Failure during conversion - Bad CRC");
    }

    if (this.adapter.getByte() == 0)
      throw new OneWireIOException("Conversion failed to complete.");
  }
}