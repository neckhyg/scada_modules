package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import com.dalsemi.onewire.utils.CRC16;

class MemoryBankScratchCRC extends MemoryBankScratchEx
{
  public MemoryBankScratchCRC(OneWireContainer ibutton)
  {
    super(ibutton);

    this.bankDescription = "Scratchpad with CRC";
    this.pageAutoCRC = true;

    this.COPY_SCRATCHPAD_COMMAND = 85;
  }

  public void readPageCRC(int page, boolean readContinue, byte[] readBuf, int offset)
    throws OneWireIOException, OneWireException
  {
    byte[] extraInfo = new byte[this.extraInfoLength];

    readPageCRC(page, readContinue, readBuf, offset, extraInfo);
  }

  public void readPageCRC(int page, boolean readContinue, byte[] readBuf, int offset, byte[] extraInfo)
    throws OneWireIOException, OneWireException
  {
    if (!this.pageAutoCRC) {
      throw new OneWireException("Read page with CRC not supported in this memory bank");
    }

    if (!readContinue) {
      checkSpeed();
    }

    if (page > this.numberPages) {
      throw new OneWireException("Read exceeds memory bank end");
    }

    readScratchpad(readBuf, offset, this.pageLength, extraInfo);
  }

  public void readScratchpad(byte[] readBuf, int offset, int len, byte[] extraInfo)
    throws OneWireIOException, OneWireException
  {
    if (!this.ib.adapter.select(this.ib.address))
    {
      forceVerify();

      throw new OneWireIOException("Device select failed");
    }

    byte[] raw_buf = new byte[this.extraInfoLength + this.pageLength + 3];

    raw_buf[0] = -86;

    System.arraycopy(this.ffBlock, 0, raw_buf, 1, raw_buf.length - 1);

    this.ib.adapter.dataBlock(raw_buf, 0, raw_buf.length);

    int addr = raw_buf[1];

    addr = (addr | raw_buf[2] << 8 & 0xFF00) & 0xFFFF;

    int num_crc = 35 - (addr & 0x1F) + this.extraInfoLength;

    if (CRC16.compute(raw_buf, 0, num_crc, 0) != 45057)
    {
      forceVerify();

      throw new OneWireIOException("Invalid CRC16 read from device");
    }

    if (extraInfo != null) {
      System.arraycopy(raw_buf, 1, extraInfo, 0, this.extraInfoLength);
    }

    System.arraycopy(raw_buf, this.extraInfoLength + 1, readBuf, 0, this.pageLength);
  }
}