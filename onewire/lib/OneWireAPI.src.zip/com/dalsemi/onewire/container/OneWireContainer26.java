package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import com.dalsemi.onewire.utils.CRC8;
import java.util.Enumeration;
import java.util.Vector;

public class OneWireContainer26 extends OneWireContainer
  implements ADContainer, TemperatureContainer, ClockContainer, HumidityContainer
{
  private static final byte READ_SCRATCHPAD_COMMAND = -66;
  private static final byte RECALL_MEMORY_COMMAND = -72;
  private static final byte COPY_SCRATCHPAD_COMMAND = 72;
  private static final byte WRITE_SCRATCHPAD_COMMAND = 78;
  private static final byte CONVERT_TEMP_COMMAND = 68;
  private static final byte CONVERT_VOLTAGE_COMMAND = -76;
  public static final int CHANNEL_VDD = 0;
  public static final int CHANNEL_VAD = 1;
  public static final int CHANNEL_VSENSE = 2;
  public static final byte IAD_FLAG = 1;
  public static final byte CA_FLAG = 2;
  public static final byte EE_FLAG = 4;
  public static final byte AD_FLAG = 8;
  public static final byte TB_FLAG = 16;
  public static final byte NVB_FLAG = 32;
  public static final byte ADB_FLAG = 64;
  private double Rsens = 0.05D;

  private boolean doSpeedEnable = true;

  public OneWireContainer26()
  {
  }

  public OneWireContainer26(DSPortAdapter sourceAdapter, byte[] newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public OneWireContainer26(DSPortAdapter sourceAdapter, long newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public OneWireContainer26(DSPortAdapter sourceAdapter, String newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public Enumeration getMemoryBanks()
  {
    Vector bank_vector = new Vector(8);

    bank_vector.addElement(new MemoryBankSBM(this));

    MemoryBankSBM temp = new MemoryBankSBM(this);
    temp.bankDescription = "Temperature/Voltage/Current";
    temp.generalPurposeMemory = false;
    temp.startPhysicalAddress = 1;
    temp.size = 6;
    temp.readWrite = false;
    temp.readOnly = true;
    temp.nonVolatile = false;
    temp.powerDelivery = false;
    bank_vector.addElement(temp);

    temp = new MemoryBankSBM(this);
    temp.bankDescription = "Threshold";
    temp.generalPurposeMemory = false;
    temp.startPhysicalAddress = 7;
    temp.size = 1;
    temp.readWrite = true;
    temp.readOnly = false;
    temp.nonVolatile = true;
    temp.powerDelivery = true;
    bank_vector.addElement(temp);

    temp = new MemoryBankSBM(this);
    temp.bankDescription = "Elapsed Timer Meter";
    temp.generalPurposeMemory = false;
    temp.startPhysicalAddress = 8;
    temp.size = 5;
    temp.readWrite = true;
    temp.readOnly = false;
    temp.nonVolatile = false;
    temp.powerDelivery = true;
    bank_vector.addElement(temp);

    temp = new MemoryBankSBM(this);
    temp.bankDescription = "Current Offset";
    temp.generalPurposeMemory = false;
    temp.startPhysicalAddress = 13;
    temp.size = 2;
    temp.readWrite = true;
    temp.readOnly = false;
    temp.nonVolatile = true;
    temp.powerDelivery = true;
    bank_vector.addElement(temp);

    temp = new MemoryBankSBM(this);
    temp.bankDescription = "Disconnect / End of Charge";
    temp.generalPurposeMemory = false;
    temp.startPhysicalAddress = 16;
    temp.size = 8;
    temp.readWrite = true;
    temp.readOnly = false;
    temp.nonVolatile = false;
    temp.powerDelivery = true;
    bank_vector.addElement(temp);

    temp = new MemoryBankSBM(this);
    temp.bankDescription = "User Main Memory";
    temp.generalPurposeMemory = true;
    temp.startPhysicalAddress = 24;
    temp.size = 32;
    temp.readWrite = true;
    temp.readOnly = false;
    temp.nonVolatile = true;
    temp.powerDelivery = true;
    bank_vector.addElement(temp);

    temp = new MemoryBankSBM(this);
    temp.bankDescription = "User Memory / CCA / DCA";
    temp.generalPurposeMemory = false;
    temp.startPhysicalAddress = 56;
    temp.size = 8;
    temp.readWrite = true;
    temp.readOnly = false;
    temp.nonVolatile = true;
    temp.powerDelivery = true;
    bank_vector.addElement(temp);

    return bank_vector.elements();
  }

  public String getName()
  {
    return "DS2438";
  }

  public String getAlternateNames()
  {
    return "Smart Battery Monitor";
  }

  public String getDescription()
  {
    return "1-Wire device that integrates the total current charging or discharging through a battery and stores it in a register. It also returns the temperature (accurate to 2 degrees celcius), as well as the instantaneous current and voltage and also provides 40 bytes of EEPROM storage.";
  }

  public synchronized void setSenseResistor(double resistance)
  {
    this.Rsens = resistance;
  }

  public double getSenseResistor()
  {
    return this.Rsens;
  }

  public synchronized void setSpeedCheck(boolean doSpeedCheck)
  {
    this.doSpeedEnable = doSpeedCheck;
  }

  public byte[] readPage(int page)
    throws OneWireIOException, OneWireException, IllegalArgumentException
  {
    byte[] buffer = new byte[11];
    byte[] result = new byte[8];

    if ((page < 0) || (page > 7)) {
      throw new IllegalArgumentException("OneWireContainer26-Page " + page + " is an invalid page.");
    }

    if (this.doSpeedEnable) {
      doSpeed();
    }
    if (this.adapter.select(this.address))
    {
      buffer[0] = -72;
      buffer[1] = (byte)page;

      this.adapter.dataBlock(buffer, 0, 2);

      this.adapter.reset();
      this.adapter.select(this.address);

      buffer[0] = -66;
      buffer[1] = (byte)page;

      for (int i = 2; i < 11; i++) {
        buffer[i] = -1;
      }
      this.adapter.dataBlock(buffer, 0, 11);

      int crc8 = CRC8.compute(buffer, 2, 9);

      if (crc8 != 0) {
        throw new OneWireIOException("OneWireContainer26-Bad CRC during read." + crc8);
      }

      System.arraycopy(buffer, 2, result, 0, 8);
    }
    else {
      throw new OneWireException("OneWireContainer26-device not found.");
    }
    return result;
  }

  public void writePage(int page, byte[] source, int offset)
    throws OneWireIOException, OneWireException
  {
    byte[] buffer = new byte[10];

    if ((page < 0) || (page > 7)) {
      throw new IllegalArgumentException("OneWireContainer26-Page " + page + " is an invalid page.");
    }

    if (source.length < 8) {
      throw new IllegalArgumentException("OneWireContainer26-Invalid data page passed to writePage.");
    }

    if (this.doSpeedEnable) {
      doSpeed();
    }
    if (this.adapter.select(this.address))
    {
      buffer[0] = 78;
      buffer[1] = (byte)page;

      System.arraycopy(source, offset, buffer, 2, 8);
      this.adapter.dataBlock(buffer, 0, 10);

      this.adapter.reset();
      this.adapter.select(this.address);

      buffer[0] = 72;
      buffer[1] = (byte)page;

      this.adapter.dataBlock(buffer, 0, 2);
    }
    else {
      throw new OneWireException("OneWireContainer26-Device not found.");
    }
  }

  public boolean getFlag(byte flagToGet)
    throws OneWireIOException, OneWireException, IllegalArgumentException
  {
    byte[] data = readPage(0);

    return (data[0] & flagToGet) != 0;
  }

  public void setFlag(byte flagToSet, boolean flagValue)
    throws OneWireIOException, OneWireException, IllegalArgumentException
  {
    byte[] data = readPage(0);

    if (flagValue)
      data[0] = (byte)(data[0] | flagToSet);
    else {
      data[0] = (byte)(data[0] & (flagToSet ^ 0xFFFFFFFF));
    }
    writePage(0, data, 0);
  }

  public double getCurrent(byte[] state)
  {
    short rawCurrent = (short)(state[6] << 8 | state[5] & 0xFF);

    return rawCurrent / (4096.0D * this.Rsens);
  }

  public double getRemainingCapacity()
    throws OneWireIOException, OneWireException, IllegalArgumentException
  {
    int ica = getICA();

    return 1000 * ica / (2048.0D * this.Rsens);
  }

  public boolean isCharging(byte[] state)
    throws OneWireIOException, OneWireException, IllegalArgumentException
  {
    return getCurrent(state) > 0.0D;
  }

  public void calibrateCurrentADC()
    throws OneWireIOException, OneWireException, IllegalArgumentException
  {
    boolean IADvalue = getFlag(1);

    setFlag(1, false);

    byte[] data = readPage(1);
    int tmp25_24 = 0; data[6] = tmp25_24; data[5] = tmp25_24;

    writePage(1, data, 0);

    setFlag(1, true);

    data = readPage(0);
    byte currentLSB = data[5];
    byte currentMSB = data[6];

    setFlag(1, false);

    data = readPage(1);
    data[5] = (byte)((currentLSB ^ 0xFFFFFFFF) + 1);
    data[6] = (byte)(currentMSB ^ 0xFFFFFFFF);

    writePage(1, data, 0);

    setFlag(1, IADvalue);
  }

  public void setThreshold(byte thresholdValue)
    throws OneWireIOException, OneWireException
  {
    byte thresholdReg;
    switch (thresholdValue)
    {
    case 0:
      thresholdReg = 0;
      break;
    case 2:
      thresholdReg = 64;
      break;
    case 4:
      thresholdReg = -128;
      break;
    case 8:
      thresholdReg = -64;
      break;
    case 1:
    case 3:
    case 5:
    case 6:
    case 7:
    default:
      throw new IllegalArgumentException("OneWireContainer26-Threshold value must be 0,2,4, or 8.");
    }

    boolean IADvalue = getFlag(1);

    setFlag(1, false);

    byte[] data = readPage(0);
    data[7] = thresholdReg;

    writePage(0, data, 0);

    setFlag(1, IADvalue);
  }

  public int getICA()
    throws OneWireIOException, OneWireException, IllegalArgumentException
  {
    byte[] data = readPage(1);

    return data[4] & 0xFF;
  }

  public int getCCA()
    throws OneWireIOException, OneWireException, IllegalArgumentException
  {
    byte[] data = readPage(7);

    return data[5] << 8 & 0xFF00 | data[4] & 0xFF;
  }

  public int getDCA()
    throws OneWireIOException, OneWireException, IllegalArgumentException
  {
    byte[] data = readPage(7);

    return data[7] << 8 & 0xFF00 | data[6] & 0xFF;
  }

  public void setICA(int icaValue)
    throws OneWireIOException, OneWireException, IllegalArgumentException
  {
    byte[] data = readPage(1);

    data[4] = (byte)(icaValue & 0xFF);

    writePage(1, data, 0);
  }

  public void setCCA(int ccaValue)
    throws OneWireIOException, OneWireException, IllegalArgumentException
  {
    byte[] data = readPage(7);

    data[4] = (byte)(ccaValue & 0xFF);
    data[5] = (byte)((ccaValue & 0xFF00) >>> 8);

    writePage(7, data, 0);
  }

  public void setDCA(int dcaValue)
    throws OneWireIOException, OneWireException, IllegalArgumentException
  {
    byte[] data = readPage(7);

    data[6] = (byte)(dcaValue & 0xFF);
    data[7] = (byte)((dcaValue & 0xFF00) >>> 8);

    writePage(7, data, 0);
  }

  public long getDisconnectTime(byte[] state)
  {
    return getTime(state, 16) * 1000L;
  }

  public long getEndOfChargeTime(byte[] state)
  {
    return getTime(state, 20) * 1000L;
  }

  private long getTime(byte[] state, int start)
  {
    long time = state[start] & 0xFF | (state[(start + 1)] & 0xFF) << 8 | (state[(start + 2)] & 0xFF) << 16 | (state[(start + 3)] & 0xFF) << 24;

    return time & 0xFFFFFFFF;
  }

  public int getNumberADChannels()
  {
    return 3;
  }

  public boolean hasADAlarms()
  {
    return false;
  }

  public double[] getADRanges(int channel)
  {
    double[] result = new double[1];

    if (channel == 2)
      result[0] = 0.25D;
    else {
      result[0] = 10.23D;
    }

    return result;
  }

  public double[] getADResolutions(int channel, double range)
  {
    double[] result = new double[1];

    if (channel == 2)
      result[0] = 0.2441D;
    else {
      result[0] = 0.01D;
    }
    return result;
  }

  public boolean canADMultiChannelRead()
  {
    return false;
  }

  public void doADConvert(int channel, byte[] state)
    throws OneWireIOException, OneWireException
  {
    if (channel == 2)
    {
      if ((state[0] & 0x1) == 0)
      {
        setFlag(1, true);
        int tmp21_20 = 0;
        byte[] tmp21_19 = state; tmp21_19[tmp21_20] = (byte)(tmp21_19[tmp21_20] | 0x1);
        try
        {
          Thread.sleep(30L);
        }
        catch (InterruptedException e) {
        }
      }
      byte[] data = readPage(0);

      System.arraycopy(data, 5, state, 5, 2);
    }
    else
    {
      setFlag(8, channel == 0);

      if (this.doSpeedEnable) {
        doSpeed();
      }
      if (this.adapter.select(this.address))
      {
        this.adapter.putByte(-76);
        try
        {
          Thread.sleep(4L);
        }
        catch (InterruptedException e) {
        }
        byte[] data = readPage(0);

        System.arraycopy(data, 0, state, 0, 8);

        state[(24 + channel * 2)] = data[4];
        state[(24 + channel * 2 + 1)] = data[3];
      }
      else {
        throw new OneWireException("OneWireContainer26-Device not found.");
      }
    }
  }

  public void doADConvert(boolean[] doConvert, byte[] state)
    throws OneWireIOException, OneWireException
  {
    throw new OneWireException("This device cannot do multi-channel reads");
  }

  public double[] getADVoltage(byte[] state)
    throws OneWireIOException, OneWireException
  {
    throw new OneWireException("This device cannot do multi-channel reads");
  }

  public double getADVoltage(int channel, byte[] state)
    throws OneWireIOException, OneWireException
  {
    double result = 0.0D;

    if (channel == 2)
      result = (state[6] << 8 | state[5] & 0xFF) / 4096.0D;
    else {
      result = (state[(24 + channel * 2)] << 8 & 0x300 | state[(24 + channel * 2 + 1)] & 0xFF) / 100.0D;
    }

    return result;
  }

  public double getADAlarm(int channel, int alarmType, byte[] state)
    throws OneWireException
  {
    throw new OneWireException("This device does not have A/D alarms");
  }

  public boolean getADAlarmEnable(int channel, int alarmType, byte[] state)
    throws OneWireException
  {
    throw new OneWireException("This device does not have A/D alarms");
  }

  public boolean hasADAlarmed(int channel, int alarmType, byte[] state)
    throws OneWireException
  {
    throw new OneWireException("This device does not have A/D alarms");
  }

  public double getADResolution(int channel, byte[] state)
  {
    return 0.01D;
  }

  public double getADRange(int channel, byte[] state)
  {
    if (channel == 2) {
      return 0.25D;
    }
    return 10.23D;
  }

  public void setADAlarm(int channel, int alarmType, double alarm, byte[] state)
    throws OneWireException
  {
    throw new OneWireException("This device does not have A/D alarms");
  }

  public void setADAlarmEnable(int channel, int alarmType, boolean alarmEnable, byte[] state)
    throws OneWireException
  {
    throw new OneWireException("This device does not have AD alarms");
  }

  public void setADResolution(int channel, double resolution, byte[] state)
  {
  }

  public void setADRange(int channel, double range, byte[] state)
  {
  }

  public byte[] readDevice()
    throws OneWireIOException, OneWireException
  {
    byte[] state = new byte[28];

    for (int i = 0; i < 3; i++)
    {
      byte[] pg = readPage(i);

      System.arraycopy(pg, 0, state, i * 8, 8);
    }

    return state;
  }

  public void writeDevice(byte[] state)
    throws OneWireIOException, OneWireException
  {
    writePage(0, state, 0);
    writePage(1, state, 8);
  }

  public boolean hasTemperatureAlarms()
  {
    return false;
  }

  public boolean hasSelectableTemperatureResolution()
  {
    return false;
  }

  public double[] getTemperatureResolutions()
  {
    double[] result = new double[1];

    result[0] = 0.03125D;

    return result;
  }

  public double getTemperatureAlarmResolution()
    throws OneWireException
  {
    throw new OneWireException("This device does not have temperature alarms");
  }

  public double getMaxTemperature()
  {
    return 125.0D;
  }

  public double getMinTemperature()
  {
    return -55.0D;
  }

  public void doTemperatureConvert(byte[] state)
    throws OneWireIOException, OneWireException
  {
    if (this.doSpeedEnable) {
      doSpeed();
    }
    if (this.adapter.select(this.address))
    {
      this.adapter.putByte(68);
      try
      {
        Thread.sleep(10L);
      }
      catch (InterruptedException Ie) {
      }
      byte[] data = readPage(0);
      state[2] = data[2];
      state[1] = data[1];
    }
    else {
      throw new OneWireException("OneWireContainer26-Device not found.");
    }
  }

  public double getTemperature(byte[] state)
  {
    double temp = ((short)(state[2] << 8 | state[1] & 0xFF) >> 3) * 0.03125D;

    return temp;
  }

  public double getTemperatureAlarm(int alarmType, byte[] state)
    throws OneWireException
  {
    throw new OneWireException("This device does not have temperature alarms");
  }

  public double getTemperatureResolution(byte[] state)
  {
    return 0.03125D;
  }

  public void setTemperatureAlarm(int alarmType, double alarmValue, byte[] state)
    throws OneWireException, OneWireIOException
  {
    throw new OneWireException("This device does not have temperature alarms");
  }

  public void setTemperatureResolution(double resolution, byte[] state)
    throws OneWireException, OneWireIOException
  {
  }

  public boolean hasClockAlarm()
  {
    return false;
  }

  public boolean canDisableClock()
  {
    return false;
  }

  public long getClockResolution()
  {
    return 1000L;
  }

  public long getClock(byte[] state)
  {
    return getTime(state, 8) * 1000L;
  }

  public long getClockAlarm(byte[] state)
    throws OneWireException
  {
    throw new OneWireException("This device does not have a clock alarm!");
  }

  public boolean isClockAlarming(byte[] state)
  {
    return false;
  }

  public boolean isClockAlarmEnabled(byte[] state)
  {
    return false;
  }

  public boolean isClockRunning(byte[] state)
  {
    return true;
  }

  public void setClock(long time, byte[] state)
  {
    time /= 1000L;
    state[8] = (byte)(int)time;
    state[9] = (byte)(int)(time >> 8);
    state[10] = (byte)(int)(time >> 16);
    state[11] = (byte)(int)(time >> 24);
  }

  public void setClockAlarm(long time, byte[] state)
    throws OneWireException
  {
    throw new OneWireException("This device does not have a clock alarm!");
  }

  public void setClockRunEnable(boolean runEnable, byte[] state)
    throws OneWireException
  {
    if (!runEnable)
      throw new OneWireException("This device's clock cannot be disabled!");
  }

  public void setClockAlarmEnable(boolean alarmEnable, byte[] state)
    throws OneWireException
  {
    throw new OneWireException("This device does not have a clock alarm!");
  }

  public boolean isRelative()
  {
    return true;
  }

  public boolean hasHumidityAlarms()
  {
    return false;
  }

  public boolean hasSelectableHumidityResolution()
  {
    return false;
  }

  public double[] getHumidityResolutions()
  {
    double[] result = new double[1];

    result[0] = 0.1D;

    return result;
  }

  public double getHumidityAlarmResolution()
    throws OneWireException
  {
    throw new OneWireException("This device does not have a humidity alarm!");
  }

  public void doHumidityConvert(byte[] state)
    throws OneWireIOException, OneWireException
  {
    doTemperatureConvert(state);

    doADConvert(0, state);

    doADConvert(1, state);
  }

  public double getHumidity(byte[] state)
  {
    double temp = 0.0D; double vdd = 0.0D; double vad = 0.0D; double rh = 0.0D;
    try
    {
      temp = getTemperature(state);

      vdd = getADVoltage(0, state);

      vad = getADVoltage(1, state);
    }
    catch (OneWireException e)
    {
      return 0.0D;
    }

    if (vdd != 0.0D) {
      rh = (vad / vdd - 0.16D) / 0.0062D / (1.0546D - 0.00216D * temp);
    }
    if (rh < 0.0D)
      rh = 0.0D;
    else if (rh > 100.0D) {
      rh = 100.0D;
    }
    return rh;
  }

  public double getHumidityResolution(byte[] state)
  {
    return 0.1D;
  }

  public double getHumidityAlarm(int alarmType, byte[] state)
    throws OneWireException
  {
    throw new OneWireException("This device does not have a humidity alarm!");
  }

  public void setHumidityAlarm(int alarmType, double alarmValue, byte[] state)
    throws OneWireException
  {
    throw new OneWireException("This device does not have a humidity alarm!");
  }

  public void setHumidityResolution(double resolution, byte[] state)
    throws OneWireException
  {
    throw new OneWireException("This device does not have selectable humidity resolution!");
  }
}