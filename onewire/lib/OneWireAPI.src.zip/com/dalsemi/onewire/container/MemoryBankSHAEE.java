package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import com.dalsemi.onewire.utils.CRC16;

public class MemoryBankSHAEE
  implements PagedMemoryBank
{
  private static final boolean DEBUG = false;
  public static final byte READ_MEMORY = -16;
  public static final byte READ_AUTH_PAGE = -91;
  protected boolean checked;
  protected int size;
  protected String bankDescription;
  protected boolean generalPurposeMemory;
  protected boolean readWrite;
  protected boolean writeOnce;
  protected boolean readOnly;
  protected int startPhysicalAddress;
  protected boolean writeVerification;
  protected int numberPages;
  protected int pageLength;
  protected boolean extraInfo;
  protected int extraInfoLength;
  protected int maxPacketDataLength;
  protected boolean pageCRC;
  protected OneWireContainer33 ib = null;

  protected DSPortAdapter adapter = null;
  protected boolean doSetSpeed;
  protected static final byte[] ffBlock = OneWireContainer33.ffBlock;

  protected static final byte[] zeroBlock = OneWireContainer33.zeroBlock;
  protected MemoryBankScratchSHAEE scratchpad;

  public MemoryBankSHAEE(OneWireContainer33 ibutton, MemoryBankScratchSHAEE scratch)
  {
    this.ib = ibutton;

    this.scratchpad = scratch;

    this.adapter = this.ib.getAdapter();

    this.doSetSpeed = true;
  }

  public String getBankDescription()
  {
    return this.bankDescription;
  }

  public boolean isGeneralPurposeMemory()
  {
    return this.generalPurposeMemory;
  }

  public boolean isReadWrite()
  {
    return this.readWrite;
  }

  public boolean isWriteOnce()
  {
    return this.writeOnce;
  }

  public boolean isReadOnly()
  {
    return this.readOnly;
  }

  public boolean isNonVolatile()
  {
    return true;
  }

  public boolean needsProgramPulse()
  {
    return false;
  }

  public boolean needsPowerDelivery()
  {
    return true;
  }

  public int getStartPhysicalAddress()
  {
    return this.startPhysicalAddress;
  }

  public int getSize()
  {
    return this.size;
  }

  public void setWriteVerification(boolean doReadVerf)
  {
    this.writeVerification = doReadVerf;
  }

  public int getNumberPages()
  {
    return this.numberPages;
  }

  public int getPageLength()
  {
    return this.pageLength;
  }

  public boolean hasPageAutoCRC()
  {
    return this.pageCRC;
  }

  /** @deprecated */
  public boolean haveExtraInfo()
  {
    return this.extraInfo;
  }

  public boolean hasExtraInfo()
  {
    return this.extraInfo;
  }

  public int getExtraInfoLength()
  {
    return this.extraInfoLength;
  }

  public String getExtraInfoDescription()
  {
    return "The MAC for the SHA Engine";
  }

  public int getMaxPacketDataLength()
  {
    return this.maxPacketDataLength;
  }

  public void read(int startAddr, boolean readContinue, byte[] readBuf, int offset, int len)
    throws OneWireIOException, OneWireException
  {
    if ((!readContinue) && (this.ib.adapterSet())) {
      checkSpeed();
    }

    if (startAddr + len > this.pageLength * this.numberPages) {
      throw new OneWireException("Read exceeds memory bank end.");
    }

    if (!readContinue)
    {
      if (!this.adapter.select(this.ib.getAddress())) {
        throw new OneWireIOException("Device select failed.");
      }

      int addr = startAddr + this.startPhysicalAddress;
      byte[] raw_buf = new byte[3];

      raw_buf[0] = -16;
      raw_buf[1] = (byte)(addr & 0xFF);
      raw_buf[2] = (byte)((addr & 0xFFFF) >>> 8 & 0xFF);

      this.adapter.dataBlock(raw_buf, 0, 3);
    }

    int pgs = len / this.pageLength;
    int extra = len % this.pageLength;

    for (int i = 0; i < pgs; i++) {
      System.arraycopy(ffBlock, 0, readBuf, offset + i * this.pageLength, this.pageLength);
    }
    System.arraycopy(ffBlock, 0, readBuf, offset + pgs * this.pageLength, extra);

    this.adapter.dataBlock(readBuf, offset, len);
  }

  public void write(int startAddr, byte[] writeBuf, int offset, int len)
    throws OneWireIOException, OneWireException
  {
    if (!this.checked) {
      this.checked = this.ib.checkStatus();
    }

    if (len == 0) {
      return;
    }

    checkSpeed();

    if (!this.ib.isContainerSecretSet()) {
      throw new OneWireException("Secret is not set.");
    }

    if (startAddr + len > this.size) {
      throw new OneWireException("Write exceeds memory bank end");
    }

    if (isReadOnly()) {
      throw new OneWireException("Trying to write read-only memory bank");
    }

    int startx = 0; int nextx = 0;
    byte[] raw_buf = new byte[8];
    byte[] memory = new byte[this.size - (startAddr & 0xE0)];
    int abs_addr = this.startPhysicalAddress + startAddr;
    int pl = 8;

    read(startAddr & 0xE0, false, memory, 0, memory.length);

    if (abs_addr >= 128)
    {
      this.ib.getContainerSecret(memory, 0);
    }

    do
    {
      int room_left = pl - (abs_addr + startx) % pl;

      if (len - startx > room_left)
        nextx = startx + room_left;
      else {
        nextx = len;
      }

      if (startx + startAddr >= this.pageLength)
        System.arraycopy(memory, (startx + startAddr) / 8 * 8 - 32, raw_buf, 0, 8);
      else {
        System.arraycopy(memory, (startx + startAddr) / 8 * 8, raw_buf, 0, 8);
      }
      if (nextx - startx == 8) {
        System.arraycopy(writeBuf, offset + startx, raw_buf, 0, 8);
      }
      else if ((startAddr + nextx) % 8 == 0)
        System.arraycopy(writeBuf, offset + startx, raw_buf, (startAddr + startx) % 8, 8 - (startAddr + startx) % 8);
      else {
        System.arraycopy(writeBuf, offset + startx, raw_buf, (startAddr + startx) % 8, (startAddr + nextx) % 8 - (startAddr + startx) % 8);
      }

      this.scratchpad.writeScratchpad(abs_addr + startx + room_left - 8, raw_buf, 0, 8);

      this.scratchpad.copyScratchpad(abs_addr + startx + room_left - 8, raw_buf, 0, memory, 0);

      if (startx + startAddr >= this.pageLength)
        System.arraycopy(raw_buf, 0, memory, (startx + startAddr) / 8 * 8 - 32, 8);
      else {
        System.arraycopy(raw_buf, 0, memory, (startx + startAddr) / 8 * 8, 8);
      }

      startx = nextx;
    }
    while (nextx < len);
  }

  public void readPage(int page, boolean readContinue, byte[] readBuf, int offset)
    throws OneWireIOException, OneWireException
  {
    read(page * this.pageLength, readContinue, readBuf, offset, this.pageLength);
  }

  public void readPage(int page, boolean readContinue, byte[] readBuf, int offset, byte[] extraInfo)
    throws OneWireIOException, OneWireException
  {
    byte[] pg = new byte[32];

    if (!this.checked) {
      this.checked = this.ib.checkStatus();
    }
    if (!hasPageAutoCRC()) {
      throw new OneWireException("This memory bank doesn't have crc capabilities.");
    }

    if (!readContinue) {
      checkSpeed();
    }
    if (!readAuthenticatedPage(page, pg, 0, extraInfo, 0)) {
      throw new OneWireException("Read didn't work.");
    }
    System.arraycopy(pg, 0, readBuf, offset, 32);
  }

  public int readPagePacket(int page, boolean readContinue, byte[] readBuf, int offset)
    throws OneWireIOException, OneWireException
  {
    byte[] raw_buf = new byte[this.pageLength];

    readPage(page, readContinue, raw_buf, 0);

    if ((raw_buf[0] & 0xFF) > this.maxPacketDataLength) {
      throw new OneWireIOException("Invalid length in packet.");
    }

    if (CRC16.compute(raw_buf, 0, raw_buf[0] + 3, page) == 45057)
    {
      System.arraycopy(raw_buf, 1, readBuf, offset, raw_buf[0]);

      return raw_buf[0];
    }

    throw new OneWireIOException("Invalid CRC16 in packet read.");
  }

  public int readPagePacket(int page, boolean readContinue, byte[] readBuf, int offset, byte[] extraInfo)
    throws OneWireIOException, OneWireException
  {
    byte[] raw_buf = new byte[this.pageLength];

    if (!this.checked) {
      this.checked = this.ib.checkStatus();
    }
    if (!hasPageAutoCRC()) {
      throw new OneWireException("This memory bank page doesn't have CRC capabilites.");
    }

    readAuthenticatedPage(page, raw_buf, 0, extraInfo, 0);

    if ((raw_buf[0] & 0xFF) > this.maxPacketDataLength) {
      throw new OneWireIOException("Invalid length in packet.");
    }

    if (CRC16.compute(raw_buf, 0, raw_buf[0] + 3, page) == 45057)
    {
      System.arraycopy(raw_buf, 1, readBuf, offset, raw_buf[0]);

      return raw_buf[0];
    }

    throw new OneWireIOException("Invalid CRC16 in packet read.");
  }

  public void writePagePacket(int page, byte[] writeBuf, int offset, int len)
    throws OneWireIOException, OneWireException
  {
    if (len > this.maxPacketDataLength) {
      throw new OneWireIOException("Length of packet requested exceeds page size.");
    }

    if (!this.generalPurposeMemory) {
      throw new OneWireException("Current bank is not general purpose memory.");
    }

    byte[] raw_buf = new byte[len + 3];

    raw_buf[0] = (byte)len;

    System.arraycopy(writeBuf, offset, raw_buf, 1, len);

    int crc = CRC16.compute(raw_buf, 0, len + 1, page);

    raw_buf[(len + 1)] = (byte)((crc ^ 0xFFFFFFFF) & 0xFF);
    raw_buf[(len + 2)] = (byte)(((crc ^ 0xFFFFFFFF) & 0xFFFF) >>> 8 & 0xFF);

    write(page * this.pageLength, raw_buf, 0, len + 3);
  }

  public void readPageCRC(int page, boolean readContinue, byte[] readBuf, int offset)
    throws OneWireIOException, OneWireException
  {
    byte[] extra = new byte[20];
    byte[] pg = new byte[32];

    if (!this.checked) {
      this.checked = this.ib.checkStatus();
    }
    if (!hasPageAutoCRC()) {
      throw new OneWireException("This memory bank doesn't have CRC capabilites.");
    }
    if (!readAuthenticatedPage(page, pg, 0, extra, 0)) {
      throw new OneWireException("Read didn't work.");
    }
    System.arraycopy(pg, 0, readBuf, offset, this.pageLength);
  }

  public void readPageCRC(int page, boolean readContinue, byte[] readBuf, int offset, byte[] extraInfo)
    throws OneWireIOException, OneWireException
  {
    byte[] pg = new byte[32];

    if (!this.checked) {
      this.checked = this.ib.checkStatus();
    }
    if (!hasPageAutoCRC()) {
      throw new OneWireException("This memory bank doesn't have CRC capabilities.");
    }
    if (!readAuthenticatedPage(page, pg, 0, extraInfo, 0)) {
      throw new OneWireException("Read didn't work.");
    }
    System.arraycopy(pg, 0, readBuf, offset, this.pageLength);
  }

  public void writeprotect()
  {
    this.readOnly = true;
    this.readWrite = false;
  }

  public void setEPROM()
  {
    this.writeOnce = true;
  }

  public void checkSpeed()
    throws OneWireIOException, OneWireException
  {
    synchronized (this)
    {
      if (this.doSetSpeed)
      {
        this.ib.doSpeed();

        this.doSetSpeed = false;
      }
    }
  }

  public boolean readAuthenticatedPage(int page, byte[] data, int dataStart, byte[] extra_info, int extraStart)
    throws OneWireException, OneWireIOException
  {
    byte[] send_block = new byte[40];
    byte[] challenge = new byte[8];

    int addr = page * this.pageLength + this.startPhysicalAddress;

    this.ib.getChallenge(challenge, 4);
    this.scratchpad.writeScratchpad(addr, challenge, 0, 8);

    if (!this.adapter.select(this.ib.getAddress())) {
      throw new OneWireIOException("Device select failed.");
    }

    send_block[0] = -91;

    send_block[1] = (byte)(addr & 0xFF);

    send_block[2] = (byte)((addr & 0xFFFF) >>> 8 & 0xFF);

    System.arraycopy(ffBlock, 0, send_block, 3, 35);

    this.adapter.dataBlock(send_block, 0, 38);

    if (CRC16.compute(send_block, 0, 38, 0) != 45057)
    {
      throw new OneWireException("First CRC didn't pass.");
    }

    System.arraycopy(send_block, 3, data, dataStart, 32);

    System.arraycopy(ffBlock, 0, send_block, 0, 22);
    try
    {
      Thread.sleep(2L);
    }
    catch (InterruptedException ie)
    {
    }
    this.adapter.dataBlock(send_block, 0, 22);

    if (CRC16.compute(send_block, 0, 22, 0) != 45057)
    {
      throw new OneWireException("Second CRC didn't pass.");
    }

    System.arraycopy(send_block, 0, extra_info, extraStart, 20);
    return true;
  }

  public void forceVerify()
  {
    synchronized (this)
    {
      this.doSetSpeed = true;
    }
  }
}