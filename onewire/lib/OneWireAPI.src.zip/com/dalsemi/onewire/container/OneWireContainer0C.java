package com.dalsemi.onewire.container;

import com.dalsemi.onewire.adapter.DSPortAdapter;
import java.util.Enumeration;
import java.util.Vector;

public class OneWireContainer0C extends OneWireContainer
{
  public OneWireContainer0C()
  {
  }

  public OneWireContainer0C(DSPortAdapter sourceAdapter, byte[] newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public OneWireContainer0C(DSPortAdapter sourceAdapter, long newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public OneWireContainer0C(DSPortAdapter sourceAdapter, String newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public String getName()
  {
    return "DS1996";
  }

  public String getDescription()
  {
    return "65536 bit read/write nonvolatile memory partitioned into two-hundred fifty-six pages of 256 bits each.";
  }

  public int getMaxSpeed()
  {
    return 2;
  }

  public Enumeration getMemoryBanks()
  {
    Vector bank_vector = new Vector(2);

    MemoryBankScratch scratch = new MemoryBankScratch(this);

    bank_vector.addElement(scratch);

    MemoryBankNV nv = new MemoryBankNV(this, scratch);

    nv.numberPages = 256;
    nv.size = 8192;

    bank_vector.addElement(nv);

    return bank_vector.elements();
  }
}