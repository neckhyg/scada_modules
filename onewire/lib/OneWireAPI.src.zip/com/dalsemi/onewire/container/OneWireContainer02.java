package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;

public class OneWireContainer02 extends OneWireContainer
{
  private static final byte WRITE_SCRATCHPAD_COMMAND = -106;
  private static final byte READ_SCRATCHPAD_COMMAND = 105;
  private static final byte COPY_SCRATCHPAD_COMMAND = 60;
  private static final byte WRITE_PASSWORD_COMMAND = 90;
  private static final byte WRITE_SUBKEY_COMMAND = -103;
  private static final byte READ_SUBKEY_COMMAND = 102;
  private static byte[][] blockCodes = null;

  private byte[] buffer = new byte[82];

  public OneWireContainer02()
  {
  }

  public OneWireContainer02(DSPortAdapter sourceAdapter, byte[] newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public OneWireContainer02(DSPortAdapter sourceAdapter, long newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public OneWireContainer02(DSPortAdapter sourceAdapter, String newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public String getName()
  {
    return "DS1991";
  }

  public String getAlternateNames()
  {
    return "DS1425";
  }

  public String getDescription()
  {
    return "2048 bits of nonvolatile read/write memory organized as three secure keys of 384 bits each and a 512 bit scratch pad. Each key has its own 64 bit password and 64 bit ID field.  Secure memory cannot be deciphered without matching 64 bit password.";
  }

  public void writeScratchpad(int addr, byte[] data)
    throws OneWireIOException, OneWireException, IllegalArgumentException
  {
    if (addr > 63) {
      throw new IllegalArgumentException("Address out of range: 0x00 to 0x3F");
    }

    int dataRoom = 63 - addr + 1;

    if (dataRoom < data.length) {
      throw new IllegalArgumentException("Data is too long for scratchpad.");
    }

    this.buffer[0] = -106;
    this.buffer[1] = (byte)(addr | 0xC0);
    this.buffer[2] = (byte)(this.buffer[1] ^ 0xFFFFFFFF);

    System.arraycopy(data, 0, this.buffer, 3, data.length);

    if (this.adapter.select(this.address))
    {
      this.adapter.dataBlock(this.buffer, 0, 3 + data.length);
    }
    else
    {
      throw new OneWireIOException("MultiKey iButton " + getAddressAsString() + " not found on 1-Wire Network");
    }
  }

  public byte[] readScratchpad()
    throws OneWireIOException, OneWireException
  {
    this.buffer[0] = 105;
    this.buffer[1] = -64;
    this.buffer[2] = 63;

    for (int i = 3; i < 67; i++) {
      this.buffer[i] = -1;
    }

    if (this.adapter.select(this.address))
    {
      this.adapter.dataBlock(this.buffer, 0, 67);

      byte[] retData = new byte[64];

      System.arraycopy(this.buffer, 3, retData, 0, 64);

      return retData;
    }

    throw new OneWireIOException("MultiKey iButton " + getAddressAsString() + " not found on 1-Wire Network");
  }

  public void copyScratchpad(int key, byte[] passwd, int blockNum)
    throws OneWireIOException, OneWireException, IllegalArgumentException
  {
    if ((key < 0) || (key > 2)) {
      throw new IllegalArgumentException("Key out of range: 0 to 2.");
    }
    if (passwd.length != 8) {
      throw new IllegalArgumentException("Password must contain exactly 8 characters");
    }

    if ((blockNum < 0) || (blockNum > 8)) {
      throw new IllegalArgumentException("Block id out of range: 0 to 8.");
    }
    this.buffer[0] = 60;
    this.buffer[1] = (byte)(key << 6);
    this.buffer[2] = (byte)(this.buffer[1] ^ 0xFFFFFFFF);

    System.arraycopy(blockCodes[blockNum], 0, this.buffer, 3, 8);

    System.arraycopy(passwd, 0, this.buffer, 11, 8);

    if (this.adapter.select(this.address))
    {
      this.adapter.dataBlock(this.buffer, 0, 19);
    }
    else
    {
      throw new OneWireIOException("MultiKey iButton " + getAddressAsString() + " not found on 1-Wire Network");
    }
  }

  public byte[] readSubkey(int key, byte[] passwd)
    throws OneWireIOException, OneWireException, IllegalArgumentException
  {
    byte[] retData = new byte[64];

    readSubkey(retData, key, passwd);

    return retData;
  }

  public void readSubkey(byte[] data, int key, byte[] passwd)
    throws OneWireIOException, OneWireException, IllegalArgumentException
  {
    if (key > 3) {
      throw new IllegalArgumentException("Key out of range: 0 to 2.");
    }
    if (passwd.length != 8) {
      throw new IllegalArgumentException("Password must contain exactly 8 characters.");
    }

    if (data.length != 64) {
      throw new IllegalArgumentException("Data must be size 64.");
    }
    this.buffer[0] = 102;
    this.buffer[1] = (byte)(key << 6 | 0x10);
    this.buffer[2] = (byte)(this.buffer[1] ^ 0xFFFFFFFF);

    for (int i = 3; i < 67; i++) {
      this.buffer[i] = -1;
    }

    System.arraycopy(passwd, 0, this.buffer, 11, 8);

    if (this.adapter.select(this.address))
    {
      this.adapter.dataBlock(this.buffer, 0, 67);
      this.adapter.reset();

      System.arraycopy(this.buffer, 3, data, 0, 64);
    }
    else
    {
      throw new OneWireIOException("MultiKey iButton " + getAddressAsString() + " not found on 1-Wire Network");
    }
  }

  public void writePassword(int key, byte[] oldName, byte[] newName, byte[] newPasswd)
    throws OneWireIOException, OneWireException, IllegalArgumentException
  {
    if (key > 3) {
      throw new IllegalArgumentException("Key value out of range: 0 to 2.");
    }

    if (newPasswd.length != 8) {
      throw new IllegalArgumentException("Password must contain exactly 8 characters.");
    }

    if (oldName.length != 8) {
      throw new IllegalArgumentException("Old name must contain exactly 8 characters.");
    }

    if (newName.length != 8) {
      throw new IllegalArgumentException("New name must contain exactly 8 characters.");
    }

    this.buffer[0] = 90;
    this.buffer[1] = (byte)(key << 6);
    this.buffer[2] = (byte)(this.buffer[1] ^ 0xFFFFFFFF);

    for (int i = 3; i < 11; i++) {
      this.buffer[i] = -1;
    }

    System.arraycopy(oldName, 0, this.buffer, 11, 8);

    System.arraycopy(newName, 0, this.buffer, 19, 8);

    System.arraycopy(newPasswd, 0, this.buffer, 27, 8);

    if (this.adapter.select(this.address))
    {
      this.adapter.dataBlock(this.buffer, 0, 35);
      this.adapter.reset();
    }
    else
    {
      throw new OneWireIOException("MultiKey iButton " + getAddressAsString() + " not found on 1-Wire Network");
    }
  }

  public void writeSubkey(int key, int addr, byte[] passwd, byte[] data)
    throws OneWireIOException, OneWireException, IllegalArgumentException
  {
    if (key > 3) {
      throw new IllegalArgumentException("Key out of range: 0 to 2.");
    }
    if ((addr < 0) || (addr > 63)) {
      throw new IllegalArgumentException("Address must be between 0x00 and 0x3F");
    }

    if (passwd.length != 8) {
      throw new IllegalArgumentException("Password must contain exactly 8 characters.");
    }

    if (data.length > 63 - addr + 1) {
      throw new IllegalArgumentException("Data length out of bounds.");
    }
    this.buffer[0] = -103;
    this.buffer[1] = (byte)(key << 6 | addr);
    this.buffer[2] = (byte)(this.buffer[1] ^ 0xFFFFFFFF);

    for (int i = 3; i < 11; i++) {
      this.buffer[i] = -1;
    }

    System.arraycopy(passwd, 0, this.buffer, 11, 8);

    System.arraycopy(data, 0, this.buffer, 19, data.length);

    if (this.adapter.select(this.address))
    {
      this.adapter.dataBlock(this.buffer, 0, 19 + data.length);
      this.adapter.reset();
    }
    else
    {
      throw new OneWireIOException("MultiKey iButton " + getAddressAsString() + " not found on 1-Wire Network");
    }
  }

  private static void initBlockCodes(byte[][] codes)
  {
    codes[8][0] = 86;
    codes[8][1] = 86;
    codes[8][2] = 127;
    codes[8][3] = 81;
    codes[8][4] = 87;
    codes[8][5] = 93;
    codes[8][6] = 90;
    codes[8][7] = 127;
    codes[0][0] = -102;
    codes[0][1] = -102;
    codes[0][2] = -77;
    codes[0][3] = -99;
    codes[0][4] = 100;
    codes[0][5] = 110;
    codes[0][6] = 105;
    codes[0][7] = 76;
    codes[1][0] = -102;
    codes[1][1] = -102;
    codes[1][2] = 76;
    codes[1][3] = 98;
    codes[1][4] = -101;
    codes[1][5] = -111;
    codes[1][6] = 105;
    codes[1][7] = 76;
    codes[2][0] = -102;
    codes[2][1] = 101;
    codes[2][2] = -77;
    codes[2][3] = 98;
    codes[2][4] = -101;
    codes[2][5] = 110;
    codes[2][6] = -106;
    codes[2][7] = 76;
    codes[3][0] = 106;
    codes[3][1] = 106;
    codes[3][2] = 67;
    codes[3][3] = 109;
    codes[3][4] = 107;
    codes[3][5] = 97;
    codes[3][6] = 102;
    codes[3][7] = 67;
    codes[4][0] = -107;
    codes[4][1] = -107;
    codes[4][2] = -68;
    codes[4][3] = -110;
    codes[4][4] = -108;
    codes[4][5] = -98;
    codes[4][6] = -103;
    codes[4][7] = -68;
    codes[5][0] = 101;
    codes[5][1] = -102;
    codes[5][2] = 76;
    codes[5][3] = -99;
    codes[5][4] = 100;
    codes[5][5] = -111;
    codes[5][6] = 105;
    codes[5][7] = -77;
    codes[6][0] = 101;
    codes[6][1] = 101;
    codes[6][2] = -77;
    codes[6][3] = -99;
    codes[6][4] = 100;
    codes[6][5] = 110;
    codes[6][6] = -106;
    codes[6][7] = -77;
    codes[7][0] = 101;
    codes[7][1] = 101;
    codes[7][2] = 76;
    codes[7][3] = 98;
    codes[7][4] = -101;
    codes[7][5] = -111;
    codes[7][6] = -106;
    codes[7][7] = -77;
  }

  static
  {
    blockCodes = new byte[9][8];

    initBlockCodes(blockCodes);
  }
}