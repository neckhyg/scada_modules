package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import com.dalsemi.onewire.utils.CRC16;

class MemoryBankAppReg
  implements OTPMemoryBank
{
  public static final int PAGE_SIZE = 8;
  public static final byte READ_MEMORY_COMMAND = -61;
  public static final byte WRITE_MEMORY_COMMAND = -103;
  public static final byte COPY_LOCK_COMMAND = 90;
  public static final byte READ_STATUS_COMMAND = 102;
  public static final byte VALIDATION_KEY = -91;
  public static final byte LOCKED_FLAG = -4;
  protected OneWireContainer ib;
  protected byte[] ffBlock;
  protected int size;
  protected static String bankDescription = "Application register, non-volatile when locked";
  protected boolean writeVerification;
  protected int extraInfoLength;
  protected static String extraInfoDescription = "Page Locked flag";

  public MemoryBankAppReg(OneWireContainer ibutton)
  {
    this.ib = ibutton;

    this.writeVerification = true;

    this.ffBlock = new byte[50];

    for (int i = 0; i < 50; i++)
      this.ffBlock[i] = -1;
  }

  public String getBankDescription()
  {
    return bankDescription;
  }

  public boolean isGeneralPurposeMemory()
  {
    return true;
  }

  public boolean isReadWrite()
  {
    return true;
  }

  public boolean isWriteOnce()
  {
    return false;
  }

  public boolean isReadOnly()
  {
    return false;
  }

  public boolean isNonVolatile()
  {
    return false;
  }

  public boolean needsProgramPulse()
  {
    return false;
  }

  public boolean needsPowerDelivery()
  {
    return true;
  }

  public int getStartPhysicalAddress()
  {
    return 0;
  }

  public int getSize()
  {
    return 8;
  }

  public int getNumberPages()
  {
    return 1;
  }

  public int getPageLength()
  {
    return 8;
  }

  public int getMaxPacketDataLength()
  {
    return 6;
  }

  public boolean hasPageAutoCRC()
  {
    return false;
  }

  /** @deprecated */
  public boolean haveExtraInfo()
  {
    return true;
  }

  public boolean hasExtraInfo()
  {
    return true;
  }

  public int getExtraInfoLength()
  {
    return 1;
  }

  public String getExtraInfoDescription()
  {
    return extraInfoDescription;
  }

  public void setWriteVerification(boolean doReadVerf)
  {
    this.writeVerification = doReadVerf;
  }

  public boolean canRedirectPage()
  {
    return false;
  }

  public boolean canLockPage()
  {
    return true;
  }

  public boolean canLockRedirectPage()
  {
    return false;
  }

  public void read(int startAddr, boolean readContinue, byte[] readBuf, int offset, int len)
    throws OneWireIOException, OneWireException
  {
    if (startAddr + len > 8) {
      throw new OneWireException("Read exceeds memory bank end");
    }

    this.ib.doSpeed();

    if (!this.ib.adapter.select(this.ib.address)) {
      throw new OneWireIOException("Device select failed");
    }

    this.ib.adapter.putByte(-61);
    this.ib.adapter.putByte(startAddr & 0xFF);

    System.arraycopy(this.ffBlock, 0, readBuf, offset, len);

    this.ib.adapter.dataBlock(readBuf, offset, len);
  }

  public void write(int startAddr, byte[] writeBuf, int offset, int len)
    throws OneWireIOException, OneWireException
  {
    if (len == 0) {
      return;
    }

    if (!this.ib.adapter.canDeliverPower()) {
      throw new OneWireException("Power delivery required but not available");
    }

    if (startAddr + len > 8) {
      throw new OneWireException("Write exceeds memory bank end");
    }

    this.ib.doSpeed();

    if (!this.ib.adapter.select(this.ib.address)) {
      throw new OneWireIOException("Device select failed");
    }

    this.ib.adapter.putByte(-103);
    this.ib.adapter.putByte(startAddr & 0xFF);

    this.ib.adapter.dataBlock(writeBuf, offset, len);

    if (this.writeVerification)
    {
      byte[] read_buf = new byte[len];

      read(startAddr, true, read_buf, 0, len);

      for (int i = 0; i < len; i++)
      {
        if (read_buf[i] != writeBuf[(i + offset)])
          throw new OneWireIOException("Read back from write compare is incorrect, page may be locked");
      }
    }
  }

  public void readPage(int page, boolean readContinue, byte[] readBuf, int offset)
    throws OneWireIOException, OneWireException
  {
    if (page != 0) {
      throw new OneWireException("Invalid page number for this memory bank");
    }

    read(0, true, readBuf, offset, 8);
  }

  public void readPage(int page, boolean readContinue, byte[] readBuf, int offset, byte[] extraInfo)
    throws OneWireIOException, OneWireException
  {
    read(page, true, readBuf, offset, 8);

    readStatus(extraInfo);
  }

  public int readPagePacket(int page, boolean readContinue, byte[] readBuf, int offset, byte[] extraInfo)
    throws OneWireIOException, OneWireException
  {
    byte[] raw_buf = new byte[8];

    read(page, true, raw_buf, 0, 8);

    if (raw_buf[0] > 6) {
      throw new OneWireIOException("Invalid length in packet");
    }

    if (CRC16.compute(raw_buf, 0, raw_buf[0] + 3, page) == 45057)
    {
      System.arraycopy(raw_buf, 1, readBuf, offset, raw_buf[0]);

      readStatus(extraInfo);

      return raw_buf[0];
    }

    throw new OneWireIOException("Invalid CRC16 in packet read");
  }

  public int readPagePacket(int page, boolean readContinue, byte[] readBuf, int offset)
    throws OneWireIOException, OneWireException
  {
    byte[] raw_buf = new byte[8];

    read(page, true, raw_buf, 0, 8);

    if (raw_buf[0] > 6) {
      throw new OneWireIOException("Invalid length in packet");
    }

    if (CRC16.compute(raw_buf, 0, raw_buf[0] + 3, page) == 45057)
    {
      System.arraycopy(raw_buf, 1, readBuf, offset, raw_buf[0]);

      return raw_buf[0];
    }

    throw new OneWireIOException("Invalid CRC16 in packet read");
  }

  public void writePagePacket(int page, byte[] writeBuf, int offset, int len)
    throws OneWireIOException, OneWireException
  {
    if (len > 6) {
      throw new OneWireIOException("Length of packet requested exceeds page size");
    }

    byte[] raw_buf = new byte[len + 3];

    raw_buf[0] = (byte)len;

    System.arraycopy(writeBuf, offset, raw_buf, 1, len);

    int crc = CRC16.compute(raw_buf, 0, len + 1, page);

    raw_buf[(len + 1)] = (byte)((crc ^ 0xFFFFFFFF) & 0xFF);
    raw_buf[(len + 2)] = (byte)(((crc ^ 0xFFFFFFFF) & 0xFFFF) >>> 8 & 0xFF);

    write(page * 8, raw_buf, 0, len + 3);
  }

  public void readPageCRC(int page, boolean readContinue, byte[] readBuf, int offset)
    throws OneWireIOException, OneWireException
  {
    throw new OneWireException("Read page with CRC not supported by this memory bank");
  }

  public void readPageCRC(int page, boolean readContinue, byte[] readBuf, int offset, byte[] extraInfo)
    throws OneWireIOException, OneWireException
  {
    throw new OneWireException("Read page with CRC not supported by this memory bank");
  }

  public void lockPage(int page)
    throws OneWireIOException, OneWireException
  {
    this.ib.doSpeed();

    if (!this.ib.adapter.select(this.ib.address)) {
      throw new OneWireIOException("Device select failed");
    }

    this.ib.adapter.putByte(90);
    this.ib.adapter.putByte(-91);

    if (!isPageLocked(page))
      throw new OneWireIOException("Read back from write incorrect, could not lock page");
  }

  public boolean isPageLocked(int page)
    throws OneWireIOException, OneWireException
  {
    if (page != 0) {
      throw new OneWireException("Invalid page number for this memory bank");
    }

    this.ib.doSpeed();

    return readStatus() == -4;
  }

  public void redirectPage(int page, int newPage)
    throws OneWireIOException, OneWireException
  {
    throw new OneWireException("Page redirection not supported by this memory bank");
  }

  /** @deprecated */
  public int isPageRedirected(int page)
    throws OneWireIOException, OneWireException
  {
    return 0;
  }

  public int getRedirectedPage(int page)
    throws OneWireIOException, OneWireException
  {
    return 0;
  }

  public void lockRedirectPage(int page)
    throws OneWireIOException, OneWireException
  {
    throw new OneWireException("Lock Page redirection not supported by this memory bank");
  }

  public boolean isRedirectPageLocked(int page)
    throws OneWireIOException, OneWireException
  {
    return false;
  }

  protected void readStatus(byte[] readBuf)
    throws OneWireIOException, OneWireException
  {
    readBuf[0] = readStatus();
  }

  protected byte readStatus()
    throws OneWireIOException, OneWireException
  {
    if (!this.ib.adapter.select(this.ib.address)) {
      throw new OneWireIOException("Device select failed");
    }

    this.ib.adapter.putByte(102);

    this.ib.adapter.putByte(0);

    return (byte)this.ib.adapter.getByte();
  }
}