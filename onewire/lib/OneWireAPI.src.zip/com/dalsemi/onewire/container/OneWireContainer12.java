package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import com.dalsemi.onewire.utils.CRC16;
import java.util.Enumeration;
import java.util.Vector;

public class OneWireContainer12 extends OneWireContainer
  implements SwitchContainer
{
  public static final byte SOURCE_ACTIVITY_LATCH = 2;
  public static final byte SOURCE_FLIP_FLOP = 4;
  public static final byte SOURCE_PIO = 6;
  public static final byte POLARITY_ZERO = 0;
  public static final byte POLARITY_ONE = 1;
  public static final byte CHANNEL_NONE = 0;
  public static final byte DONT_CHANGE = -1;
  public static final byte CHANNEL_A_ONLY = 4;
  public static final byte CHANNEL_B_ONLY = 8;
  public static final byte CHANNEL_BOTH = 12;
  public static final byte CRC_DISABLE = 0;
  public static final byte CRC_EVERY_BYTE = 1;
  public static final byte CRC_EVERY_8_BYTES = 2;
  public static final byte CRC_EVERY_32_BYTES = 3;
  private static final byte WRITE_STATUS_COMMAND = 85;
  private static final byte CHANNEL_ACCESS_COMMAND = -11;
  private byte[] buffer = new byte[7];
  private boolean clearactivity = false;
  private boolean doSpeedEnable = true;

  public OneWireContainer12()
  {
  }

  public OneWireContainer12(DSPortAdapter sourceAdapter, byte[] newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public OneWireContainer12(DSPortAdapter sourceAdapter, long newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public OneWireContainer12(DSPortAdapter sourceAdapter, String newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public String getName()
  {
    return "DS2406";
  }

  public String getAlternateNames()
  {
    return "Dual Addressable Switch, DS2407";
  }

  public String getDescription()
  {
    return "1-Wire Dual Addressable Switch.  PIO pin channel A sink capability of typical 50mA at 0.4V with soft turn-on; optional channel B typical 10 mA at 0.4V.  1024 bits of Electrically Programmable Read Only Memory (EPROM) partitioned into four 256 bit pages.  7 bytes of user-programmable status memory to control the device.";
  }

  public Enumeration getMemoryBanks()
  {
    Vector bank_vector = new Vector(2);

    MemoryBankEPROM mn = new MemoryBankEPROM(this);

    mn.numberPages = 4;
    mn.size = 128;

    bank_vector.addElement(mn);

    MemoryBankEPROM st = new MemoryBankEPROM(this);

    st.bankDescription = "Write protect pages, Page redirection, Switch control";

    st.numberPages = 1;
    st.size = 8;
    st.pageLength = 8;
    st.generalPurposeMemory = false;
    st.extraInfo = false;
    st.extraInfoLength = 0;
    st.extraInfoDescription = null;
    st.crcAfterAddress = false;
    st.READ_PAGE_WITH_CRC = -86;
    st.WRITE_MEMORY_COMMAND = 85;

    bank_vector.addElement(st);

    mn.mbLock = st;
    mn.lockPage = true;
    mn.mbRedirect = st;
    mn.redirectOffset = 1;
    mn.redirectPage = true;

    return bank_vector.elements();
  }

  public boolean isPowerSupplied(byte[] state)
  {
    return (state[0] & 0x80) == 128;
  }

  public int getNumberChannels(byte[] state)
  {
    return (state[0] & 0x40) == 64 ? 2 : 1;
  }

  public boolean isHighSideSwitch()
  {
    return false;
  }

  public boolean hasActivitySensing()
  {
    return true;
  }

  public boolean hasLevelSensing()
  {
    return true;
  }

  public boolean hasSmartOn()
  {
    return false;
  }

  public boolean onlySingleChannelOn()
  {
    return false;
  }

  public boolean getLevel(int channel, byte[] state)
  {
    if (channel == 0) {
      return (state[0] & 0x4) == 4;
    }
    return (state[0] & 0x8) == 8;
  }

  public boolean getLatchState(int channel, byte[] state)
  {
    if (channel == 0)
    {
      return (state[1] & 0x20) != 32;
    }

    return (state[1] & 0x40) != 64;
  }

  public boolean getSensedActivity(int channel, byte[] state)
  {
    if (channel == 0) {
      return (state[0] & 0x10) == 16;
    }
    return (state[0] & 0x20) == 32;
  }

  public void clearActivity()
  {
    synchronized (this)
    {
      this.clearactivity = true;
    }
  }

  public void setLatchState(int channel, boolean latchState, boolean doSmart, byte[] state)
  {
    if (channel == 0)
    {
      int tmp7_6 = 1;
      byte[] tmp7_4 = state; tmp7_4[tmp7_6] = (byte)(tmp7_4[tmp7_6] & 0xFFFFFFDF);
      if (!latchState)
        state[1] = (byte)(state[1] | 0x20);
    }
    else
    {
      int tmp36_35 = 1;
      byte[] tmp36_33 = state; tmp36_33[tmp36_35] = (byte)(tmp36_33[tmp36_35] & 0xFFFFFFBF);
      if (!latchState)
        state[1] = (byte)(state[1] | 0x40);
    }
  }

  public byte[] readDevice()
    throws OneWireIOException, OneWireException
  {
    byte[] state = new byte[2];

    synchronized (this)
    {
      if (this.doSpeedEnable) {
        doSpeed();
      }

      if (this.adapter.select(this.address))
      {
        this.buffer[0] = -11;

        if (this.clearactivity)
        {
          this.buffer[1] = -43;
          this.clearactivity = false;
        }
        else
        {
          this.buffer[1] = 85;
        }

        this.buffer[2] = -1;

        for (int i = 3; i < 7; i++) {
          this.buffer[i] = -1;
        }

        this.adapter.dataBlock(this.buffer, 0, 7);

        if (CRC16.compute(this.buffer, 0, 7, 0) == 45057)
        {
          state[0] = this.buffer[3];

          this.buffer[0] = -86;
          this.buffer[1] = 7;
          this.buffer[2] = 0;
          for (int i = 3; i < 6; i++)
            this.buffer[i] = -1;
          this.adapter.reset();
          this.adapter.select(this.address);
          this.adapter.dataBlock(this.buffer, 0, 6);
          if (CRC16.compute(this.buffer, 0, 6, 0) == 45057)
          {
            state[1] = this.buffer[3];
            return state;
          }
        }
      }

    }

    throw new OneWireIOException("OneWireContainer12-device not present");
  }

  public void writeDevice(byte[] state)
    throws OneWireIOException, OneWireException
  {
    if (this.doSpeedEnable) {
      doSpeed();
    }
    if (this.adapter.select(this.address))
    {
      synchronized (this)
      {
        this.buffer[0] = 85;

        this.buffer[1] = 7;
        this.buffer[2] = 0;

        this.buffer[3] = state[1];

        this.buffer[4] = -1;
        this.buffer[5] = -1;

        this.adapter.dataBlock(this.buffer, 0, 6);

        if (CRC16.compute(this.buffer, 0, 6, 0) == 45057) {
          return;
        }
      }
    }

    throw new OneWireException("OneWireContainer12-device not present");
  }

  public synchronized void setSpeedCheck(boolean doSpeedCheck)
  {
    this.doSpeedEnable = doSpeedCheck;
  }

  public void setSearchConditions(byte channel, byte source, byte polarity, byte[] state)
  {
    byte newstate = 0;
    if (channel != -1)
    {
      newstate = (byte)(channel << 1);
    }
    if (source != -1)
    {
      newstate = (byte)(newstate | source);
    }
    if (polarity != -1)
    {
      newstate = (byte)(newstate | polarity);
    }
    state[1] = (byte)(state[1] & 0xE0);
    int tmp54_53 = 1;
    byte[] tmp54_51 = state; tmp54_51[tmp54_53] = (byte)(tmp54_51[tmp54_53] | newstate);
  }

  public byte[] channelAccess(byte[] inbuffer, boolean toggleRW, boolean readInitially, int CRCMode, int channelMode, boolean clearActivity, boolean interleave)
    throws OneWireException, OneWireIOException
  {
    CRCMode &= 3;
    channelMode &= 12;

    if (channelMode == 0) {
      channelMode = 4;
    }
    if ((interleave) && (channelMode != 12)) {
      interleave = false;
    }
    if (this.doSpeedEnable) {
      doSpeed();
    }
    if (this.adapter.select(this.address))
    {
      int inlength = inbuffer.length;

      if (toggleRW) {
        inlength <<= 1;
      }
      switch (CRCMode)
      {
      case 1:
      default:
        inlength *= 3;
        break;
      case 2:
        inlength += (inlength >> 3 << 1);
        break;
      case 3:
        inlength += (inlength >> 5 << 1);
      }

      byte[] outputbuffer = new byte[inlength + 3 + 1];

      outputbuffer[0] = -11;
      int crc16 = CRC16.compute(245);

      outputbuffer[1] = (byte)(CRCMode | channelMode | (clearActivity ? '' : 0) | (interleave ? 16 : 0) | (toggleRW ? 32 : 0) | (readInitially ? 64 : 0));

      outputbuffer[2] = -1;
      crc16 = CRC16.compute(outputbuffer, 1, 2, crc16);

      for (int i = 3; i < outputbuffer.length; i++) {
        outputbuffer[i] = -1;
      }

      int j = 4;
      int option = outputbuffer[1] & 0x63;

      option = (option >> 3 | option) & 0xF;

      if ((option < 8) || (option > 11))
      {
        for (i = 0; i < inbuffer.length; i++)
        {
          if (option > 11) {
            j += fixJ(i * 2 + 1, option);
          }
          outputbuffer[j] = inbuffer[i];

          if (option < 4) {
            j += fixJ(i + 1, option);
          }
          else {
            if (option < 8) {
              j += fixJ(i * 2 + 1, option);
            }
            j += fixJ(i * 2 + 2, option);
          }

        }

      }

      this.adapter.dataBlock(outputbuffer, 0, outputbuffer.length);

      crc16 = CRC16.compute(outputbuffer[3], crc16);
      j = 0;

      int k = 0;
      boolean fresh = false;
      byte[] returnbuffer = new byte[inbuffer.length];

      for (i = 4; i < outputbuffer.length; i++)
      {
        if (CRCMode != 0)
        {
          if (fresh)
          {
            crc16 = CRC16.compute(outputbuffer[i]);
            fresh = false;
          }
          else {
            crc16 = CRC16.compute(outputbuffer[i], crc16);
          }
        }
        if (((!toggleRW) && (readInitially)) || ((toggleRW) && (readInitially) && ((j & 0x1) == 0)) || ((toggleRW) && (!readInitially) && ((j & 0x1) == 1)))
        {
          returnbuffer[k] = outputbuffer[i];

          k++;
        }

        j++;

        if ((fixJ(j, option) <= 1) || (CRCMode == 0))
          continue;
        crc16 = CRC16.compute(outputbuffer, i + 1, 2, crc16);
        i += 2;

        if (crc16 != 45057) {
          throw new OneWireIOException("Invalid CRC");
        }
        fresh = true;
      }

      return returnbuffer;
    }

    throw new OneWireIOException("OneWireContainer12-device not present");
  }

  private int fixJ(int current_index, int option_mask)
  {
    switch (option_mask & 0x3)
    {
    case 0:
      return 1;
    case 1:
      return 3;
    }
    if ((current_index & 8 + 24 * (option_mask & 0x1) - 1) == 0) {
      return 3;
    }

    return 1;
  }
}