package com.dalsemi.onewire.container;

import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.utils.Bit;

public class OneWireContainer27 extends OneWireContainer24
  implements ClockContainer
{
  public static final byte INTERRUPT_INTERVAL_1 = 0;
  public static final byte INTERRUPT_INTERVAL_4 = 1;
  public static final byte INTERRUPT_INTERVAL_32 = 2;
  public static final byte INTERRUPT_INTERVAL_64 = 3;
  public static final byte INTERRUPT_INTERVAL_2048 = 4;
  public static final byte INTERRUPT_INTERVAL_4096 = 5;
  public static final byte INTERRUPT_INTERVAL_65536 = 6;
  public static final byte INTERRUPT_INTERVAL_131072 = 7;

  public OneWireContainer27()
  {
  }

  public OneWireContainer27(DSPortAdapter sourceAdapter, byte[] newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public OneWireContainer27(DSPortAdapter sourceAdapter, long newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public OneWireContainer27(DSPortAdapter sourceAdapter, String newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public String getName()
  {
    return "DS2417";
  }

  public String getAlternateNames()
  {
    return "1-Wire Time Chip with hardware interrupt";
  }

  public String getDescription()
  {
    return "Real time clock with interrupt implemented as a binary counter that can be used to add functions such as calendar, time and date stamp and logbook to any type of electronic device or embedded application that uses a microcontroller.";
  }

  public long getInterruptInterval(byte[] state)
  {
    long ret = 0L;
    switch ((state[0] & 0x70) >>> 4)
    {
    default:
      break;
    case 0:
      ret = 1L;
      break;
    case 1:
      ret = 4L;
      break;
    case 2:
      ret = 32L;
      break;
    case 3:
      ret = 64L;
      break;
    case 4:
      ret = 2048L;
      break;
    case 5:
      ret = 4096L;
      break;
    case 6:
      ret = 65536L;
      break;
    case 7:
      ret = 131072L;
    }

    return ret;
  }

  public boolean isInterruptEnabled(byte[] state)
  {
    return Bit.arrayReadBit(7, 0, state) == 1;
  }

  public void setInterruptInterval(byte intervalValue, byte[] state)
  {
    int tmp2_1 = 0;
    byte[] tmp2_0 = state; tmp2_0[tmp2_1] = (byte)(tmp2_0[tmp2_1] & 0xFFFFFF8F);
    int tmp11_10 = 0;
    byte[] tmp11_9 = state; tmp11_9[tmp11_10] = (byte)(tmp11_9[tmp11_10] | (byte)(intervalValue << 4));
  }

  public void setInterruptEnable(boolean iEnable, byte[] state)
  {
    Bit.arrayWriteBit(iEnable ? 1 : 0, 7, 0, state);
  }
}