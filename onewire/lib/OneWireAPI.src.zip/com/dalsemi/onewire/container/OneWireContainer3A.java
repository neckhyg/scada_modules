package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;

public class OneWireContainer3A extends OneWireContainer
  implements SwitchContainer
{
  private MemoryBankEEPROMstatus map;
  private MemoryBankEEPROMstatus search;
  public static final byte PIO_ACCESS_READ = -11;
  public static final byte PIO_ACCESS_WRITE = 90;
  private byte[] FF = new byte[8];

  public OneWireContainer3A()
  {
    for (int i = 0; i < this.FF.length; i++)
      this.FF[i] = -1;
  }

  public OneWireContainer3A(DSPortAdapter sourceAdapter, byte[] newAddress)
  {
    super(sourceAdapter, newAddress);

    for (int i = 0; i < this.FF.length; i++)
      this.FF[i] = -1;
  }

  public OneWireContainer3A(DSPortAdapter sourceAdapter, long newAddress)
  {
    super(sourceAdapter, newAddress);

    for (int i = 0; i < this.FF.length; i++)
      this.FF[i] = -1;
  }

  public OneWireContainer3A(DSPortAdapter sourceAdapter, String newAddress)
  {
    super(sourceAdapter, newAddress);

    for (int i = 0; i < this.FF.length; i++)
      this.FF[i] = -1;
  }

  public String getName()
  {
    return "DS2413";
  }

  public String getAlternateNames()
  {
    return "Dual Channel Switch";
  }

  public String getDescription()
  {
    return "Dual Channel Addressable Switch";
  }

  public int getMaxSpeed()
  {
    return 2;
  }

  public int getNumberChannels(byte[] state)
  {
    return 2;
  }

  public boolean isHighSideSwitch()
  {
    return false;
  }

  public boolean hasActivitySensing()
  {
    return false;
  }

  public boolean hasLevelSensing()
  {
    return true;
  }

  public boolean hasSmartOn()
  {
    return false;
  }

  public boolean onlySingleChannelOn()
  {
    return false;
  }

  public boolean getLevel(int channel, byte[] state)
  {
    byte level = (byte)(1 << channel * 2);
    return (state[1] & level) == level;
  }

  public boolean getLatchState(int channel, byte[] state)
  {
    byte latch = (byte)(1 << channel * 2 + 1);
    return (state[1] & latch) == latch;
  }

  public boolean getSensedActivity(int channel, byte[] state)
    throws OneWireException
  {
    return false;
  }

  public void clearActivity()
    throws OneWireException
  {
  }

  public void setLatchState(int channel, boolean latchState, boolean doSmart, byte[] state)
  {
    byte latch = (byte)(1 << channel);

    state[0] = -4;
    byte temp;
    if (getLatchState(0, state))
    {
      temp = 1;
      state[0] = (byte)(state[0] | temp);
    }

    if (getLatchState(1, state))
    {
      temp = 2;
      state[0] = (byte)(state[0] | temp);
    }

    if (latchState)
      state[0] = (byte)(state[0] | latch);
    else
      state[0] = (byte)(state[0] & (latch ^ 0xFFFFFFFF));
  }

  public void setLatchState(byte set, byte[] state)
  {
    state[0] = set;
  }

  public byte[] readDevice()
    throws OneWireIOException, OneWireException
  {
    byte[] buff = new byte[2];

    buff[0] = -11;
    buff[1] = -1;

    if (this.adapter.select(this.address))
    {
      this.adapter.dataBlock(buff, 0, 2);
    }
    else {
      throw new OneWireIOException("Device select failed");
    }
    return buff;
  }

  public byte[] readRegister()
    throws OneWireIOException, OneWireException
  {
    byte[] register = new byte[3];

    return register;
  }

  public void writeDevice(byte[] state)
    throws OneWireIOException, OneWireException
  {
    byte[] buff = new byte[5];

    buff[0] = 90;
    buff[1] = state[0];
    buff[2] = (byte)(state[0] ^ 0xFFFFFFFF);
    buff[3] = -1;
    buff[4] = -1;

    if (this.adapter.select(this.address))
    {
      this.adapter.dataBlock(buff, 0, 5);
    }
    else {
      throw new OneWireIOException("Device select failed");
    }
    if (buff[3] != -86)
    {
      throw new OneWireIOException("Failure to change latch state.");
    }
  }

  public void writeRegister(byte[] register)
    throws OneWireIOException, OneWireException
  {
  }
}