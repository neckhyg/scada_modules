package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import java.util.Enumeration;
import java.util.Vector;

public class OneWireContainer2D extends OneWireContainer
{
  private MemoryBankEEPROM register;
  private MemoryBankEEPROM main_mem;
  public static final byte WRITEONCE_FLAG = -86;

  public OneWireContainer2D()
  {
  }

  public OneWireContainer2D(DSPortAdapter sourceAdapter, byte[] newAddress)
  {
    super(sourceAdapter, newAddress);

    initMem();
  }

  public OneWireContainer2D(DSPortAdapter sourceAdapter, long newAddress)
  {
    super(sourceAdapter, newAddress);

    initMem();
  }

  public OneWireContainer2D(DSPortAdapter sourceAdapter, String newAddress)
  {
    super(sourceAdapter, newAddress);

    initMem();
  }

  public void setupContainer(DSPortAdapter sourceAdapter, byte[] newAddress)
  {
    super.setupContainer(sourceAdapter, newAddress);

    initMem();
  }

  public void setupContainer(DSPortAdapter sourceAdapter, long newAddress)
  {
    super.setupContainer(sourceAdapter, newAddress);

    initMem();
  }

  public void setupContainer(DSPortAdapter sourceAdapter, String newAddress)
  {
    super.setupContainer(sourceAdapter, newAddress);

    initMem();
  }

  public String getName()
  {
    return "DS1972";
  }

  public String getAlternateNames()
  {
    return "DS2431";
  }

  public String getDescription()
  {
    return "1K-Bit protected 1-Wire EEPROM.";
  }

  public int getMaxSpeed()
  {
    return 2;
  }

  public Enumeration getMemoryBanks()
  {
    Vector bank_vector = new Vector(2);

    bank_vector.addElement(this.main_mem);

    bank_vector.addElement(this.register);

    return bank_vector.elements();
  }

  private void initMem()
  {
    MemoryBankScratchEE sp = new MemoryBankScratchEE(this);
    sp.size = 8;
    sp.pageLength = 8;
    sp.maxPacketDataLength = 5;
    sp.pageAutoCRC = true;
    sp.COPY_DELAY_LEN = 30;
    sp.ES_MASK = 0;

    this.main_mem = new MemoryBankEEPROM(this, sp);

    this.register = new MemoryBankEEPROM(this, sp);

    this.register.generalPurposeMemory = false;
    this.register.bankDescription = "Write-protect/EPROM-Mode control register";
    this.register.numberPages = 1;
    this.register.size = 8;
    this.register.pageLength = 8;
    this.register.maxPacketDataLength = 0;
    this.register.readWrite = true;
    this.register.writeOnce = false;
    this.register.readOnly = false;
    this.register.nonVolatile = true;
    this.register.pageAutoCRC = false;
    this.register.lockPage = false;
    this.register.programPulse = false;
    this.register.powerDelivery = true;
    this.register.extraInfo = false;
    this.register.extraInfoLength = 0;
    this.register.extraInfoDescription = null;
    this.register.writeVerification = false;
    this.register.startPhysicalAddress = 128;
    this.register.doSetSpeed = true;

    this.main_mem.mbLock = this.register;
  }

  public boolean isPageWriteOnce(int page)
    throws OneWireIOException, OneWireException
  {
    byte[] rd_byte = new byte[1];

    this.register.read(page, false, rd_byte, 0, 1);

    return rd_byte[0] == -86;
  }

  public void setPageWriteOnce(int page)
    throws OneWireIOException, OneWireException
  {
    byte[] wr_byte = new byte[1];

    wr_byte[0] = -86;

    this.register.write(page, wr_byte, 0, 1);

    if (!isPageWriteOnce(page))
      throw new OneWireIOException("Failed to set page to write-once mode.");
  }
}