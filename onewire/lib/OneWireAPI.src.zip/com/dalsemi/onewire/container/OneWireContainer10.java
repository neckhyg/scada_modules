package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import com.dalsemi.onewire.utils.CRC8;
import com.dalsemi.onewire.utils.Convert;

public class OneWireContainer10 extends OneWireContainer
  implements TemperatureContainer
{
  private boolean normalResolution = true;
  public static final double RESOLUTION_NORMAL = 0.5D;
  public static final double RESOLUTION_MAXIMUM = 0.1D;
  private static final byte CONVERT_TEMPERATURE_COMMAND = 68;
  private static final byte READ_SCRATCHPAD_COMMAND = -66;
  private static final byte WRITE_SCRATCHPAD_COMMAND = 78;
  private static final byte COPY_SCRATCHPAD_COMMAND = 72;
  private static final byte RECALL_EEPROM_COMMAND = -72;

  public OneWireContainer10()
  {
  }

  public OneWireContainer10(DSPortAdapter sourceAdapter, byte[] newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public OneWireContainer10(DSPortAdapter sourceAdapter, long newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public OneWireContainer10(DSPortAdapter sourceAdapter, String newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public String getName()
  {
    return "DS1920";
  }

  public String getAlternateNames()
  {
    return "DS18S20";
  }

  public String getDescription()
  {
    return "Digital thermometer measures temperatures from -55C to 100C in typically 0.2 seconds.  +/- 0.5C Accuracy between 0C and 70C. 0.5C standard resolution, higher resolution through interpolation.  Contains high and low temperature set points for generation of alarm.";
  }

  public boolean hasTemperatureAlarms()
  {
    return true;
  }

  public boolean hasSelectableTemperatureResolution()
  {
    return true;
  }

  public double[] getTemperatureResolutions()
  {
    double[] resolutions = new double[2];

    resolutions[0] = 0.5D;
    resolutions[1] = 0.1D;

    return resolutions;
  }

  public double getTemperatureAlarmResolution()
  {
    return 1.0D;
  }

  public double getMaxTemperature()
  {
    return 100.0D;
  }

  public double getMinTemperature()
  {
    return -55.0D;
  }

  public void doTemperatureConvert(byte[] state)
    throws OneWireIOException, OneWireException
  {
    doSpeed();

    if (this.adapter.select(this.address))
    {
      this.adapter.setPowerDuration(5);
      this.adapter.startPowerDelivery(2);

      this.adapter.putByte(68);
      try
      {
        Thread.sleep(750L);
      }
      catch (InterruptedException e)
      {
      }
      this.adapter.setPowerNormal();

      if (this.adapter.getByte() != 255) {
        throw new OneWireIOException("OneWireContainer10-temperature conversion not complete");
      }

      byte mode = state[4];

      this.adapter.select(this.address);
      readScratch(state);

      state[4] = mode;
    }
    else
    {
      throw new OneWireIOException("OneWireContainer10-device not present");
    }
  }

  public double getTemperature(byte[] state)
    throws OneWireIOException
  {
    if (((state[1] & 0xFF) != 0) && ((state[1] & 0xFF) != 255)) {
      throw new OneWireIOException("Invalid temperature data!");
    }
    short temp = (short)(state[0] & 0xFF | state[1] << 8);

    if (state[4] == 1)
    {
      temp = (short)(temp >> 1);

      double tmp = temp;
      double cr = state[6] & 0xFF;
      double cpc = state[7] & 0xFF;

      tmp = tmp - 0.25D + (cpc - cr) / cpc;

      return tmp;
    }

    return temp / 2.0D;
  }

  public double getTemperatureAlarm(int alarmType, byte[] state)
  {
    return state[2];
  }

  public double getTemperatureResolution(byte[] state)
  {
    if (state[4] == 0) {
      return 0.5D;
    }
    return 0.1D;
  }

  public void setTemperatureAlarm(int alarmType, double alarmValue, byte[] state)
  {
    if ((alarmType != 0) && (alarmType != 1)) {
      throw new IllegalArgumentException("Invalid alarm type.");
    }
    if ((alarmValue > 100.0D) || (alarmValue < -55.0D)) {
      throw new IllegalArgumentException("Value for alarm not in accepted range.  Must be -55 C <-> +100 C.");
    }

    state[(alarmType == 0 ? 3 : 2)] = (byte)(int)alarmValue;
  }

  public void setTemperatureResolution(double resolution, byte[] state)
  {
    synchronized (this)
    {
      if (resolution == 0.5D)
        this.normalResolution = true;
      else {
        this.normalResolution = false;
      }
      state[4] = (this.normalResolution ? 0 : 1);
    }
  }

  public byte[] readDevice()
    throws OneWireIOException, OneWireException
  {
    byte[] data = new byte[8];

    doSpeed();

    if (this.adapter.select(this.address))
    {
      byte[] buffer = new byte[10];

      buffer[0] = -66;

      for (int i = 1; i < 10; i++) {
        buffer[i] = -1;
      }

      this.adapter.dataBlock(buffer, 0, buffer.length);

      if (CRC8.compute(buffer, 1, 9) == 0)
        System.arraycopy(buffer, 1, data, 0, 8);
      else
        throw new OneWireIOException("OneWireContainer10-Error reading CRC8 from device.");
    }
    else
    {
      throw new OneWireIOException("OneWireContainer10-Device not found on 1-Wire Network");
    }

    data[4] = (this.normalResolution ? 0 : 1);

    return data;
  }

  public void writeDevice(byte[] state)
    throws OneWireIOException, OneWireException
  {
    doSpeed();

    byte[] temp = new byte[2];

    temp[0] = state[2];
    temp[1] = state[3];

    writeScratchpad(temp);

    copyScratchpad();
  }

  /** @deprecated */
  public static double convertToFahrenheit(double celsiusTemperature)
  {
    return Convert.toFahrenheit(celsiusTemperature);
  }

  /** @deprecated */
  public static double convertToCelsius(double fahrenheitTemperature)
  {
    return Convert.toCelsius(fahrenheitTemperature);
  }

  private void readScratch(byte[] data)
    throws OneWireIOException, OneWireException
  {
    if (this.adapter.select(this.address))
    {
      byte[] buffer = new byte[10];

      buffer[0] = -66;

      for (int i = 1; i < 10; i++) {
        buffer[i] = -1;
      }

      this.adapter.dataBlock(buffer, 0, buffer.length);

      if (CRC8.compute(buffer, 1, 9) == 0)
        System.arraycopy(buffer, 1, data, 0, 8);
      else
        throw new OneWireIOException("OneWireContainer10-Error reading CRC8 from device.");
    }
    else
    {
      throw new OneWireIOException("OneWireContainer10-Device not found on 1-Wire Network");
    }
  }

  private void writeScratchpad(byte[] data)
    throws OneWireIOException, OneWireException, IllegalArgumentException
  {
    byte[] write_block = new byte[3];
    byte[] buffer = new byte[8];

    if (data.length != 2) {
      throw new IllegalArgumentException("Bad data.  Data must consist of only TWO bytes.");
    }

    write_block[0] = 78;
    write_block[1] = data[0];
    write_block[2] = data[1];

    if (this.adapter.select(this.address))
      this.adapter.dataBlock(write_block, 0, 3);
    else {
      throw new OneWireIOException("OneWireContainer10 - Device not found");
    }

    buffer = new byte[8];

    readScratch(buffer);

    if ((buffer[2] != data[0]) || (buffer[3] != data[1]))
      throw new OneWireIOException("OneWireContainer10 - data read back incorrect");
  }

  private void copyScratchpad()
    throws OneWireIOException, OneWireException
  {
    if (this.adapter.select(this.address))
    {
      this.adapter.putByte(72);

      this.adapter.setPowerDuration(5);
      this.adapter.startPowerDelivery(0);
      try
      {
        Thread.sleep(10L);
      }
      catch (InterruptedException e)
      {
      }
      this.adapter.setPowerNormal();
    }
    else {
      throw new OneWireIOException("OneWireContainer10 - device not found");
    }
  }
}