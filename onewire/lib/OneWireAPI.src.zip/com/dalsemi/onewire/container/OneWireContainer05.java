package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;

public class OneWireContainer05 extends OneWireContainer
  implements SwitchContainer
{
  public OneWireContainer05()
  {
  }

  public OneWireContainer05(DSPortAdapter sourceAdapter, byte[] newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public OneWireContainer05(DSPortAdapter sourceAdapter, long newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public OneWireContainer05(DSPortAdapter sourceAdapter, String newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public String getName()
  {
    return "DS2405";
  }

  public String getAlternateNames()
  {
    return "Addressable Switch";
  }

  public String getDescription()
  {
    return "Addressable Switch with controlled open drain PIO pin. PIO pin sink capability is greater than 4mA at 0.4V.";
  }

  public int getNumberChannels(byte[] state)
  {
    return 1;
  }

  public boolean isHighSideSwitch()
  {
    return false;
  }

  public boolean hasActivitySensing()
  {
    return false;
  }

  public boolean hasLevelSensing()
  {
    return true;
  }

  public boolean hasSmartOn()
  {
    return false;
  }

  public boolean onlySingleChannelOn()
  {
    return true;
  }

  public boolean getLevel(int channel, byte[] state)
  {
    return (state[0] & 0x2) == 2;
  }

  public boolean getLatchState(int channel, byte[] state)
  {
    return (state[0] & 0x1) == 1;
  }

  public boolean getSensedActivity(int channel, byte[] state)
    throws OneWireException
  {
    throw new OneWireException("Sense Activity not supported");
  }

  public void clearActivity()
    throws OneWireException
  {
    throw new OneWireException("Sense Activity not supported");
  }

  public void setLatchState(int channel, boolean latchState, boolean doSmart, byte[] state)
  {
    if (latchState)
      state[0] = (byte)(state[0] | 0x1);
    else
      state[0] = (byte)(state[0] & 0xFE);
  }

  public byte[] readDevice()
    throws OneWireIOException, OneWireException
  {
    doSpeed();

    byte[] state = new byte[1];

    state[0] = 0;

    if (isPresent())
    {
      if (isAlarming())
        state[0] = 1;
    }
    else {
      throw new OneWireIOException("Device not present");
    }
    if (isPresent())
    {
      if (this.adapter.getByte() != 0)
        state[0] = (byte)(state[0] | 0x2);
    }
    else {
      throw new OneWireIOException("Device not present");
    }
    return state;
  }

  public void writeDevice(byte[] state)
    throws OneWireIOException, OneWireException
  {
    doSpeed();

    boolean value = (state[0] & 0x1) == 1;
    boolean compare = isAlarming();

    if (compare == value) {
      return;
    }

    if (this.adapter.select(this.address))
    {
      compare = isAlarming();

      if (compare == value) {
        return;
      }
    }
    throw new OneWireIOException("Failure to change DS2405 latch state");
  }
}