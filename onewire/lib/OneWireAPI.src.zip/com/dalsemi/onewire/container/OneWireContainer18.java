package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import com.dalsemi.onewire.utils.CRC16;
import java.util.Enumeration;
import java.util.Vector;

public class OneWireContainer18 extends OneWireContainer
{
  private static final boolean DEBUG = false;
  private MemoryBankScratch scratch;
  private MemoryBankNVCRC memory;
  private MemoryBankNVCRC memoryPlus;
  private int block_wait_count = 20;

  private boolean resume = false;

  private boolean doSpeedEnable = true;

  private byte[] byte_buffer = new byte[60];
  private byte[] private_address = null;

  static byte[] FF = new byte[60];
  private byte TA1;
  private byte TA2;
  private byte ES;
  public static final byte READ_MEMORY = -16;
  public static final byte WRITE_SCRATCHPAD = 15;
  public static final byte MATCH_SCRATCHPAD = 60;
  public static final byte ERASE_SCRATCHPAD = -61;
  public static final byte READ_SCRATCHPAD = -86;
  public static final byte READ_AUTHENTICATED_PAGE = -91;
  public static final byte COPY_SCRATCHPAD = 85;
  public static final byte COMPUTE_SHA = 51;
  public static final byte COMPUTE_FIRST_SECRET = 15;
  public static final byte COMPUTE_NEXT_SECRET = -16;
  public static final byte VALIDATE_DATA_PAGE = 60;
  public static final byte SIGN_DATA_PAGE = -61;
  public static final byte COMPUTE_CHALLENGE = -52;
  public static final byte AUTH_HOST = -86;
  public static final byte RESUME = -91;
  private byte[] bind_code_temp = new byte[32];
  private byte[] bind_code_alt_temp = new byte[32];
  private byte[] bind_data_temp = new byte[32];

  public OneWireContainer18()
  {
    super(null, 0L);

    if (this.private_address == null) {
      this.private_address = new byte[8];
    }

    initMem();
  }

  public OneWireContainer18(DSPortAdapter sourceAdapter, byte[] newAddress)
  {
    super(sourceAdapter, newAddress);

    if (this.private_address == null) {
      this.private_address = new byte[8];
    }

    initMem();
  }

  public OneWireContainer18(DSPortAdapter sourceAdapter, long newAddress)
  {
    super(sourceAdapter, newAddress);

    if (this.private_address == null) {
      this.private_address = new byte[8];
    }

    initMem();
  }

  public OneWireContainer18(DSPortAdapter sourceAdapter, String newAddress)
  {
    super(sourceAdapter, newAddress);

    if (this.private_address == null) {
      this.private_address = new byte[8];
    }

    initMem();
  }

  public void setupContainer(DSPortAdapter sourceAdapter, byte[] newAddress)
  {
    this.adapter = sourceAdapter;

    synchronized (this)
    {
      if (this.private_address == null) {
        this.private_address = new byte[8];
      }
      System.arraycopy(newAddress, 0, this.private_address, 0, 8);

      this.address = this.private_address;
    }

    this.speed = 0;
    this.speedFallBackOK = false;
  }

  public String getName()
  {
    return "DS1963S";
  }

  public String getAlternateNames()
  {
    return "SHA-1 iButton";
  }

  public String getDescription()
  {
    return "4096 bits of read/write nonvolatile memory. Memory is partitioned into sixteen pages of 256 bits each. Has overdrive mode.  One-chip 512-bit SHA-1 engine and secret storage.";
  }

  public int getMaxSpeed()
  {
    return 2;
  }

  public Enumeration getMemoryBanks()
  {
    Vector bank = new Vector(4);

    bank.addElement(this.scratch);

    bank.addElement(this.memory);

    bank.addElement(this.memoryPlus);

    MemoryBankNV cnt = new MemoryBankNV(this, this.scratch);

    cnt.numberPages = 3;
    cnt.size = 96;
    cnt.bankDescription = "Write cycle counters and PRNG counter";
    cnt.startPhysicalAddress = 608;
    cnt.readOnly = true;
    cnt.pageAutoCRC = false;
    cnt.generalPurposeMemory = false;
    cnt.readWrite = false;

    bank.addElement(cnt);

    return bank.elements();
  }

  private void initMem()
  {
    this.scratch = new MemoryBankScratchSHA(this);

    this.memory = new MemoryBankNVCRC(this, this.scratch);

    this.memory.numberPages = 8;
    this.memory.size = 256;
    this.memory.extraInfoLength = 8;
    this.memory.readContinuePossible = false;
    this.memory.numVerifyBytes = 8;

    this.memoryPlus = new MemoryBankNVCRC(this, this.scratch);

    this.memoryPlus.numberPages = 8;
    this.memoryPlus.size = 256;
    this.memoryPlus.bankDescription = "Memory with write cycle counter";
    this.memoryPlus.startPhysicalAddress = 256;
    this.memoryPlus.extraInfo = true;
    this.memoryPlus.extraInfoDescription = "Write cycle counter";
    this.memoryPlus.extraInfoLength = 8;
    this.memoryPlus.readContinuePossible = false;
    this.memoryPlus.numVerifyBytes = 8;
  }

  public synchronized void setSpeedCheck(boolean doSpeedCheck)
  {
    this.doSpeedEnable = doSpeedCheck;
  }

  public synchronized void useResume(boolean set)
  {
    this.resume = set;
  }

  public synchronized boolean eraseScratchPad(int page)
    throws OneWireIOException, OneWireException
  {
    if ((this.doSpeedEnable) && (!this.resume)) {
      doSpeed();
    }

    if (!this.resume) {
      this.adapter.select(this.address);
    }
    else {
      this.adapter.reset();
      this.adapter.putByte(-91);
    }

    byte[] buffer = this.byte_buffer;

    buffer[0] = -61;
    buffer[1] = (byte)(page << 5);
    buffer[2] = (byte)(page >> 3);

    System.arraycopy(FF, 0, buffer, 3, 3);

    this.adapter.dataBlock(buffer, 0, 6);

    if (buffer[5] == -1) {
      return waitForSuccessfulFinish();
    }
    return true;
  }

  public synchronized boolean waitForSuccessfulFinish()
    throws OneWireIOException, OneWireException
  {
    int count = 0;

    while (this.adapter.getByte() == 255)
    {
      count++;

      if (count == this.block_wait_count) {
        return false;
      }
    }
    return true;
  }

  public void readMemoryPage(int pageNum, byte[] data, int start)
    throws OneWireIOException, OneWireException
  {
    readMemoryPage(pageNum, -16, 32, data, start);
  }

  private synchronized void readMemoryPage(int pageNum, byte COMMAND, int bytes_to_read, byte[] data, int start)
    throws OneWireIOException, OneWireException
  {
    if ((this.doSpeedEnable) && (!this.resume)) {
      doSpeed();
    }
    if (!this.resume) {
      this.adapter.select(this.address);
    }
    else {
      this.adapter.reset();
      this.adapter.putByte(-91);
    }

    byte[] buffer = this.byte_buffer;
    int addr = pageNum << 5;

    buffer[0] = COMMAND;
    buffer[1] = (byte)addr;
    buffer[2] = (byte)(addr >> 8);

    System.arraycopy(FF, 0, buffer, 3, bytes_to_read);
    this.adapter.dataBlock(buffer, 0, 3 + bytes_to_read);

    System.arraycopy(buffer, 3, data, start, bytes_to_read);
  }

  public boolean readAuthenticatedPage(int pageNum, byte[] data, int start)
    throws OneWireIOException, OneWireException
  {
    readMemoryPage(pageNum, -91, 42, data, start);

    int crc = CRC16.compute(-91);

    crc = CRC16.compute((byte)(pageNum << 5), crc);
    crc = CRC16.compute((byte)(pageNum >>> 3), crc);

    if (CRC16.compute(data, start, 42, crc) != 45057)
    {
      return false;
    }

    return waitForSuccessfulFinish();
  }

  public synchronized boolean writeScratchPad(int targetPage, int targetPageOffset, byte[] inputbuffer, int start, int length)
    throws OneWireIOException, OneWireException
  {
    if ((this.doSpeedEnable) && (!this.resume)) {
      doSpeed();
    }
    if (!this.resume) {
      this.adapter.select(this.address);
    }
    else {
      this.adapter.reset();
      this.adapter.putByte(-91);
    }

    byte[] buffer = this.byte_buffer;
    int addr = (targetPage << 5) + targetPageOffset;

    buffer[0] = 15;
    buffer[1] = (byte)addr;
    buffer[2] = (byte)(addr >> 8);

    int maxbytes = 32 - (addr & 0x1F);

    if (length > maxbytes) {
      length = maxbytes;
    }

    System.arraycopy(inputbuffer, start, buffer, 3, length);

    buffer[(3 + length)] = -1;
    buffer[(4 + length)] = -1;

    this.adapter.dataBlock(buffer, 0, (addr + length & 0x1F) == 0 ? length + 5 : length + 3);

    if ((addr + length & 0x1F) != 0) {
      return true;
    }

    return CRC16.compute(buffer, 0, length + 5, 0) == 45057;
  }

  public synchronized boolean matchScratchPad(byte[] mac)
    throws OneWireIOException, OneWireException
  {
    if ((this.doSpeedEnable) && (!this.resume)) {
      doSpeed();
    }
    if (!this.resume) {
      this.adapter.select(this.address);
    }
    else {
      this.adapter.reset();
      this.adapter.putByte(-91);
    }

    byte[] buffer = this.byte_buffer;

    buffer[0] = 60;

    System.arraycopy(mac, 0, buffer, 1, 20);

    buffer[21] = -1;
    buffer[22] = -1;
    buffer[23] = -1;

    this.adapter.dataBlock(buffer, 0, 24);

    if (CRC16.compute(buffer, 0, 23, 0) != 45057)
    {
      return false;
    }

    return buffer[23] != -1;
  }

  public synchronized int readScratchPad(byte[] data, int start)
    throws OneWireIOException, OneWireException
  {
    if ((this.doSpeedEnable) && (!this.resume)) {
      doSpeed();
    }
    if (!this.resume) {
      this.adapter.select(this.address);
    }
    else {
      this.adapter.reset();
      this.adapter.putByte(-91);
    }

    byte[] buffer = this.byte_buffer;

    buffer[0] = -86;

    System.arraycopy(FF, 0, buffer, 1, 37);
    this.adapter.dataBlock(buffer, 0, 38);

    this.TA1 = buffer[1];
    this.TA2 = buffer[2];
    this.ES = buffer[3];

    int length = 32 - (this.TA1 & 0x1F);

    if (CRC16.compute(buffer, 0, 6 + length, 0) != 45057)
    {
      return -1;
    }

    if (data != null) {
      System.arraycopy(buffer, 4, data, start, length);
    }
    return length;
  }

  public synchronized boolean copyScratchPad()
    throws OneWireIOException, OneWireException
  {
    if ((this.doSpeedEnable) && (!this.resume)) {
      doSpeed();
    }
    if (!this.resume) {
      this.adapter.select(this.address);
    }
    else {
      this.adapter.reset();
      this.adapter.putByte(-91);
    }

    byte[] buffer = this.byte_buffer;

    buffer[0] = 85;
    buffer[1] = this.TA1;
    buffer[2] = this.TA2;
    buffer[3] = this.ES;

    System.arraycopy(FF, 0, buffer, 4, 5);

    this.adapter.dataBlock(buffer, 0, 9);

    if (buffer[8] == -1) {
      return waitForSuccessfulFinish();
    }
    return true;
  }

  public synchronized boolean installMasterSecret(int page, byte[] secret, int secret_number)
    throws OneWireIOException, OneWireException
  {
    if (secret.length == 0) {
      return false;
    }
    byte[] input_secret = null;
    byte[] buffer = this.byte_buffer;
    int secret_mod_length = secret.length % 47;

    if (secret_mod_length == 0) {
      input_secret = secret;
    }
    else
    {
      input_secret = new byte[secret.length + (47 - secret_mod_length)];

      System.arraycopy(secret, 0, input_secret, 0, secret.length);
    }

    secret_number &= 7;

    int secret_page = secret_number > 3 ? 17 : 16;

    int secret_offset = (secret_number & 0x3) << 3;
    int offset = 0;
    byte[] sp_buffer = new byte[32];

    while (offset < input_secret.length)
    {
      if (!eraseScratchPad(page)) {
        return false;
      }
      if (!writeScratchPad(page, 0, input_secret, offset, 32)) {
        return false;
      }
      if (readScratchPad(buffer, 0) < 0) {
        return false;
      }
      if (!copyScratchPad()) {
        return false;
      }
      System.arraycopy(input_secret, offset + 32, sp_buffer, 8, 15);

      if (!writeScratchPad(page, 0, sp_buffer, 0, 32)) {
        return false;
      }
      if (!SHAFunction(offset == 0 ? 15 : -16))
      {
        return false;
      }

      if (!write_read_copy_quick(secret_page, secret_offset)) {
        return false;
      }
      offset += 47;
    }

    writeDataPage(page, FF);

    return true;
  }

  public synchronized boolean bindSecretToiButton(int page, byte[] bind_data, byte[] bind_code, int secret_number)
    throws OneWireIOException, OneWireException
  {
    if (bind_data.length != 32)
    {
      System.arraycopy(bind_data, 0, this.bind_data_temp, 0, bind_data.length > 32 ? 32 : bind_data.length);

      bind_data = this.bind_data_temp;
    }

    if (bind_code.length != 15)
    {
      if (bind_code.length == 7)
      {
        System.arraycopy(bind_code, 0, this.bind_code_alt_temp, 0, 4);

        this.bind_code_alt_temp[4] = (byte)page;

        System.arraycopy(this.address, 0, this.bind_code_alt_temp, 5, 7);
        System.arraycopy(bind_code, 4, this.bind_code_alt_temp, 12, 3);
      }
      else
      {
        System.arraycopy(bind_code, 0, this.bind_code_alt_temp, 0, bind_code.length > 15 ? 15 : bind_code.length);
      }

      bind_code = this.bind_code_alt_temp;
    }

    System.arraycopy(bind_code, 0, this.bind_code_temp, 8, 15);

    bind_code = this.bind_code_temp;

    if (!writeDataPage(page, bind_data)) {
      return false;
    }
    this.resume = true;

    if (!writeScratchPad(page, 0, bind_code, 0, 32))
    {
      this.resume = false;

      return false;
    }

    if (!SHAFunction(-16))
    {
      this.resume = false;

      return false;
    }

    this.resume = false;

    secret_number &= 7;

    int secret_page = secret_number > 3 ? 17 : 16;

    int secret_offset = (secret_number & 0x3) << 3;

    return write_read_copy_quick(secret_page, secret_offset);
  }

  private synchronized boolean write_read_copy_quick(int secret_page, int secret_offset)
    throws OneWireIOException, OneWireException
  {
    int addr = (secret_page << 5) + secret_offset;
    byte[] buffer = this.byte_buffer;

    buffer[0] = -91;
    buffer[1] = 15;
    buffer[2] = (byte)addr;
    buffer[3] = (byte)(addr >> 8);

    int length = 32 - secret_offset;

    this.adapter.reset();
    System.arraycopy(FF, 0, buffer, 4, length + 2);
    this.adapter.dataBlock(buffer, 0, length + 6);

    if (CRC16.compute(buffer, 1, length + 5, 0) != 45057)
    {
      return false;
    }

    buffer[1] = -86;

    System.arraycopy(FF, 0, buffer, 2, 8);
    this.adapter.reset();
    this.adapter.dataBlock(buffer, 0, 5);

    buffer[1] = 85;

    this.adapter.reset();

    this.adapter.dataBlock(buffer, 0, 8);

    if (buffer[7] == -1) {
      return waitForSuccessfulFinish();
    }
    return true;
  }

  public synchronized boolean writeDataPage(int page_number, byte[] page_data)
    throws OneWireIOException, OneWireException
  {
    if ((this.doSpeedEnable) && (!this.resume)) {
      doSpeed();
    }

    if (!this.resume) {
      this.adapter.select(this.address);
    }
    else {
      this.adapter.reset();
      this.adapter.putByte(-91);
    }

    byte[] buffer = this.byte_buffer;

    buffer[1] = -61;
    buffer[2] = 0;
    buffer[3] = 0;

    System.arraycopy(FF, 0, buffer, 4, 3);
    this.adapter.dataBlock(buffer, 1, 6);

    if ((buffer[6] == -1) && 
      (!waitForSuccessfulFinish())) {
      return false;
    }

    int addr = page_number << 5;

    buffer[0] = -91;
    buffer[1] = 15;
    buffer[2] = (byte)addr;
    buffer[3] = (byte)(addr >> 8);

    System.arraycopy(page_data, 0, buffer, 4, 32);

    buffer[36] = -1;
    buffer[37] = -1;

    this.adapter.reset();

    this.adapter.dataBlock(buffer, 0, 38);

    if (CRC16.compute(buffer, 1, 37, 0) != 45057)
    {
      return false;
    }

    this.adapter.reset();

    buffer[1] = -86;

    System.arraycopy(FF, 0, buffer, 2, 37);
    this.adapter.dataBlock(buffer, 0, 39);

    for (int i = 0; i < 32; i++)
    {
      if (page_data[i] != buffer[(5 + i)])
      {
        return false;
      }

    }

    this.TA1 = buffer[2];
    this.TA2 = buffer[3];
    this.ES = buffer[4];
    int length = 32 - (this.TA1 & 0x1F);

    if (CRC16.compute(buffer, 1, 6 + length, 0) != 45057)
    {
      return false;
    }

    this.adapter.reset();

    buffer[1] = 85;

    System.arraycopy(FF, 0, buffer, 5, 3);
    this.adapter.dataBlock(buffer, 0, 8);

    if (buffer[7] == -1) {
      return waitForSuccessfulFinish();
    }
    return true;
  }

  public boolean SHAFunction(byte function)
    throws OneWireIOException, OneWireException
  {
    return SHAFunction(function, this.TA1 & 0xFF | this.TA2 << 8);
  }

  public synchronized boolean SHAFunction(byte function, int T)
    throws OneWireIOException, OneWireException
  {
    if ((this.doSpeedEnable) && (!this.resume)) {
      doSpeed();
    }
    if (!this.resume) {
      this.adapter.select(this.address);
    }
    else {
      this.adapter.reset();
      this.adapter.putByte(-91);
    }

    byte[] buffer = this.byte_buffer;

    buffer[0] = 51;
    buffer[1] = (byte)T;
    buffer[2] = (byte)(T >> 8);
    buffer[3] = function;

    System.arraycopy(FF, 0, buffer, 4, 5);

    this.adapter.dataBlock(buffer, 0, 9);

    if (CRC16.compute(buffer, 0, 6, 0) != 45057)
    {
      return false;
    }

    if (buffer[8] == -1) {
      return waitForSuccessfulFinish();
    }
    return true;
  }

  static
  {
    for (int i = 0; i < FF.length; i++)
      FF[i] = -1;
  }
}