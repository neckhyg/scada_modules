package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import com.dalsemi.onewire.utils.CRC16;

class MemoryBankScratchSHA extends MemoryBankScratchCRC
{
  public static final byte ERASE_SCRATCHPAD_COMMAND = -61;

  public MemoryBankScratchSHA(OneWireContainer ibutton)
  {
    super(ibutton);

    this.bankDescription = "Scratchpad with CRC and auto-hide";
  }

  public void writeScratchpad(int startAddr, byte[] writeBuf, int offset, int len)
    throws OneWireIOException, OneWireException
  {
    boolean calcCRC = false;
    byte[] raw_buf = new byte[37];

    if (!this.ib.adapter.select(this.ib.address))
    {
      forceVerify();

      throw new OneWireIOException("Device select failed");
    }

    raw_buf[0] = -61;

    System.arraycopy(this.ffBlock, 0, raw_buf, 1, 8);
    this.ib.adapter.dataBlock(raw_buf, 0, 9);

    if (((byte)(raw_buf[8] & 0xF0) != -96) && ((byte)(raw_buf[8] & 0xF0) != 80))
    {
      forceVerify();

      throw new OneWireIOException("Erase scratchpad complete not found");
    }

    if (!this.ib.adapter.select(this.ib.address))
    {
      forceVerify();

      throw new OneWireIOException("Device select failed");
    }

    raw_buf[0] = 15;
    raw_buf[1] = (byte)(startAddr & 0xFF);
    raw_buf[2] = (byte)((startAddr & 0xFFFF) >>> 8 & 0xFF);

    System.arraycopy(writeBuf, offset, raw_buf, 3, len);

    if ((startAddr + len) % this.pageLength == 0)
    {
      System.arraycopy(this.ffBlock, 0, raw_buf, len + 3, 2);

      calcCRC = true;
    }

    this.ib.adapter.dataBlock(raw_buf, 0, len + 3 + (calcCRC ? 2 : 0));

    if (calcCRC)
    {
      if (CRC16.compute(raw_buf, 0, len + 5, 0) != 45057)
      {
        forceVerify();

        throw new OneWireIOException("Invalid CRC16 read from device");
      }
    }
  }
}