package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import com.dalsemi.onewire.utils.Address;
import java.util.Enumeration;
import java.util.Vector;

public class OneWireContainer
{
  protected DSPortAdapter adapter;
  protected byte[] address;
  private byte[] addressCopy;
  protected int speed;
  protected boolean speedFallBackOK;

  public OneWireContainer()
  {
  }

  public OneWireContainer(DSPortAdapter sourceAdapter, byte[] newAddress)
  {
    setupContainer(sourceAdapter, newAddress);
  }

  public OneWireContainer(DSPortAdapter sourceAdapter, long newAddress)
  {
    setupContainer(sourceAdapter, newAddress);
  }

  public OneWireContainer(DSPortAdapter sourceAdapter, String newAddress)
  {
    setupContainer(sourceAdapter, newAddress);
  }

  public void setupContainer(DSPortAdapter sourceAdapter, byte[] newAddress)
  {
    this.adapter = sourceAdapter;

    synchronized (this)
    {
      this.address = new byte[8];
      this.addressCopy = new byte[8];

      System.arraycopy(newAddress, 0, this.address, 0, 8);
    }

    this.speed = 0;
    this.speedFallBackOK = false;
  }

  public void setupContainer(DSPortAdapter sourceAdapter, long newAddress)
  {
    this.adapter = sourceAdapter;

    synchronized (this)
    {
      this.address = Address.toByteArray(newAddress);
      this.addressCopy = new byte[8];
    }

    this.speed = 0;
    this.speedFallBackOK = false;
  }

  public void setupContainer(DSPortAdapter sourceAdapter, String newAddress)
  {
    this.adapter = sourceAdapter;

    synchronized (this)
    {
      this.address = Address.toByteArray(newAddress);
      this.addressCopy = new byte[8];
    }

    this.speed = 0;
    this.speedFallBackOK = false;
  }

  public DSPortAdapter getAdapter()
  {
    return this.adapter;
  }

  public String getName()
  {
    synchronized (this)
    {
      return "Device type: " + ((this.address[0] & 0xFF) < 16 ? "0" + Integer.toHexString(this.address[0] & 0xFF) : Integer.toHexString(this.address[0] & 0xFF));
    }
  }

  public String getAlternateNames()
  {
    return "";
  }

  public String getDescription()
  {
    return "No description available.";
  }

  public void setSpeed(int newSpeed, boolean fallBack)
  {
    this.speed = newSpeed;
    this.speedFallBackOK = fallBack;
  }

  public int getMaxSpeed()
  {
    return 0;
  }

  public byte[] getAddress()
  {
    return this.address;
  }

  public String getAddressAsString()
  {
    return Address.toString(this.address);
  }

  public long getAddressAsLong()
  {
    return Address.toLong(this.address);
  }

  public Enumeration getMemoryBanks()
  {
    return new Vector(0).elements();
  }

  public boolean isPresent()
    throws OneWireIOException, OneWireException
  {
    synchronized (this)
    {
      return this.adapter.isPresent(this.address);
    }
  }

  public boolean isAlarming()
    throws OneWireIOException, OneWireException
  {
    synchronized (this)
    {
      return this.adapter.isAlarming(this.address);
    }
  }

  public void doSpeed()
    throws OneWireIOException, OneWireException
  {
    boolean is_present = false;
    try
    {
      if ((this.speed == this.adapter.getSpeed()) && (this.adapter.isPresent(this.address))) {
        return;
      }

    }
    catch (OneWireIOException e)
    {
    }

    if (this.speed == 2)
    {
      try
      {
        this.adapter.setSpeed(0);
        this.adapter.reset();
        this.adapter.putByte(105);
        this.adapter.setSpeed(2);
      }
      catch (OneWireIOException e)
      {
      }

      synchronized (this)
      {
        System.arraycopy(this.address, 0, this.addressCopy, 0, 8);
        this.adapter.dataBlock(this.addressCopy, 0, 8);
      }

      try
      {
        is_present = this.adapter.isPresent(this.address);
      }
      catch (OneWireIOException e)
      {
      }

      if (!is_present)
      {
        if (this.speedFallBackOK)
          this.adapter.setSpeed(0);
        else {
          throw new OneWireIOException("Failed to get device to selected speed (overdrive)");
        }
      }

    }
    else if ((this.speed == 0) || (this.speed == 1))
    {
      this.adapter.setSpeed(this.speed);
    }
    else {
      throw new OneWireException("Speed selected (hyperdrive) is not supported by this method");
    }
  }

  public int hashCode()
  {
    if (this.address == null) {
      return 0;
    }
    return new Long(Address.toLong(this.address)).hashCode();
  }

  public boolean equals(Object obj)
  {
    if (obj == this) {
      return true;
    }
    if ((obj instanceof OneWireContainer))
    {
      OneWireContainer owc = (OneWireContainer)obj;

      if (owc.getClass() == getClass()) {
        return owc.getAddressAsLong() == getAddressAsLong();
      }
    }
    return false;
  }

  public String toString()
  {
    return Address.toString(this.address) + " " + getName();
  }
}