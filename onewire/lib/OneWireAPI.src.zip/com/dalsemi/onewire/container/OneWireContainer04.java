package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import com.dalsemi.onewire.utils.Bit;
import com.dalsemi.onewire.utils.Convert;
import java.util.Enumeration;
import java.util.Vector;

public class OneWireContainer04 extends OneWireContainer
  implements ClockContainer
{
  protected static final int BITMAP_OFFSET = 32;
  protected static final int STATUS_OFFSET = 0;
  protected static final int CONTROL_OFFSET = 1;
  protected static final int RTC_OFFSET = 2;
  protected static final int INTERVAL_OFFSET = 7;
  protected static final int COUNTER_OFFSET = 12;
  protected static final int RTC_ALARM_OFFSET = 16;
  protected static final int INTERVAL_ALARM_OFFSET = 21;
  protected static final int COUNTER_ALARM_OFFSET = 26;
  private MemoryBankScratch scratch;
  private MemoryBankNV clock;

  public OneWireContainer04()
  {
    initClock();
  }

  public OneWireContainer04(DSPortAdapter sourceAdapter, byte[] newAddress)
  {
    super(sourceAdapter, newAddress);

    initClock();
  }

  public OneWireContainer04(DSPortAdapter sourceAdapter, long newAddress)
  {
    super(sourceAdapter, newAddress);

    initClock();
  }

  public OneWireContainer04(DSPortAdapter sourceAdapter, String newAddress)
  {
    super(sourceAdapter, newAddress);

    initClock();
  }

  public String getName()
  {
    return "DS1994";
  }

  public String getAlternateNames()
  {
    return "DS2404, Time-in-a-can, DS1427";
  }

  public String getDescription()
  {
    return "4096 bit read/write nonvolatile memory partitioned into sixteen pages of 256 bits each and a real time clock/calendar in binary format.";
  }

  public Enumeration getMemoryBanks()
  {
    Vector bank_vector = new Vector(3);

    bank_vector.addElement(this.scratch);

    bank_vector.addElement(new MemoryBankNV(this, this.scratch));

    bank_vector.addElement(this.clock);

    return bank_vector.elements();
  }

  public boolean hasClockAlarm()
  {
    return true;
  }

  public boolean canDisableClock()
  {
    return true;
  }

  public long getClockResolution()
  {
    return 4L;
  }

  public byte[] readDevice()
    throws OneWireIOException, OneWireException
  {
    byte[][] read_buf = new byte[2][36];

    int buf_num = 0; int attempt = 0;

    for (int i = 32; i < 36; i++)
    {
      read_buf[0][i] = 0;
      read_buf[1][i] = 0;
    }

    boolean alarming = isAlarming();
    do
    {
      if ((alarming) && (attempt != 0))
        this.clock.read(1, false, read_buf[buf_num], 1, 31);
      else {
        this.clock.read(0, false, read_buf[buf_num], 0, 32);
      }

      if (attempt++ != 0)
      {
        for (i = 1; i < 32; i++)
        {
          if ((i != 2) && (i != 7) && 
            (read_buf[0][i] != read_buf[1][i]))
          {
            break;
          }
        }

        if (i == 32) {
          return read_buf[buf_num];
        }
      }

      buf_num = buf_num == 0 ? 1 : 0;
    }

    while (attempt < 5);

    throw new OneWireIOException("Failed to read the clock register page");
  }

  public void writeDevice(byte[] state)
    throws OneWireIOException, OneWireException
  {
    int start_offset = 0; int len = 0;
    boolean got_block = false;

    for (int i = 0; i < 32; i++)
    {
      if ((Bit.arrayReadBit(i, 32, state) == 1) && (i != 1))
      {
        if (got_block) {
          len++;
        }
        else
        {
          got_block = true;
          start_offset = i;
          len = 1;
        }

        if (i == 31)
          this.clock.write(start_offset, state, start_offset, len);
      } else {
        if (!got_block)
        {
          continue;
        }
        this.clock.write(start_offset, state, start_offset, len);

        got_block = false;
      }

    }

    if (Bit.arrayReadBit(1, 32, state) == 1)
    {
      this.clock.write(1, state, 1, 1);

      if ((state[1] & 0x7) != 0)
      {
        for (i = 0; i < 2; i++) {
          this.scratch.writeScratchpad(this.clock.getStartPhysicalAddress() + 1, state, 1, 1);
        }

      }

    }

    for (i = 32; i < state.length; i++)
      state[i] = 0;
  }

  public long getClock(byte[] state)
  {
    return Convert.toLong(state, 2, 5) * 1000L / 256L;
  }

  public long getClockAlarm(byte[] state)
    throws OneWireException
  {
    return Convert.toLong(state, 16, 5) * 1000L / 256L;
  }

  public boolean isClockAlarming(byte[] state)
  {
    return Bit.arrayReadBit(0, 0, state) == 1;
  }

  public boolean isClockAlarmEnabled(byte[] state)
  {
    return Bit.arrayReadBit(3, 0, state) == 0;
  }

  public boolean isClockRunning(byte[] state)
  {
    return Bit.arrayReadBit(4, 1, state) == 1;
  }

  public long getIntervalTimer(byte[] state)
  {
    return Convert.toLong(state, 7, 5) * 1000L / 256L;
  }

  public long getCycleCounter(byte[] state)
  {
    return Convert.toLong(state, 12, 4);
  }

  public long getIntervalTimerAlarm(byte[] state)
  {
    return Convert.toLong(state, 21, 5) * 1000L / 256L;
  }

  public long getCycleCounterAlarm(byte[] state)
  {
    return Convert.toLong(state, 26, 4);
  }

  public boolean isIntervalTimerAlarming(byte[] state)
  {
    return Bit.arrayReadBit(1, 0, state) == 1;
  }

  public boolean isCycleCounterAlarming(byte[] state)
  {
    return Bit.arrayReadBit(2, 0, state) == 1;
  }

  public boolean isIntervalTimerAlarmEnabled(byte[] state)
  {
    return Bit.arrayReadBit(4, 0, state) == 0;
  }

  public boolean isCycleCounterAlarmEnabled(byte[] state)
  {
    return Bit.arrayReadBit(5, 0, state) == 0;
  }

  public boolean isClockWriteProtected(byte[] state)
  {
    return Bit.arrayReadBit(0, 1, state) == 1;
  }

  public boolean isIntervalTimerWriteProtected(byte[] state)
  {
    return Bit.arrayReadBit(1, 1, state) == 1;
  }

  public boolean isCycleCounterWriteProtected(byte[] state)
  {
    return Bit.arrayReadBit(2, 1, state) == 1;
  }

  public boolean canReadAfterExpire(byte[] state)
  {
    return Bit.arrayReadBit(3, 1, state) == 1;
  }

  public boolean isIntervalTimerAutomatic(byte[] state)
  {
    return Bit.arrayReadBit(5, 1, state) == 1;
  }

  public boolean isIntervalTimerStopped(byte[] state)
  {
    return Bit.arrayReadBit(6, 1, state) == 1;
  }

  public boolean isAutomaticDelayLong(byte[] state)
  {
    return Bit.arrayReadBit(7, 1, state) == 1;
  }

  public void setClock(long time, byte[] state)
  {
    Convert.toByteArray(time * 256L / 1000L, state, 2, 5);

    for (int i = 0; i < 5; i++)
      Bit.arrayWriteBit(1, 2 + i, 32, state);
  }

  public void setClockAlarm(long time, byte[] state)
    throws OneWireException
  {
    Convert.toByteArray(time * 256L / 1000L, state, 16, 5);

    for (int i = 0; i < 5; i++)
      Bit.arrayWriteBit(1, 16 + i, 32, state);
  }

  public void setClockRunEnable(boolean runEnable, byte[] state)
    throws OneWireException
  {
    Bit.arrayWriteBit(runEnable ? 1 : 0, 4, 1, state);

    Bit.arrayWriteBit(1, 1, 32, state);
  }

  public void setClockAlarmEnable(boolean alarmEnable, byte[] state)
    throws OneWireException
  {
    Bit.arrayWriteBit(alarmEnable ? 0 : 1, 3, 0, state);

    Bit.arrayWriteBit(1, 0, 32, state);
  }

  public void setIntervalTimer(long time, byte[] state)
  {
    Convert.toByteArray(time * 256L / 1000L, state, 7, 5);

    for (int i = 0; i < 5; i++)
      Bit.arrayWriteBit(1, 7 + i, 32, state);
  }

  public void setCycleCounter(long cycles, byte[] state)
  {
    Convert.toByteArray(cycles, state, 12, 4);

    for (int i = 0; i < 4; i++)
      Bit.arrayWriteBit(1, 12 + i, 32, state);
  }

  public void setIntervalTimerAlarm(long time, byte[] state)
  {
    Convert.toByteArray(time * 256L / 1000L, state, 21, 5);

    for (int i = 0; i < 5; i++)
      Bit.arrayWriteBit(1, 21 + i, 32, state);
  }

  public void setCycleCounterAlarm(long cycles, byte[] state)
  {
    Convert.toByteArray(cycles, state, 26, 4);

    for (int i = 0; i < 4; i++)
      Bit.arrayWriteBit(1, 26 + i, 32, state);
  }

  public void writeProtectClock(byte[] state)
  {
    Bit.arrayWriteBit(1, 0, 1, state);

    Bit.arrayWriteBit(1, 1, 32, state);
  }

  public void writeProtectIntervalTimer(byte[] state)
  {
    Bit.arrayWriteBit(1, 1, 1, state);

    Bit.arrayWriteBit(1, 1, 32, state);
  }

  public void writeProtectCycleCounter(byte[] state)
  {
    Bit.arrayWriteBit(1, 2, 1, state);

    Bit.arrayWriteBit(1, 1, 32, state);
  }

  public void setReadAfterExpire(boolean readAfter, byte[] state)
  {
    Bit.arrayWriteBit(readAfter ? 1 : 0, 3, 1, state);

    Bit.arrayWriteBit(1, 1, 32, state);
  }

  public void setIntervalTimerAutomatic(boolean autoTimer, byte[] state)
  {
    Bit.arrayWriteBit(autoTimer ? 1 : 0, 5, 1, state);

    Bit.arrayWriteBit(1, 1, 32, state);
  }

  public void setIntervalTimerRunState(boolean runState, byte[] state)
  {
    Bit.arrayWriteBit(runState ? 1 : 0, 6, 1, state);

    Bit.arrayWriteBit(1, 1, 32, state);
  }

  public void setAutomaticDelayLong(boolean delayLong, byte[] state)
  {
    Bit.arrayWriteBit(delayLong ? 1 : 0, 7, 1, state);

    Bit.arrayWriteBit(1, 1, 32, state);
  }

  public void setIntervalTimerAlarmEnable(boolean alarmEnable, byte[] state)
  {
    Bit.arrayWriteBit(alarmEnable ? 0 : 1, 4, 0, state);

    Bit.arrayWriteBit(1, 0, 32, state);
  }

  public void setCycleCounterAlarmEnable(boolean alarmEnable, byte[] state)
  {
    Bit.arrayWriteBit(alarmEnable ? 0 : 1, 5, 0, state);

    Bit.arrayWriteBit(1, 0, 32, state);
  }

  private void initClock()
  {
    this.scratch = new MemoryBankScratch(this);

    this.clock = new MemoryBankNV(this, this.scratch);
    this.clock.numberPages = 1;
    this.clock.startPhysicalAddress = 512;
    this.clock.size = 32;
    this.clock.generalPurposeMemory = false;
    this.clock.maxPacketDataLength = 0;
    this.clock.bankDescription = "Clock/alarm registers";
  }
}