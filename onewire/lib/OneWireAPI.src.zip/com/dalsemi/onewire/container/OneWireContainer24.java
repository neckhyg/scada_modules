package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import com.dalsemi.onewire.utils.Bit;
import com.dalsemi.onewire.utils.Convert;

public class OneWireContainer24 extends OneWireContainer
  implements ClockContainer
{
  protected static final int RTC_OFFSET = 1;
  protected static final int CONTROL_OFFSET = 0;
  protected static final byte READ_CLOCK_COMMAND = 102;
  protected static final byte WRITE_CLOCK_COMMAND = -103;

  public OneWireContainer24()
  {
  }

  public OneWireContainer24(DSPortAdapter sourceAdapter, byte[] newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public OneWireContainer24(DSPortAdapter sourceAdapter, long newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public OneWireContainer24(DSPortAdapter sourceAdapter, String newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public String getName()
  {
    return "DS2415";
  }

  public String getAlternateNames()
  {
    return "DS1904";
  }

  public String getDescription()
  {
    return "Real time clock implemented as a binary counter that can be used to add functions such as calendar, time and date stamp and logbook to any type of electronic device or embedded application that uses a microcontroller.";
  }

  public boolean hasClockAlarm()
  {
    return false;
  }

  public boolean canDisableClock()
  {
    return true;
  }

  public long getClockResolution()
  {
    return 1000L;
  }

  public byte[] readDevice()
    throws OneWireIOException, OneWireException
  {
    byte[] state = new byte[5];
    if (this.adapter.select(this.address))
    {
      this.adapter.putByte(102);

      this.adapter.getBlock(state, 0, 5);
      return state;
    }

    throw new OneWireIOException("Device not found on 1-Wire Network");
  }

  public void writeDevice(byte[] state)
    throws OneWireIOException, OneWireException
  {
    if (this.adapter.select(this.address))
    {
      byte[] writeblock = new byte[6];
      writeblock[0] = -103;
      System.arraycopy(state, 0, writeblock, 1, 5);

      this.adapter.dataBlock(writeblock, 0, 6);

      byte[] readblock = readDevice();
      if ((readblock[0] & 0xC) != (state[0] & 0xC))
        throw new OneWireIOException("Failed to write to the clock register page");
      for (int i = 1; i < 5; i++)
        if (readblock[i] != state[i])
          throw new OneWireIOException("Failed to write to the clock register page");
    }
    else {
      throw new OneWireIOException("Device not found on one-wire network");
    }
  }

  public long getClock(byte[] state)
  {
    return Convert.toLong(state, 1, 4) * 1000L;
  }

  public long getClockAlarm(byte[] state)
    throws OneWireException
  {
    throw new OneWireException("This device does not support clock alarms.");
  }

  public boolean isClockAlarming(byte[] state)
  {
    return false;
  }

  public boolean isClockAlarmEnabled(byte[] state)
  {
    return false;
  }

  public boolean isClockRunning(byte[] state)
  {
    return Bit.arrayReadBit(3, 0, state) == 1;
  }

  public void setClock(long time, byte[] state)
  {
    Convert.toByteArray(time / 1000L, state, 1, 4);
  }

  public void setClockAlarm(long time, byte[] state)
    throws OneWireException
  {
    throw new OneWireException("This device does not support clock alarms.");
  }

  public void setClockAlarmEnable(boolean alarmEnable, byte[] state)
    throws OneWireException
  {
    throw new OneWireException("This device does not support clock alarms.");
  }

  public void setClockRunEnable(boolean runEnable, byte[] state)
  {
    Bit.arrayWriteBit(runEnable ? 1 : 0, 3, 0, state);

    Bit.arrayWriteBit(runEnable ? 1 : 0, 2, 0, state);
  }
}