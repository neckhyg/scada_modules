package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.OneWireIOException;

public abstract interface PotentiometerContainer extends OneWireSensor
{
  public abstract boolean isLinear(byte[] paramArrayOfByte);

  public abstract boolean wiperSettingsAreVolatile(byte[] paramArrayOfByte);

  public abstract int numberOfPotentiometers(byte[] paramArrayOfByte);

  public abstract int numberOfWiperSettings(byte[] paramArrayOfByte);

  public abstract int potentiometerResistance(byte[] paramArrayOfByte);

  public abstract int getCurrentWiperNumber(byte[] paramArrayOfByte);

  public abstract void setCurrentWiperNumber(int paramInt, byte[] paramArrayOfByte);

  public abstract boolean isChargePumpOn(byte[] paramArrayOfByte);

  public abstract void setChargePump(boolean paramBoolean, byte[] paramArrayOfByte);

  public abstract int getWiperPosition()
    throws OneWireIOException, OneWireException;

  public abstract boolean setWiperPosition(int paramInt)
    throws OneWireIOException, OneWireException;

  public abstract int increment(boolean paramBoolean)
    throws OneWireIOException, OneWireException;

  public abstract int decrement(boolean paramBoolean)
    throws OneWireIOException, OneWireException;

  public abstract int increment()
    throws OneWireIOException, OneWireException;

  public abstract int decrement()
    throws OneWireIOException, OneWireException;
}