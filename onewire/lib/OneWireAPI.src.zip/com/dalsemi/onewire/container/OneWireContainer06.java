package com.dalsemi.onewire.container;

import com.dalsemi.onewire.adapter.DSPortAdapter;
import java.util.Enumeration;
import java.util.Vector;

public class OneWireContainer06 extends OneWireContainer
{
  public OneWireContainer06()
  {
  }

  public OneWireContainer06(DSPortAdapter sourceAdapter, byte[] newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public OneWireContainer06(DSPortAdapter sourceAdapter, long newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public OneWireContainer06(DSPortAdapter sourceAdapter, String newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public String getName()
  {
    return "DS1993";
  }

  public String getDescription()
  {
    return "4096 bit read/write nonvolatile memory partitioned into sixteen pages of 256 bits each. ";
  }

  public Enumeration getMemoryBanks()
  {
    Vector bank_vector = new Vector(2);

    MemoryBankScratch scratch = new MemoryBankScratch(this);

    bank_vector.addElement(scratch);

    bank_vector.addElement(new MemoryBankNV(this, scratch));

    return bank_vector.elements();
  }
}