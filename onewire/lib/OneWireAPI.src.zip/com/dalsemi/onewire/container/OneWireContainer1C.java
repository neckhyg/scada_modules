package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import java.util.Enumeration;
import java.util.Vector;

public class OneWireContainer1C extends OneWireContainer
  implements SwitchContainer
{
  private byte[] FF = new byte[8];
  private MemoryBankScratch scratch;
  private MemoryBankNV mainMemory;
  private MemoryBankNV protectionMemory;
  private MemoryBankNV pioMemory;
  private MemoryBankNV searchMemory;
  public static final byte PIO_ACCESS_READ = -11;
  public static final byte PIO_ACCESS_WRITE = 90;
  public static final byte PIO_ACCESS_PULSE = -91;
  public static final byte RESET_ACTIVITY_LATCHES = -61;
  public static final byte WRITE_REGISTER = -52;

  public OneWireContainer1C()
  {
    initmem();

    for (int i = 0; i < this.FF.length; i++)
      this.FF[i] = -1;
  }

  public OneWireContainer1C(DSPortAdapter sourceAdapter, byte[] newAddress)
  {
    super(sourceAdapter, newAddress);

    initmem();

    for (int i = 0; i < this.FF.length; i++)
      this.FF[i] = -1;
  }

  public OneWireContainer1C(DSPortAdapter sourceAdapter, long newAddress)
  {
    super(sourceAdapter, newAddress);

    initmem();

    for (int i = 0; i < this.FF.length; i++)
      this.FF[i] = -1;
  }

  public OneWireContainer1C(DSPortAdapter sourceAdapter, String newAddress)
  {
    super(sourceAdapter, newAddress);

    initmem();

    for (int i = 0; i < this.FF.length; i++)
      this.FF[i] = -1;
  }

  public String getName()
  {
    return "DS28E04";
  }

  public Enumeration getMemoryBanks()
  {
    Vector bank_vector = new Vector(5);

    bank_vector.addElement(this.scratch);
    bank_vector.addElement(this.mainMemory);
    bank_vector.addElement(this.protectionMemory);
    bank_vector.addElement(this.pioMemory);
    bank_vector.addElement(this.searchMemory);

    return bank_vector.elements();
  }

  public String getAlternateNames()
  {
    return "DS28E04";
  }

  public String getDescription()
  {
    return "Addressable 1-Wire 4K-bit EEPROM, with 2 channels of general-purpose PIO pins with pulse generation capability.";
  }

  public int getNumberChannels(byte[] state)
  {
    return 2;
  }

  public boolean isHighSideSwitch()
  {
    return false;
  }

  public boolean hasActivitySensing()
  {
    return true;
  }

  public boolean hasLevelSensing()
  {
    return true;
  }

  public boolean hasSmartOn()
  {
    return false;
  }

  public boolean onlySingleChannelOn()
  {
    return false;
  }

  public boolean getLevel(int channel, byte[] state)
  {
    byte level = (byte)(1 << channel);
    return (state[0] & level) == level;
  }

  public boolean getLatchState(int channel, byte[] state)
  {
    byte latch = (byte)(1 << channel);
    return (state[1] & latch) == latch;
  }

  public boolean getSensedActivity(int channel, byte[] state)
    throws OneWireException
  {
    byte activity = (byte)(1 << channel);
    return (state[2] & activity) == activity;
  }

  public void clearActivity()
    throws OneWireException
  {
    this.adapter.assertSelect(this.address);

    byte[] buffer = new byte[9];

    buffer[0] = -61;
    System.arraycopy(this.FF, 0, buffer, 1, 8);

    this.adapter.dataBlock(buffer, 0, 9);

    if ((buffer[1] != -86) && (buffer[1] != 85))
      throw new OneWireException("Sense Activity was not cleared.");
  }

  public void setLatchState(int channel, boolean latchState, boolean doSmart, byte[] state)
  {
    byte latch = (byte)(1 << channel);

    if (latchState)
      state[1] = (byte)(state[1] | latch);
    else
      state[1] = (byte)(state[1] & (latch ^ 0xFFFFFFFF));
  }

  public void setLatchState(byte set, byte[] state)
  {
    state[1] = set;
  }

  public byte[] readDevice()
    throws OneWireIOException, OneWireException
  {
    byte[] state = new byte[3];

    System.arraycopy(this.FF, 0, state, 0, 3);
    this.pioMemory.read(0, false, state, 0, 3);

    return state;
  }

  public byte[] readRegister()
    throws OneWireIOException, OneWireException
  {
    byte[] register = new byte[3];

    this.searchMemory.read(0, false, register, 0, 3);

    return register;
  }

  public void writeDevice(byte[] state)
    throws OneWireIOException, OneWireException
  {
    this.adapter.assertSelect(this.address);

    byte[] buffer = new byte[5];

    buffer[0] = 90;
    buffer[1] = state[1];
    buffer[2] = (byte)(state[1] ^ 0xFFFFFFFF);
    buffer[3] = -1;
    buffer[4] = -1;

    this.adapter.dataBlock(buffer, 0, 5);

    if (buffer[3] != -86)
    {
      throw new OneWireIOException("Failure to change latch state.");
    }

    state[0] = buffer[4];
  }

  public void writeRegister(byte[] register)
    throws OneWireIOException, OneWireException
  {
    this.adapter.assertSelect(this.address);

    byte[] buffer = new byte[6];

    buffer[0] = -52;
    buffer[1] = 35;
    buffer[2] = 2;
    buffer[3] = register[0];
    buffer[4] = register[1];
    buffer[5] = register[2];

    this.adapter.dataBlock(buffer, 0, 6);
  }

  public boolean isVccPowered(byte[] register)
    throws OneWireIOException, OneWireException
  {
    return (register[2] & 0xFFFFFF80) == -128;
  }

  public boolean getDefaultPolarity(byte[] register)
  {
    return (register[2] & 0x40) == 64;
  }

  public boolean getPowerOnResetLatch(byte[] register)
  {
    return (register[2] & 0x8) == 8;
  }

  public void clearPowerOnReset(byte[] register)
  {
    if ((register[2] & 0x8) == 8)
    {
      register[2] = (byte)(register[2] & 0xFFFFFFF7);
    }
  }

  public void orConditionalSearch(byte[] register)
  {
    if ((register[2] & 0x2) == 2)
    {
      register[2] = (byte)(register[2] & 0xFFFFFFFD);
    }
  }

  public void andConditionalSearch(byte[] register)
  {
    if ((register[2] & 0x2) != 2)
    {
      register[2] = (byte)(register[2] | 0x2);
    }
  }

  public void setConditionalSearchLogicLevel(byte[] register)
  {
    if ((register[2] & 0x1) == 1)
    {
      register[2] = (byte)(register[2] & 0xFFFFFFFE);
    }
  }

  public void setConditionalSearchActivity(byte[] register)
  {
    if ((register[2] & 0x1) != 1)
    {
      register[2] = (byte)(register[2] | 0x1);
    }
  }

  public void setChannelMask(int channel, boolean set, byte[] register)
  {
    byte mask = (byte)(1 << channel);

    if (set)
      register[0] = (byte)(register[0] | mask);
    else
      register[0] = (byte)(register[0] & (byte)(mask ^ 0xFFFFFFFF));
  }

  public void setChannelPolarity(int channel, boolean set, byte[] register)
  {
    byte polarity = (byte)(1 << channel);

    if (set)
      register[1] = (byte)(register[1] | polarity);
    else
      register[1] = (byte)(register[1] & (byte)(polarity ^ 0xFFFFFFFF));
  }

  public boolean getChannelMask(int channel, byte[] register)
  {
    byte mask = (byte)(1 << channel);

    return (register[0] & mask) == mask;
  }

  public boolean getChannelPolarity(int channel, byte[] register)
  {
    byte polarity = (byte)(1 << channel);

    return (register[1] & polarity) == polarity;
  }

  private void initmem()
  {
    this.scratch = new MemoryBankScratchEE(this);
    this.scratch.bankDescription = "Scratchpad";
    ((MemoryBankScratchEE)this.scratch).COPY_DELAY_LEN = 18;
    ((MemoryBankScratchEE)this.scratch).numVerificationBytes = 2;

    this.mainMemory = new MemoryBankNV(this, this.scratch);
    this.mainMemory.bankDescription = "User Data Memory";
    this.mainMemory.startPhysicalAddress = 0;
    this.mainMemory.size = 512;
    this.mainMemory.readOnly = false;
    this.mainMemory.generalPurposeMemory = true;
    this.mainMemory.readWrite = true;
    this.mainMemory.powerDelivery = true;

    this.protectionMemory = new MemoryBankNV(this, this.scratch);
    this.protectionMemory.bankDescription = "Protection Control and Factory Bytes";
    this.protectionMemory.startPhysicalAddress = 512;
    this.protectionMemory.size = 32;
    this.protectionMemory.readOnly = false;
    this.protectionMemory.generalPurposeMemory = false;
    this.protectionMemory.readWrite = true;
    this.protectionMemory.powerDelivery = true;

    this.pioMemory = new MemoryBankNV(this, this.scratch);
    this.pioMemory.bankDescription = "PIO Readouts";
    this.pioMemory.startPhysicalAddress = 544;
    this.pioMemory.size = 3;
    this.pioMemory.readOnly = true;
    this.pioMemory.generalPurposeMemory = false;
    this.pioMemory.nonVolatile = false;
    this.pioMemory.readWrite = false;
    this.pioMemory.powerDelivery = false;

    this.searchMemory = new MemoryBankNV(this, this.scratch);
    this.searchMemory.bankDescription = "Conditional Search and Status Register";
    this.searchMemory.startPhysicalAddress = 547;
    this.searchMemory.size = 3;
    this.searchMemory.readOnly = true;
    this.searchMemory.generalPurposeMemory = false;
    this.searchMemory.nonVolatile = false;
    this.searchMemory.readWrite = false;
    this.searchMemory.powerDelivery = false;
  }
}