package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.OneWireIOException;

public abstract interface OTPMemoryBank extends PagedMemoryBank
{
  public abstract boolean canRedirectPage();

  public abstract boolean canLockPage();

  public abstract boolean canLockRedirectPage();

  public abstract void lockPage(int paramInt)
    throws OneWireIOException, OneWireException;

  public abstract boolean isPageLocked(int paramInt)
    throws OneWireIOException, OneWireException;

  public abstract void redirectPage(int paramInt1, int paramInt2)
    throws OneWireIOException, OneWireException;

  /** @deprecated */
  public abstract int isPageRedirected(int paramInt)
    throws OneWireIOException, OneWireException;

  public abstract int getRedirectedPage(int paramInt)
    throws OneWireIOException, OneWireException;

  public abstract void lockRedirectPage(int paramInt)
    throws OneWireIOException, OneWireException;

  public abstract boolean isRedirectPageLocked(int paramInt)
    throws OneWireIOException, OneWireException;
}