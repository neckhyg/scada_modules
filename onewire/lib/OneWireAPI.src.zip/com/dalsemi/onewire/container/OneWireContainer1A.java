package com.dalsemi.onewire.container;

import com.dalsemi.onewire.adapter.DSPortAdapter;
import java.util.Enumeration;
import java.util.Vector;

public class OneWireContainer1A extends OneWireContainer
{
  public OneWireContainer1A()
  {
  }

  public OneWireContainer1A(DSPortAdapter sourceAdapter, byte[] newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public OneWireContainer1A(DSPortAdapter sourceAdapter, long newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public OneWireContainer1A(DSPortAdapter sourceAdapter, String newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public String getName()
  {
    return "DS1963L";
  }

  public String getAlternateNames()
  {
    return "Monetary iButton";
  }

  public String getDescription()
  {
    return "4096 bit read/write nonvolatile memory with four 32-bit read-only non rolling-over page write cycle counters and tamper-detect bits for small money storage";
  }

  public int getMaxSpeed()
  {
    return 2;
  }

  public Enumeration getMemoryBanks()
  {
    Vector bank_vector = new Vector(3);

    MemoryBankScratch scratch = new MemoryBankScratchEx(this);

    bank_vector.addElement(scratch);

    MemoryBankNV nv = new MemoryBankNVCRC(this, scratch);

    nv.numberPages = 12;
    nv.size = 384;
    nv.extraInfoLength = 8;

    bank_vector.addElement(nv);

    nv = new MemoryBankNVCRC(this, scratch);
    nv.numberPages = 4;
    nv.size = 128;
    nv.bankDescription = "Memory with write cycle counter";
    nv.startPhysicalAddress = 384;
    nv.extraInfo = true;
    nv.extraInfoDescription = "Write cycle counter";
    nv.extraInfoLength = 8;

    bank_vector.addElement(nv);

    return bank_vector.elements();
  }
}