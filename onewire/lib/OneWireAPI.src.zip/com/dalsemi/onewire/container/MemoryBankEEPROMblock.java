package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import com.dalsemi.onewire.utils.CRC16;

class MemoryBankEEPROMblock
  implements OTPMemoryBank
{
  private static final byte WRITE_DATA_COMMAND = 108;
  private static final byte READ_DATA_COMMAND = 105;
  private static final byte COPY_DATA_COMMAND = 72;
  private static final byte RECALL_DATA_COMMAND = -72;
  protected OneWireContainer30 ib;
  protected byte[] ffBlock = new byte[32];
  protected boolean doSetSpeed;
  protected int size;
  protected int startPhysicalAddress;
  protected boolean writeVerification;
  protected int numberPages;
  protected int pageLength;
  protected int maxPacketDataLength;
  protected boolean lockPage0;
  protected boolean lockPage1;

  public MemoryBankEEPROMblock(OneWireContainer30 ibutton)
  {
    this.ib = ibutton;

    this.numberPages = 2;
    this.size = 32;
    this.pageLength = 16;
    this.maxPacketDataLength = 13;
    try
    {
      this.lockPage0 = this.ib.getFlag(7, 1);

      this.lockPage1 = this.ib.getFlag(7, 2);
    }
    catch (Exception ioe)
    {
      ioe.printStackTrace();
    }

    this.writeVerification = false;
    this.startPhysicalAddress = 32;
    this.doSetSpeed = true;

    for (int i = 0; i < 32; i++)
      this.ffBlock[i] = -1;
  }

  public String getBankDescription()
  {
    return "EEPROM memory for DS2760";
  }

  public boolean isGeneralPurposeMemory()
  {
    return true;
  }

  public boolean isReadWrite()
  {
    return (!this.lockPage0) || (!this.lockPage1);
  }

  public boolean isWriteOnce()
  {
    return false;
  }

  public boolean isReadOnly()
  {
    return (this.lockPage0) && (this.lockPage1);
  }

  public boolean isNonVolatile()
  {
    return true;
  }

  public boolean needsProgramPulse()
  {
    return false;
  }

  public boolean needsPowerDelivery()
  {
    return false;
  }

  public int getStartPhysicalAddress()
  {
    return this.startPhysicalAddress;
  }

  public int getSize()
  {
    return this.size;
  }

  public int getNumberPages()
  {
    return this.numberPages;
  }

  public int getPageLength()
  {
    return this.pageLength;
  }

  public int getMaxPacketDataLength()
  {
    return this.maxPacketDataLength;
  }

  public boolean hasPageAutoCRC()
  {
    return false;
  }

  /** @deprecated */
  public boolean haveExtraInfo()
  {
    return false;
  }

  public boolean hasExtraInfo()
  {
    return false;
  }

  public int getExtraInfoLength()
  {
    return 0;
  }

  public String getExtraInfoDescription()
  {
    return null;
  }

  public void setWriteVerification(boolean doReadVerf)
  {
    this.writeVerification = doReadVerf;
  }

  public boolean canRedirectPage()
  {
    return false;
  }

  public boolean canLockPage()
  {
    return true;
  }

  public boolean canLockRedirectPage()
  {
    return false;
  }

  public void read(int startAddr, boolean readContinue, byte[] readBuf, int offset, int len)
    throws OneWireIOException, OneWireException
  {
    byte[] buffer = new byte[18];

    if (startAddr + len > 32)
      throw new OneWireException("Read exceeds memory bank end");
    byte memAddr;
    if (startAddr < 16)
      memAddr = (byte)this.startPhysicalAddress;
    else {
      memAddr = (byte)(this.startPhysicalAddress + 16);
    }

    this.ib.doSpeed();
    this.ib.adapter.reset();

    if (this.ib.adapter.select(this.ib.address))
    {
      buffer[0] = -72;
      buffer[1] = memAddr;

      this.ib.adapter.dataBlock(buffer, 0, 2);

      this.ib.adapter.reset();
      this.ib.adapter.select(this.ib.address);

      buffer[0] = 105;

      System.arraycopy(this.ffBlock, 0, buffer, 2, 16);

      this.ib.adapter.dataBlock(buffer, 0, 18);
      int i;
      if ((startAddr < 16) && (startAddr + len < 16))
      {
        for (i = startAddr; i < startAddr + len; i++)
          readBuf[(offset + i - startAddr)] = buffer[(i + 2)];
      }
      else if (startAddr >= 16)
      {
        for (i = startAddr; i < startAddr + len; i++)
          readBuf[(offset + i - startAddr)] = buffer[(i - startAddr + 2 + (startAddr - 16))];
      }
      else
      {
        for (i = startAddr; i < 16; i++) {
          readBuf[(offset + i - startAddr)] = buffer[(i + 2)];
        }
        this.ib.adapter.reset();
        this.ib.adapter.select(this.ib.address);

        buffer[0] = -72;
        buffer[1] = (byte)(memAddr + 16);

        this.ib.adapter.dataBlock(buffer, 0, 2);

        this.ib.adapter.reset();
        this.ib.adapter.select(this.ib.address);

        buffer[0] = 105;

        System.arraycopy(this.ffBlock, 0, buffer, 2, 16);

        this.ib.adapter.dataBlock(buffer, 0, 18);

        for (i = 16; i < startAddr + len; i++)
          readBuf[(i + offset - startAddr)] = buffer[(i - 14)];
      }
    }
    else {
      throw new OneWireException("OneWireContainer30-Device not found.");
    }
  }

  public void write(int startAddr, byte[] writeBuf, int offset, int len)
    throws OneWireIOException, OneWireException
  {
    byte[] buffer = new byte[18];
    byte[] memory = new byte[32];

    if (startAddr + len > 32)
      throw new OneWireException("Write exceeds memory bank end");
    byte memAddr;
    if (startAddr < 16)
      memAddr = (byte)this.startPhysicalAddress;
    else {
      memAddr = (byte)(this.startPhysicalAddress + 16);
    }

    if (((this.lockPage0) && (memAddr == 32)) || ((this.lockPage1) && (memAddr == 48))) {
      throw new OneWireIOException("OneWireContainer30-Cant write data to locked EEPROM block.");
    }

    read(0, false, memory, 0, 32);

    System.arraycopy(writeBuf, offset, memory, startAddr, len);

    this.ib.doSpeed();
    this.ib.adapter.reset();

    if (this.ib.adapter.select(this.ib.address))
    {
      buffer[0] = 108;
      buffer[1] = memAddr;
      int modify;
      if (memAddr == 32)
      {
        System.arraycopy(memory, 0, buffer, 2, 16);
        modify = 0;
      }
      else
      {
        System.arraycopy(memory, 16, buffer, 2, 16);
        modify = 16;
      }

      this.ib.adapter.dataBlock(buffer, 0, 18);

      this.ib.adapter.reset();
      this.ib.adapter.select(this.ib.address);

      buffer[0] = 105;

      System.arraycopy(this.ffBlock, 0, buffer, 2, 16);

      this.ib.adapter.dataBlock(buffer, 0, 18);

      for (int i = 0; i < 16; i++) {
        if (buffer[(i + 2)] != memory[(i + modify)]) {
          throw new OneWireIOException("Error writing EEPROM memory bank");
        }
      }

      this.ib.adapter.reset();
      this.ib.adapter.select(this.ib.address);

      buffer[0] = 72;

      this.ib.adapter.dataBlock(buffer, 0, 2);

      if ((startAddr < 16) && (startAddr + len >= 16))
      {
        memAddr = 48;
        this.ib.adapter.reset();

        if (this.ib.adapter.select(this.ib.address))
        {
          buffer[0] = 108;
          buffer[1] = memAddr;

          System.arraycopy(memory, 16, buffer, 2, 16);

          this.ib.adapter.dataBlock(buffer, 0, 18);

          this.ib.adapter.reset();
          this.ib.adapter.select(this.ib.address);

          buffer[0] = 105;

          System.arraycopy(this.ffBlock, 0, buffer, 2, 16);

          this.ib.adapter.dataBlock(buffer, 0, 18);

          for (i = 0; i < 16; i++) {
            if (buffer[(i + 2)] != memory[(i + 16)]) {
              throw new OneWireIOException("Error writing EEPROM memory bank");
            }
          }

          this.ib.adapter.reset();
          this.ib.adapter.select(this.ib.address);

          buffer[0] = 72;

          this.ib.adapter.dataBlock(buffer, 0, 2);
        }
      }
    }
    else {
      throw new OneWireException("OneWireContainer30-Device not found.");
    }
  }

  public void readPage(int page, boolean readContinue, byte[] readBuf, int offset)
    throws OneWireIOException, OneWireException
  {
    read(page * this.pageLength, readContinue, readBuf, offset, this.pageLength);
  }

  public void readPage(int page, boolean readContinue, byte[] readBuf, int offset, byte[] extraInfo)
    throws OneWireIOException, OneWireException
  {
    throw new OneWireException("Read extra information not supported on this memory bank");
  }

  public int readPagePacket(int page, boolean readContinue, byte[] readBuf, int offset, byte[] extraInfo)
    throws OneWireIOException, OneWireException
  {
    throw new OneWireException("Read extra information not supported on this memory bank");
  }

  public int readPagePacket(int page, boolean readContinue, byte[] readBuf, int offset)
    throws OneWireIOException, OneWireException
  {
    byte[] raw_buf = new byte[this.pageLength];

    read(page * this.pageLength, readContinue, raw_buf, 0, this.pageLength);

    if ((raw_buf[0] & 0xFF) > this.maxPacketDataLength)
    {
      forceVerify();

      throw new OneWireIOException("Invalid length in packet");
    }

    if (CRC16.compute(raw_buf, 0, raw_buf[0] + 3, page) == 45057)
    {
      System.arraycopy(raw_buf, 1, readBuf, offset, raw_buf[0]);

      return raw_buf[0];
    }

    forceVerify();

    throw new OneWireIOException("Invalid CRC16 in packet read");
  }

  public void writePagePacket(int page, byte[] writeBuf, int offset, int len)
    throws OneWireIOException, OneWireException
  {
    if (len > this.maxPacketDataLength) {
      throw new OneWireIOException("Length of packet requested exceeds page size");
    }

    byte[] raw_buf = new byte[len + 3];

    raw_buf[0] = (byte)len;

    System.arraycopy(writeBuf, offset, raw_buf, 1, len);

    int crc = CRC16.compute(raw_buf, 0, len + 1, page);

    raw_buf[(len + 1)] = (byte)((crc ^ 0xFFFFFFFF) & 0xFF);
    raw_buf[(len + 2)] = (byte)(((crc ^ 0xFFFFFFFF) & 0xFFFF) >>> 8 & 0xFF);

    write(page * this.pageLength, raw_buf, 0, len + 3);
  }

  public void readPageCRC(int page, boolean readContinue, byte[] readBuf, int offset)
    throws OneWireIOException, OneWireException
  {
    throw new OneWireException("Read page with CRC not supported in this memory bank");
  }

  public void readPageCRC(int page, boolean readContinue, byte[] readBuf, int offset, byte[] extraInfo)
    throws OneWireIOException, OneWireException
  {
    throw new OneWireException("Read page with CRC not supported in this memory bank");
  }

  public void lockPage(int page)
    throws OneWireIOException, OneWireException
  {
    if (page > 1) {
      throw new OneWireException("Page does not exist to lock");
    }
    this.ib.setFlag(7, 64, true);

    if (page == 0)
    {
      this.ib.setFlag(7, 1, true);
    }
    else if (page == 1)
    {
      this.ib.setFlag(7, 2, true);
    }

    if (!isPageLocked(page))
    {
      forceVerify();

      throw new OneWireIOException("Read back from write incorrect, could not lock page");
    }

    if (page == 0)
    {
      this.lockPage0 = true;
    }
    else if (page == 1)
    {
      this.lockPage1 = true;
    }
  }

  public boolean isPageLocked(int page)
    throws OneWireIOException, OneWireException
  {
    boolean flag = false;

    if (page > 1) {
      throw new OneWireException("Page does not exist to be locked");
    }
    if (page == 0)
    {
      flag = this.ib.getFlag(7, 1);
    }
    else if (page == 1)
    {
      flag = this.ib.getFlag(7, 2);
    }

    return flag;
  }

  public void redirectPage(int page, int newPage)
    throws OneWireIOException, OneWireException
  {
    throw new OneWireException("This memory bank does not support redirection.");
  }

  /** @deprecated */
  public int isPageRedirected(int page)
    throws OneWireIOException, OneWireException
  {
    throw new OneWireException("This memory bank does not support redirection.");
  }

  public int getRedirectedPage(int page)
    throws OneWireIOException, OneWireException
  {
    throw new OneWireException("This memory bank does not support redirection.");
  }

  public void lockRedirectPage(int page)
    throws OneWireIOException, OneWireException
  {
    throw new OneWireException("This memory bank does not support redirection.");
  }

  public boolean isRedirectPageLocked(int page)
    throws OneWireIOException, OneWireException
  {
    throw new OneWireException("This memory bank does not support redirection.");
  }

  public void checkSpeed()
    throws OneWireIOException, OneWireException
  {
    synchronized (this)
    {
      if (this.doSetSpeed)
      {
        this.ib.doSpeed();

        this.doSetSpeed = false;
      }
    }
  }

  public void forceVerify()
  {
    synchronized (this)
    {
      this.doSetSpeed = true;
    }
  }
}