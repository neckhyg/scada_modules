package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import com.dalsemi.onewire.utils.SHA;
import java.util.Enumeration;
import java.util.Vector;

public class OneWireContainer33 extends OneWireContainer
{
  private static final boolean DEBUG = false;
  private byte[] secret = new byte[8];

  private byte[] challenge = new byte[3];
  private MemoryBankScratchSHAEE mbScratchpad;
  private MemoryBankSHAEE memstatus;
  private final MemoryBankSHAEE[] memoryPages = new MemoryBankSHAEE[4];

  private byte[] MAC_buffer = new byte[20];
  protected boolean secretSet;
  protected boolean secretProtected;
  protected boolean setAdapter;
  protected boolean container_check;
  protected static final byte[] ffBlock = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };

  protected static final byte[] zeroBlock = { 0, 0, 0, 0, 0, 0, 0, 0 };

  private static final byte[] ACTIVATION_BYTE = { -86 };

  public OneWireContainer33()
  {
    System.arraycopy(ffBlock, 0, this.secret, 0, 8);
    System.arraycopy(ffBlock, 0, this.challenge, 0, 3);

    this.setAdapter = false;
    this.container_check = false;
  }

  public OneWireContainer33(DSPortAdapter sourceAdapter, byte[] newAddress)
  {
    super(sourceAdapter, newAddress);

    System.arraycopy(ffBlock, 0, this.secret, 0, 8);
    System.arraycopy(ffBlock, 0, this.challenge, 0, 3);

    this.setAdapter = true;
    this.container_check = false;
    initmem();
  }

  public OneWireContainer33(DSPortAdapter sourceAdapter, long newAddress)
  {
    super(sourceAdapter, newAddress);

    System.arraycopy(ffBlock, 0, this.secret, 0, 8);
    System.arraycopy(ffBlock, 0, this.challenge, 0, 3);

    this.setAdapter = true;
    this.container_check = false;
    initmem();
  }

  public OneWireContainer33(DSPortAdapter sourceAdapter, String newAddress)
  {
    super(sourceAdapter, newAddress);

    System.arraycopy(ffBlock, 0, this.secret, 0, 8);
    System.arraycopy(ffBlock, 0, this.challenge, 0, 3);

    this.setAdapter = true;
    this.container_check = false;
    initmem();
  }

  protected boolean adapterSet()
  {
    return this.setAdapter;
  }

  public void setupContainer(DSPortAdapter sourceAdapter, byte[] newAddress)
  {
    super.setupContainer(sourceAdapter, newAddress);

    if (!this.setAdapter) {
      initmem();
    }
    this.setAdapter = true;
  }

  public void setupContainer(DSPortAdapter sourceAdapter, long newAddress)
  {
    super.setupContainer(sourceAdapter, newAddress);

    if (!this.setAdapter) {
      initmem();
    }
    this.setAdapter = true;
  }

  public void setupContainer(DSPortAdapter sourceAdapter, String newAddress)
  {
    super.setupContainer(sourceAdapter, newAddress);

    if (!this.setAdapter) {
      initmem();
    }
    this.setAdapter = true;
  }

  public String getName()
  {
    return "DS1961S";
  }

  public String getAlternateNames()
  {
    return "DS2432";
  }

  public String getDescription()
  {
    return "1K-Bit protected 1-Wire EEPROM with SHA-1 Engine.";
  }

  public int getMaxSpeed()
  {
    return 2;
  }

  public Enumeration getMemoryBanks()
  {
    Vector bank_vector = new Vector(4);

    bank_vector.addElement(this.mbScratchpad);
    bank_vector.addElement(this.memoryPages[0]);
    bank_vector.addElement(this.memoryPages[1]);
    bank_vector.addElement(this.memoryPages[2]);
    bank_vector.addElement(this.memstatus);

    return bank_vector.elements();
  }

  public MemoryBankScratchSHAEE getScratchpadMemoryBank()
  {
    return this.mbScratchpad;
  }

  public MemoryBankSHAEE getStatusPageMemoryBank()
  {
    return this.memstatus;
  }

  public MemoryBankSHAEE getMemoryBankForPage(int page)
  {
    if (page == 3)
      page = 2;
    return this.memoryPages[page];
  }

  public void setContainerSecret(byte[] newSecret, int offset)
  {
    System.arraycopy(newSecret, offset, this.secret, 0, 8);
    this.secretSet = true;
  }

  public void getContainerSecret(byte[] secretBuf, int offset)
  {
    System.arraycopy(this.secret, 0, secretBuf, offset, 8);
  }

  public boolean isContainerSecretSet()
    throws OneWireIOException, OneWireException
  {
    return this.secretSet;
  }

  public boolean isSecretWriteProtected()
    throws OneWireIOException, OneWireException
  {
    if (!this.container_check) {
      this.container_check = checkStatus();
    }
    return this.secretProtected;
  }

  public void setChallenge(byte[] challengeset, int offset)
  {
    System.arraycopy(challengeset, offset, this.challenge, 0, 3);
  }

  public void getChallenge(byte[] get, int offset)
  {
    System.arraycopy(this.challenge, 0, get, offset, 3);
  }

  public boolean isWriteProtectAllSet()
    throws OneWireIOException, OneWireException
  {
    if (!this.container_check) {
      this.container_check = checkStatus();
    }
    return this.memoryPages[2].readOnly;
  }

  public void writeProtectSecret()
    throws OneWireIOException, OneWireException
  {
    if (!this.container_check) {
      this.container_check = checkStatus();
    }

    this.memstatus.write(8, ACTIVATION_BYTE, 0, 1);

    this.secretProtected = true;
  }

  public void writeProtectAll()
    throws OneWireIOException, OneWireException
  {
    if (!this.container_check) {
      this.container_check = checkStatus();
    }

    this.memstatus.write(9, ACTIVATION_BYTE, 0, 1);

    this.memoryPages[0].writeprotect();
    this.memoryPages[1].writeprotect();
    this.memoryPages[2].writeprotect();
  }

  public void setEPROMModePageOne()
    throws OneWireIOException, OneWireException
  {
    if (!this.container_check) {
      this.container_check = checkStatus();
    }

    this.memstatus.write(12, ACTIVATION_BYTE, 0, 1);

    this.memoryPages[1].setEPROM();
  }

  public boolean isPageOneEPROMmode()
    throws OneWireIOException, OneWireException
  {
    if (!this.container_check) {
      this.container_check = checkStatus();
    }
    return this.memoryPages[1].isWriteOnce();
  }

  public void writeProtectPageZero()
    throws OneWireIOException, OneWireException
  {
    if (!this.container_check) {
      this.container_check = checkStatus();
    }

    this.memstatus.write(13, ACTIVATION_BYTE, 0, 1);

    this.memoryPages[0].writeprotect();
  }

  public boolean isWriteProtectPageZeroSet()
    throws OneWireIOException, OneWireException
  {
    if (!this.container_check) {
      this.container_check = checkStatus();
    }
    return this.memoryPages[0].isReadOnly();
  }

  public void computeNextSecret(int pageNum, byte[] partialsecret, int offset)
    throws OneWireIOException, OneWireException
  {
    if (!this.container_check) {
      this.container_check = checkStatus();
    }
    this.mbScratchpad.computeNextSecret(pageNum * 32, partialsecret, offset);
  }

  public void computeNextSecret(int pageNum)
    throws OneWireIOException, OneWireException
  {
    if (!this.container_check) {
      this.container_check = checkStatus();
    }
    this.mbScratchpad.computeNextSecret(pageNum * 32);
  }

  public boolean loadFirstSecret(byte[] data, int offset)
    throws OneWireIOException, OneWireException
  {
    if (!this.container_check) {
      this.container_check = checkStatus();
    }
    this.mbScratchpad.loadFirstSecret(128, data, offset);
    return true;
  }

  public boolean refreshPage(int page, int offset)
    throws OneWireException, OneWireIOException
  {
    if (!this.container_check) {
      this.container_check = checkStatus();
    }
    int addr = page * 32 + offset;
    try
    {
      this.mbScratchpad.refreshScratchpad(addr);
    }
    catch (OneWireException owe)
    {
      return false;
    }

    this.mbScratchpad.loadFirstSecret(addr);
    return true;
  }

  public boolean refreshPage(int page)
    throws OneWireException, OneWireIOException
  {
    return (refreshPage(page, 0)) && (refreshPage(page, 8)) && (refreshPage(page, 16)) && (refreshPage(page, 24));
  }

  protected boolean checkStatus()
    throws OneWireIOException, OneWireException
  {
    if (!this.container_check)
    {
      byte[] mem = new byte[8];

      this.memstatus.read(8, false, mem, 0, 8);

      if ((mem[0] == -86) || (mem[0] == 85))
        this.secretProtected = true;
      else {
        this.secretProtected = false;
      }
      if ((mem[1] == -86) || (mem[1] == 85) || (mem[5] == -86) || (mem[5] == 85))
      {
        this.memoryPages[0].readWrite = false;
        this.memoryPages[0].readOnly = true;
      }
      else
      {
        this.memoryPages[0].readWrite = true;
        this.memoryPages[0].readOnly = false;
      }

      if ((mem[4] == -86) || (mem[4] == 85))
        this.memoryPages[1].writeOnce = true;
      else {
        this.memoryPages[1].writeOnce = false;
      }
      if ((mem[1] == -86) || (mem[1] == 85))
      {
        this.memoryPages[1].readWrite = false;
        this.memoryPages[1].readOnly = true;
      }
      else
      {
        this.memoryPages[1].readWrite = true;
        this.memoryPages[1].readOnly = false;
      }

      if ((mem[1] == -86) || (mem[1] == 85))
      {
        this.memoryPages[2].readWrite = false;
        this.memoryPages[2].readOnly = true;
      }
      else
      {
        this.memoryPages[2].readWrite = true;
        this.memoryPages[2].readOnly = false;
      }

      this.memstatus.checked = true;
      this.memoryPages[0].checked = true;
      this.memoryPages[1].checked = true;
      this.memoryPages[2].checked = true;
      this.container_check = true;
    }

    return this.container_check;
  }

  private void initmem()
  {
    this.secretSet = false;

    this.mbScratchpad = new MemoryBankScratchSHAEE(this);

    this.memstatus = new MemoryBankSHAEE(this, this.mbScratchpad);
    this.memstatus.bankDescription = "Status Page that contains the secret and the status.";
    this.memstatus.generalPurposeMemory = true;
    this.memstatus.startPhysicalAddress = 128;
    this.memstatus.size = 32;
    this.memstatus.numberPages = 1;
    this.memstatus.pageLength = 32;
    this.memstatus.maxPacketDataLength = 29;
    this.memstatus.extraInfo = false;
    this.memstatus.extraInfoLength = 20;
    this.memstatus.readWrite = false;
    this.memstatus.writeOnce = false;
    this.memstatus.pageCRC = false;
    this.memstatus.readOnly = false;
    this.memstatus.checked = false;

    this.memoryPages[0] = new MemoryBankSHAEE(this, this.mbScratchpad);
    this.memoryPages[0].bankDescription = "Page Zero with write protection.";
    this.memoryPages[0].generalPurposeMemory = true;
    this.memoryPages[0].startPhysicalAddress = 0;
    this.memoryPages[0].size = 32;
    this.memoryPages[0].numberPages = 1;
    this.memoryPages[0].pageLength = 32;
    this.memoryPages[0].maxPacketDataLength = 29;
    this.memoryPages[0].extraInfo = true;
    this.memoryPages[0].extraInfoLength = 20;
    this.memoryPages[0].writeOnce = false;
    this.memoryPages[0].pageCRC = true;
    this.memoryPages[0].checked = false;

    this.memoryPages[1] = new MemoryBankSHAEE(this, this.mbScratchpad);
    this.memoryPages[1].bankDescription = "Page One with EPROM mode and write protection.";
    this.memoryPages[1].generalPurposeMemory = true;
    this.memoryPages[1].startPhysicalAddress = 32;
    this.memoryPages[1].size = 32;
    this.memoryPages[1].numberPages = 1;
    this.memoryPages[1].pageLength = 32;
    this.memoryPages[1].maxPacketDataLength = 29;
    this.memoryPages[1].extraInfo = true;
    this.memoryPages[1].extraInfoLength = 20;
    this.memoryPages[1].pageCRC = true;
    this.memoryPages[1].checked = false;

    this.memoryPages[2] = new MemoryBankSHAEE(this, this.mbScratchpad);
    this.memoryPages[2].bankDescription = "Page Two and Three with write protection.";
    this.memoryPages[2].generalPurposeMemory = true;
    this.memoryPages[2].startPhysicalAddress = 64;
    this.memoryPages[2].size = 64;
    this.memoryPages[2].numberPages = 2;
    this.memoryPages[2].pageLength = 32;
    this.memoryPages[2].maxPacketDataLength = 29;
    this.memoryPages[2].extraInfo = true;
    this.memoryPages[2].extraInfoLength = 20;
    this.memoryPages[2].writeOnce = false;
    this.memoryPages[2].pageCRC = true;
    this.memoryPages[2].checked = false;

    this.memoryPages[3] = this.memoryPages[2];
  }

  public static boolean isMACValid(int addr, byte[] SerNum, byte[] memory, byte[] mac, byte[] challenge, byte[] secret)
  {
    byte[] MT = new byte[64];

    System.arraycopy(secret, 0, MT, 0, 4);
    System.arraycopy(memory, 0, MT, 4, 32);
    System.arraycopy(ffBlock, 0, MT, 36, 4);

    MT[40] = (byte)(0x40 | addr << 3 & 0x8 | addr >>> 5 & 0x7);

    System.arraycopy(SerNum, 0, MT, 41, 7);
    System.arraycopy(secret, 4, MT, 48, 4);
    System.arraycopy(challenge, 0, MT, 52, 3);

    MT[55] = -128;
    for (int i = 56; i < 62; i++)
      MT[i] = 0;
    MT[62] = 1;
    MT[63] = -72;

    int[] AtoE = new int[5];
    SHA.ComputeSHA(MT, AtoE);

    int cnt = 0;
    for (int i = 0; i < 5; i++)
    {
      int temp = AtoE[(4 - i)];
      for (int j = 0; j < 4; j++)
      {
        if (mac[(cnt++)] != (byte)(temp & 0xFF))
        {
          return false;
        }
        temp >>>= 8;
      }
    }

    return true;
  }

  public boolean installMasterSecret(int page, byte[] newSecret)
    throws OneWireIOException, OneWireException
  {
    for (int i = 0; i < this.secret.length; i++)
      this.secret[i] = 0;
    if (loadFirstSecret(this.secret, 0))
    {
      if (newSecret.length == 0) {
        return false;
      }
      byte[] input_secret = null;
      byte[] sp_buffer = new byte[8];
      int secret_mod_length = newSecret.length % 47;

      if (secret_mod_length == 0) {
        input_secret = newSecret;
      }
      else {
        input_secret = new byte[newSecret.length + (47 - secret_mod_length)];

        System.arraycopy(newSecret, 0, input_secret, 0, newSecret.length);
      }

      for (int i = 0; i < input_secret.length; i += 47)
      {
        writeDataPage(page, input_secret, i);
        System.arraycopy(input_secret, i + 36, sp_buffer, 0, 8);
        this.mbScratchpad.computeNextSecret(page * 32, sp_buffer, 0);
      }
      return true;
    }

    throw new OneWireException("Load first secret failed");
  }

  public boolean bindSecretToiButton(int pageNum, byte[] bindData)
    throws OneWireIOException, OneWireException
  {
    if (!writeDataPage(pageNum, bindData)) {
      return false;
    }
    byte[] bind_code = new byte[8];
    bind_code[0] = (byte)pageNum;
    System.arraycopy(this.address, 0, bind_code, 1, 7);
    this.mbScratchpad.computeNextSecret(pageNum * 32, bind_code, 0);

    return true;
  }

  public boolean writeDataPage(int targetPage, byte[] pageData)
    throws OneWireIOException, OneWireException
  {
    return writeDataPage(targetPage, pageData, 0);
  }

  public boolean writeDataPage(int targetPage, byte[] pageData, int offset)
    throws OneWireIOException, OneWireException
  {
    int addr = 0;
    if (targetPage == 3)
      addr = 32;
    this.memoryPages[targetPage].write(addr, pageData, offset, 32);
    return true;
  }

  public boolean writeScratchpad(int targetPage, int targetPageOffset, byte[] inputbuffer, int start, int length)
    throws OneWireIOException, OneWireException
  {
    int addr = (targetPage << 5) + targetPageOffset;
    this.mbScratchpad.writeScratchpad(addr, inputbuffer, start, length);
    return true;
  }

  public void readScratchpad(byte[] scratchpad, int offset, byte[] extraInfo)
    throws OneWireIOException, OneWireException
  {
    this.mbScratchpad.readScratchpad(scratchpad, offset, 8, extraInfo);
  }

  public boolean copyScratchpad(int targetPage, int targetPageOffset, byte[] copy_auth, int authStart)
    throws OneWireIOException, OneWireException
  {
    int addr = (targetPage << 5) + targetPageOffset;
    this.mbScratchpad.copyScratchpadWithMAC(addr, copy_auth, authStart);
    return true;
  }

  public boolean copyScratchpad(int targetPage, int targetPageOffset)
    throws OneWireIOException, OneWireException
  {
    int addr = (targetPage << 5) + targetPageOffset;
    this.mbScratchpad.copyScratchpad(addr, 8);

    return true;
  }

  public boolean readMemoryPage(int page, byte[] pageData, int offset)
    throws OneWireIOException, OneWireException
  {
    int addr = 0;
    if (page == 3)
      addr = 32;
    this.memoryPages[page].read(addr, false, pageData, offset, 32);
    return true;
  }

  public boolean readAuthenticatedPage(int page, byte[] pagedata, int offset, byte[] computed_mac, int macStart)
    throws OneWireIOException, OneWireException
  {
    int mbPage = 0;
    if (page == 3)
    {
      mbPage = 1;
      page = 2;
    }
    return this.memoryPages[page].readAuthenticatedPage(mbPage, pagedata, offset, computed_mac, macStart);
  }
}