package com.dalsemi.onewire.container;

import com.dalsemi.onewire.adapter.DSPortAdapter;
import java.util.Enumeration;
import java.util.Vector;

public class OneWireContainer09 extends OneWireContainer
{
  public OneWireContainer09()
  {
  }

  public OneWireContainer09(DSPortAdapter sourceAdapter, byte[] newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public OneWireContainer09(DSPortAdapter sourceAdapter, long newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public OneWireContainer09(DSPortAdapter sourceAdapter, String newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public String getName()
  {
    return "DS1982";
  }

  public String getAlternateNames()
  {
    return "DS2502";
  }

  public String getDescription()
  {
    return "1024 bit Electrically Programmable Read Only Memory (EPROM) partitioned into four 256 bit pages.Each memory page can be permanently write-protected to prevent tampering.  Architecture allows software to patch data by supersending a used page in favor of a newly programmed page.";
  }

  public int getMaxSpeed()
  {
    return 2;
  }

  public Enumeration getMemoryBanks()
  {
    Vector bank_vector = new Vector(2);

    MemoryBankEPROM mn = new MemoryBankEPROM(this);

    mn.numberPages = 4;
    mn.size = 128;
    mn.pageLength = 32;
    mn.extraInfo = false;
    mn.extraInfoLength = 0;
    mn.extraInfoDescription = null;
    mn.numCRCBytes = 1;
    mn.normalReadCRC = true;
    mn.READ_PAGE_WITH_CRC = -61;

    bank_vector.addElement(mn);

    MemoryBankEPROM st = new MemoryBankEPROM(this);

    st.bankDescription = "Write protect pages and Page redirection";
    st.numberPages = 1;
    st.size = 8;
    st.pageLength = 8;
    st.generalPurposeMemory = false;
    st.extraInfo = false;
    st.extraInfoLength = 0;
    st.extraInfoDescription = null;
    st.numCRCBytes = 1;
    st.normalReadCRC = true;
    st.READ_PAGE_WITH_CRC = -86;
    st.WRITE_MEMORY_COMMAND = 85;

    bank_vector.addElement(st);

    mn.mbLock = st;
    mn.lockPage = true;
    mn.mbRedirect = st;
    mn.redirectOffset = 1;
    mn.redirectPage = true;

    return bank_vector.elements();
  }
}