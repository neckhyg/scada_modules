package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import com.dalsemi.onewire.utils.CRC16;

class MemoryBankScratchEx extends MemoryBankScratch
{
  public MemoryBankScratchEx(OneWireContainer ibutton)
  {
    super(ibutton);

    this.bankDescription = "Scratchpad Ex";

    this.COPY_SCRATCHPAD_COMMAND = 90;
  }

  public void writeScratchpad(int startAddr, byte[] writeBuf, int offset, int len)
    throws OneWireIOException, OneWireException
  {
    boolean calcCRC = false;

    if (len > this.pageLength) {
      throw new OneWireException("Write exceeds memory bank end");
    }

    if (!this.ib.adapter.select(this.ib.address))
    {
      forceVerify();

      throw new OneWireIOException("Device select failed");
    }

    byte[] raw_buf = new byte[this.pageLength + 5];

    raw_buf[0] = 15;
    raw_buf[1] = (byte)(startAddr & 0xFF);
    raw_buf[2] = (byte)((startAddr & 0xFFFF) >>> 8 & 0xFF);

    System.arraycopy(writeBuf, offset, raw_buf, 3, len);

    if ((startAddr + len) % this.pageLength == 0)
    {
      System.arraycopy(this.ffBlock, 0, raw_buf, len + 3, 2);

      calcCRC = true;
    }

    this.ib.adapter.dataBlock(raw_buf, 0, len + 3 + (calcCRC ? 2 : 0));

    if (calcCRC)
    {
      if (CRC16.compute(raw_buf, 0, len + 5, 0) != 45057)
      {
        forceVerify();

        throw new OneWireIOException("Invalid CRC16 read from device");
      }
    }
  }

  public void copyScratchpad(int startAddr, int len)
    throws OneWireIOException, OneWireException
  {
    if (!this.ib.adapter.select(this.ib.address))
    {
      forceVerify();

      throw new OneWireIOException("Device select failed");
    }

    byte[] raw_buf = new byte[6];

    raw_buf[0] = this.COPY_SCRATCHPAD_COMMAND;
    raw_buf[1] = (byte)(startAddr & 0xFF);
    raw_buf[2] = (byte)((startAddr & 0xFFFF) >>> 8 & 0xFF);
    raw_buf[3] = (byte)(startAddr + len - 1 & 0x1F);

    System.arraycopy(this.ffBlock, 0, raw_buf, 4, 2);

    this.ib.adapter.dataBlock(raw_buf, 0, raw_buf.length);

    if (((byte)(raw_buf[(raw_buf.length - 1)] & 0xF0) != -96) && ((byte)(raw_buf[(raw_buf.length - 1)] & 0xF0) != 80))
    {
      forceVerify();

      throw new OneWireIOException("Copy scratchpad complete not found");
    }
  }
}