package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import com.dalsemi.onewire.utils.CRC16;

class MemoryBankNVCRC extends MemoryBankNV
{
  public static final byte READ_PAGE_WITH_CRC = -91;
  protected boolean readContinuePossible;
  protected int numVerifyBytes;

  public MemoryBankNVCRC(OneWireContainer ibutton, ScratchPad scratch)
  {
    super(ibutton, scratch);

    this.pageAutoCRC = true;
    this.readContinuePossible = true;
    this.numVerifyBytes = 0;
  }

  public void readPage(int page, boolean readContinue, byte[] readBuf, int offset)
    throws OneWireIOException, OneWireException
  {
    readPageCRC(page, readContinue, readBuf, offset, null, this.extraInfoLength);
  }

  public void readPage(int page, boolean readContinue, byte[] readBuf, int offset, byte[] extraInfo)
    throws OneWireIOException, OneWireException
  {
    if (!this.extraInfo) {
      throw new OneWireException("Read extra information not supported on this memory bank");
    }

    readPageCRC(page, readContinue, readBuf, offset, extraInfo, this.extraInfoLength);
  }

  public int readPagePacket(int page, boolean readContinue, byte[] readBuf, int offset, byte[] extraInfo)
    throws OneWireIOException, OneWireException
  {
    byte[] raw_buf = new byte[this.pageLength];

    readPageCRC(page, readContinue, raw_buf, 0, extraInfo, this.extraInfoLength);

    if (raw_buf[0] > this.maxPacketDataLength)
    {
      this.sp.forceVerify();

      throw new OneWireIOException("Invalid length in packet");
    }

    int abs_page = this.startPhysicalAddress / this.pageLength + page;
    if (CRC16.compute(raw_buf, 0, raw_buf[0] + 3, abs_page) == 45057)
    {
      System.arraycopy(raw_buf, 1, readBuf, offset, raw_buf[0]);

      return raw_buf[0];
    }

    this.sp.forceVerify();

    throw new OneWireIOException("Invalid CRC16 in packet read");
  }

  public void readPageCRC(int page, boolean readContinue, byte[] readBuf, int offset)
    throws OneWireIOException, OneWireException
  {
    readPageCRC(page, readContinue, readBuf, offset, null, this.extraInfoLength);
  }

  public void readPageCRC(int page, boolean readContinue, byte[] readBuf, int offset, byte[] extraInfo)
    throws OneWireIOException, OneWireException
  {
    readPageCRC(page, readContinue, readBuf, offset, extraInfo, this.extraInfoLength);
  }

  protected void readPageCRC(int page, boolean readContinue, byte[] readBuf, int offset, byte[] extraInfo, int extraLength)
    throws OneWireIOException, OneWireException
  {
    int last_crc = 0;

    if (!this.pageAutoCRC) {
      throw new OneWireException("Read page with CRC not supported in this memory bank");
    }

    if (!readContinue) {
      this.sp.checkSpeed();
    }

    if (page > this.numberPages) {
      throw new OneWireException("Read exceeds memory bank end");
    }

    if ((!readContinue) || (!this.readContinuePossible))
    {
      if (!this.ib.adapter.select(this.ib.address))
      {
        this.sp.forceVerify();

        throw new OneWireIOException("Device select failed");
      }

      raw_buf = new byte[3];
      raw_buf[0] = -91;

      int addr = page * this.pageLength + this.startPhysicalAddress;

      raw_buf[1] = (byte)(addr & 0xFF);
      raw_buf[2] = (byte)((addr & 0xFFFF) >>> 8 & 0xFF);

      last_crc = CRC16.compute(raw_buf, 0, raw_buf.length, last_crc);

      this.ib.adapter.dataBlock(raw_buf, 0, 3);
    }

    byte[] raw_buf = new byte[this.pageLength + extraLength + 2 + this.numVerifyBytes];

    System.arraycopy(this.ffBlock, 0, raw_buf, 0, raw_buf.length);

    this.ib.adapter.dataBlock(raw_buf, 0, raw_buf.length);

    if (CRC16.compute(raw_buf, 0, raw_buf.length - this.numVerifyBytes, last_crc) != 45057)
    {
      this.sp.forceVerify();

      throw new OneWireIOException("Invalid CRC16 read from device");
    }

    System.arraycopy(raw_buf, 0, readBuf, offset, this.pageLength);

    if (extraInfo != null)
      System.arraycopy(raw_buf, this.pageLength, extraInfo, 0, extraLength);
  }
}