package com.dalsemi.onewire.container;

public class ResponseAPDU
{
  protected byte[] apduBuffer = null;
  protected int apduLength;

  public ResponseAPDU(byte[] buffer)
  {
    if (buffer.length < 2) {
      throw new RuntimeException("invalid ResponseAPDU, length must be at least 2 bytes");
    }

    this.apduLength = buffer.length;
    this.apduBuffer = new byte[this.apduLength];

    System.arraycopy(buffer, 0, this.apduBuffer, 0, this.apduLength);
  }

  public byte[] getData()
  {
    if (this.apduLength > 2)
    {
      byte[] data = new byte[this.apduLength - 2];

      System.arraycopy(this.apduBuffer, 0, data, 0, this.apduLength - 2);

      return data;
    }

    return null;
  }

  public final int getSW()
  {
    return getSW1() << 8 & 0xFF00 | getSW2() & 0xFF;
  }

  public final byte getSW1()
  {
    return this.apduBuffer[(this.apduLength - 2)];
  }

  public final byte getSW2()
  {
    return this.apduBuffer[(this.apduLength - 1)];
  }

  public final byte getByte(int index)
  {
    if (index >= this.apduLength) {
      return -1;
    }
    return this.apduBuffer[index];
  }

  public final byte[] getBytes()
  {
    byte[] apdu = new byte[this.apduLength];

    System.arraycopy(this.apduBuffer, 0, apdu, 0, this.apduLength);

    return apdu;
  }

  public final int getLength()
  {
    return this.apduLength;
  }

  public String toString()
  {
    String apduString = "";

    if (this.apduLength > 2)
    {
      byte[] dataBuffer = new byte[this.apduLength - 2];

      dataBuffer = getData();
      apduString = apduString + "DATA = ";

      for (int i = 0; i < dataBuffer.length; i++)
      {
        if ((dataBuffer[i] & 0xFF) < 16) {
          apduString = apduString + '0';
        }
        apduString = apduString + Integer.toHexString(dataBuffer[i] & 0xFF) + " ";
      }

      apduString = apduString + " | ";
    }

    apduString = apduString + "SW1 = ";

    if ((getSW1() & 0xFF) < 16) {
      apduString = apduString + '0';
    }
    apduString = apduString + Integer.toHexString(getSW1() & 0xFF);
    apduString = apduString + ", SW2 = ";

    if ((getSW2() & 0xFF) < 16) {
      apduString = apduString + '0';
    }
    apduString = apduString + Integer.toHexString(getSW2() & 0xFF);

    return apduString.toUpperCase();
  }
}