package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.OneWireIOException;

public abstract interface HumidityContainer extends OneWireSensor
{
  public static final int ALARM_HIGH = 1;
  public static final int ALARM_LOW = 0;

  public abstract boolean isRelative();

  public abstract boolean hasHumidityAlarms();

  public abstract boolean hasSelectableHumidityResolution();

  public abstract double[] getHumidityResolutions();

  public abstract double getHumidityAlarmResolution()
    throws OneWireException;

  public abstract void doHumidityConvert(byte[] paramArrayOfByte)
    throws OneWireIOException, OneWireException;

  public abstract double getHumidity(byte[] paramArrayOfByte);

  public abstract double getHumidityResolution(byte[] paramArrayOfByte);

  public abstract double getHumidityAlarm(int paramInt, byte[] paramArrayOfByte)
    throws OneWireException;

  public abstract void setHumidityAlarm(int paramInt, double paramDouble, byte[] paramArrayOfByte)
    throws OneWireException;

  public abstract void setHumidityResolution(double paramDouble, byte[] paramArrayOfByte)
    throws OneWireException;
}