package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireAccessProvider;
import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import com.dalsemi.onewire.utils.CRC16;
import com.dalsemi.onewire.utils.Convert;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.GregorianCalendar;
import java.util.Vector;

public class OneWireContainer41 extends OneWireContainer
  implements PasswordContainer, MissionContainer, ClockContainer, TemperatureContainer, ADContainer, HumidityContainer
{
  private static final boolean DEBUG = false;
  private static final int MAX_READ_RETRY_CNT = 10;
  private static final int PASSWORD_LENGTH = 8;
  private boolean isContainerVariablesSet = false;

  private MemoryBankScratchCRCPW scratch = null;

  private MemoryBankNVCRCPW userDataMemory = null;

  private MemoryBankNVCRCPW register = null;

  private MemoryBankNVCRCPW log = null;

  private String partNumber = null;

  private byte deviceConfigByte = -1;

  private double temperatureRangeLow = -40.0D;

  private double temperatureRangeWidth = 125.0D;

  private double temperatureResolution = 0.5D;

  private double adReferenceVoltage = 5.02D;

  private int adDeviceBits = 10;

  private boolean adForceResults = false;

  private boolean updatertc = false;

  private boolean doSpeedEnable = true;

  private final byte[] readPassword = new byte[8];
  private boolean readPasswordSet = false;
  private boolean readOnlyPasswordEnabled = false;

  private final byte[] readWritePassword = new byte[8];
  private boolean readWritePasswordSet = false;
  private boolean readWritePasswordEnabled = false;

  private boolean isMissionLoaded = false;

  private byte[] missionRegister = null;

  private byte[] dataLog = null; private byte[] temperatureLog = null;

  private int temperatureBytes = 0;

  private int dataBytes = 0;

  private boolean rolledOver = false;

  private int timeOffset = 0;

  private long missionTimeStamp = -1L;

  private int sampleRate = -1; private int sampleCount = -1;
  private int sampleCountTotal;
  private boolean useHumdCalibrationRegisters = false;

  private double Href1 = 20.0D; private double Href2 = 60.0D; private double Href3 = 90.0D;

  private double Hread1 = 0.0D; private double Hread2 = 0.0D; private double Hread3 = 0.0D;

  private double Herror1 = 0.0D; private double Herror2 = 0.0D; private double Herror3 = 0.0D;
  private double humdCoeffA;
  private double humdCoeffB;
  private double humdCoeffC;
  private boolean useTempCalibrationRegisters = false;

  private double Tref1 = 0.0D; private double Tref2 = 0.0D; private double Tref3 = 0.0D;

  private double Tread1 = 0.0D; private double Tread2 = 0.0D; private double Tread3 = 0.0D;

  private double Terror1 = 0.0D; private double Terror2 = 0.0D; private double Terror3 = 0.0D;
  private double tempCoeffA;
  private double tempCoeffB;
  private double tempCoeffC;
  private boolean useTemperatureCompensation = false;

  private boolean overrideTemperatureLog = false;

  private double defaultTempCompensationValue = 25.0D;

  private boolean hasHumiditySensor = false;

  private static final double[] temperatureResolutions = { 0.5D, 0.0625D };

  private static final double[] dataResolutions = { 0.5D, 0.001953125D };
  private static final double[] humidityResolutions = { 0.6D, 0.04D };

  private String descriptionString = "Rugged, self-sufficient 1-Wire device that, once setup for a mission, will measure temperature and A-to-D/Humidity, with the result recorded in a protected memory section. It stores up to 8192 1-byte measurements, which can be filled with 1- or 2-byte temperature readings and 1- or 2-byte A-to-D/Humidity readings taken at a user-specified rate.";
  private static final int FIRST_YEAR_EVER = 2000;
  private static final byte ENABLE_BYTE = -86;
  private static final byte DISABLE_BYTE = 0;
  public static final int TEMPERATURE_CHANNEL = 0;
  public static final int DATA_CHANNEL = 1;
  public static final byte WRITE_SCRATCHPAD_COMMAND = 15;
  public static final byte READ_SCRATCHPAD_COMMAND = -86;
  public static final byte COPY_SCRATCHPAD_PW_COMMAND = -103;
  public static final byte READ_MEMORY_CRC_PW_COMMAND = 105;
  public static final byte CLEAR_MEMORY_PW_COMMAND = -106;
  public static final byte START_MISSION_PW_COMMAND = -52;
  public static final byte STOP_MISSION_PW_COMMAND = 51;
  public static final byte FORCED_CONVERSION = 85;
  public static final int RTC_TIME = 512;
  public static final int RTC_DATE = 515;
  public static final int SAMPLE_RATE = 518;
  public static final int TEMPERATURE_LOW_ALARM_THRESHOLD = 520;
  public static final int TEMPERATURE_HIGH_ALARM_THRESHOLD = 521;
  public static final int DATA_LOW_ALARM_THRESHOLD = 522;
  public static final int DATA_HIGH_ALARM_THRESHOLD = 523;
  public static final int LAST_TEMPERATURE_CONVERSION_LSB = 524;
  public static final int LAST_TEMPERATURE_CONVERSION_MSB = 525;
  public static final int LAST_DATA_CONVERSION_LSB = 526;
  public static final int LAST_DATA_CONVERSION_MSB = 527;
  public static final int TEMPERATURE_CONTROL_REGISTER = 528;
  public static final byte TCR_BIT_ENABLE_TEMPERATURE_LOW_ALARM = 1;
  public static final byte TCR_BIT_ENABLE_TEMPERATURE_HIGH_ALARM = 2;
  public static final int DATA_CONTROL_REGISTER = 529;
  public static final byte DCR_BIT_ENABLE_DATA_LOW_ALARM = 1;
  public static final byte DCR_BIT_ENABLE_DATA_HIGH_ALARM = 2;
  public static final int RTC_CONTROL_REGISTER = 530;
  public static final byte RCR_BIT_ENABLE_OSCILLATOR = 1;
  public static final byte RCR_BIT_ENABLE_HIGH_SPEED_SAMPLE = 2;
  public static final int MISSION_CONTROL_REGISTER = 19;
  public static final byte MCR_BIT_ENABLE_TEMPERATURE_LOGGING = 1;
  public static final byte MCR_BIT_ENABLE_DATA_LOGGING = 2;
  public static final byte MCR_BIT_TEMPERATURE_RESOLUTION = 4;
  public static final byte MCR_BIT_DATA_RESOLUTION = 8;
  public static final byte MCR_BIT_ENABLE_ROLLOVER = 16;
  public static final byte MCR_BIT_START_MISSION_ON_TEMPERATURE_ALARM = 32;
  public static final int ALARM_STATUS_REGISTER = 532;
  public static final byte ASR_BIT_TEMPERATURE_LOW_ALARM = 1;
  public static final byte ASR_BIT_TEMPERATURE_HIGH_ALARM = 2;
  public static final byte ASR_BIT_DATA_LOW_ALARM = 4;
  public static final byte ASR_BIT_DATA_HIGH_ALARM = 8;
  public static final byte ASR_BIT_BATTERY_ON_RESET = -128;
  public static final int GENERAL_STATUS_REGISTER = 533;
  public static final byte GSR_BIT_SAMPLE_IN_PROGRESS = 1;
  public static final byte GSR_BIT_MISSION_IN_PROGRESS = 2;
  public static final byte GSR_BIT_CONVERSION_IN_PROGRESS = 4;
  public static final byte GSR_BIT_MEMORY_CLEARED = 8;
  public static final byte GSR_BIT_WAITING_FOR_TEMPERATURE_ALARM = 16;
  public static final byte GSR_BIT_FORCED_CONVERSION_IN_PROGRESS = 32;
  public static final int MISSION_START_DELAY = 534;
  public static final int MISSION_TIMESTAMP_TIME = 537;
  public static final int MISSION_TIMESTAMP_DATE = 540;
  public static final int DEVICE_CONFIGURATION_BYTE = 550;
  public static final byte DCB_DS2422 = 0;
  public static final byte DCB_DS1923 = 32;
  public static final byte DCB_DS1922L = 64;
  public static final byte DCB_DS1922T = 96;
  public static final int PASSWORD_CONTROL_REGISTER = 551;
  public static final int READ_ACCESS_PASSWORD = 552;
  public static final int READ_WRITE_ACCESS_PASSWORD = 560;
  public static final int MISSION_SAMPLE_COUNT = 544;
  public static final int DEVICE_SAMPLE_COUNT = 547;
  public static final int MISSION_LOG_SIZE = 8192;
  public static final int ODD_MISSION_LOG_SIZE = 7680;
  private static final String PART_NUMBER_DS1923 = "DS1923";
  private static final String PART_NUMBER_DS2422 = "DS2422";
  private static final String PART_NUMBER_DS1922L = "DS1922L";
  private static final String PART_NUMBER_DS1922T = "DS1922T";
  private static final String PART_NUMBER_UNKNOWN = "DS1922/DS1923/DS2422";
  private static final String DESCRIPTION_DS1923 = "The DS1923 Temperature/Humidity Logger iButton is a rugged, self-sufficient system that measures temperature and/or humidity and records the result in a protected memory section. The recording is done at a user-defined rate. A total of 8192 8-bit readings or 4096 16-bit readings taken at equidistant intervals ranging from 1 second to 273 hours can be stored. In addition to this, there are 512 bytes of SRAM for storing application specific information and 64 bytes for calibration data. A mission to collect data can be programmed to begin immediately, or after a user-defined delay or after a temperature alarm. Access to the memory and control functions can be password-protected.";
  private static final String DESCRIPTION_DS1922 = "The DS1922L/T Temperature Logger iButtons are rugged, self-sufficient systems that measure temperature and record the result in a protected memory section. The recording is done at a user-defined rate. A total of 8192 8-bit readings or 4096 16-bit readings taken at equidistant intervals ranging from 1s to 273hrs can be stored. In addition to this, there are 512 bytes of SRAM for storing applicationspecific information and 64 bytes for calibration data. A mission to collect data can be programmed to begin immediately, or after a user-defined delay or after a temperature alarm. Access to the memory and control functions can be password protected.";
  private static final String DESCRIPTION_DS2422 = "The DS2422 temperature/datalogger combines the core functions of a fully featured datalogger in a single chip. It includes a temperature sensor, realtime clock (RTC), memory, 1-Wire® interface, and serial interface for an analog-to-digital converter (ADC) as well as control circuitry for a charge pump. The ADC and the charge pump are peripherals that can be added to build application-specific dataloggers. The MAX1086 is an example of a compatible serial ADC. Without external ADC, the DS2422 functions as a temperature logger only. The DS2422 measures the temperature and/or reads the ADC at a user-defined rate. A total of 8192 8-bit readings or 4096 16-bit readings taken at equidistant intervals ranging from 1s to 273hrs can be stored.";
  private static final String DESCRIPTION_UNKNOWN = "Rugged, self-sufficient 1-Wire device that, once setup for a mission, will measure temperature and A-to-D/Humidity, with the result recorded in a protected memory section. It stores up to 8192 1-byte measurements, which can be filled with 1- or 2-byte temperature readings and 1- or 2-byte A-to-D/Humidity readings taken at a user-specified rate.";

  public OneWireContainer41()
  {
    initMem();
    setContainerVariables(null);
  }

  public OneWireContainer41(DSPortAdapter sourceAdapter, byte[] newAddress)
  {
    super(sourceAdapter, newAddress);

    initMem();
    setContainerVariables(null);
  }

  public OneWireContainer41(DSPortAdapter sourceAdapter, long newAddress)
  {
    super(sourceAdapter, newAddress);

    initMem();
    setContainerVariables(null);
  }

  public OneWireContainer41(DSPortAdapter sourceAdapter, String newAddress)
  {
    super(sourceAdapter, newAddress);

    initMem();
    setContainerVariables(null);
  }

  public void setupContainer(DSPortAdapter sourceAdapter, byte[] newAddress)
  {
    super.setupContainer(sourceAdapter, newAddress);

    initMem();
    setContainerVariables(null);
  }

  public void setupContainer(DSPortAdapter sourceAdapter, long newAddress)
  {
    super.setupContainer(sourceAdapter, newAddress);

    initMem();
    setContainerVariables(null);
  }

  public void setupContainer(DSPortAdapter sourceAdapter, String newAddress)
  {
    super.setupContainer(sourceAdapter, newAddress);

    initMem();
    setContainerVariables(null);
  }

  public byte[] readDevice()
    throws OneWireIOException, OneWireException
  {
    byte[] buffer = new byte[96];

    int retryCnt = 10;
    int page = 0;
    do
    {
      try
      {
        switch (page)
        {
        default:
          break;
        case 0:
          this.register.readPageCRC(0, false, buffer, 0);
          page++;
        case 1:
          this.register.readPageCRC(1, retryCnt == 10, buffer, 32);
          page++;
        case 2:
          this.register.readPageCRC(2, retryCnt == 10, buffer, 64);
          page++;
        }
        retryCnt = 10;
      }
      catch (OneWireIOException owioe)
      {
        retryCnt--; if (retryCnt == 0) {
          throw owioe;
        }

      }
      catch (OneWireException owe)
      {
        retryCnt--; if (retryCnt == 0)
          throw owe;
      }
    }
    while (page < 3);

    if (!this.isContainerVariablesSet) {
      setContainerVariables(buffer);
    }
    return buffer;
  }

  public void writeDevice(byte[] state)
    throws OneWireIOException, OneWireException
  {
    int start = this.updatertc ? 0 : 6;

    this.register.write(start, state, start, 32 - start);

    synchronized (this)
    {
      this.updatertc = false;
    }
  }

  public byte readByte(int memAddr)
    throws OneWireIOException, OneWireException
  {
    byte msbAddress = (byte)(memAddr >> 8 & 0xFF);
    byte lsbAddress = (byte)(memAddr & 0xFF);

    if ((msbAddress > 47) || (msbAddress < 0)) {
      throw new IllegalArgumentException("OneWireContainer41-Address for read out of range.");
    }

    int numBytesToEndOfPage = 32 - (lsbAddress & 0x1F);
    byte[] buffer = new byte[11 + numBytesToEndOfPage + 2];

    if (this.doSpeedEnable) {
      doSpeed();
    }
    if (this.adapter.select(this.address))
    {
      buffer[0] = 105;
      buffer[1] = lsbAddress;
      buffer[2] = msbAddress;

      if (isContainerReadWritePasswordSet())
        getContainerReadWritePassword(buffer, 3);
      else {
        getContainerReadOnlyPassword(buffer, 3);
      }
      for (int i = 11; i < buffer.length; i++) {
        buffer[i] = -1;
      }

      this.adapter.dataBlock(buffer, 0, buffer.length);

      if (CRC16.compute(buffer, 11, buffer.length - 11, CRC16.compute(buffer, 0, 3, 0)) != 45057)
      {
        throw new OneWireIOException("Invalid CRC16 read from device.  Password may be incorrect or a sample may be in progress.");
      }

      return buffer[11];
    }

    throw new OneWireException("OneWireContainer41-Device not present.");
  }

  public boolean getFlag(int register, byte bitMask)
    throws OneWireIOException, OneWireException
  {
    int retryCnt = 10;
    while (true)
    {
      try
      {
        return (readByte(register) & bitMask) != 0;
      }
      catch (OneWireException owe)
      {
        retryCnt--; if (retryCnt == 0)
          throw owe;
      }
    }
  }

  public boolean getFlag(int register, byte bitMask, byte[] state)
  {
    return (state[(register & 0x3F)] & bitMask) != 0;
  }

  public void setFlag(int register, byte bitMask, boolean flagValue)
    throws OneWireIOException, OneWireException
  {
    byte[] state = readDevice();

    setFlag(register, bitMask, flagValue, state);

    writeDevice(state);
  }

  public void setFlag(int register, byte bitMask, boolean flagValue, byte[] state)
  {
    register &= 63;

    byte flags = state[register];

    if (flagValue)
      flags = (byte)(flags | bitMask);
    else {
      flags = (byte)(flags & (bitMask ^ 0xFFFFFFFF));
    }

    state[register] = flags;
  }

  public Enumeration getMemoryBanks()
  {
    Vector v = new Vector(4);

    v.addElement(this.scratch);
    v.addElement(this.userDataMemory);
    v.addElement(this.register);
    v.addElement(this.log);

    return v.elements();
  }

  public MemoryBankScratchCRCPW getScratchpadMemoryBank()
  {
    return this.scratch;
  }

  public MemoryBankNVCRCPW getUserDataMemoryBank()
  {
    return this.userDataMemory;
  }

  public MemoryBankNVCRCPW getDataLogMemoryBank()
  {
    return this.log;
  }

  public MemoryBankNVCRCPW getRegisterMemoryBank()
  {
    return this.register;
  }

  public int getMaxSpeed()
  {
    return 2;
  }

  public String getName()
  {
    return this.partNumber;
  }

  public String getAlternateNames()
  {
    if (this.partNumber.equals("DS1923"))
      return "Hygrochron";
    return "Thermochron8k";
  }

  public String getDescription()
  {
    return this.descriptionString;
  }

  public byte getDeviceConfigByte()
    throws OneWireIOException, OneWireException
  {
    if (this.deviceConfigByte == -1)
    {
      byte[] state = readDevice();
      if (this.deviceConfigByte == -1)
        this.deviceConfigByte = state[38];
    }
    return this.deviceConfigByte;
  }

  public synchronized void setSpeedCheck(boolean doSpeedCheck)
  {
    this.doSpeedEnable = doSpeedCheck;
  }

  public void stopMission()
    throws OneWireException, OneWireIOException
  {
    if (this.doSpeedEnable) {
      doSpeed();
    }
    if (!this.adapter.select(this.address)) {
      throw new OneWireException("OneWireContainer41-Device not present.");
    }
    byte[] buffer = new byte[10];
    buffer[0] = 51;
    getContainerReadWritePassword(buffer, 1);
    buffer[9] = -1;

    this.adapter.dataBlock(buffer, 0, 10);

    if (getFlag(533, 2))
      throw new OneWireException("OneWireContainer41-Stop mission failed.  Check read/write password.");
  }

  public void startMission()
    throws OneWireException, OneWireIOException
  {
    if (getFlag(533, 2)) {
      throw new OneWireException("OneWireContainer41-Cannot start a mission while a mission is in progress.");
    }

    if (!getFlag(533, 8)) {
      throw new OneWireException("OneWireContainer41-Must clear memory before calling start mission.");
    }

    if (this.doSpeedEnable) {
      doSpeed();
    }
    if (!this.adapter.select(this.address)) {
      throw new OneWireException("OneWireContainer41-Device not present.");
    }
    byte[] buffer = new byte[10];
    buffer[0] = -52;
    getContainerReadWritePassword(buffer, 1);
    buffer[9] = -1;

    this.adapter.dataBlock(buffer, 0, 10);
  }

  public void clearMemory()
    throws OneWireException, OneWireIOException
  {
    if (getFlag(533, 2)) {
      throw new OneWireException("OneWireContainer41-Cannot clear memory while mission is in progress.");
    }

    if (this.doSpeedEnable) {
      doSpeed();
    }
    if (!this.adapter.select(this.address)) {
      throw new OneWireException("OneWireContainer41-Device not present.");
    }
    byte[] buffer = new byte[10];
    buffer[0] = -106;
    getContainerReadWritePassword(buffer, 1);
    buffer[9] = -1;

    this.adapter.dataBlock(buffer, 0, 10);

    msWait(2L);

    if (!getFlag(533, 8))
      throw new OneWireException("OneWireContainer41-Clear Memory failed.  Check read/write password.");
  }

  public int getReadOnlyPasswordLength()
    throws OneWireException
  {
    return 8;
  }

  public int getReadWritePasswordLength()
    throws OneWireException
  {
    return 8;
  }

  public int getWriteOnlyPasswordLength()
    throws OneWireException
  {
    throw new OneWireException("The DS1922 does not have a write only password.");
  }

  public int getReadOnlyPasswordAddress()
    throws OneWireException
  {
    return 552;
  }

  public int getReadWritePasswordAddress()
    throws OneWireException
  {
    return 560;
  }

  public int getWriteOnlyPasswordAddress()
    throws OneWireException
  {
    throw new OneWireException("The DS1922 does not have a write password.");
  }

  public boolean hasReadOnlyPassword()
  {
    return true;
  }

  public boolean hasReadWritePassword()
  {
    return true;
  }

  public boolean hasWriteOnlyPassword()
  {
    return false;
  }

  public boolean getDeviceReadOnlyPasswordEnable()
    throws OneWireException
  {
    return this.readOnlyPasswordEnabled;
  }

  public boolean getDeviceReadWritePasswordEnable()
    throws OneWireException
  {
    return this.readWritePasswordEnabled;
  }

  public boolean getDeviceWriteOnlyPasswordEnable()
    throws OneWireException
  {
    throw new OneWireException("The DS1922 does not have a Write Only Password.");
  }

  public boolean hasSinglePasswordEnable()
  {
    return false;
  }

  public void setDevicePasswordEnable(boolean enableReadOnly, boolean enableReadWrite, boolean enableWriteOnly)
    throws OneWireException, OneWireIOException
  {
    if (enableWriteOnly) {
      throw new OneWireException("The DS1922 does not have a write only password.");
    }
    if (enableReadOnly != enableReadWrite) {
      throw new OneWireException("Both read-only and read/write will be set with enable.");
    }
    if (!isContainerReadOnlyPasswordSet())
      throw new OneWireException("Container Read Password is not set");
    if (!isContainerReadWritePasswordSet()) {
      throw new OneWireException("Container Read/Write Password is not set");
    }

    byte[] bothPasswordsEnable = new byte[17];
    bothPasswordsEnable[0] = (enableReadOnly ? -86 : 0);
    getContainerReadOnlyPassword(bothPasswordsEnable, 1);
    getContainerReadWritePassword(bothPasswordsEnable, 9);

    this.register.write(39, bothPasswordsEnable, 0, 17);

    if (enableReadOnly)
    {
      this.readOnlyPasswordEnabled = true;
      this.readWritePasswordEnabled = true;
    }
    else
    {
      this.readOnlyPasswordEnabled = false;
      this.readWritePasswordEnabled = false;
    }
  }

  public void setDevicePasswordEnableAll(boolean enableAll)
    throws OneWireException, OneWireIOException
  {
    setDevicePasswordEnable(enableAll, enableAll, false);
  }

  public void setDeviceReadOnlyPassword(byte[] password, int offset)
    throws OneWireException, OneWireIOException
  {
    if (getFlag(533, 2)) {
      throw new OneWireIOException("OneWireContainer41-Cannot change password while mission is in progress.");
    }

    if (!isContainerReadWritePasswordSet()) {
      throw new OneWireException("Container Read/Write Password is not set");
    }

    byte[] bothPasswords = new byte[16];
    System.arraycopy(password, offset, bothPasswords, 0, 8);
    getContainerReadWritePassword(bothPasswords, 8);

    this.register.write(40, bothPasswords, 0, 16);
    setContainerReadOnlyPassword(password, offset);
  }

  public void setDeviceReadWritePassword(byte[] password, int offset)
    throws OneWireException, OneWireIOException
  {
    if (getFlag(533, 2)) {
      throw new OneWireIOException("OneWireContainer41-Cannot change password while mission is in progress.");
    }

    this.register.write(48, password, offset, 8);
    setContainerReadWritePassword(password, offset);
  }

  public void setDeviceWriteOnlyPassword(byte[] password, int offset)
    throws OneWireException, OneWireIOException
  {
    throw new OneWireException("The DS1922 does not have a write only password.");
  }

  public void setContainerReadOnlyPassword(byte[] password, int offset)
    throws OneWireException
  {
    System.arraycopy(password, offset, this.readPassword, 0, 8);
    this.readPasswordSet = true;
  }

  public void setContainerReadWritePassword(byte[] password, int offset)
    throws OneWireException
  {
    System.arraycopy(password, offset, this.readWritePassword, 0, 8);
    this.readWritePasswordSet = true;
  }

  public void setContainerWriteOnlyPassword(byte[] password, int offset)
    throws OneWireException
  {
    throw new OneWireException("The DS1922 does not have a write only password.");
  }

  public boolean isContainerReadOnlyPasswordSet()
    throws OneWireException
  {
    return this.readPasswordSet;
  }

  public boolean isContainerReadWritePasswordSet()
    throws OneWireException
  {
    return this.readWritePasswordSet;
  }

  public boolean isContainerWriteOnlyPasswordSet()
    throws OneWireException
  {
    throw new OneWireException("The DS1922 does not have a write only password");
  }

  public void getContainerReadOnlyPassword(byte[] password, int offset)
    throws OneWireException
  {
    System.arraycopy(this.readPassword, 0, password, offset, 8);
  }

  public void getContainerReadWritePassword(byte[] password, int offset)
    throws OneWireException
  {
    System.arraycopy(this.readWritePassword, 0, password, offset, 8);
  }

  public void getContainerWriteOnlyPassword(byte[] password, int offset)
    throws OneWireException
  {
    throw new OneWireException("The DS1922 does not have a write only password");
  }

  public String getMissionLabel(int channel)
    throws OneWireException, OneWireIOException
  {
    if (channel == 0)
    {
      return "Temperature";
    }
    if (channel == 1)
    {
      if ((this.hasHumiditySensor) && (!this.adForceResults)) {
        return "Humidity";
      }
      return "Data";
    }

    throw new OneWireException("Invalid Channel");
  }

  public void setStartUponTemperatureAlarmEnable(boolean enable)
    throws OneWireException, OneWireIOException
  {
    setFlag(19, 32, enable);
  }

  public void setStartUponTemperatureAlarmEnable(boolean enable, byte[] state)
    throws OneWireException, OneWireIOException
  {
    setFlag(19, 32, enable, state);
  }

  public boolean isStartUponTemperatureAlarmEnabled()
    throws OneWireException, OneWireIOException
  {
    return getFlag(19, 32);
  }

  public boolean isStartUponTemperatureAlarmEnabled(byte[] state)
    throws OneWireException, OneWireIOException
  {
    return getFlag(19, 32, state);
  }

  public boolean isMissionSUTA()
    throws OneWireException, OneWireIOException
  {
    if (this.isMissionLoaded) {
      return getFlag(19, 32, this.missionRegister);
    }

    return getFlag(19, 32);
  }

  public boolean isMissionWFTA()
    throws OneWireException, OneWireIOException
  {
    if ((isMissionRunning()) && (isMissionSUTA()))
    {
      if (this.isMissionLoaded) {
        return getFlag(533, 16, this.missionRegister);
      }

      return getFlag(533, 16);
    }

    return false;
  }

  public void startNewMission(int sampleRate, int missionStartDelay, boolean rolloverEnabled, boolean syncClock, boolean[] channelEnabled)
    throws OneWireException, OneWireIOException
  {
    byte[] state = readDevice();

    for (int i = 0; i < getNumberMissionChannels(); i++) {
      setMissionChannelEnable(i, channelEnabled[i], state);
    }
    if ((sampleRate % 60 == 0) || (sampleRate > 16383))
    {
      sampleRate = sampleRate / 60 & 0x3FFF;
      setFlag(530, 2, false, state);
    }
    else
    {
      setFlag(530, 2, true, state);
    }

    Convert.toByteArray(sampleRate, state, 6, 2);

    Convert.toByteArray(missionStartDelay, state, 22, 2);

    setFlag(19, 16, rolloverEnabled, state);

    if (syncClock)
    {
      setClock(new Date().getTime(), state);
    }
    else if (!getFlag(530, 1, state))
    {
      setFlag(530, 1, true, state);
    }

    clearMemory();
    writeDevice(state);
    startMission();
  }

  public synchronized void loadMissionResults()
    throws OneWireException, OneWireIOException
  {
    this.missionRegister = readDevice();

    this.sampleCount = Convert.toInt(this.missionRegister, 32, 3);

    this.sampleCountTotal = this.sampleCount;

    this.sampleRate = Convert.toInt(this.missionRegister, 6, 2);
    if (!getFlag(530, 2, this.missionRegister))
    {
      this.sampleRate *= 60;
    }

    int[] time = getTime(25, this.missionRegister);

    int[] date = getDate(28, this.missionRegister);

    Calendar d = new GregorianCalendar(date[0], date[1] - 1, date[2], time[2], time[1], time[0]);

    this.missionTimeStamp = d.getTime().getTime();

    this.temperatureBytes = 0;

    if (getFlag(19, 1, this.missionRegister))
    {
      this.temperatureBytes += 1;

      if (getFlag(19, 4, this.missionRegister))
      {
        this.temperatureBytes += 1;
      }

    }

    this.dataBytes = 0;

    if (getFlag(19, 2, this.missionRegister))
    {
      this.dataBytes += 1;

      if (getFlag(19, 8, this.missionRegister))
      {
        this.dataBytes += 1;
      }

    }

    int logSize = 8192;

    int maxSamples = 0;
    switch (this.temperatureBytes + this.dataBytes)
    {
    case 1:
      maxSamples = 8192;
      break;
    case 2:
      maxSamples = 4096;
      break;
    case 3:
      maxSamples = 2560;
      logSize = 7680;
      break;
    case 4:
      maxSamples = 2048;
      break;
    case 0:
    }

    int wrapCount = 0; int offsetDepth = 0;
    if (getFlag(19, 16, this.missionRegister)) if ((this.rolledOver = this.sampleCount > maxSamples ? 1 : 0) != 0)
      {
        wrapCount = this.sampleCount / maxSamples - 1;
        offsetDepth = this.sampleCount % maxSamples;
        this.sampleCount = maxSamples;
      }


    if ((!getFlag(19, 16, this.missionRegister)) && (this.rolledOver))
    {
      throw new OneWireException("Device Error: rollover was not enabled, but it did occur.");
    }

    int temperatureLogSize = this.temperatureBytes * maxSamples;

    this.timeOffset = (wrapCount * maxSamples + offsetDepth);

    this.temperatureLog = new byte[this.sampleCount * this.temperatureBytes];

    this.dataLog = new byte[this.sampleCount * this.dataBytes];

    byte[] missionLogBuffer = new byte[Math.max(this.temperatureLog.length, this.dataLog.length)];
    byte[] pagebuffer = new byte[32];

    if (this.temperatureLog.length > 0)
    {
      int numPages = this.temperatureLog.length / 32 + (this.temperatureLog.length % 32 > 0 ? 1 : 0);

      int retryCnt = 10;
      for (int i = 0; i < numPages; )
      {
        try
        {
          this.log.readPageCRC(i, (i > 0) && (retryCnt == 10), pagebuffer, 0);

          System.arraycopy(pagebuffer, 0, missionLogBuffer, i * 32, Math.min(32, this.temperatureLog.length - i * 32));

          retryCnt = 10;
          i++;
        }
        catch (OneWireIOException owioe)
        {
          retryCnt--; if (retryCnt == 0)
            throw owioe;
        }
        catch (OneWireException owe)
        {
          retryCnt--; if (retryCnt == 0) {
            throw owe;
          }
        }
      }

      int offsetIndex = offsetDepth * this.temperatureBytes;
      System.arraycopy(missionLogBuffer, offsetIndex, this.temperatureLog, 0, this.temperatureLog.length - offsetIndex);

      System.arraycopy(missionLogBuffer, 0, this.temperatureLog, this.temperatureLog.length - offsetIndex, offsetIndex);
    }

    if (this.dataLog.length > 0)
    {
      int numPages = this.dataLog.length / 32 + (this.dataLog.length % 32 > 0 ? 1 : 0);

      int retryCnt = 10;
      for (int i = 0; i < numPages; )
      {
        try
        {
          this.log.readPageCRC(temperatureLogSize / 32 + i, (i > 0) && (retryCnt == 10), pagebuffer, 0);

          System.arraycopy(pagebuffer, 0, missionLogBuffer, i * 32, Math.min(32, this.dataLog.length - i * 32));

          retryCnt = 10;
          i++;
        }
        catch (OneWireIOException owioe)
        {
          retryCnt--; if (retryCnt == 0)
            throw owioe;
        }
        catch (OneWireException owe)
        {
          retryCnt--; if (retryCnt == 0) {
            throw owe;
          }
        }
      }

      int offsetIndex = offsetDepth * this.dataBytes;
      System.arraycopy(missionLogBuffer, offsetIndex, this.dataLog, 0, this.dataLog.length - offsetIndex);

      System.arraycopy(missionLogBuffer, 0, this.dataLog, this.dataLog.length - offsetIndex, offsetIndex);
    }

    this.isMissionLoaded = true;
  }

  public boolean isMissionLoaded()
  {
    return this.isMissionLoaded;
  }

  public int getNumberMissionChannels()
  {
    if ((this.deviceConfigByte == 64) || (this.deviceConfigByte == 96)) {
      return 1;
    }
    return 2;
  }

  public void setMissionChannelEnable(int channel, boolean enable)
    throws OneWireException, OneWireIOException
  {
    if (!this.isMissionLoaded)
      this.missionRegister = readDevice();
    setMissionChannelEnable(channel, enable, this.missionRegister);
    writeDevice(this.missionRegister);
  }

  public void setMissionChannelEnable(int channel, boolean enable, byte[] state)
    throws OneWireException, OneWireIOException
  {
    if (channel == 0)
    {
      setFlag(19, 1, enable, state);
    }
    else if (channel == 1)
    {
      setFlag(19, 2, enable, state);
    }
    else
    {
      throw new IllegalArgumentException("Invalid Channel");
    }
  }

  public boolean getMissionChannelEnable(int channel)
    throws OneWireException, OneWireIOException
  {
    if (!this.isMissionLoaded) {
      this.missionRegister = readDevice();
    }
    return getMissionChannelEnable(channel, this.missionRegister);
  }

  public boolean getMissionChannelEnable(int channel, byte[] state)
    throws OneWireException, OneWireIOException
  {
    if (channel == 0)
    {
      return getFlag(19, 1, state);
    }

    if (channel == 1)
    {
      return getFlag(19, 2, state);
    }

    throw new IllegalArgumentException("Invalid Channel");
  }

  public int getMissionSampleRate(int channel)
    throws OneWireException, OneWireIOException
  {
    if (!this.isMissionLoaded) {
      throw new OneWireException("Must load mission results first.");
    }
    return this.sampleRate;
  }

  public int getMissionSampleCount(int channel)
    throws OneWireException, OneWireIOException
  {
    if (!this.isMissionLoaded) {
      throw new OneWireException("Must load mission results first.");
    }
    return this.sampleCount;
  }

  public int getDeviceSampleCount()
    throws OneWireException, OneWireIOException
  {
    return getDeviceSampleCount(readDevice());
  }

  public int getDeviceSampleCount(byte[] state)
    throws OneWireException, OneWireIOException
  {
    return Convert.toInt(state, 35, 3);
  }

  public int getMissionSampleCountTotal(int channel)
    throws OneWireException, OneWireIOException
  {
    if (!this.isMissionLoaded) {
      throw new OneWireException("Must load mission results first.");
    }
    return this.sampleCountTotal;
  }

  public double getMissionSample(int channel, int sampleNum)
    throws OneWireException, OneWireIOException
  {
    if (!this.isMissionLoaded) {
      throw new OneWireException("Must load mission results first.");
    }
    if ((sampleNum >= this.sampleCount) || (sampleNum < 0)) {
      throw new IllegalArgumentException("Invalid sample number");
    }
    double val = 0.0D;
    if (channel == 0)
    {
      val = decodeTemperature(this.temperatureLog, sampleNum * this.temperatureBytes, this.temperatureBytes, true);

      if (this.useTempCalibrationRegisters)
      {
        double valsq = val * val;
        double error = this.tempCoeffA * valsq + this.tempCoeffB * val + this.tempCoeffC;

        val -= error;
      }
    }
    else if (channel == 1)
    {
      if ((this.hasHumiditySensor) && (!this.adForceResults))
      {
        val = decodeHumidity(this.dataLog, sampleNum * this.dataBytes, this.dataBytes, true);

        if (this.useTemperatureCompensation)
        {
          double T;
          if ((!this.overrideTemperatureLog) && (getMissionSampleCount(0) > 0))
          {
            T = getMissionSample(0, sampleNum);
          }
          else T = this.defaultTempCompensationValue;
          double gamma = T > 15.0D ? 1.E-005D : -5.E-005D;
          T -= 25.0D;
          val = (val * 0.0307D + 0.0035D * T - 4.3E-005D * T * T) / (0.0307D + gamma * T - 2.0E-006D * T * T);
        }

      }
      else
      {
        val = getADVoltage(this.dataLog, sampleNum * this.dataBytes, this.dataBytes, true);
      }
    }
    else {
      throw new IllegalArgumentException("Invalid Channel");
    }
    return val;
  }

  public int getMissionSampleAsInteger(int channel, int sampleNum)
    throws OneWireException, OneWireIOException
  {
    if (!this.isMissionLoaded) {
      throw new OneWireException("Must load mission results first.");
    }
    if ((sampleNum >= this.sampleCount) || (sampleNum < 0)) {
      throw new IllegalArgumentException("Invalid sample number");
    }
    int i = 0;
    if (channel == 0)
    {
      if (this.temperatureBytes == 2)
      {
        i = (0xFF & this.temperatureLog[(sampleNum * this.temperatureBytes)]) << 8 | 0xFF & this.temperatureLog[(sampleNum * this.temperatureBytes + 1)];
      }
      else
      {
        i = 0xFF & this.temperatureLog[(sampleNum * this.temperatureBytes)];
      }
    }
    else if (channel == 1)
    {
      if (this.dataBytes == 2)
      {
        i = (0xFF & this.dataLog[(sampleNum * this.dataBytes)]) << 8 | 0xFF & this.dataLog[(sampleNum * this.dataBytes + 1)];
      }
      else
      {
        i = 0xFF & this.dataLog[(sampleNum * this.dataBytes)];
      }
    }
    else {
      throw new IllegalArgumentException("Invalid Channel");
    }
    return i;
  }

  public long getMissionSampleTimeStamp(int channel, int sampleNum)
    throws OneWireException, OneWireIOException
  {
    if (!this.isMissionLoaded) {
      throw new OneWireException("Must load mission results first.");
    }
    long delta = (this.timeOffset + sampleNum) * this.sampleRate;
    return delta * 1000L + this.missionTimeStamp;
  }

  public boolean isMissionRunning()
    throws OneWireException, OneWireIOException
  {
    return getFlag(533, 2);
  }

  public boolean isMissionRolloverEnabled()
    throws OneWireException, OneWireIOException
  {
    if (this.isMissionLoaded) {
      return getFlag(19, 16, this.missionRegister);
    }

    return getFlag(19, 16);
  }

  public boolean hasMissionRolloverOccurred()
    throws OneWireException, OneWireIOException
  {
    if (!this.isMissionLoaded) {
      throw new OneWireException("Must load mission results first.");
    }
    return this.rolledOver;
  }

  public void clearMissionResults()
    throws OneWireException, OneWireIOException
  {
    clearMemory();
    this.isMissionLoaded = false;
  }

  public long getMissionTimeStamp(int channel)
    throws OneWireException, OneWireIOException
  {
    if (!this.isMissionLoaded) {
      throw new OneWireException("Must load mission results first.");
    }
    return this.missionTimeStamp;
  }

  public long getFirstSampleOffset(int channel)
    throws OneWireException, OneWireIOException
  {
    if (!this.isMissionLoaded) {
      throw new OneWireException("Must load mission results first.");
    }
    return this.timeOffset * this.sampleRate * 1000L;
  }

  public double[] getMissionResolutions(int channel)
    throws OneWireException, OneWireIOException
  {
    if (channel == 0)
    {
      return new double[] { temperatureResolutions[0], temperatureResolutions[1] };
    }
    if (channel == 1)
    {
      if ((this.hasHumiditySensor) && (!this.adForceResults))
        return new double[] { humidityResolutions[0], humidityResolutions[1] };
      if (this.adForceResults) {
        return new double[] { dataResolutions[0], dataResolutions[1] };
      }
      return new double[] { 8.0D, 16.0D };
    }

    throw new IllegalArgumentException("Invalid Channel");
  }

  public double getMissionResolution(int channel)
    throws OneWireException, OneWireIOException
  {
    if (!this.isMissionLoaded) {
      throw new OneWireException("Must load mission results first.");
    }
    double resolution = 0.0D;
    if (channel == 0)
    {
      if (getFlag(19, 4, this.missionRegister))
      {
        resolution = temperatureResolutions[1];
      }
      else resolution = temperatureResolutions[0];
    }
    else if (channel == 1)
    {
      if (getFlag(19, 8, this.missionRegister))
      {
        if ((this.hasHumiditySensor) && (!this.adForceResults))
          resolution = humidityResolutions[1];
        else if (this.adForceResults)
          resolution = dataResolutions[1];
        else {
          resolution = 16.0D;
        }

      }
      else if ((this.hasHumiditySensor) && (!this.adForceResults))
        resolution = humidityResolutions[0];
      else if (this.adForceResults)
        resolution = dataResolutions[0];
      else {
        resolution = 8.0D;
      }
    }
    else
    {
      throw new IllegalArgumentException("Invalid Channel");
    }
    return resolution;
  }

  public void setMissionResolution(int channel, double resolution)
    throws OneWireException, OneWireIOException
  {
    if (!this.isMissionLoaded) {
      this.missionRegister = readDevice();
    }
    if (channel == 0)
    {
      setFlag(19, 4, resolution == temperatureResolutions[1], this.missionRegister);
    }
    else if (channel == 1)
    {
      if ((this.hasHumiditySensor) && (!this.adForceResults)) {
        setFlag(19, 8, resolution == humidityResolutions[1], this.missionRegister);
      }
      else if (this.adForceResults) {
        setFlag(19, 8, resolution == dataResolutions[1], this.missionRegister);
      }
      else
      {
        setFlag(19, 8, resolution == 16.0D, this.missionRegister);
      }

    }
    else
    {
      throw new IllegalArgumentException("Invalid Channel");
    }

    writeDevice(this.missionRegister);
  }

  public void setTemperatureCalibrationRegisterUsage(boolean use)
  {
    this.useTempCalibrationRegisters = use;
  }

  public void setHumidityCalibrationRegisterUsage(boolean use)
  {
    this.useHumdCalibrationRegisters = use;
  }

  public void setTemperatureCompensationUsage(boolean use)
  {
    this.useTemperatureCompensation = use;
  }

  public void setDefaultTemperatureCompensationValue(double temperatureValue, boolean override)
  {
    this.defaultTempCompensationValue = temperatureValue;
    this.overrideTemperatureLog = override;
  }

  public boolean hasMissionAlarms(int channel)
  {
    return true;
  }

  public boolean hasMissionAlarmed(int channel, int alarmType)
    throws OneWireException, OneWireIOException
  {
    if (!this.isMissionLoaded) {
      throw new OneWireException("Must load mission results first.");
    }
    if (channel == 0)
    {
      if (alarmType == 1)
      {
        return getFlag(532, 2, this.missionRegister);
      }

      return getFlag(532, 1, this.missionRegister);
    }

    if (channel == 1)
    {
      if (alarmType == 1)
      {
        return getFlag(532, 8, this.missionRegister);
      }

      return getFlag(532, 4, this.missionRegister);
    }

    throw new IllegalArgumentException("Invalid Channel");
  }

  public boolean getMissionAlarmEnable(int channel, int alarmType)
    throws OneWireException, OneWireIOException
  {
    if (!this.isMissionLoaded) {
      throw new OneWireException("Must load mission results first.");
    }
    if (channel == 0)
    {
      if (alarmType == 1)
      {
        return getFlag(528, 2, this.missionRegister);
      }

      return getFlag(528, 1, this.missionRegister);
    }

    if (channel == 1)
    {
      if (alarmType == 1)
      {
        return getFlag(529, 2, this.missionRegister);
      }

      return getFlag(529, 1, this.missionRegister);
    }

    throw new IllegalArgumentException("Invalid Channel");
  }

  public void setMissionAlarmEnable(int channel, int alarmType, boolean enable)
    throws OneWireException, OneWireIOException
  {
    if (!this.isMissionLoaded) {
      this.missionRegister = readDevice();
    }

    if (channel == 0)
    {
      if (alarmType == 1)
      {
        setFlag(528, 2, enable, this.missionRegister);
      }
      else
      {
        setFlag(528, 1, enable, this.missionRegister);
      }

    }
    else if (channel == 1)
    {
      if (alarmType == 1)
      {
        setFlag(529, 2, enable, this.missionRegister);
      }
      else
      {
        setFlag(529, 1, enable, this.missionRegister);
      }

    }
    else
    {
      throw new IllegalArgumentException("Invalid Channel");
    }

    writeDevice(this.missionRegister);
  }

  public double getMissionAlarm(int channel, int alarmType)
    throws OneWireException, OneWireIOException
  {
    if (!this.isMissionLoaded) {
      throw new OneWireException("Must load mission results first.");
    }
    double th = 0.0D;
    if (channel == 0)
    {
      if (alarmType == 1)
      {
        th = decodeTemperature(this.missionRegister, 9, 1, false);
      }
      else
      {
        th = decodeTemperature(this.missionRegister, 8, 1, false);
      }

    }
    else if (channel == 1)
    {
      if (alarmType == 1)
      {
        if ((this.hasHumiditySensor) && (!this.adForceResults))
          th = decodeHumidity(this.missionRegister, 11, 1, false);
        else if (this.adForceResults)
          th = getADVoltage(this.missionRegister, 11, 1, false);
        else {
          th = 0xFF & this.missionRegister[11];
        }

      }
      else if ((this.hasHumiditySensor) && (!this.adForceResults))
        th = decodeHumidity(this.missionRegister, 10, 1, false);
      else if (this.adForceResults)
        th = getADVoltage(this.missionRegister, 10, 1, false);
      else {
        th = 0xFF & this.missionRegister[10];
      }
    }
    else
    {
      throw new IllegalArgumentException("Invalid Channel");
    }
    return th;
  }

  public void setMissionAlarm(int channel, int alarmType, double threshold)
    throws OneWireException, OneWireIOException
  {
    if (!this.isMissionLoaded) {
      this.missionRegister = readDevice();
    }

    if (channel == 0)
    {
      if (alarmType == 1)
      {
        encodeTemperature(threshold, this.missionRegister, 9, 1, false);
      }
      else
      {
        encodeTemperature(threshold, this.missionRegister, 8, 1, false);
      }

    }
    else if (channel == 1)
    {
      if (alarmType == 1)
      {
        if ((this.hasHumiditySensor) && (!this.adForceResults))
          encodeHumidity(threshold, this.missionRegister, 11, 1, false);
        else if (this.adForceResults)
          setADVoltage(threshold, this.missionRegister, 11, 1, false);
        else {
          this.missionRegister[11] = (byte)(int)threshold;
        }

      }
      else if ((this.hasHumiditySensor) && (!this.adForceResults))
        encodeHumidity(threshold, this.missionRegister, 10, 1, false);
      else if (this.adForceResults)
        setADVoltage(threshold, this.missionRegister, 10, 1, false);
      else {
        this.missionRegister[10] = (byte)(int)threshold;
      }
    }
    else
    {
      throw new IllegalArgumentException("Invalid Channel");
    }

    writeDevice(this.missionRegister);
  }

  public boolean hasTemperatureAlarms()
  {
    return true;
  }

  public boolean hasSelectableTemperatureResolution()
  {
    return false;
  }

  public double[] getTemperatureResolutions()
  {
    double[] d = new double[1];

    d[0] = temperatureResolutions[1];

    return d;
  }

  public double getTemperatureAlarmResolution()
  {
    return temperatureResolutions[0];
  }

  public double getMaxTemperature()
  {
    return this.temperatureRangeLow + this.temperatureRangeWidth;
  }

  public double getMinTemperature()
  {
    return this.temperatureRangeLow;
  }

  public void doTemperatureConvert(byte[] state)
    throws OneWireIOException, OneWireException
  {
    if (getFlag(533, 2, state)) {
      throw new OneWireIOException("OneWireContainer41-Cant force temperature read during a mission.");
    }

    if (!getFlag(530, 1, state)) {
      throw new OneWireIOException("OneWireContainer41-Cant force temperature conversion if the oscillator is not enabled");
    }

    if (this.doSpeedEnable) {
      doSpeed();
    }
    this.adapter.reset();

    if (this.adapter.select(this.address))
    {
      byte[] buffer = { 85, -1 };
      this.adapter.dataBlock(buffer, 0, 2);

      msWait(750L);

      state[12] = readByte(524);

      state[13] = readByte(525);
    }
    else
    {
      throw new OneWireException("OneWireContainer41-Device not found!");
    }
  }

  public double getTemperature(byte[] state)
  {
    double val = decodeTemperature(state, 12, 2, false);
    if (this.useTempCalibrationRegisters)
    {
      double valsq = val * val;
      double error = this.tempCoeffA * valsq + this.tempCoeffB * val + this.tempCoeffC;

      val -= error;
    }
    return val;
  }

  public double getTemperatureAlarm(int alarmType, byte[] state)
  {
    double th = 0.0D;
    if (alarmType == 1) {
      th = decodeTemperature(state, 9, 1, false);
    }
    else {
      th = decodeTemperature(state, 8, 1, false);
    }
    if (this.useTempCalibrationRegisters)
    {
      double thsq = th * th;
      double error = this.tempCoeffA * thsq + this.tempCoeffB * th + this.tempCoeffC;

      th -= error;
    }
    return th;
  }

  public double getTemperatureResolution(byte[] state)
  {
    return temperatureResolutions[1];
  }

  public void setTemperatureAlarm(int alarmType, double alarmValue, byte[] state)
  {
    if (this.useTempCalibrationRegisters)
    {
      alarmValue = (1.0D - this.tempCoeffB - Math.sqrt((this.tempCoeffB - 1.0D) * (this.tempCoeffB - 1.0D) - 4.0D * this.tempCoeffA * (this.tempCoeffC + alarmValue))) / (2.0D * this.tempCoeffA);
    }

    if (alarmType == 1)
    {
      encodeTemperature(alarmValue, state, 9, 1, false);
    }
    else
    {
      encodeTemperature(alarmValue, state, 8, 1, false);
    }
  }

  public void setTemperatureResolution(double resolution, byte[] state)
    throws OneWireException
  {
    throw new OneWireException("Selectable Temperature Resolution Not Supported");
  }

  public boolean isRelative()
  {
    return true;
  }

  public boolean hasHumidityAlarms()
  {
    return true;
  }

  public boolean hasSelectableHumidityResolution()
  {
    return false;
  }

  public double[] getHumidityResolutions()
  {
    double[] d = new double[1];

    d[0] = humidityResolutions[1];

    return d;
  }

  public double getHumidityAlarmResolution()
    throws OneWireException
  {
    return humidityResolutions[0];
  }

  public void doHumidityConvert(byte[] state)
    throws OneWireIOException, OneWireException
  {
    if (getFlag(533, 2, state)) {
      throw new OneWireIOException("OneWireContainer41-Cant force Humidity read during a mission.");
    }

    if (!getFlag(530, 1, state)) {
      throw new OneWireIOException("OneWireContainer41-Cant force Humidity conversion if the oscillator is not enabled");
    }

    if (this.doSpeedEnable) {
      doSpeed();
    }
    this.adapter.reset();

    if (this.adapter.select(this.address))
    {
      byte[] buffer = { 85, -1 };
      this.adapter.dataBlock(buffer, 0, 2);

      msWait(750L);

      state[14] = readByte(526);

      state[15] = readByte(527);
    }
    else
    {
      throw new OneWireException("OneWireContainer41-Device not found!");
    }
  }

  public double getHumidity(byte[] state)
  {
    double val = decodeHumidity(state, 14, 2, false);
    if (this.useTemperatureCompensation)
    {
      double T = decodeTemperature(state, 12, 2, false);
      double gamma = T > 15.0D ? 1.E-005D : -5.E-005D;
      T -= 25.0D;
      val = (val * 0.0307D + 0.0035D * T - 4.3E-005D * T * T) / (0.0307D + gamma * T - 2.0E-006D * T * T);
    }

    return val;
  }

  public double getHumidityResolution(byte[] state)
  {
    return humidityResolutions[1];
  }

  public double getHumidityAlarm(int alarmType, byte[] state)
    throws OneWireException
  {
    double th;
    if (alarmType == 1)
      th = decodeHumidity(state, 11, 1, false);
    else
      th = decodeHumidity(state, 10, 1, false);
    return th;
  }

  public void setHumidityAlarm(int alarmType, double alarmValue, byte[] state)
    throws OneWireException
  {
    if (alarmType == 1)
      encodeHumidity(alarmValue, state, 11, 1, false);
    else
      encodeHumidity(alarmValue, state, 10, 1, false);
  }

  public void setHumidityResolution(double resolution, byte[] state)
    throws OneWireException
  {
    throw new OneWireException("Selectable Humidity Resolution Not Supported");
  }

  public int getNumberADChannels()
  {
    return 1;
  }

  public boolean hasADAlarms()
  {
    return true;
  }

  public double[] getADRanges(int channel)
  {
    return new double[] { 127.0D };
  }

  public double[] getADResolutions(int channel, double range)
  {
    return new double[] { dataResolutions[1] };
  }

  public boolean canADMultiChannelRead()
  {
    return true;
  }

  public void doADConvert(int channel, byte[] state)
    throws OneWireIOException, OneWireException
  {
    if (getFlag(533, 2, state)) {
      throw new OneWireIOException("OneWireContainer41-Cant force temperature read during a mission.");
    }

    if (!getFlag(530, 1, state)) {
      throw new OneWireIOException("OneWireContainer41-Cant force A/D conversion if the oscillator is not enabled");
    }

    if (this.doSpeedEnable) {
      doSpeed();
    }
    this.adapter.reset();

    if (this.adapter.select(this.address))
    {
      byte[] buffer = { 85, -1 };
      this.adapter.dataBlock(buffer, 0, 2);

      msWait(750L);

      state[14] = readByte(526);

      state[15] = readByte(527);
    }
    else
    {
      throw new OneWireException("OneWireContainer41-Device not found!");
    }
  }

  public void doADConvert(boolean[] doConvert, byte[] state)
    throws OneWireIOException, OneWireException
  {
    doADConvert(1, state);
  }

  public double[] getADVoltage(byte[] state)
    throws OneWireIOException, OneWireException
  {
    return new double[] { getADVoltage(1, state) };
  }

  public double getADVoltage(int channel, byte[] state)
    throws OneWireIOException, OneWireException
  {
    return getADVoltage(state, 14, 2, false);
  }

  public double getADAlarm(int channel, int alarmType, byte[] state)
    throws OneWireException
  {
    double th = 0.0D;
    if (alarmType == 1)
    {
      th = getADVoltage(state, 11, 1, false);
    }
    else
    {
      th = getADVoltage(state, 10, 1, false);
    }

    return th;
  }

  public boolean getADAlarmEnable(int channel, int alarmType, byte[] state)
    throws OneWireException
  {
    boolean b = false;
    if (alarmType == 1)
    {
      b = getFlag(529, 2, state);
    }
    else
    {
      b = getFlag(529, 1, state);
    }

    return b;
  }

  public boolean hasADAlarmed(int channel, int alarmType, byte[] state)
    throws OneWireException
  {
    boolean b = false;
    if (alarmType == 1)
    {
      b = getFlag(532, 8, state);
    }
    else
    {
      b = getFlag(532, 4, state);
    }

    return b;
  }

  public double getADResolution(int channel, byte[] state)
  {
    return dataResolutions[1];
  }

  public double getADRange(int channel, byte[] state)
  {
    return 127.0D;
  }

  public void setADAlarm(int channel, int alarmType, double alarm, byte[] state)
    throws OneWireException
  {
    if (alarmType == 1)
    {
      setADVoltage(alarm, state, 11, 1, false);
    }
    else
    {
      setADVoltage(alarm, state, 10, 1, false);
    }
  }

  public void setADAlarmEnable(int channel, int alarmType, boolean alarmEnable, byte[] state)
    throws OneWireException
  {
    if (alarmType == 1)
    {
      setFlag(529, 2, alarmEnable, state);
    }
    else
    {
      setFlag(529, 1, alarmEnable, state);
    }
  }

  public void setADResolution(int channel, double resolution, byte[] state)
  {
  }

  public void setADRange(int channel, double range, byte[] state)
  {
  }

  public void setADReferenceVoltage(double referenceVoltage)
  {
    this.adReferenceVoltage = referenceVoltage;
  }

  public double getADReferenceVoltage()
  {
    return this.adReferenceVoltage;
  }

  public void setADDeviceBitCount(int bits)
  {
    if (bits > 16)
      bits = 16;
    if (bits < 8)
      bits = 8;
    this.adDeviceBits = bits;
  }

  public int getADDeviceBitCount()
  {
    return this.adDeviceBits;
  }

  public void setForceADResults(boolean force)
  {
    this.adForceResults = force;
  }

  public boolean getForceADResults()
  {
    return this.adForceResults;
  }

  public boolean hasClockAlarm()
  {
    return false;
  }

  public boolean canDisableClock()
  {
    return true;
  }

  public long getClockResolution()
  {
    return 1000L;
  }

  public long getClock(byte[] state)
  {
    int[] time = getTime(0, state);

    int[] date = getDate(3, state);

    Calendar d = new GregorianCalendar(date[0], date[1] - 1, date[2], time[2], time[1], time[0]);

    return d.getTime().getTime();
  }

  public long getClockAlarm(byte[] state)
    throws OneWireException
  {
    throw new OneWireException("Device does not support clock alarms");
  }

  public boolean isClockAlarming(byte[] state)
  {
    return false;
  }

  public boolean isClockAlarmEnabled(byte[] state)
  {
    return false;
  }

  public boolean isClockRunning(byte[] state)
  {
    return getFlag(530, 1, state);
  }

  public void setClock(long time, byte[] state)
  {
    Date x = new Date(time);
    Calendar d = new GregorianCalendar();

    d.setTime(x);
    setTime(0, d.get(11), d.get(12), d.get(13), false, state);

    setDate(3, d.get(1), d.get(2) + 1, d.get(5), state);

    if (!getFlag(530, 1, state)) {
      setFlag(530, 1, true, state);
    }
    synchronized (this)
    {
      this.updatertc = true;
    }
  }

  public void setClockAlarm(long time, byte[] state)
    throws OneWireException
  {
    throw new OneWireException("Device does not support clock alarms");
  }

  public void setClockRunEnable(boolean runEnable, byte[] state)
  {
    setFlag(530, 1, runEnable, state);
  }

  public void setClockAlarmEnable(boolean alarmEnable, byte[] state)
    throws OneWireException
  {
    throw new OneWireException("Device does not support clock alarms");
  }

  private int[] getTime(int timeReg, byte[] state)
  {
    int[] result = new int[3];

    byte lower = state[(timeReg++)];
    byte upper = (byte)(lower >>> 4 & 0x7);
    lower = (byte)(lower & 0xF);
    result[0] = (lower + upper * 10);

    lower = state[(timeReg++)];
    upper = (byte)(lower >>> 4 & 0x7);
    lower = (byte)(lower & 0xF);
    result[1] = (lower + upper * 10);

    lower = state[timeReg];
    upper = (byte)(lower >>> 4 & 0x7);
    lower = (byte)(lower & 0xF);

    byte PM = 0;

    if ((upper & 0x4) != 0)
    {
      if ((upper & 0x2) > 0) {
        PM = 12;
      }

      upper = (byte)(upper & 0x1);
    }

    result[2] = (upper * 10 + lower + PM);

    return result;
  }

  private void setTime(int timeReg, int hours, int minutes, int seconds, boolean AMPM, byte[] state)
  {
    byte upper = (byte)(seconds / 10 << 4 & 0xF0);
    byte lower = (byte)(seconds % 10 & 0xF);
    state[(timeReg++)] = (byte)(upper | lower);

    upper = (byte)(minutes / 10 << 4 & 0xF0);
    lower = (byte)(minutes % 10 & 0xF);
    state[(timeReg++)] = (byte)(upper | lower);

    if (AMPM)
    {
      upper = 4;

      if (hours > 11) {
        upper = (byte)(upper | 0x2);
      }

      if ((hours % 12 == 0) || (hours % 12 > 9)) {
        upper = (byte)(upper | 0x1);
      }
      if (hours > 12) {
        hours -= 12;
      }
      if (hours == 0)
        lower = 2;
      else
        lower = (byte)(hours % 10 & 0xF);
    }
    else
    {
      upper = (byte)(hours / 10);
      lower = (byte)(hours % 10);
    }

    upper = (byte)(upper << 4 & 0xF0);
    lower = (byte)(lower & 0xF);
    state[timeReg] = (byte)(upper | lower);
  }

  private int[] getDate(int timeReg, byte[] state)
  {
    int[] result = { 0, 0, 0 };

    byte lower = state[(timeReg++)];
    byte upper = (byte)(lower >>> 4 & 0xF);
    lower = (byte)(lower & 0xF);
    result[2] = (upper * 10 + lower);

    lower = state[(timeReg++)];
    if ((lower & 0x80) == 128)
      result[0] = 100;
    upper = (byte)(lower >>> 4 & 0x1);
    lower = (byte)(lower & 0xF);
    result[1] = (upper * 10 + lower);

    lower = state[(timeReg++)];
    upper = (byte)(lower >>> 4 & 0xF);
    lower = (byte)(lower & 0xF);
    result[0] += upper * 10 + lower + 2000;

    return result;
  }

  private void setDate(int timeReg, int year, int month, int day, byte[] state)
  {
    byte upper = (byte)(day / 10 << 4 & 0xF0);
    byte lower = (byte)(day % 10 & 0xF);
    state[(timeReg++)] = (byte)(upper | lower);

    upper = (byte)(month / 10 << 4 & 0xF0);
    lower = (byte)(month % 10 & 0xF);
    state[(timeReg++)] = (byte)(upper | lower);

    year -= 2000;
    if (year > 100)
    {
      int tmp91_90 = (timeReg - 1);
      byte[] tmp91_86 = state; tmp91_86[tmp91_90] = (byte)(tmp91_86[tmp91_90] | 0x80);
      year -= 100;
    }
    upper = (byte)(year / 10 << 4 & 0xF0);
    lower = (byte)(year % 10 & 0xF);
    state[timeReg] = (byte)(upper | lower);
  }

  private void initMem()
  {
    this.scratch = new MemoryBankScratchCRCPW(this);

    this.userDataMemory = new MemoryBankNVCRCPW(this, this.scratch);
    this.userDataMemory.numberPages = 16;
    this.userDataMemory.size = 512;
    this.userDataMemory.bankDescription = "User Data Memory";
    this.userDataMemory.startPhysicalAddress = 0;
    this.userDataMemory.generalPurposeMemory = true;
    this.userDataMemory.readOnly = false;
    this.userDataMemory.readWrite = true;

    this.register = new MemoryBankNVCRCPW(this, this.scratch);
    this.register.numberPages = 32;
    this.register.size = 1024;
    this.register.bankDescription = "Register control";
    this.register.startPhysicalAddress = 512;
    this.register.generalPurposeMemory = false;

    this.log = new MemoryBankNVCRCPW(this, this.scratch);
    this.log.numberPages = 256;
    this.log.size = 8192;
    this.log.bankDescription = "Data log";
    this.log.startPhysicalAddress = 4096;
    this.log.generalPurposeMemory = false;
    this.log.readOnly = true;
    this.log.readWrite = false;
  }

  private void setContainerVariables(byte[] registerPages)
  {
    double Tref1 = 60.0D;
    boolean autoLoadCalibration = true;

    this.isContainerVariablesSet = false;

    this.hasHumiditySensor = false;
    this.isMissionLoaded = false;
    this.missionRegister = null;
    this.dataLog = null;
    this.temperatureLog = null;
    this.adReferenceVoltage = 5.02D;
    this.adDeviceBits = 10;
    this.adForceResults = false;

    this.deviceConfigByte = -1;
    if (registerPages != null)
    {
      this.deviceConfigByte = registerPages[38];
    }

    switch (this.deviceConfigByte)
    {
    case 0:
      this.partNumber = "DS2422";
      this.temperatureRangeLow = -40.0D;
      this.temperatureRangeWidth = 125.0D;
      Tref1 = 60.0D;
      this.descriptionString = "The DS2422 temperature/datalogger combines the core functions of a fully featured datalogger in a single chip. It includes a temperature sensor, realtime clock (RTC), memory, 1-Wire® interface, and serial interface for an analog-to-digital converter (ADC) as well as control circuitry for a charge pump. The ADC and the charge pump are peripherals that can be added to build application-specific dataloggers. The MAX1086 is an example of a compatible serial ADC. Without external ADC, the DS2422 functions as a temperature logger only. The DS2422 measures the temperature and/or reads the ADC at a user-defined rate. A total of 8192 8-bit readings or 4096 16-bit readings taken at equidistant intervals ranging from 1s to 273hrs can be stored.";
      autoLoadCalibration = false;
      break;
    case 32:
      this.partNumber = "DS1923";
      this.temperatureRangeLow = -40.0D;
      this.temperatureRangeWidth = 125.0D;
      Tref1 = 60.0D;
      this.hasHumiditySensor = true;
      this.descriptionString = "The DS1923 Temperature/Humidity Logger iButton is a rugged, self-sufficient system that measures temperature and/or humidity and records the result in a protected memory section. The recording is done at a user-defined rate. A total of 8192 8-bit readings or 4096 16-bit readings taken at equidistant intervals ranging from 1 second to 273 hours can be stored. In addition to this, there are 512 bytes of SRAM for storing application specific information and 64 bytes for calibration data. A mission to collect data can be programmed to begin immediately, or after a user-defined delay or after a temperature alarm. Access to the memory and control functions can be password-protected.";
      break;
    case 64:
      this.partNumber = "DS1922L";
      this.temperatureRangeLow = -40.0D;
      this.temperatureRangeWidth = 125.0D;
      Tref1 = 60.0D;
      this.descriptionString = "The DS1922L/T Temperature Logger iButtons are rugged, self-sufficient systems that measure temperature and record the result in a protected memory section. The recording is done at a user-defined rate. A total of 8192 8-bit readings or 4096 16-bit readings taken at equidistant intervals ranging from 1s to 273hrs can be stored. In addition to this, there are 512 bytes of SRAM for storing applicationspecific information and 64 bytes for calibration data. A mission to collect data can be programmed to begin immediately, or after a user-defined delay or after a temperature alarm. Access to the memory and control functions can be password protected.";
      break;
    case 96:
      this.partNumber = "DS1922T";
      this.temperatureRangeLow = 0.0D;
      this.temperatureRangeWidth = 125.0D;
      Tref1 = 90.0D;
      this.descriptionString = "The DS1922L/T Temperature Logger iButtons are rugged, self-sufficient systems that measure temperature and record the result in a protected memory section. The recording is done at a user-defined rate. A total of 8192 8-bit readings or 4096 16-bit readings taken at equidistant intervals ranging from 1s to 273hrs can be stored. In addition to this, there are 512 bytes of SRAM for storing applicationspecific information and 64 bytes for calibration data. A mission to collect data can be programmed to begin immediately, or after a user-defined delay or after a temperature alarm. Access to the memory and control functions can be password protected.";
      break;
    default:
      this.partNumber = "DS1922/DS1923/DS2422";
      this.temperatureRangeLow = -40.0D;
      this.temperatureRangeWidth = 125.0D;
      Tref1 = 60.0D;
      this.descriptionString = "Rugged, self-sufficient 1-Wire device that, once setup for a mission, will measure temperature and A-to-D/Humidity, with the result recorded in a protected memory section. It stores up to 8192 1-byte measurements, which can be filled with 1- or 2-byte temperature readings and 1- or 2-byte A-to-D/Humidity readings taken at a user-specified rate.";
      autoLoadCalibration = false;
    }

    if (registerPages != null)
    {
      this.isContainerVariablesSet = true;

      if (autoLoadCalibration)
      {
        if (this.hasHumiditySensor)
        {
          this.useHumdCalibrationRegisters = true;

          String useHumdCal = OneWireAccessProvider.getProperty("DS1923.useHumidityCalibrationRegisters");

          if ((useHumdCal != null) && (useHumdCal.toLowerCase().equals("false")))
          {
            this.useHumdCalibrationRegisters = false;
          }

          this.Href1 = decodeHumidity(registerPages, 72, 2, true);
          this.Hread1 = decodeHumidity(registerPages, 74, 2, true);
          this.Herror1 = (this.Hread1 - this.Href1);
          this.Href2 = decodeHumidity(registerPages, 76, 2, true);
          this.Hread2 = decodeHumidity(registerPages, 78, 2, true);
          this.Herror2 = (this.Hread2 - this.Href2);
          this.Href3 = decodeHumidity(registerPages, 80, 2, true);
          this.Hread3 = decodeHumidity(registerPages, 82, 2, true);
          this.Herror3 = (this.Hread3 - this.Href3);

          double Href1sq = this.Href1 * this.Href1;
          double Href2sq = this.Href2 * this.Href2;
          double Href3sq = this.Href3 * this.Href3;
          this.humdCoeffB = (((Href2sq - Href1sq) * (this.Herror3 - this.Herror1) + Href3sq * (this.Herror1 - this.Herror2) + Href1sq * (this.Herror2 - this.Herror1)) / ((Href2sq - Href1sq) * (this.Href3 - this.Href1) + (Href3sq - Href1sq) * (this.Href1 - this.Href2)));

          this.humdCoeffA = ((this.Herror2 - this.Herror1 + this.humdCoeffB * (this.Href1 - this.Href2)) / (Href2sq - Href1sq));

          this.humdCoeffC = (this.Herror1 - this.humdCoeffA * Href1sq - this.humdCoeffB * this.Href1);
        }

        this.useTempCalibrationRegisters = true;

        String useTempCal = OneWireAccessProvider.getProperty("DS1923.useTemperatureCalibrationRegisters");

        if ((useTempCal != null) && (useTempCal.toLowerCase().equals("false")))
        {
          this.useTempCalibrationRegisters = false;
        }

        this.Tref2 = decodeTemperature(registerPages, 64, 2, true);
        this.Tread2 = decodeTemperature(registerPages, 66, 2, true);
        this.Terror2 = (this.Tread2 - this.Tref2);
        this.Tref3 = decodeTemperature(registerPages, 68, 2, true);
        this.Tread3 = decodeTemperature(registerPages, 70, 2, true);
        this.Terror3 = (this.Tread3 - this.Tref3);
        this.Terror1 = this.Terror2;
        this.Tread1 = (Tref1 + this.Terror1);

        double Tref1sq = Tref1 * Tref1;
        double Tref2sq = this.Tref2 * this.Tref2;
        double Tref3sq = this.Tref3 * this.Tref3;
        this.tempCoeffB = (((Tref2sq - Tref1sq) * (this.Terror3 - this.Terror1) + Tref3sq * (this.Terror1 - this.Terror2) + Tref1sq * (this.Terror2 - this.Terror1)) / ((Tref2sq - Tref1sq) * (this.Tref3 - Tref1) + (Tref3sq - Tref1sq) * (Tref1 - this.Tref2)));

        this.tempCoeffA = ((this.Terror2 - this.Terror1 + this.tempCoeffB * (Tref1 - this.Tref2)) / (Tref2sq - Tref1sq));

        this.tempCoeffC = (this.Terror1 - this.tempCoeffA * Tref1sq - this.tempCoeffB * Tref1);
      }
    }
  }

  private static final void msWait(long ms)
  {
    try
    {
      Thread.sleep(ms);
    }
    catch (InterruptedException ie)
    {
    }
  }

  private final double decodeTemperature(byte[] data, int offset, int length, boolean reverse)
  {
    double fraction = 0.0D;
    double whole;
    if ((reverse) && (length == 2))
    {
      fraction = (data[(offset + 1)] & 0xFF) / 512.0D;
      whole = (data[offset] & 0xFF) / 2.0D + (this.temperatureRangeLow - 1.0D);
    }
    else if (length == 2)
    {
      fraction = (data[offset] & 0xFF) / 512.0D;
      whole = (data[(offset + 1)] & 0xFF) / 2.0D + (this.temperatureRangeLow - 1.0D);
    }
    else
    {
      whole = (data[offset] & 0xFF) / 2.0D + (this.temperatureRangeLow - 1.0D);
    }

    return whole + fraction;
  }

  private final void encodeTemperature(double temperature, byte[] data, int offset, int length, boolean reverse)
  {
    double val = 2.0D * (temperature - (this.temperatureRangeLow - 1.0D));

    if ((reverse) && (length == 2))
    {
      data[(offset + 1)] = (byte)(0xC0 & (byte)(int)(val * 256.0D));
      data[offset] = (byte)(int)val;
    }
    else if (length == 2)
    {
      data[offset] = (byte)(0xC0 & (byte)(int)(val * 256.0D));
      data[(offset + 1)] = (byte)(int)val;
    }
    else
    {
      data[offset] = (byte)(int)val;
    }
  }

  private final double decodeHumidity(byte[] data, int offset, int length, boolean reverse)
  {
    double val = getADVoltage(data, offset, length, reverse);

    val = (val - 0.958D) / 0.0307D;

    if (this.useHumdCalibrationRegisters)
    {
      double valsq = val * val;
      double error = this.humdCoeffA * valsq + this.humdCoeffB * val + this.humdCoeffC;

      val -= error;
    }

    return val;
  }

  private final void encodeHumidity(double humidity, byte[] data, int offset, int length, boolean reverse)
  {
    if (this.useHumdCalibrationRegisters)
    {
      humidity = (1.0D - this.humdCoeffB - Math.sqrt((this.humdCoeffB - 1.0D) * (this.humdCoeffB - 1.0D) - 4.0D * this.humdCoeffA * (this.humdCoeffC + humidity))) / (2.0D * this.humdCoeffA);
    }

    double val = humidity * 0.0307D + 0.958D;

    setADVoltage(val, data, offset, length, reverse);
  }

  private final double getADVoltage(byte[] data, int offset, int length, boolean reverse)
  {
    int ival = 0;
    if ((reverse) && (length == 2))
    {
      ival = (data[offset] & 0xFF) << this.adDeviceBits - 8;
      ival |= (data[(offset + 1)] & 0xFF) >> 16 - this.adDeviceBits;
    }
    else if (length == 2)
    {
      ival = (data[(offset + 1)] & 0xFF) << this.adDeviceBits - 8;
      ival |= (data[offset] & 0xFF) >> 16 - this.adDeviceBits;
    }
    else
    {
      ival = (data[offset] & 0xFF) << this.adDeviceBits - 8;
    }

    double dval = ival * this.adReferenceVoltage / (1 << this.adDeviceBits);

    return dval;
  }

  private final void setADVoltage(double voltage, byte[] data, int offset, int length, boolean reverse)
  {
    int val = (int)(voltage * (1 << this.adDeviceBits) / this.adReferenceVoltage);
    val &= (1 << this.adDeviceBits) - 1;

    if ((reverse) && (length == 2))
    {
      data[offset] = (byte)(val >> this.adDeviceBits - 8);
      data[(offset + 1)] = (byte)(val << 16 - this.adDeviceBits);
    }
    else if (length == 2)
    {
      data[(offset + 1)] = (byte)(val >> this.adDeviceBits - 8);
      data[offset] = (byte)(val << 16 - this.adDeviceBits);
    }
    else
    {
      data[offset] = (byte)((val & 0x3FC) >> this.adDeviceBits - 8);
    }
  }
}