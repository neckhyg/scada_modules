package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import java.util.Enumeration;
import java.util.Vector;

public class OneWireContainer30 extends OneWireContainer
  implements ADContainer, TemperatureContainer
{
  private static final byte WRITE_DATA_COMMAND = 108;
  private static final byte READ_DATA_COMMAND = 105;
  private static final byte COPY_DATA_COMMAND = 72;
  private static final byte RECALL_DATA_COMMAND = -72;
  private static final byte LOCK_COMMAND = 106;
  public static final byte PROTECTION_REGISTER = 0;
  public static final byte STATUS_REGISTER = 1;
  public static final byte EEPROM_REGISTER = 7;
  public static final byte SPECIAL_FEATURE_REGISTER = 8;
  public static final byte OVERVOLTAGE_FLAG = -128;
  public static final byte UNDERVOLTAGE_FLAG = 64;
  public static final byte CHARGE_OVERCURRENT_FLAG = 32;
  public static final byte DISCHARGE_OVERCURRENT_FLAG = 16;
  public static final byte CC_PIN_STATE_FLAG = 8;
  public static final byte DC_PIN_STATE_FLAG = 4;
  public static final byte CHARGE_ENABLE_FLAG = 2;
  public static final byte DISCHARGE_ENABLE_FLAG = 1;
  public static final byte SLEEP_MODE_ENABLE_FLAG = 32;
  public static final byte READ_NET_ADDRESS_OPCODE_FLAG = 16;
  public static final byte EEPROM_COPY_FLAG = -128;
  public static final byte EEPROM_LOCK_ENABLE_FLAG = 64;
  public static final byte EEPROM_BLOCK_1_LOCK_FLAG = 2;
  public static final byte EEPROM_BLOCK_0_LOCK_FLAG = 1;
  public static final byte PS_PIN_STATE_FLAG = -128;
  public static final byte PIO_PIN_SENSE_AND_CONTROL_FLAG = 64;
  private double Rsens = 0.05D;
  private boolean internalResistor;

  public OneWireContainer30()
  {
    this.internalResistor = true;
  }

  public OneWireContainer30(DSPortAdapter sourceAdapter, byte[] newAddress)
  {
    super(sourceAdapter, newAddress);

    this.internalResistor = true;
  }

  public OneWireContainer30(DSPortAdapter sourceAdapter, long newAddress)
  {
    super(sourceAdapter, newAddress);

    this.internalResistor = true;
  }

  public OneWireContainer30(DSPortAdapter sourceAdapter, String newAddress)
  {
    super(sourceAdapter, newAddress);

    this.internalResistor = true;
  }

  public String getName()
  {
    return "DS2760";
  }

  public String getAlternateNames()
  {
    return "1-Cell Li-Ion Battery Monitor";
  }

  public String getDescription()
  {
    return "The DS2760 is a data acquisition, information storage, and safety protection device tailored for cost-sensitive battery pack applications. This low-power device integrates precise temperature, voltage, and current measurement , nonvolatile data storage, and Li-Ion protection into the small footprint of either a TSSOP packet or flip-chip.";
  }

  public Enumeration getMemoryBanks()
  {
    Vector bank_vector = new Vector(1);

    MemoryBankEEPROMblock mn = new MemoryBankEEPROMblock(this);

    bank_vector.addElement(mn);

    return bank_vector.elements();
  }

  public synchronized void setResistorInternal()
  {
    this.internalResistor = true;
  }

  public synchronized void setResistorExternal(double Rsens)
  {
    this.internalResistor = false;
    this.Rsens = Rsens;
  }

  public byte readByte(int memAddr)
    throws OneWireIOException, OneWireException
  {
    byte[] buffer = new byte[3];

    doSpeed();
    this.adapter.reset();

    if (this.adapter.select(this.address))
    {
      buffer[0] = 105;
      buffer[1] = (byte)memAddr;
      buffer[2] = -1;

      this.adapter.dataBlock(buffer, 0, 3);

      return buffer[2];
    }

    throw new OneWireException("OneWireContainer30-Device not found.");
  }

  public void readBytes(int memAddr, byte[] buffer, int start, int len)
    throws OneWireIOException, OneWireException
  {
    doSpeed();
    this.adapter.reset();

    if (this.adapter.select(this.address))
    {
      for (int i = start; i < start + len; i++) {
        buffer[i] = -1;
      }
      this.adapter.putByte(105);
      this.adapter.putByte(memAddr & 0xFF);
      this.adapter.dataBlock(buffer, start, len);
    }
    else {
      throw new OneWireException("OneWireContainer30-Device not found.");
    }
  }

  public void writeByte(int memAddr, byte data)
    throws OneWireIOException, OneWireException
  {
    byte[] buffer = new byte[3];

    doSpeed();
    this.adapter.reset();

    if (this.adapter.select(this.address))
    {
      buffer[0] = 108;
      buffer[1] = (byte)memAddr;
      buffer[2] = data;

      this.adapter.dataBlock(buffer, 0, 3);
    }
    else
    {
      throw new OneWireException("OneWireContainer30-Device not found.");
    }
  }

  public byte[] readEEPROMBlock(int blockNumber)
    throws OneWireIOException, OneWireException
  {
    byte[] buffer = new byte[18];
    byte[] result = new byte[16];

    byte memAddr = (byte)(32 + blockNumber * 16);

    if (((blockNumber != 0 ? 1 : 0) & (blockNumber != 1 ? 1 : 0)) != 0) {
      throw new IllegalArgumentException("OneWireContainer30-Block number " + blockNumber + " is not a valid EEPROM block.");
    }

    doSpeed();
    this.adapter.reset();

    if (this.adapter.select(this.address))
    {
      buffer[0] = -72;
      buffer[1] = memAddr;

      this.adapter.dataBlock(buffer, 0, 2);

      this.adapter.reset();
      this.adapter.select(this.address);

      buffer[0] = 105;

      for (int i = 0; i < 16; i++) {
        buffer[(i + 2)] = -1;
      }
      this.adapter.dataBlock(buffer, 0, 18);

      System.arraycopy(buffer, 2, result, 0, 16);

      return result;
    }

    throw new OneWireException("OneWireContainer30-Device not found.");
  }

  public void writeEEPROMBlock(int blockNumber, byte[] data)
    throws OneWireIOException, OneWireException
  {
    byte[] buffer = new byte[18];

    byte memAddr = (byte)(32 + blockNumber * 16);

    if (data.length < 16) {
      throw new IllegalArgumentException("OneWireContainer30-Data block must consist of 16 bytes.");
    }

    if ((blockNumber != 0) && (blockNumber != 1)) {
      throw new IllegalArgumentException("OneWireContainer30-Block number " + blockNumber + " is not a valid EEPROM block.");
    }

    if (((blockNumber == 0) && (getFlag(7, 1))) || ((blockNumber == 1) && (getFlag(7, 2))))
    {
      throw new OneWireIOException("OneWireContainer30-Cant write data to locked EEPROM block.");
    }

    doSpeed();
    this.adapter.reset();

    if (this.adapter.select(this.address))
    {
      buffer[0] = 108;
      buffer[1] = memAddr;

      for (int i = 0; i < 16; i++) {
        buffer[(i + 2)] = data[i];
      }
      this.adapter.dataBlock(buffer, 0, 18);

      this.adapter.reset();
      this.adapter.select(this.address);

      buffer[0] = 105;

      for (int i = 0; i < 16; i++) {
        buffer[(i + 2)] = -1;
      }
      this.adapter.dataBlock(buffer, 0, 18);

      for (int i = 0; i < 16; i++) {
        if (buffer[(i + 2)] != data[i]) {
          throw new OneWireIOException("OneWireContainer30-Error writing EEPROM block" + blockNumber + ".");
        }

      }

      this.adapter.reset();
      this.adapter.select(this.address);

      buffer[0] = 72;

      this.adapter.dataBlock(buffer, 0, 2);
    }
    else {
      throw new OneWireException("OneWireContainer30-Device not found.");
    }
  }

  public void lockBlock(int blockNumber)
    throws OneWireIOException, OneWireException
  {
    byte memAddr = (byte)(32 + blockNumber * 16);

    if (((blockNumber != 0 ? 1 : 0) & (blockNumber != 1 ? 1 : 0)) != 0) {
      throw new IllegalArgumentException("OneWireContainer30-Block " + blockNumber + " is not a valid EEPROM block.");
    }

    doSpeed();
    this.adapter.reset();

    if (this.adapter.select(this.address))
    {
      this.adapter.putByte(106);
      this.adapter.putByte(memAddr);
    }
    else {
      throw new OneWireException("OneWireContainer30-Device not found.");
    }
  }

  public boolean getFlag(int memAddr, byte flagToGet)
    throws OneWireIOException, OneWireException
  {
    byte data = readByte(memAddr);

    return (data & flagToGet) != 0;
  }

  public void setFlag(int memAddr, byte flagToSet, boolean flagValue)
    throws OneWireIOException, OneWireException
  {
    if (memAddr == 1) {
      memAddr = 49;
    }
    byte data = readByte(memAddr);

    if (flagValue)
      data = (byte)(data | flagToSet);
    else {
      data = (byte)(data & (flagToSet ^ 0xFFFFFFFF));
    }
    writeByte(memAddr, data);
  }

  public double getCurrent(byte[] state)
    throws OneWireIOException, OneWireException
  {
    int data = state[14] << 8 | state[15] & 0xFF;

    data >>= 3;
    double result;
    if (this.internalResistor) {
      result = data * 0.625D / 1000.0D;
    }
    else
    {
      result = data * 1.5625E-005D / this.Rsens;
    }
    return result;
  }

  public void setRemainingCapacity(double remainingCapacity)
    throws OneWireIOException, OneWireException
  {
    int data;
    if (this.internalResistor)
      data = (int)(remainingCapacity * 4.0D);
    else {
      data = (int)(remainingCapacity * this.Rsens / 0.00626D);
    }

    writeByte(16, (byte)(data >> 8));
    writeByte(17, (byte)(data & 0xFF));
  }

  public double getRemainingCapacity(byte[] state)
    throws OneWireIOException, OneWireException
  {
    double result = 0.0D;

    int data = (state[16] & 0xFF) << 8 | state[17] & 0xFF;

    if (this.internalResistor) {
      result = data / 4.0D;
    }
    else
    {
      result = data * 0.00626D / this.Rsens;
    }
    return result;
  }

  public void setLatchState(boolean on)
    throws OneWireIOException, OneWireException
  {
    writeByte(8, on ? 64 : 0);
  }

  public boolean getLatchState()
    throws OneWireIOException, OneWireException
  {
    return (readByte(8) & 0x40) == 64;
  }

  public void clearConditions()
    throws OneWireIOException, OneWireException
  {
    byte protect_reg = readByte(0);

    writeByte(0, (byte)(protect_reg & 0xF));
  }

  public int getNumberADChannels()
  {
    return 2;
  }

  public boolean hasADAlarms()
  {
    return false;
  }

  public double[] getADRanges(int channel)
  {
    double[] result = new double[1];

    result[0] = 5.0D;

    return result;
  }

  public double[] getADResolutions(int channel, double range)
  {
    double[] result = new double[1];

    result[0] = getADResolution(channel, null);

    return result;
  }

  public boolean canADMultiChannelRead()
  {
    return false;
  }

  public void doADConvert(int channel, byte[] state)
    throws OneWireIOException, OneWireException
  {
  }

  public void doADConvert(boolean[] doConvert, byte[] state)
    throws OneWireIOException, OneWireException
  {
    throw new OneWireException("This device does not support multi-channel reading");
  }

  public double[] getADVoltage(byte[] state)
    throws OneWireIOException, OneWireException
  {
    throw new OneWireException("This device does not support multi-channel reading");
  }

  public double getADVoltage(int channel, byte[] state)
    throws OneWireIOException, OneWireException
  {
    if ((channel < 0) || (channel > 1)) {
      throw new OneWireException("Invalid channel");
    }

    double result = 0.0D;

    int data = state[(12 + channel * 2)] << 8 | state[(13 + channel * 2)] & 0xFF;

    if (channel == 0)
    {
      data >>= 5;
    }
    else
    {
      data >>= 3;
    }

    result = data * getADResolution(channel, state);

    return result;
  }

  public double getADAlarm(int channel, int alarmType, byte[] state)
    throws OneWireException
  {
    throw new OneWireException("This device does not have AD alarms");
  }

  public boolean getADAlarmEnable(int channel, int alarmType, byte[] state)
    throws OneWireException
  {
    throw new OneWireException("This device does not have AD alarms");
  }

  public boolean hasADAlarmed(int channel, int alarmType, byte[] state)
    throws OneWireException
  {
    throw new OneWireException("This device does not have AD alarms");
  }

  public double getADResolution(int channel, byte[] state)
  {
    if (channel == 0)
    {
      return 0.00488D;
    }

    if (this.internalResistor)
    {
      return 0.000625D;
    }

    return 1.5625E-005D;
  }

  public double getADRange(int channel, byte[] state)
  {
    return 5.0D;
  }

  public void setADAlarm(int channel, int alarmType, double alarm, byte[] state)
    throws OneWireException
  {
    throw new OneWireException("This device does not have AD alarms");
  }

  public void setADAlarmEnable(int channel, int alarmType, boolean alarmEnable, byte[] state)
    throws OneWireException
  {
    throw new OneWireException("This device does not have AD alarms");
  }

  public void setADResolution(int channel, double resolution, byte[] state)
  {
  }

  public void setADRange(int channel, double range, byte[] state)
  {
  }

  public boolean hasTemperatureAlarms()
  {
    return false;
  }

  public boolean hasSelectableTemperatureResolution()
  {
    return false;
  }

  public double[] getTemperatureResolutions()
  {
    double[] result = new double[1];

    result[0] = 0.125D;

    return result;
  }

  public double getTemperatureAlarmResolution()
    throws OneWireException
  {
    throw new OneWireException("This device does not have temperature alarms");
  }

  public double getMaxTemperature()
  {
    return 85.0D;
  }

  public double getMinTemperature()
  {
    return -40.0D;
  }

  public void doTemperatureConvert(byte[] state)
    throws OneWireIOException, OneWireException
  {
  }

  public double getTemperature(byte[] state)
  {
    int data = state[24] << 8 | state[25] & 0xFF;
    data >>= 5;

    double temperature = data / 8.0D;

    return temperature;
  }

  public double getTemperatureAlarm(int alarmType, byte[] state)
    throws OneWireException
  {
    throw new OneWireException("This device does not have temperature alarms");
  }

  public double getTemperatureResolution(byte[] state)
  {
    return 0.125D;
  }

  public void setTemperatureAlarm(int alarmType, double alarmValue, byte[] state)
    throws OneWireException, OneWireIOException
  {
    throw new OneWireException("This device does not have temperature alarms");
  }

  public void setTemperatureResolution(double resolution, byte[] state)
    throws OneWireException, OneWireIOException
  {
  }

  public byte[] readDevice()
    throws OneWireIOException, OneWireException
  {
    byte[] result = new byte[32];

    doSpeed();
    this.adapter.reset();

    if (this.adapter.select(this.address))
    {
      this.adapter.putByte(105);
      this.adapter.putByte(0);
      this.adapter.getBlock(result, 0, 32);
    }
    else {
      throw new OneWireException("OneWireContainer30-Device not found.");
    }
    return result;
  }

  public void writeDevice(byte[] state)
    throws OneWireIOException, OneWireException
  {
  }
}