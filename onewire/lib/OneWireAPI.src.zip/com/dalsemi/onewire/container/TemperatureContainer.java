package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.OneWireIOException;

public abstract interface TemperatureContainer extends OneWireSensor
{
  public static final int ALARM_HIGH = 1;
  public static final int ALARM_LOW = 0;

  public abstract boolean hasTemperatureAlarms();

  public abstract boolean hasSelectableTemperatureResolution();

  public abstract double[] getTemperatureResolutions();

  public abstract double getTemperatureAlarmResolution()
    throws OneWireException;

  public abstract double getMaxTemperature();

  public abstract double getMinTemperature();

  public abstract void doTemperatureConvert(byte[] paramArrayOfByte)
    throws OneWireIOException, OneWireException;

  public abstract double getTemperature(byte[] paramArrayOfByte)
    throws OneWireIOException;

  public abstract double getTemperatureAlarm(int paramInt, byte[] paramArrayOfByte)
    throws OneWireException;

  public abstract double getTemperatureResolution(byte[] paramArrayOfByte);

  public abstract void setTemperatureAlarm(int paramInt, double paramDouble, byte[] paramArrayOfByte)
    throws OneWireException;

  public abstract void setTemperatureResolution(double paramDouble, byte[] paramArrayOfByte)
    throws OneWireException;
}