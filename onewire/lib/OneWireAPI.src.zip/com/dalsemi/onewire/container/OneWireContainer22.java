package com.dalsemi.onewire.container;

import com.dalsemi.onewire.adapter.DSPortAdapter;

public class OneWireContainer22 extends OneWireContainer28
  implements TemperatureContainer
{
  public OneWireContainer22()
  {
  }

  public OneWireContainer22(DSPortAdapter sourceAdapter, byte[] newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public OneWireContainer22(DSPortAdapter sourceAdapter, long newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public OneWireContainer22(DSPortAdapter sourceAdapter, String newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public String getName()
  {
    return "DS1822";
  }

  public String getAlternateNames()
  {
    return "";
  }

  public String getDescription()
  {
    return "Digital thermometer measures temperatures from -55C to 125C in 0.75 seconds (max).  +/- 2C accuracy between -10C and 85C. Thermometer resolution is programmable at 9, 10, 11, and 12 bits. ";
  }
}