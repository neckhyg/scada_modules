package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import com.dalsemi.onewire.utils.CRC16;

class MemoryBankEEPROM
  implements OTPMemoryBank
{
  public static final byte READ_MEMORY_COMMAND = -16;
  public static final byte LOCKED_FLAG = 85;
  public static final byte EPROM_MODE_FLAG = -86;
  protected ScratchPad sp;
  protected OneWireContainer ib;
  protected byte[] ffBlock = new byte[''];
  protected boolean doSetSpeed;
  protected int size;
  protected String bankDescription;
  protected boolean generalPurposeMemory;
  protected boolean readWrite;
  protected boolean writeOnce;
  protected boolean readOnly;
  protected boolean nonVolatile;
  protected boolean programPulse;
  protected boolean powerDelivery;
  protected int startPhysicalAddress;
  protected boolean writeVerification;
  protected int numberPages;
  protected int pageLength;
  protected int maxPacketDataLength;
  protected boolean pageAutoCRC;
  protected boolean extraInfo;
  protected int extraInfoLength;
  protected String extraInfoDescription;
  protected boolean lockPage;
  protected MemoryBankEEPROM mbLock;

  public MemoryBankEEPROM(OneWireContainer ibutton, ScratchPad scratch)
  {
    this.ib = ibutton;

    this.sp = scratch;

    this.mbLock = null;
    this.lockPage = true;

    this.generalPurposeMemory = true;
    this.bankDescription = "Main memory";
    this.numberPages = 4;
    this.size = 128;
    this.pageLength = 32;
    this.maxPacketDataLength = 29;
    this.readWrite = true;
    this.writeOnce = false;
    this.readOnly = false;
    this.nonVolatile = true;
    this.pageAutoCRC = false;
    this.lockPage = true;
    this.programPulse = false;
    this.powerDelivery = true;
    this.extraInfo = false;
    this.extraInfoLength = 0;
    this.extraInfoDescription = null;
    this.writeVerification = false;
    this.startPhysicalAddress = 0;
    this.doSetSpeed = true;

    for (int i = 0; i < 150; i++)
      this.ffBlock[i] = -1;
  }

  public String getBankDescription()
  {
    return this.bankDescription;
  }

  public boolean isGeneralPurposeMemory()
  {
    return this.generalPurposeMemory;
  }

  public boolean isReadWrite()
  {
    return this.readWrite;
  }

  public boolean isWriteOnce()
  {
    return this.writeOnce;
  }

  public boolean isReadOnly()
  {
    return this.readOnly;
  }

  public boolean isNonVolatile()
  {
    return this.nonVolatile;
  }

  public boolean needsProgramPulse()
  {
    return this.programPulse;
  }

  public boolean needsPowerDelivery()
  {
    return this.powerDelivery;
  }

  public int getStartPhysicalAddress()
  {
    return this.startPhysicalAddress;
  }

  public int getSize()
  {
    return this.size;
  }

  public int getNumberPages()
  {
    return this.numberPages;
  }

  public int getPageLength()
  {
    return this.pageLength;
  }

  public int getMaxPacketDataLength()
  {
    return this.maxPacketDataLength;
  }

  public boolean hasPageAutoCRC()
  {
    return this.pageAutoCRC;
  }

  /** @deprecated */
  public boolean haveExtraInfo()
  {
    return false;
  }

  public boolean hasExtraInfo()
  {
    return this.extraInfo;
  }

  public int getExtraInfoLength()
  {
    return this.extraInfoLength;
  }

  public String getExtraInfoDescription()
  {
    return this.extraInfoDescription;
  }

  public void setWriteVerification(boolean doReadVerf)
  {
    this.writeVerification = doReadVerf;
  }

  public boolean canRedirectPage()
  {
    return false;
  }

  public boolean canLockPage()
  {
    return this.lockPage;
  }

  public boolean canLockRedirectPage()
  {
    return false;
  }

  public void read(int startAddr, boolean readContinue, byte[] readBuf, int offset, int len)
    throws OneWireIOException, OneWireException
  {
    byte[] buff = new byte[''];

    System.arraycopy(this.ffBlock, 0, buff, 0, 150);

    if (startAddr + len > this.pageLength * this.numberPages) {
      throw new OneWireException("Read exceeds memory bank end");
    }
    if (len < 0) {
      throw new OneWireException("Invalid length");
    }

    if (!readContinue)
    {
      this.sp.checkSpeed();

      if (this.ib.adapter.select(this.ib.address))
      {
        buff[0] = -16;

        buff[1] = (byte)(startAddr + this.startPhysicalAddress & 0xFF);

        buff[2] = (byte)((startAddr + this.startPhysicalAddress & 0xFFFF) >>> 8 & 0xFF);

        this.ib.adapter.dataBlock(buff, 0, len + 3);

        System.arraycopy(buff, 3, readBuf, offset, len);
      }
      else {
        throw new OneWireIOException("Device select failed");
      }
    }
    else {
      this.ib.adapter.dataBlock(buff, 0, len);

      System.arraycopy(buff, 0, readBuf, offset, len);
    }
  }

  public void write(int startAddr, byte[] writeBuf, int offset, int len)
    throws OneWireIOException, OneWireException
  {
    if (len == 0) {
      return;
    }

    this.sp.checkSpeed();

    if (startAddr + len > this.size) {
      throw new OneWireException("Write exceeds memory bank end");
    }

    if (isReadOnly()) {
      throw new OneWireException("Trying to write read-only memory bank");
    }

    int startx = 0; int nextx = 0;
    byte[] raw_buf = new byte[8];
    byte[] memory = new byte[this.size];

    int abs_addr = startAddr + this.startPhysicalAddress;
    int pl = 8;

    if ((startAddr & 0x7) != 0) {
      read(startAddr & 0xF8, false, memory, startAddr & 0xF8, startAddr - (startAddr & 0xF8) + 1);
    }

    if ((startAddr + len - 1 & 0x7) != 7) {
      read(startAddr + len, false, memory, startAddr + len, (startAddr + len | 0x7) - (startAddr + len) + 1);
    }

    do
    {
      int room_left = pl - (abs_addr + startx) % pl;

      if (len - startx > room_left)
        nextx = startx + room_left;
      else {
        nextx = len;
      }
      System.arraycopy(memory, (startx + startAddr) / 8 * 8, raw_buf, 0, 8);

      if (nextx - startx == 8)
      {
        System.arraycopy(writeBuf, offset + startx, raw_buf, 0, 8);
      }
      else if ((startAddr + nextx) % 8 == 0)
      {
        System.arraycopy(writeBuf, offset + startx, raw_buf, (startAddr + startx) % 8, 8 - (startAddr + startx) % 8);
      }
      else
      {
        System.arraycopy(writeBuf, offset + startx, raw_buf, (startAddr + startx) % 8, (startAddr + nextx) % 8 - (startAddr + startx) % 8);
      }

      this.sp.writeScratchpad(abs_addr + startx + room_left - 8, raw_buf, 0, 8);

      this.sp.copyScratchpad(abs_addr + startx + room_left - 8, 8);

      if (startAddr >= this.pageLength)
        System.arraycopy(raw_buf, 0, memory, (startx + startAddr) / 8 * 8 - 32, 8);
      else {
        System.arraycopy(raw_buf, 0, memory, (startx + startAddr) / 8 * 8, 8);
      }

      startx = nextx;
    }
    while (nextx < len);
  }

  public void readPage(int page, boolean readContinue, byte[] readBuf, int offset)
    throws OneWireIOException, OneWireException
  {
    read(page * this.pageLength, readContinue, readBuf, offset, this.pageLength);
  }

  public void readPage(int page, boolean readContinue, byte[] readBuf, int offset, byte[] extraInfo)
    throws OneWireIOException, OneWireException
  {
    throw new OneWireException("Read extra information not supported on this memory bank");
  }

  public int readPagePacket(int page, boolean readContinue, byte[] readBuf, int offset, byte[] extraInfo)
    throws OneWireIOException, OneWireException
  {
    throw new OneWireException("Read extra information not supported on this memory bank");
  }

  public int readPagePacket(int page, boolean readContinue, byte[] readBuf, int offset)
    throws OneWireIOException, OneWireException
  {
    byte[] raw_buf = new byte[this.pageLength];

    read(page * this.pageLength, readContinue, raw_buf, 0, this.pageLength);

    if ((raw_buf[0] & 0xFF) > this.maxPacketDataLength)
    {
      this.sp.forceVerify();

      throw new OneWireIOException("Invalid length in packet");
    }

    if (CRC16.compute(raw_buf, 0, raw_buf[0] + 3, page) == 45057)
    {
      System.arraycopy(raw_buf, 1, readBuf, offset, raw_buf[0]);

      return raw_buf[0];
    }

    this.sp.forceVerify();

    throw new OneWireIOException("Invalid CRC16 in packet read");
  }

  public void writePagePacket(int page, byte[] writeBuf, int offset, int len)
    throws OneWireIOException, OneWireException
  {
    if (len > this.maxPacketDataLength) {
      throw new OneWireIOException("Length of packet requested exceeds page size");
    }

    if (!this.generalPurposeMemory) {
      throw new OneWireException("Current bank is not general purpose memory");
    }

    byte[] raw_buf = new byte[len + 3];

    raw_buf[0] = (byte)len;

    System.arraycopy(writeBuf, offset, raw_buf, 1, len);

    int crc = CRC16.compute(raw_buf, 0, len + 1, page);

    raw_buf[(len + 1)] = (byte)((crc ^ 0xFFFFFFFF) & 0xFF);
    raw_buf[(len + 2)] = (byte)(((crc ^ 0xFFFFFFFF) & 0xFFFF) >>> 8 & 0xFF);

    write(page * this.pageLength, raw_buf, 0, len + 3);
  }

  public void readPageCRC(int page, boolean readContinue, byte[] readBuf, int offset)
    throws OneWireIOException, OneWireException
  {
    throw new OneWireException("Read page with CRC not supported in this memory bank");
  }

  public void readPageCRC(int page, boolean readContinue, byte[] readBuf, int offset, byte[] extraInfo)
    throws OneWireIOException, OneWireException
  {
    throw new OneWireException("Read page with CRC not supported in this memory bank");
  }

  public void lockPage(int page)
    throws OneWireIOException, OneWireException
  {
    byte[] wr_byte = new byte[1];

    wr_byte[0] = 85;

    this.mbLock.write(page, wr_byte, 0, 1);

    if (!isPageLocked(page))
    {
      this.sp.forceVerify();

      throw new OneWireIOException("Read back from write incorrect, could not lock page");
    }
  }

  public boolean isPageLocked(int page)
    throws OneWireIOException, OneWireException
  {
    byte[] rd_byte = new byte[1];

    this.mbLock.read(page, false, rd_byte, 0, 1);

    return rd_byte[0] == 85;
  }

  public void redirectPage(int page, int newPage)
    throws OneWireIOException, OneWireException
  {
    throw new OneWireException("This memory bank does not support redirection.");
  }

  /** @deprecated */
  public int isPageRedirected(int page)
    throws OneWireIOException, OneWireException
  {
    throw new OneWireException("This memory bank does not support redirection.");
  }

  public int getRedirectedPage(int page)
    throws OneWireIOException, OneWireException
  {
    throw new OneWireException("This memory bank does not support redirection.");
  }

  public void lockRedirectPage(int page)
    throws OneWireIOException, OneWireException
  {
    throw new OneWireException("This memory bank does not support redirection.");
  }

  public boolean isRedirectPageLocked(int page)
    throws OneWireIOException, OneWireException
  {
    throw new OneWireException("This memory bank does not support redirection.");
  }
}