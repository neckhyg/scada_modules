package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import com.dalsemi.onewire.utils.Bit;

public class OneWireContainer1F extends OneWireContainer
  implements SwitchContainer
{
  protected static final int BITMAP_OFFSET = 3;
  protected static final int STATUS_OFFSET = 0;
  protected static final int MAIN_OFFSET = 1;
  protected static final int AUX_OFFSET = 2;
  protected static final int SWITCH_OFF = 0;
  protected static final int SWITCH_ON = 1;
  protected static final int SWITCH_SMART = 2;
  protected static final byte READ_WRITE_STATUS_COMMAND = 90;
  protected static final byte ALL_LINES_OFF_COMMAND = 102;
  protected static final byte DISCHARGE_COMMAND = -103;
  protected static final byte DIRECT_ON_MAIN_COMMAND = -91;
  protected static final byte SMART_ON_MAIN_COMMAND = -52;
  protected static final byte SMART_ON_AUX_COMMAND = 51;
  public static final int CHANNEL_MAIN = 0;
  public static final int CHANNEL_AUX = 1;
  private boolean clearActivityOnWrite;
  private boolean doSpeedEnable = true;

  private boolean devicesOnBranch = false;

  public OneWireContainer1F()
  {
    this.clearActivityOnWrite = false;
  }

  public OneWireContainer1F(DSPortAdapter sourceAdapter, byte[] newAddress)
  {
    super(sourceAdapter, newAddress);

    this.clearActivityOnWrite = false;
  }

  public OneWireContainer1F(DSPortAdapter sourceAdapter, long newAddress)
  {
    super(sourceAdapter, newAddress);

    this.clearActivityOnWrite = false;
  }

  public OneWireContainer1F(DSPortAdapter sourceAdapter, String newAddress)
  {
    super(sourceAdapter, newAddress);

    this.clearActivityOnWrite = false;
  }

  public String getName()
  {
    return "DS2409";
  }

  public String getAlternateNames()
  {
    return "Coupler";
  }

  public String getDescription()
  {
    return "1-Wire Network Coupler with dual addressable switches and a general purpose open drain control output.  Provides a common ground for all connectedmulti-level MicroLan networks.  Keeps inactive branchesPulled to 5V.";
  }

  public synchronized void setSpeedCheck(boolean doSpeedCheck)
  {
    this.doSpeedEnable = doSpeedCheck;
  }

  public byte[] readDevice()
    throws OneWireIOException, OneWireException
  {
    byte[] ret_buf = new byte[4];

    if (this.doSpeedEnable) {
      doSpeed();
    }

    byte[] tmp_buf = deviceOperation(90, -1, 2);

    ret_buf[0] = tmp_buf[2];

    return ret_buf;
  }

  public void writeDevice(byte[] state)
    throws OneWireIOException, OneWireException
  {
    int extra = 0;

    byte[] tmp_buf = null;

    if (this.doSpeedEnable) {
      doSpeed();
    }

    if ((Bit.arrayReadBit(1, 3, state) == 1) && (Bit.arrayReadBit(2, 3, state) == 1))
    {
      if ((state[1] != 0) && (state[2] != 0))
      {
        throw new OneWireException("Attempting to set both channels on, only single channel on at a time");
      }

    }

    if (Bit.arrayReadBit(0, 3, state) == 1)
    {
      byte first_byte = 0;

      if (Bit.arrayReadBit(7, 0, state) == 1) {
        first_byte = (byte)(first_byte | 0x20);
      }

      if (Bit.arrayReadBit(6, 0, state) == 1) {
        first_byte = (byte)(first_byte | 0xFFFFFFC0);
      }
      tmp_buf = deviceOperation(90, first_byte, 2);

      state[0] = tmp_buf[2];
    }

    byte command = 0;

    if (Bit.arrayReadBit(2, 3, state) == 1)
    {
      if ((state[2] == 1) || (state[2] == 2))
      {
        command = 51;
        extra = 2;
      }
      else
      {
        command = 102;
        extra = 0;
      }

    }

    if (Bit.arrayReadBit(1, 3, state) == 1)
    {
      if (state[1] == 1)
      {
        command = -91;
        extra = 0;
      }
      else if (state[1] == 2)
      {
        command = -52;
        extra = 2;
      }
      else
      {
        command = 102;
        extra = 0;
      }

    }

    if ((this.clearActivityOnWrite) && (command != 102))
    {
      if ((Bit.arrayReadBit(4, 0, state) == 1) || (Bit.arrayReadBit(5, 0, state) == 1))
      {
        deviceOperation(102, -1, 0);

        if (command == 0)
        {
          if (Bit.arrayReadBit(0, 0, state) == 0)
            command = -52;
          else if (Bit.arrayReadBit(2, 0, state) == 0) {
            command = 51;
          }
          extra = 2;
        }
      }

    }

    if (command != 0) {
      tmp_buf = deviceOperation(command, -1, extra);
    }

    if ((command == -52) || (command == 51))
    {
      this.devicesOnBranch = (tmp_buf[2] == 0);
    }
    else {
      this.devicesOnBranch = false;
    }

    this.clearActivityOnWrite = false;

    state[3] = 0;
  }

  public void dischargeLines(int time)
    throws OneWireIOException, OneWireException
  {
    if (time < 100) {
      time = 100;
    }
    if (this.doSpeedEnable) {
      doSpeed();
    }

    deviceOperation(-103, -1, 0);
    try
    {
      Thread.sleep(time);
    }
    catch (InterruptedException e)
    {
    }

    deviceOperation(90, -1, 2);
  }

  public boolean isHighSideSwitch()
  {
    return true;
  }

  public boolean hasActivitySensing()
  {
    return true;
  }

  public boolean hasLevelSensing()
  {
    return true;
  }

  public boolean hasSmartOn()
  {
    return true;
  }

  public boolean onlySingleChannelOn()
  {
    return true;
  }

  public int getNumberChannels(byte[] state)
  {
    return 2;
  }

  public boolean getLevel(int channel, byte[] state)
    throws OneWireException
  {
    return Bit.arrayReadBit(1 + channel * 2, 0, state) == 1;
  }

  public boolean getLatchState(int channel, byte[] state)
  {
    return Bit.arrayReadBit(channel * 2, 0, state) == 0;
  }

  public boolean getSensedActivity(int channel, byte[] state)
    throws OneWireException
  {
    return Bit.arrayReadBit(4 + channel, 0, state) == 1;
  }

  public boolean isModeAuto(byte[] state)
  {
    return Bit.arrayReadBit(7, 0, state) == 0;
  }

  public int getControlChannelAssociation(byte[] state)
  {
    return Bit.arrayReadBit(6, 0, state);
  }

  public int getControlData(byte[] state)
  {
    return Bit.arrayReadBit(6, 0, state);
  }

  public boolean getLastSmartOnDeviceDetect()
  {
    return this.devicesOnBranch;
  }

  public void setLatchState(int channel, boolean latchState, boolean doSmart, byte[] state)
  {
    if (latchState) {
      state[(channel + 1)] = (doSmart ? 2 : 1);
    }
    else {
      state[(channel + 1)] = 0;
    }

    Bit.arrayWriteBit(1, channel + 1, 3, state);
  }

  public void clearActivity()
    throws OneWireException
  {
    this.clearActivityOnWrite = true;
  }

  public void setModeAuto(boolean makeAuto, byte[] state)
  {
    Bit.arrayWriteBit(makeAuto ? 0 : 1, 7, 0, state);

    Bit.arrayWriteBit(1, 0, 3, state);
  }

  public void setControlChannelAssociation(int channel, byte[] state)
    throws OneWireException
  {
    if (!isModeAuto(state)) {
      throw new OneWireException("Trying to set channel association in manual mode");
    }

    Bit.arrayWriteBit(channel, 6, 0, state);

    Bit.arrayWriteBit(1, 0, 3, state);
  }

  public void setControlData(boolean data, byte[] state)
    throws OneWireException
  {
    if (isModeAuto(state)) {
      throw new OneWireException("Trying to set control data when control is in automatic mode");
    }

    Bit.arrayWriteBit(data ? 1 : 0, 6, 0, state);

    Bit.arrayWriteBit(1, 0, 3, state);
  }

  private byte[] deviceOperation(byte command, byte sendByte, int extra)
    throws OneWireIOException, OneWireException
  {
    OneWireIOException exc = null;
    for (int attemptCounter = 2; attemptCounter > 0; attemptCounter--)
    {
      byte[] raw_buf = new byte[extra + 2];

      raw_buf[0] = command;
      raw_buf[1] = sendByte;

      for (int i = 2; i < raw_buf.length; i++) {
        raw_buf[i] = -1;
      }

      if (this.adapter.select(this.address))
      {
        this.adapter.dataBlock(raw_buf, 0, raw_buf.length);

        if (command == 90)
        {
          if (raw_buf[(raw_buf.length - 1)] != raw_buf[(raw_buf.length - 2)])
          {
            if (exc != null) continue;
            exc = new OneWireIOException("OneWireContainer1F verify on command incorrect"); continue;
          }

        }
        else if (raw_buf[(raw_buf.length - 1)] != command)
        {
          if (exc != null) continue;
          exc = new OneWireIOException("OneWireContainer1F verify on command incorrect"); continue;
        }

        return raw_buf;
      }
      else {
        throw new OneWireIOException("OneWireContainer1F failure - Device not found.");
      }
    }

    throw exc;
  }
}