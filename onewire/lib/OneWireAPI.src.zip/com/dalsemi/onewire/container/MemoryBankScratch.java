package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import com.dalsemi.onewire.utils.CRC16;

class MemoryBankScratch
  implements PagedMemoryBank, ScratchPad
{
  public static final byte WRITE_SCRATCHPAD_COMMAND = 15;
  public static final byte READ_SCRATCHPAD_COMMAND = -86;
  protected OneWireContainer ib;
  protected byte[] ffBlock;
  protected byte COPY_SCRATCHPAD_COMMAND;
  protected boolean doSetSpeed;
  protected int size;
  protected String bankDescription;
  protected boolean generalPurposeMemory;
  protected boolean readWrite;
  protected boolean writeOnce;
  protected boolean readOnly;
  protected boolean nonVolatile;
  protected boolean programPulse;
  protected boolean powerDelivery;
  protected int startPhysicalAddress;
  protected boolean writeVerification;
  protected int numberPages;
  protected int pageLength;
  protected int maxPacketDataLength;
  protected boolean pageAutoCRC;
  protected boolean extraInfo;
  protected int extraInfoLength;
  protected String extraInfoDescription;

  public MemoryBankScratch(OneWireContainer ibutton)
  {
    this.ib = ibutton;

    this.bankDescription = "Scratchpad";
    this.generalPurposeMemory = false;
    this.startPhysicalAddress = 0;
    this.size = 32;
    this.readWrite = true;
    this.writeOnce = false;
    this.readOnly = false;
    this.nonVolatile = false;
    this.programPulse = false;
    this.powerDelivery = false;
    this.writeVerification = true;
    this.numberPages = 1;
    this.pageLength = 32;
    this.maxPacketDataLength = 29;
    this.pageAutoCRC = false;
    this.extraInfo = true;
    this.extraInfoLength = 3;
    this.extraInfoDescription = "Target address, offset";

    this.ffBlock = new byte[96];

    for (int i = 0; i < 96; i++) {
      this.ffBlock[i] = -1;
    }

    this.COPY_SCRATCHPAD_COMMAND = 85;

    this.doSetSpeed = true;
  }

  public String getBankDescription()
  {
    return this.bankDescription;
  }

  public boolean isGeneralPurposeMemory()
  {
    return this.generalPurposeMemory;
  }

  public boolean isReadWrite()
  {
    return this.readWrite;
  }

  public boolean isWriteOnce()
  {
    return this.writeOnce;
  }

  public boolean isReadOnly()
  {
    return this.readOnly;
  }

  public boolean isNonVolatile()
  {
    return this.nonVolatile;
  }

  public boolean needsProgramPulse()
  {
    return this.programPulse;
  }

  public boolean needsPowerDelivery()
  {
    return this.powerDelivery;
  }

  public int getStartPhysicalAddress()
  {
    return this.startPhysicalAddress;
  }

  public int getSize()
  {
    return this.size;
  }

  public int getNumberPages()
  {
    return this.numberPages;
  }

  public int getPageLength()
  {
    return this.pageLength;
  }

  public int getMaxPacketDataLength()
  {
    return this.maxPacketDataLength;
  }

  public boolean hasPageAutoCRC()
  {
    return this.pageAutoCRC;
  }

  /** @deprecated */
  public boolean haveExtraInfo()
  {
    return this.extraInfo;
  }

  public boolean hasExtraInfo()
  {
    return this.extraInfo;
  }

  public int getExtraInfoLength()
  {
    return this.extraInfoLength;
  }

  public String getExtraInfoDescription()
  {
    return this.extraInfoDescription;
  }

  public void setWriteVerification(boolean doReadVerf)
  {
    this.writeVerification = doReadVerf;
  }

  public void read(int startAddr, boolean readContinue, byte[] readBuf, int offset, int len)
    throws OneWireIOException, OneWireException
  {
    if (startAddr + len > this.size) {
      throw new OneWireException("Read exceeds memory bank end");
    }

    checkSpeed();

    readScratchpad(readBuf, offset, len, null);
  }

  public void write(int startAddr, byte[] writeBuf, int offset, int len)
    throws OneWireIOException, OneWireException
  {
    if (len == 0) {
      return;
    }

    checkSpeed();

    if (startAddr + len > this.size) {
      throw new OneWireException("Write exceeds memory bank end");
    }

    writeScratchpad(this.startPhysicalAddress + startAddr, writeBuf, offset, len);

    byte[] raw_buf = new byte[this.pageLength];
    byte[] extra_buf = new byte[this.extraInfoLength];

    readScratchpad(raw_buf, 0, this.pageLength, extra_buf);

    for (int i = 0; i < len; i++) {
      if (raw_buf[i] == writeBuf[(i + offset)])
        continue;
      forceVerify();

      throw new OneWireIOException("Read back verify had incorrect data");
    }

    if (((extra_buf[0] & 0xFF | extra_buf[1] << 8 & 0xFF00) & 0xFFFF) != this.startPhysicalAddress + startAddr)
    {
      forceVerify();

      throw new OneWireIOException("Read back address had incorrect data");
    }
  }

  public void readPage(int page, boolean readContinue, byte[] readBuf, int offset)
    throws OneWireIOException, OneWireException
  {
    if (page != 0) {
      throw new OneWireException("Page read exceeds memory bank end");
    }

    checkSpeed();

    readScratchpad(readBuf, offset, this.pageLength, null);
  }

  public void readPage(int page, boolean readContinue, byte[] readBuf, int offset, byte[] extraInfo)
    throws OneWireIOException, OneWireException
  {
    if (page != 0) {
      throw new OneWireException("Page read exceeds memory bank end");
    }

    checkSpeed();

    readScratchpad(readBuf, offset, this.pageLength, extraInfo);
  }

  public int readPagePacket(int page, boolean readContinue, byte[] readBuf, int offset)
    throws OneWireIOException, OneWireException
  {
    byte[] raw_buf = new byte[this.pageLength];

    checkSpeed();

    readScratchpad(raw_buf, 0, this.pageLength, null);

    if (raw_buf[0] > this.maxPacketDataLength)
    {
      forceVerify();

      throw new OneWireIOException("Invalid length in packet");
    }

    if (CRC16.compute(raw_buf, 0, raw_buf[0] + 3, page) == 45057)
    {
      System.arraycopy(raw_buf, 1, readBuf, offset, raw_buf[0]);

      return raw_buf[0];
    }

    forceVerify();

    throw new OneWireIOException("Invalid CRC16 in packet read");
  }

  public int readPagePacket(int page, boolean readContinue, byte[] readBuf, int offset, byte[] extraInfo)
    throws OneWireIOException, OneWireException
  {
    byte[] raw_buf = new byte[this.pageLength];

    checkSpeed();

    readScratchpad(raw_buf, 0, this.pageLength, extraInfo);

    if (raw_buf[0] > this.maxPacketDataLength)
    {
      forceVerify();

      throw new OneWireIOException("Invalid length in packet");
    }

    if (CRC16.compute(raw_buf, 0, raw_buf[0] + 3, page) == 45057)
    {
      System.arraycopy(raw_buf, 1, readBuf, offset, raw_buf[0]);

      return raw_buf[0];
    }

    forceVerify();

    throw new OneWireIOException("Invalid CRC16 in packet read");
  }

  public void writePagePacket(int page, byte[] writeBuf, int offset, int len)
    throws OneWireIOException, OneWireException
  {
    if (len > this.maxPacketDataLength) {
      throw new OneWireException("Length of packet requested exceeds page size");
    }

    if (!this.generalPurposeMemory) {
      throw new OneWireException("Current bank is not general purpose memory");
    }

    byte[] raw_buf = new byte[len + 3];

    raw_buf[0] = (byte)len;

    System.arraycopy(writeBuf, offset, raw_buf, 1, len);

    int crc = CRC16.compute(raw_buf, 0, len + 1, page);

    raw_buf[(len + 1)] = (byte)((crc ^ 0xFFFFFFFF) & 0xFF);
    raw_buf[(len + 2)] = (byte)(((crc ^ 0xFFFFFFFF) & 0xFFFF) >>> 8 & 0xFF);

    write(page * this.pageLength, raw_buf, 0, len + 3);
  }

  public void readPageCRC(int page, boolean readContinue, byte[] readBuf, int offset)
    throws OneWireIOException, OneWireException
  {
    throw new OneWireException("Read page with CRC not supported by this memory bank");
  }

  public void readPageCRC(int page, boolean readContinue, byte[] readBuf, int offset, byte[] extraInfo)
    throws OneWireIOException, OneWireException
  {
    throw new OneWireException("Read page with CRC and extra-info not supported by this memory bank");
  }

  public void readScratchpad(byte[] readBuf, int offset, int len, byte[] extraInfo)
    throws OneWireIOException, OneWireException
  {
    if (!this.ib.adapter.select(this.ib.address))
    {
      forceVerify();

      throw new OneWireIOException("Device select failed");
    }

    byte[] raw_buf = new byte[1 + this.extraInfoLength];

    raw_buf[0] = -86;

    System.arraycopy(this.ffBlock, 0, raw_buf, 1, this.extraInfoLength);

    this.ib.adapter.dataBlock(raw_buf, 0, 1 + this.extraInfoLength);

    if (extraInfo != null) {
      System.arraycopy(raw_buf, 1, extraInfo, 0, this.extraInfoLength);
    }

    System.arraycopy(this.ffBlock, 0, readBuf, offset, len);

    this.ib.adapter.dataBlock(readBuf, offset, len);
  }

  public void writeScratchpad(int startAddr, byte[] writeBuf, int offset, int len)
    throws OneWireIOException, OneWireException
  {
    if (!this.ib.adapter.select(this.ib.address))
    {
      forceVerify();

      throw new OneWireIOException("Device select failed");
    }

    byte[] raw_buf = new byte[3 + len];

    raw_buf[0] = 15;
    raw_buf[1] = (byte)(startAddr & 0xFF);
    raw_buf[2] = (byte)((startAddr & 0xFFFF) >>> 8 & 0xFF);

    System.arraycopy(writeBuf, offset, raw_buf, 3, len);

    this.ib.adapter.dataBlock(raw_buf, 0, len + 3);
  }

  public void copyScratchpad(int startAddr, int len)
    throws OneWireIOException, OneWireException
  {
    if (!this.ib.adapter.select(this.ib.address))
    {
      forceVerify();

      throw new OneWireIOException("Device select failed");
    }

    byte[] raw_buf = new byte[5];

    raw_buf[0] = this.COPY_SCRATCHPAD_COMMAND;
    raw_buf[1] = (byte)(startAddr & 0xFF);
    raw_buf[2] = (byte)((startAddr & 0xFFFF) >>> 8 & 0xFF);
    raw_buf[3] = (byte)(startAddr + len - 1 & 0x1F);
    raw_buf[4] = -1;

    this.ib.adapter.dataBlock(raw_buf, 0, 5);

    if ((raw_buf[4] & 0xF0) != 0)
    {
      forceVerify();

      throw new OneWireIOException("Copy scratchpad complete not found");
    }
  }

  public void checkSpeed()
    throws OneWireIOException, OneWireException
  {
    synchronized (this)
    {
      if ((this.doSetSpeed) || (this.ib.adapter.getSpeed() != this.ib.getMaxSpeed()))
      {
        this.ib.doSpeed();

        this.doSetSpeed = false;
      }
    }
  }

  public void forceVerify()
  {
    synchronized (this)
    {
      this.doSetSpeed = true;
    }
  }
}