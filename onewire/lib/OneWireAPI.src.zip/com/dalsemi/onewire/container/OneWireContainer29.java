package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import java.util.Enumeration;
import java.util.Vector;

public class OneWireContainer29 extends OneWireContainer
  implements SwitchContainer
{
  private MemoryBankEEPROMstatus map;
  private MemoryBankEEPROMstatus search;
  public static final byte RESET_ACTIVITY_LATCHES = -61;
  private byte[] FF = new byte[8];

  public OneWireContainer29()
  {
    initmem();

    for (int i = 0; i < this.FF.length; i++)
      this.FF[i] = -1;
  }

  public OneWireContainer29(DSPortAdapter sourceAdapter, byte[] newAddress)
  {
    super(sourceAdapter, newAddress);

    initmem();

    for (int i = 0; i < this.FF.length; i++)
      this.FF[i] = -1;
  }

  public OneWireContainer29(DSPortAdapter sourceAdapter, long newAddress)
  {
    super(sourceAdapter, newAddress);

    initmem();

    for (int i = 0; i < this.FF.length; i++)
      this.FF[i] = -1;
  }

  public OneWireContainer29(DSPortAdapter sourceAdapter, String newAddress)
  {
    super(sourceAdapter, newAddress);

    initmem();

    for (int i = 0; i < this.FF.length; i++)
      this.FF[i] = -1;
  }

  public String getName()
  {
    return "DS2408";
  }

  public Enumeration getMemoryBanks()
  {
    Vector bank_vector = new Vector(5);

    bank_vector.addElement(this.map);
    bank_vector.addElement(this.search);

    return bank_vector.elements();
  }

  public String getAlternateNames()
  {
    return "8-Channel Addressable Switch";
  }

  public String getDescription()
  {
    return "1-Wire 8-Channel Addressable Switch";
  }

  public int getMaxSpeed()
  {
    return 2;
  }

  public int getNumberChannels(byte[] state)
  {
    return 8;
  }

  public boolean isHighSideSwitch()
  {
    return false;
  }

  public boolean hasActivitySensing()
  {
    return true;
  }

  public boolean hasLevelSensing()
  {
    return true;
  }

  public boolean hasSmartOn()
  {
    return false;
  }

  public boolean onlySingleChannelOn()
  {
    return false;
  }

  public boolean getLevel(int channel, byte[] state)
  {
    byte level = (byte)(1 << channel);
    return (state[0] & level) == level;
  }

  public boolean getLatchState(int channel, byte[] state)
  {
    byte latch = (byte)(1 << channel);
    return (state[1] & latch) == latch;
  }

  public boolean getSensedActivity(int channel, byte[] state)
    throws OneWireException
  {
    byte activity = (byte)(1 << channel);
    return (state[2] & activity) == activity;
  }

  public void clearActivity()
    throws OneWireException
  {
    this.adapter.select(this.address);
    byte[] buffer = new byte[9];

    buffer[0] = -61;
    System.arraycopy(this.FF, 0, buffer, 1, 8);

    this.adapter.dataBlock(buffer, 0, 9);

    if ((buffer[1] != -86) && (buffer[1] != 85))
      throw new OneWireException("Sense Activity was not cleared.");
  }

  public void setLatchState(int channel, boolean latchState, boolean doSmart, byte[] state)
  {
    byte latch = (byte)(1 << channel);

    if (latchState)
      state[1] = (byte)(state[1] | latch);
    else
      state[1] = (byte)(state[1] & (latch ^ 0xFFFFFFFF));
  }

  public void setLatchState(byte set, byte[] state)
  {
    state[1] = set;
  }

  public byte[] readDevice()
    throws OneWireIOException, OneWireException
  {
    byte[] state = new byte[3];

    System.arraycopy(this.FF, 0, state, 0, 3);
    this.map.read(0, false, state, 0, 3);

    return state;
  }

  public byte[] readRegister()
    throws OneWireIOException, OneWireException
  {
    byte[] register = new byte[3];

    this.search.read(0, false, register, 0, 3);

    return register;
  }

  public void writeDevice(byte[] state)
    throws OneWireIOException, OneWireException
  {
    this.map.write(1, state, 1, 1);
  }

  public void writeRegister(byte[] register)
    throws OneWireIOException, OneWireException
  {
    this.search.write(0, register, 0, 3);
  }

  public void setResetMode(byte[] register, boolean set)
    throws OneWireIOException, OneWireException
  {
    if ((set) && ((register[2] & 0x4) == 4))
    {
      register[2] = (byte)(register[2] & 0xFFFFFFFB);
    }
    else if ((!set) && ((register[2] & 0x4) == 0))
    {
      register[2] = (byte)(register[2] | 0x4);
    }
  }

  public boolean getVCC(byte[] register)
    throws OneWireIOException, OneWireException
  {
    return (register[2] & 0xFFFFFF80) == -128;
  }

  public void clearPowerOnReset(byte[] register)
  {
    if ((register[2] & 0x8) == 8)
    {
      register[2] = (byte)(register[2] & 0xFFFFFFF7);
    }
  }

  public void orConditionalSearch(byte[] register)
  {
    if ((register[2] & 0x2) == 2)
    {
      register[2] = (byte)(register[2] & 0xFFFFFFFD);
    }
  }

  public void andConditionalSearch(byte[] register)
  {
    if ((register[2] & 0x2) != 2)
    {
      register[2] = (byte)(register[2] | 0x2);
    }
  }

  public void pioConditionalSearch(byte[] register)
  {
    if ((register[2] & 0x1) == 1)
    {
      register[2] = (byte)(register[2] & 0xFFFFFFFE);
    }
  }

  public void activityConditionalSearch(byte[] register)
  {
    if ((register[2] & 0x1) != 1)
    {
      register[2] = (byte)(register[2] | 0x1);
    }
  }

  public void setChannelMask(int channel, boolean set, byte[] register)
  {
    byte mask = (byte)(1 << channel);

    if (set)
      register[0] = (byte)(register[0] | mask);
    else
      register[0] = (byte)(register[0] & (byte)(mask ^ 0xFFFFFFFF));
  }

  public void setChannelPolarity(int channel, boolean set, byte[] register)
  {
    byte polarity = (byte)(1 << channel);

    if (set)
      register[1] = (byte)(register[1] | polarity);
    else
      register[1] = (byte)(register[1] & (byte)(polarity ^ 0xFFFFFFFF));
  }

  public boolean getChannelMask(int channel, byte[] register)
  {
    byte mask = (byte)(1 << channel);

    return (register[0] & mask) == mask;
  }

  public boolean getChannelPolarity(int channel, byte[] register)
  {
    byte polarity = (byte)(1 << channel);

    return (register[1] & polarity) == polarity;
  }

  private void initmem()
  {
    this.map = new MemoryBankEEPROMstatus(this);
    this.map.bankDescription = "Memory mapped register of pin logic state, port output latch logic state and activity latch logic state.";

    this.map.startPhysicalAddress = 136;
    this.map.size = 3;
    this.map.readOnly = true;

    this.search = new MemoryBankEEPROMstatus(this);
    this.search.bankDescription = "Conditional search bit mask, polarity bit mask and control register.";

    this.search.startPhysicalAddress = 139;
    this.search.size = 3;
    this.search.readWrite = true;
  }
}