package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import com.dalsemi.onewire.utils.CRC16;

class MemoryBankNV
  implements PagedMemoryBank
{
  public static final byte READ_MEMORY_COMMAND = -16;
  protected ScratchPad sp;
  protected OneWireContainer ib;
  protected byte[] ffBlock;
  protected int size;
  protected String bankDescription;
  protected boolean generalPurposeMemory;
  protected boolean readWrite;
  protected boolean writeOnce;
  protected boolean readOnly;
  protected boolean nonVolatile;
  protected boolean programPulse;
  protected boolean powerDelivery;
  protected int startPhysicalAddress;
  protected boolean writeVerification;
  protected int numberPages;
  protected int pageLength;
  protected int maxPacketDataLength;
  protected boolean pageAutoCRC;
  protected boolean extraInfo;
  protected int extraInfoLength;
  protected String extraInfoDescription;

  public MemoryBankNV(OneWireContainer ibutton, ScratchPad scratch)
  {
    this.ib = ibutton;

    this.sp = scratch;

    this.bankDescription = "Main Memory";
    this.generalPurposeMemory = true;
    this.startPhysicalAddress = 0;
    this.size = 512;
    this.readWrite = true;
    this.writeOnce = false;
    this.readOnly = false;
    this.nonVolatile = true;
    this.programPulse = false;
    this.powerDelivery = false;
    this.writeVerification = true;
    this.numberPages = 16;
    this.pageLength = 32;
    this.maxPacketDataLength = 29;
    this.pageAutoCRC = false;
    this.extraInfo = false;
    this.extraInfoLength = 0;
    this.extraInfoDescription = null;

    this.ffBlock = new byte[96];

    for (int i = 0; i < 96; i++)
      this.ffBlock[i] = -1;
  }

  public String getBankDescription()
  {
    return this.bankDescription;
  }

  public boolean isGeneralPurposeMemory()
  {
    return this.generalPurposeMemory;
  }

  public boolean isReadWrite()
  {
    return this.readWrite;
  }

  public boolean isWriteOnce()
  {
    return this.writeOnce;
  }

  public boolean isReadOnly()
  {
    return this.readOnly;
  }

  public boolean isNonVolatile()
  {
    return this.nonVolatile;
  }

  public boolean needsProgramPulse()
  {
    return this.programPulse;
  }

  public boolean needsPowerDelivery()
  {
    return this.powerDelivery;
  }

  public int getStartPhysicalAddress()
  {
    return this.startPhysicalAddress;
  }

  public int getSize()
  {
    return this.size;
  }

  public void setWriteVerification(boolean doReadVerf)
  {
    this.writeVerification = doReadVerf;
  }

  public int getNumberPages()
  {
    return this.numberPages;
  }

  public int getPageLength()
  {
    return this.pageLength;
  }

  public int getMaxPacketDataLength()
  {
    return this.maxPacketDataLength;
  }

  public boolean hasPageAutoCRC()
  {
    return this.pageAutoCRC;
  }

  /** @deprecated */
  public boolean haveExtraInfo()
  {
    return this.extraInfo;
  }

  public boolean hasExtraInfo()
  {
    return this.extraInfo;
  }

  public int getExtraInfoLength()
  {
    return this.extraInfoLength;
  }

  public String getExtraInfoDescription()
  {
    return this.extraInfoDescription;
  }

  public void read(int startAddr, boolean readContinue, byte[] readBuf, int offset, int len)
    throws OneWireIOException, OneWireException
  {
    if (!readContinue) {
      this.sp.checkSpeed();
    }

    if (startAddr + len > this.pageLength * this.numberPages) {
      throw new OneWireException("Read exceeds memory bank end");
    }

    if (!readContinue)
    {
      if (!this.ib.adapter.select(this.ib.address))
      {
        this.sp.forceVerify();

        throw new OneWireIOException("Device select failed");
      }

      int addr = startAddr + this.startPhysicalAddress;
      byte[] raw_buf = new byte[3];

      raw_buf[0] = -16;
      raw_buf[1] = (byte)(addr & 0xFF);
      raw_buf[2] = (byte)((addr & 0xFFFF) >>> 8 & 0xFF);

      this.ib.adapter.dataBlock(raw_buf, 0, 3);
    }

    int pgs = len / this.pageLength;
    int extra = len % this.pageLength;

    for (int i = 0; i < pgs; i++) {
      System.arraycopy(this.ffBlock, 0, readBuf, offset + i * this.pageLength, this.pageLength);
    }
    System.arraycopy(this.ffBlock, 0, readBuf, offset + pgs * this.pageLength, extra);

    this.ib.adapter.dataBlock(readBuf, offset, len);
  }

  public void write(int startAddr, byte[] writeBuf, int offset, int len)
    throws OneWireIOException, OneWireException
  {
    if (len == 0) {
      return;
    }

    this.sp.checkSpeed();

    if (startAddr + len > this.size) {
      throw new OneWireException("Write exceeds memory bank end");
    }

    if (isReadOnly()) {
      throw new OneWireException("Trying to write read-only memory bank");
    }

    int startx = 0; int nextx = 0;
    byte[] raw_buf = new byte[this.pageLength];
    byte[] extra_buf = new byte[this.sp.getExtraInfoLength()];
    int abs_addr = this.startPhysicalAddress + startAddr;
    int pl = this.pageLength;
    do
    {
      int room_left = pl - (abs_addr + startx) % pl;

      if (len - startx > room_left)
        nextx = startx + room_left;
      else {
        nextx = len;
      }

      this.sp.writeScratchpad(abs_addr + startx, writeBuf, offset + startx, nextx - startx);

      this.sp.readScratchpad(raw_buf, 0, pl, extra_buf);

      for (int i = 0; i < nextx - startx; i++) {
        if (raw_buf[i] == writeBuf[(i + offset + startx)])
          continue;
        this.sp.forceVerify();

        throw new OneWireIOException("Read back of scratchpad had incorrect data");
      }

      if (((extra_buf[0] & 0xFF | extra_buf[1] << 8 & 0xFF00) & 0xFFFF) != abs_addr + startx)
      {
        this.sp.forceVerify();

        throw new OneWireIOException("Address read back from scrachpad was incorrect");
      }

      this.sp.copyScratchpad(abs_addr + startx, nextx - startx);

      startx = nextx;
    }
    while (nextx < len);
  }

  public void readPage(int page, boolean readContinue, byte[] readBuf, int offset)
    throws OneWireIOException, OneWireException
  {
    read(page * this.pageLength, readContinue, readBuf, offset, this.pageLength);
  }

  public void readPage(int page, boolean readContinue, byte[] readBuf, int offset, byte[] extraInfo)
    throws OneWireIOException, OneWireException
  {
    throw new OneWireException("Read page with extra-info not supported by this memory bank");
  }

  public int readPagePacket(int page, boolean readContinue, byte[] readBuf, int offset)
    throws OneWireIOException, OneWireException
  {
    byte[] raw_buf = new byte[this.pageLength];

    readPage(page, readContinue, raw_buf, 0);

    if ((raw_buf[0] & 0xFF) > this.maxPacketDataLength) {
      throw new OneWireIOException("Invalid length in packet");
    }

    int abs_page = this.startPhysicalAddress / this.pageLength + page;
    if (CRC16.compute(raw_buf, 0, raw_buf[0] + 3, abs_page) == 45057)
    {
      System.arraycopy(raw_buf, 1, readBuf, offset, raw_buf[0]);

      return raw_buf[0];
    }

    throw new OneWireIOException("Invalid CRC16 in packet read");
  }

  public int readPagePacket(int page, boolean readContinue, byte[] readBuf, int offset, byte[] extraInfo)
    throws OneWireIOException, OneWireException
  {
    throw new OneWireException("Read packet with extra-info not supported by this memory bank");
  }

  public void writePagePacket(int page, byte[] writeBuf, int offset, int len)
    throws OneWireIOException, OneWireException
  {
    if (len > this.maxPacketDataLength) {
      throw new OneWireIOException("Length of packet requested exceeds page size");
    }

    if (!this.generalPurposeMemory) {
      throw new OneWireException("Current bank is not general purpose memory");
    }

    byte[] raw_buf = new byte[len + 3];

    raw_buf[0] = (byte)len;

    System.arraycopy(writeBuf, offset, raw_buf, 1, len);

    int abs_page = this.startPhysicalAddress / this.pageLength + page;
    int crc = CRC16.compute(raw_buf, 0, len + 1, abs_page);

    raw_buf[(len + 1)] = (byte)((crc ^ 0xFFFFFFFF) & 0xFF);
    raw_buf[(len + 2)] = (byte)(((crc ^ 0xFFFFFFFF) & 0xFFFF) >>> 8 & 0xFF);

    write(page * this.pageLength, raw_buf, 0, len + 3);
  }

  public void readPageCRC(int page, boolean readContinue, byte[] readBuf, int offset)
    throws OneWireIOException, OneWireException
  {
    throw new OneWireException("Read page with CRC not supported by this memory bank");
  }

  public void readPageCRC(int page, boolean readContinue, byte[] readBuf, int offset, byte[] extraInfo)
    throws OneWireIOException, OneWireException
  {
    throw new OneWireException("Read page with CRC and extra-info not supported by this memory bank");
  }
}