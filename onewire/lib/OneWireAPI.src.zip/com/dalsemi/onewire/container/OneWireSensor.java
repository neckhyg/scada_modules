package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.OneWireIOException;

public abstract interface OneWireSensor
{
  public abstract byte[] readDevice()
    throws OneWireIOException, OneWireException;

  public abstract void writeDevice(byte[] paramArrayOfByte)
    throws OneWireIOException, OneWireException;
}