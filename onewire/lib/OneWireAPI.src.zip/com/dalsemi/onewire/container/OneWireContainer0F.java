package com.dalsemi.onewire.container;

import com.dalsemi.onewire.adapter.DSPortAdapter;
import java.util.Enumeration;
import java.util.Vector;

public class OneWireContainer0F extends OneWireContainer
{
  public OneWireContainer0F()
  {
  }

  public OneWireContainer0F(DSPortAdapter sourceAdapter, byte[] newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public OneWireContainer0F(DSPortAdapter sourceAdapter, long newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public OneWireContainer0F(DSPortAdapter sourceAdapter, String newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public String getName()
  {
    return "DS1986";
  }

  public String getAlternateNames()
  {
    return "DS2506";
  }

  public String getDescription()
  {
    return "65536 bit Electrically Programmable Read Only Memory (EPROM) partitioned into two-hundered fifty-six 256 bit pages.  Each memory page can be permanently write-protected to prevent tampering.  Architecture allows software to patch data by supersending a used page in favor of a newly programmed page.";
  }

  public int getMaxSpeed()
  {
    return 2;
  }

  public Enumeration getMemoryBanks()
  {
    Vector bank_vector = new Vector(5);

    MemoryBankEPROM mn = new MemoryBankEPROM(this);

    mn.numberPages = 256;
    mn.size = 8192;

    bank_vector.addElement(mn);

    MemoryBankEPROM wp = new MemoryBankEPROM(this);

    wp.bankDescription = "Write protect pages";
    wp.numberPages = 4;
    wp.size = 32;
    wp.pageLength = 8;
    wp.generalPurposeMemory = false;
    wp.extraInfo = false;
    wp.extraInfoLength = 0;
    wp.extraInfoDescription = null;
    wp.crcAfterAddress = false;
    wp.READ_PAGE_WITH_CRC = -86;
    wp.WRITE_MEMORY_COMMAND = 85;

    bank_vector.addElement(wp);

    MemoryBankEPROM wpr = new MemoryBankEPROM(this);

    wpr.bankDescription = "Write protect redirection";
    wpr.numberPages = 4;
    wpr.size = 32;
    wpr.pageLength = 8;
    wpr.generalPurposeMemory = false;
    wpr.extraInfo = false;
    wpr.extraInfoLength = 0;
    wpr.extraInfoDescription = null;
    wpr.crcAfterAddress = false;
    wpr.READ_PAGE_WITH_CRC = -86;
    wpr.WRITE_MEMORY_COMMAND = 85;
    wpr.startPhysicalAddress = 32;

    bank_vector.addElement(wpr);

    MemoryBankEPROM bm = new MemoryBankEPROM(this);

    bm.bankDescription = "Bitmap of used pages for file structure";
    bm.numberPages = 4;
    bm.size = 32;
    bm.pageLength = 8;
    bm.generalPurposeMemory = false;
    bm.extraInfo = false;
    bm.extraInfoLength = 0;
    bm.extraInfoDescription = null;
    bm.crcAfterAddress = false;
    bm.startPhysicalAddress = 64;
    bm.READ_PAGE_WITH_CRC = -86;
    bm.WRITE_MEMORY_COMMAND = 85;

    bank_vector.addElement(bm);

    MemoryBankEPROM rd = new MemoryBankEPROM(this);

    rd.bankDescription = "Page redirection bytes";
    rd.generalPurposeMemory = false;
    rd.numberPages = 32;
    rd.size = 256;
    rd.pageLength = 8;
    rd.extraInfo = false;
    rd.extraInfoLength = 0;
    rd.extraInfoDescription = null;
    rd.crcAfterAddress = false;
    rd.startPhysicalAddress = 256;
    rd.READ_PAGE_WITH_CRC = -86;
    rd.WRITE_MEMORY_COMMAND = 85;

    bank_vector.addElement(rd);

    mn.mbLock = wp;
    mn.mbRedirect = rd;
    mn.mbLockRedirect = wpr;
    mn.redirectPage = true;
    mn.lockPage = true;
    mn.lockRedirectPage = true;

    return bank_vector.elements();
  }
}