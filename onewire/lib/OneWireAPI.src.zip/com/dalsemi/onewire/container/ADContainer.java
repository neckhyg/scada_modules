package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.OneWireIOException;

public abstract interface ADContainer extends OneWireSensor
{
  public static final int ALARM_HIGH = 1;
  public static final int ALARM_LOW = 0;

  public abstract int getNumberADChannels();

  public abstract boolean hasADAlarms();

  public abstract double[] getADRanges(int paramInt);

  public abstract double[] getADResolutions(int paramInt, double paramDouble);

  public abstract boolean canADMultiChannelRead();

  public abstract void doADConvert(int paramInt, byte[] paramArrayOfByte)
    throws OneWireIOException, OneWireException;

  public abstract void doADConvert(boolean[] paramArrayOfBoolean, byte[] paramArrayOfByte)
    throws OneWireIOException, OneWireException;

  public abstract double[] getADVoltage(byte[] paramArrayOfByte)
    throws OneWireIOException, OneWireException;

  public abstract double getADVoltage(int paramInt, byte[] paramArrayOfByte)
    throws OneWireIOException, OneWireException;

  public abstract double getADAlarm(int paramInt1, int paramInt2, byte[] paramArrayOfByte)
    throws OneWireException;

  public abstract boolean getADAlarmEnable(int paramInt1, int paramInt2, byte[] paramArrayOfByte)
    throws OneWireException;

  public abstract boolean hasADAlarmed(int paramInt1, int paramInt2, byte[] paramArrayOfByte)
    throws OneWireException;

  public abstract double getADResolution(int paramInt, byte[] paramArrayOfByte);

  public abstract double getADRange(int paramInt, byte[] paramArrayOfByte);

  public abstract void setADAlarm(int paramInt1, int paramInt2, double paramDouble, byte[] paramArrayOfByte)
    throws OneWireException;

  public abstract void setADAlarmEnable(int paramInt1, int paramInt2, boolean paramBoolean, byte[] paramArrayOfByte)
    throws OneWireException;

  public abstract void setADResolution(int paramInt, double paramDouble, byte[] paramArrayOfByte);

  public abstract void setADRange(int paramInt, double paramDouble, byte[] paramArrayOfByte);
}