package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import java.util.Enumeration;
import java.util.Vector;

public class OneWireContainer37 extends OneWireContainer
  implements PasswordContainer
{
  private static final boolean DEBUG = false;
  private static final int MAX_READ_RETRY_CNT = 15;
  private static final int PASSWORD_LENGTH = 8;
  private MemoryBankScratchCRCPW scratch = null;

  private MemoryBankNVCRCPW userDataMemory = null;

  private MemoryBankNVCRCPW register = null;

  private String partNumber = "DS1977";

  private char partLetter = '0';

  private boolean doSpeedEnable = true;

  protected final byte[] readPassword = new byte[8];
  protected boolean readPasswordSet = false;

  protected final byte[] readWritePassword = new byte[8];
  protected boolean readWritePasswordSet = false;

  private boolean readOnlyPasswordEnabled = false;
  private boolean readWritePasswordEnabled = false;
  private static final byte ENABLE_BYTE = -86;
  private static final byte DISABLE_BYTE = 0;
  private String descriptionString = "Rugged, self-sufficient 1-Wire device that, once setup can store 32KB of password protected memory with a read only and a read/write password.";
  public static final byte WRITE_SCRATCHPAD_COMMAND = 15;
  public static final byte READ_SCRATCHPAD_COMMAND = -86;
  public static final byte COPY_SCRATCHPAD_PW_COMMAND = -103;
  public static final byte READ_MEMORY_PW_COMMAND = 105;
  public static final byte VERIFY_PSW_COMMAND = -61;
  public static final byte READ_VERSION = -52;
  public static final int PASSWORD_CONTROL_REGISTER = 32720;
  public static final int READ_ACCESS_PASSWORD = 32704;
  public static final int READ_WRITE_ACCESS_PASSWORD = 32712;
  public static final int READ_WRITE_PWD = 0;
  public static final int READ_ONLY_PWD = 1;

  public OneWireContainer37()
  {
    initMem();
  }

  public OneWireContainer37(DSPortAdapter sourceAdapter, byte[] newAddress)
  {
    super(sourceAdapter, newAddress);

    initMem();
  }

  public OneWireContainer37(DSPortAdapter sourceAdapter, long newAddress)
  {
    super(sourceAdapter, newAddress);

    initMem();
  }

  public OneWireContainer37(DSPortAdapter sourceAdapter, String newAddress)
  {
    super(sourceAdapter, newAddress);

    initMem();
  }

  public void setupContainer(DSPortAdapter sourceAdapter, byte[] newAddress)
  {
    super.setupContainer(sourceAdapter, newAddress);

    initMem();
  }

  public void setupContainer(DSPortAdapter sourceAdapter, long newAddress)
  {
    super.setupContainer(sourceAdapter, newAddress);

    initMem();
  }

  public void setupContainer(DSPortAdapter sourceAdapter, String newAddress)
  {
    super.setupContainer(sourceAdapter, newAddress);

    initMem();
  }

  public Enumeration getMemoryBanks()
  {
    Vector v = new Vector(3);

    v.addElement(this.scratch);
    v.addElement(this.userDataMemory);
    v.addElement(this.register);

    return v.elements();
  }

  public int getMaxSpeed()
  {
    return 2;
  }

  public String getName()
  {
    return this.partNumber;
  }

  public String getAlternateNames()
  {
    return "";
  }

  public String getDescription()
  {
    return this.descriptionString;
  }

  public synchronized void setSpeedCheck(boolean doSpeedCheck)
  {
    this.doSpeedEnable = doSpeedCheck;
  }

  public int getReadOnlyPasswordLength()
    throws OneWireException
  {
    return 8;
  }

  public int getReadWritePasswordLength()
    throws OneWireException
  {
    return 8;
  }

  public int getWriteOnlyPasswordLength()
    throws OneWireException
  {
    throw new OneWireException("The DS1977 does not have a write password.");
  }

  public int getReadOnlyPasswordAddress()
    throws OneWireException
  {
    return 32704;
  }

  public int getReadWritePasswordAddress()
    throws OneWireException
  {
    return 32712;
  }

  public int getWriteOnlyPasswordAddress()
    throws OneWireException
  {
    throw new OneWireException("The DS1977 does not have a write password.");
  }

  public boolean hasReadOnlyPassword()
  {
    return true;
  }

  public boolean hasReadWritePassword()
  {
    return true;
  }

  public boolean hasWriteOnlyPassword()
  {
    return false;
  }

  public boolean getDeviceReadOnlyPasswordEnable()
    throws OneWireException
  {
    return this.readOnlyPasswordEnabled;
  }

  public boolean getDeviceReadWritePasswordEnable()
    throws OneWireException
  {
    return this.readWritePasswordEnabled;
  }

  public boolean getDeviceWriteOnlyPasswordEnable()
    throws OneWireException
  {
    throw new OneWireException("The DS1977 does not have a Write Only Password.");
  }

  public boolean hasSinglePasswordEnable()
  {
    return false;
  }

  public void setDevicePasswordEnableAll(boolean enableAll)
    throws OneWireException, OneWireIOException
  {
    setDevicePasswordEnable(enableAll, enableAll, false);
  }

  public void setDeviceReadOnlyPassword(byte[] password, int offset)
    throws OneWireException, OneWireIOException
  {
    this.register.write(0, password, offset, 8);

    if (verifyPassword(password, offset, 1))
      setContainerReadOnlyPassword(password, offset);
  }

  public void setDeviceReadWritePassword(byte[] password, int offset)
    throws OneWireException, OneWireIOException
  {
    this.register.write(8, password, offset, 8);

    if (verifyPassword(password, offset, 0))
      setContainerReadWritePassword(password, offset);
  }

  public void setDeviceWriteOnlyPassword(byte[] password, int offset)
    throws OneWireException, OneWireIOException
  {
    throw new OneWireException("The DS1977 does not have a write only password.");
  }

  public void setDevicePasswordEnable(boolean enableReadOnly, boolean enableReadWrite, boolean enableWriteOnly)
    throws OneWireException, OneWireIOException
  {
    if (enableWriteOnly) {
      throw new OneWireException("The DS1922 does not have a write only password.");
    }

    if ((!isContainerReadOnlyPasswordSet()) && (enableReadOnly))
      throw new OneWireException("Container Read Password is not set");
    if (!isContainerReadWritePasswordSet())
      throw new OneWireException("Container Read/Write Password is not set");
    if (enableReadOnly != enableReadWrite) {
      throw new OneWireException("Both read only and read/write passwords will both be disable or enabled");
    }

    byte[] enableCommand = new byte[1];
    enableCommand[0] = (enableReadWrite ? -86 : 0);

    this.register.write(16, enableCommand, 0, 1);

    if (enableReadOnly)
    {
      this.readOnlyPasswordEnabled = true;
      this.readWritePasswordEnabled = true;
    }
    else
    {
      this.readOnlyPasswordEnabled = false;
      this.readWritePasswordEnabled = false;
    }
  }

  public void setContainerReadOnlyPassword(byte[] password, int offset)
    throws OneWireException
  {
    System.arraycopy(password, offset, this.readPassword, 0, 8);
    this.readPasswordSet = true;
  }

  public void getContainerReadOnlyPassword(byte[] password, int offset)
    throws OneWireException
  {
    System.arraycopy(this.readPassword, 0, password, offset, 8);
  }

  public boolean isContainerReadOnlyPasswordSet()
    throws OneWireException
  {
    return this.readPasswordSet;
  }

  public void setContainerReadWritePassword(byte[] password, int offset)
    throws OneWireException
  {
    System.arraycopy(password, offset, this.readWritePassword, 0, 8);
    this.readWritePasswordSet = true;
  }

  public void getContainerReadWritePassword(byte[] password, int offset)
    throws OneWireException
  {
    System.arraycopy(this.readWritePassword, 0, password, offset, 8);
  }

  public boolean isContainerReadWritePasswordSet()
    throws OneWireException
  {
    return this.readWritePasswordSet;
  }

  public void setContainerWriteOnlyPassword(byte[] password, int offset)
    throws OneWireException
  {
    throw new OneWireException("The DS1977 does not have a write only password.");
  }

  public void getContainerWriteOnlyPassword(byte[] password, int offset)
    throws OneWireException
  {
    throw new OneWireException("The DS1977 does not have a write only password.");
  }

  public boolean isContainerWriteOnlyPasswordSet()
    throws OneWireException
  {
    throw new OneWireException("The DS1977 does not have a write only password.");
  }

  public boolean verifyPassword(byte[] password, int offset, int type)
    throws OneWireException, OneWireIOException
  {
    byte[] raw_buf = new byte[15];
    int addr = type == 1 ? 32704 : 32712;

    raw_buf[0] = -61;
    raw_buf[1] = (byte)(addr & 0xFF);
    raw_buf[2] = (byte)((addr & 0xFFFF) >>> 8 & 0xFF);

    System.arraycopy(password, offset, raw_buf, 3, 8);

    this.register.ib.adapter.dataBlock(raw_buf, 0, 10);

    if (this.register.ib.adapter.startPowerDelivery(2))
    {
      this.register.ib.adapter.putByte(raw_buf[11]);

      msWait(5L);

      this.register.ib.adapter.setPowerNormal();

      return this.register.ib.adapter.getByte() == 170;
    }

    return false;
  }

  private void initMem()
  {
    this.scratch = new MemoryBankScratchCRCPW(this);
    this.scratch.pageLength = 64;
    this.scratch.size = 64;
    this.scratch.numberPages = 1;
    this.scratch.maxPacketDataLength = 61;
    this.scratch.enablePower = true;

    this.userDataMemory = new MemoryBankNVCRCPW(this, this.scratch);
    this.userDataMemory.numberPages = 511;
    this.userDataMemory.size = 32704;
    this.userDataMemory.pageLength = 64;
    this.userDataMemory.maxPacketDataLength = 61;
    this.userDataMemory.bankDescription = "Data Memory";
    this.userDataMemory.startPhysicalAddress = 0;
    this.userDataMemory.generalPurposeMemory = true;
    this.userDataMemory.readOnly = false;
    this.userDataMemory.readWrite = true;
    this.userDataMemory.enablePower = true;

    this.register = new MemoryBankNVCRCPW(this, this.scratch);
    this.register.numberPages = 1;
    this.register.size = 64;
    this.register.pageLength = 64;
    this.register.maxPacketDataLength = 61;
    this.register.bankDescription = "Register control";
    this.register.startPhysicalAddress = 32704;
    this.register.generalPurposeMemory = false;
    this.register.enablePower = true;
  }

  private static final void msWait(long ms)
  {
    try
    {
      Thread.sleep(ms);
    }
    catch (InterruptedException ie)
    {
    }
  }
}