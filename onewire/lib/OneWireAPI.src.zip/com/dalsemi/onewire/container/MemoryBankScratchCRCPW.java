package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import com.dalsemi.onewire.utils.CRC16;

public class MemoryBankScratchCRCPW extends MemoryBankScratchEx
{
  protected PasswordContainer ibPass = null;

  public boolean enablePower = false;

  public MemoryBankScratchCRCPW(PasswordContainer ibutton)
  {
    super((OneWireContainer)ibutton);

    this.ibPass = ibutton;

    this.bankDescription = "Scratchpad with CRC and Password";
    this.pageAutoCRC = true;

    this.COPY_SCRATCHPAD_COMMAND = -103;
  }

  public void readPageCRC(int page, boolean readContinue, byte[] readBuf, int offset)
    throws OneWireIOException, OneWireException
  {
    byte[] extraInfo = new byte[this.extraInfoLength];

    readPageCRC(page, readContinue, readBuf, offset, extraInfo);
  }

  public void readPageCRC(int page, boolean readContinue, byte[] readBuf, int offset, byte[] extraInfo)
    throws OneWireIOException, OneWireException
  {
    if (!this.pageAutoCRC) {
      throw new OneWireException("Read page with CRC not supported in this memory bank");
    }

    if (!readContinue) {
      checkSpeed();
    }

    if (page > this.numberPages) {
      throw new OneWireException("Read exceeds memory bank end");
    }

    readScratchpad(readBuf, offset, this.pageLength, extraInfo);
  }

  public void readScratchpad(byte[] readBuf, int offset, int len, byte[] extraInfo)
    throws OneWireIOException, OneWireException
  {
    int blockLength = 0;
    int num_crc = 0;

    if (!this.ib.adapter.select(this.ib.address))
    {
      forceVerify();

      throw new OneWireIOException("Device select failed");
    }

    if (this.enablePower)
    {
      if (len == this.pageLength)
        blockLength = this.extraInfoLength + this.pageLength + 3;
      else
        blockLength = len + this.extraInfoLength + 1;
    }
    else {
      blockLength = this.extraInfoLength + this.pageLength + 3;
    }
    byte[] raw_buf = new byte[blockLength];

    raw_buf[0] = -86;

    System.arraycopy(this.ffBlock, 0, raw_buf, 1, raw_buf.length - 1);

    this.ib.adapter.dataBlock(raw_buf, 0, raw_buf.length);

    int addr = raw_buf[1];

    addr = (addr | raw_buf[2] << 8 & 0xFF00) & 0xFFFF;

    if ((this.enablePower) && (len == 64))
      num_crc = this.pageLength + 3 - (addr & 0x3F) + this.extraInfoLength;
    else if (!this.enablePower) {
      num_crc = this.pageLength + 3 - (addr & 0x1F) + this.extraInfoLength;
    }

    if (len == this.pageLength)
    {
      if (CRC16.compute(raw_buf, 0, num_crc, 0) != 45057)
      {
        forceVerify();
        throw new OneWireIOException("Invalid CRC16 read from device");
      }

    }

    if (extraInfo != null) {
      System.arraycopy(raw_buf, 1, extraInfo, 0, this.extraInfoLength);
    }

    if (!this.enablePower)
      System.arraycopy(raw_buf, this.extraInfoLength + 1, readBuf, offset, len);
    else
      System.arraycopy(raw_buf, this.extraInfoLength + 1, readBuf, offset, len);
  }

  public void copyScratchpad(int startAddr, int len)
    throws OneWireIOException, OneWireException
  {
    if (!this.enablePower)
    {
      if ((startAddr + len & 0x1F) != 0) {
        throw new OneWireException("CopyScratchpad failed: Ending Offset must go to end of page");
      }

    }

    if (!this.ib.adapter.select(this.ib.address))
    {
      forceVerify();
      throw new OneWireIOException("Device select failed");
    }

    int raw_buf_length = 16;
    byte[] raw_buf = new byte[raw_buf_length];

    raw_buf[0] = this.COPY_SCRATCHPAD_COMMAND;
    raw_buf[1] = (byte)(startAddr & 0xFF);
    raw_buf[2] = (byte)((startAddr & 0xFFFF) >>> 8 & 0xFF);
    if (this.enablePower)
      raw_buf[3] = (byte)(startAddr + len - 1 & 0x3F);
    else {
      raw_buf[3] = (byte)(startAddr + len - 1 & 0x1F);
    }
    if (this.ibPass.isContainerReadWritePasswordSet())
    {
      this.ibPass.getContainerReadWritePassword(raw_buf, 4);
    }

    System.arraycopy(this.ffBlock, 0, raw_buf, raw_buf_length - 4, 4);

    if (this.enablePower)
    {
      this.ib.adapter.dataBlock(raw_buf, 0, raw_buf_length - 5);

      this.ib.adapter.startPowerDelivery(2);

      this.ib.adapter.putByte(raw_buf[11]);

      msWait(23L);

      this.ib.adapter.setPowerNormal();

      raw_buf[12] = (byte)this.ib.adapter.getByte();

      if (((raw_buf[12] & 0xFFFFFFF0) != -96) && ((raw_buf[12] & 0xFFFFFFF0) != 80))
      {
        throw new OneWireIOException("Copy scratchpad complete not found");
      }
    }
    else {
      this.ib.adapter.dataBlock(raw_buf, 0, raw_buf_length);

      byte verifyByte = (byte)(raw_buf[(raw_buf_length - 1)] & 0xF);
      if ((verifyByte != 10) && (verifyByte != 5))
      {
        if (verifyByte == 15) {
          throw new OneWireIOException("Copy scratchpad failed - invalid password");
        }
        throw new OneWireIOException("Copy scratchpad complete not found");
      }
    }
  }

  public void writeScratchpad(int startAddr, byte[] writeBuf, int offset, int len)
    throws OneWireIOException, OneWireException
  {
    if (((startAddr + len & 0x1F) != 0) && (!this.enablePower)) {
      throw new OneWireException("WriteScratchpad failed: Ending Offset must go to end of page");
    }

    super.writeScratchpad(startAddr, writeBuf, offset, len);
  }

  private static final void msWait(long ms)
  {
    try
    {
      Thread.sleep(ms);
    }
    catch (InterruptedException ie)
    {
    }
  }
}