package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import com.dalsemi.onewire.utils.CRC16;

class MemoryBankAD
  implements PagedMemoryBank
{
  public static final byte READ_MEMORY_COMMAND = -86;
  public static final byte WRITE_MEMORY_COMMAND = 85;
  public static final int PAGE_LENGTH = 8;
  protected OneWireContainer ib;
  protected byte[] ffBlock;
  protected boolean writeVerification;
  protected boolean doSetSpeed;
  protected String bankDescription;
  protected boolean generalPurposeMemory;
  protected boolean readWrite;
  protected boolean writeOnce;
  protected boolean readOnly;
  protected boolean nonVolatile;
  protected int startPhysicalAddress;

  public MemoryBankAD(OneWireContainer ibutton)
  {
    this.ib = ibutton;

    this.ffBlock = new byte[50];

    for (int i = 0; i < 50; i++) {
      this.ffBlock[i] = -1;
    }

    this.bankDescription = "A/D Conversion read-out";
    this.generalPurposeMemory = false;
    this.startPhysicalAddress = 0;
    this.readWrite = false;
    this.writeOnce = false;
    this.readOnly = true;
    this.nonVolatile = false;
    this.writeVerification = true;

    this.doSetSpeed = true;
  }

  public String getBankDescription()
  {
    return this.bankDescription;
  }

  public boolean isGeneralPurposeMemory()
  {
    return this.generalPurposeMemory;
  }

  public boolean isReadWrite()
  {
    return this.readWrite;
  }

  public boolean isWriteOnce()
  {
    return this.writeOnce;
  }

  public boolean isReadOnly()
  {
    return this.readOnly;
  }

  public boolean isNonVolatile()
  {
    return this.nonVolatile;
  }

  public boolean needsProgramPulse()
  {
    return false;
  }

  public boolean needsPowerDelivery()
  {
    return false;
  }

  public int getStartPhysicalAddress()
  {
    return this.startPhysicalAddress;
  }

  public int getSize()
  {
    return 8;
  }

  public void setWriteVerification(boolean doReadVerf)
  {
    this.writeVerification = doReadVerf;
  }

  public int getNumberPages()
  {
    return 1;
  }

  public int getPageLength()
  {
    return 8;
  }

  public int getMaxPacketDataLength()
  {
    return 5;
  }

  public boolean hasPageAutoCRC()
  {
    return true;
  }

  /** @deprecated */
  public boolean haveExtraInfo()
  {
    return false;
  }

  public boolean hasExtraInfo()
  {
    return false;
  }

  public int getExtraInfoLength()
  {
    return 0;
  }

  public String getExtraInfoDescription()
  {
    return null;
  }

  public void read(int startAddr, boolean readContinue, byte[] readBuf, int offset, int len)
    throws OneWireIOException, OneWireException
  {
    if (startAddr + len > 8) {
      throw new OneWireException("Read exceeds memory bank end");
    }

    int start_pg = startAddr / 8;
    int end_pg = (startAddr + len) / 8 - 1;

    if ((startAddr + len) % 8 > 0) {
      end_pg++;
    }
    byte[] raw_buf = new byte[(end_pg - start_pg + 1) * 8];

    for (int pg = start_pg; pg <= end_pg; pg++) {
      readPageCRC(pg, pg != start_pg, raw_buf, (pg - start_pg) * 8);
    }

    System.arraycopy(raw_buf, startAddr % 8, readBuf, offset, len);
  }

  public void write(int startAddr, byte[] writeBuf, int offset, int len)
    throws OneWireIOException, OneWireException
  {
    byte[] raw_buf = new byte[7];
    int cnt = 0;

    if (len == 0) {
      return;
    }

    checkSpeed();

    if (!this.ib.adapter.select(this.ib.address))
    {
      forceVerify();

      throw new OneWireIOException("Device select failed");
    }

    raw_buf[(cnt++)] = 85;
    int start_addr = startAddr + this.startPhysicalAddress;
    int end_addr = start_addr + len;
    raw_buf[(cnt++)] = (byte)(start_addr & 0xFF);
    raw_buf[(cnt++)] = (byte)((start_addr & 0xFFFF) >>> 8 & 0xFF);

    for (int addr = start_addr; addr < end_addr; addr++)
    {
      raw_buf[(cnt++)] = writeBuf[(offset + addr - start_addr)];

      int lastcrc = CRC16.compute(raw_buf, 0, cnt, addr == start_addr ? 0 : addr);

      System.arraycopy(this.ffBlock, 0, raw_buf, cnt, 3);

      this.ib.adapter.dataBlock(raw_buf, 0, cnt + 3);

      if (CRC16.compute(raw_buf, cnt, 2, lastcrc) != 45057)
      {
        forceVerify();

        throw new OneWireIOException("Invalid CRC16 read from device");
      }

      if (raw_buf[(cnt + 2)] != writeBuf[(offset + addr - start_addr)])
      {
        forceVerify();

        throw new OneWireIOException("Write byte echo was invalid");
      }

      cnt = 0;
    }
  }

  public void readPage(int page, boolean readContinue, byte[] readBuf, int offset)
    throws OneWireIOException, OneWireException
  {
    readPageCRC(page, readContinue, readBuf, offset);
  }

  public void readPage(int page, boolean readContinue, byte[] readBuf, int offset, byte[] extraInfo)
    throws OneWireIOException, OneWireException
  {
    throw new OneWireException("Read page with extra-info not supported by this memory bank");
  }

  public int readPagePacket(int page, boolean readContinue, byte[] readBuf, int offset)
    throws OneWireIOException, OneWireException
  {
    byte[] raw_buf = new byte[8];

    readPageCRC(page, readContinue, raw_buf, 0);

    if (raw_buf[0] > 5) {
      throw new OneWireIOException("Invalid length in packet");
    }

    if (CRC16.compute(raw_buf, 0, raw_buf[0] + 3, page) == 45057)
    {
      System.arraycopy(raw_buf, 1, readBuf, offset, raw_buf[0]);

      return raw_buf[0];
    }

    forceVerify();

    throw new OneWireIOException("Invalid CRC16 in packet read");
  }

  public int readPagePacket(int page, boolean readContinue, byte[] readBuf, int offset, byte[] extraInfo)
    throws OneWireIOException, OneWireException
  {
    throw new OneWireException("Read page packet with extra-info not supported by this memory bank");
  }

  public void writePagePacket(int page, byte[] writeBuf, int offset, int len)
    throws OneWireIOException, OneWireException
  {
    if (len > 5) {
      throw new OneWireIOException("Length of packet requested exceeds page size");
    }

    byte[] raw_buf = new byte[len + 3];

    raw_buf[0] = (byte)len;

    System.arraycopy(writeBuf, offset, raw_buf, 1, len);

    int crc = CRC16.compute(raw_buf, 0, len + 1, page);

    raw_buf[(len + 1)] = (byte)((crc ^ 0xFFFFFFFF) & 0xFF);
    raw_buf[(len + 2)] = (byte)(((crc ^ 0xFFFFFFFF) & 0xFFFF) >>> 8 & 0xFF);

    write(page * 8, raw_buf, 0, len + 3);
  }

  public void readPageCRC(int page, boolean readContinue, byte[] readBuf, int offset)
    throws OneWireIOException, OneWireException
  {
    byte[] raw_buf = new byte[13];

    if (!readContinue)
      checkSpeed();
    int len;
    if (!readContinue)
    {
      if (!this.ib.adapter.select(this.ib.address))
      {
        forceVerify();

        throw new OneWireIOException("Device select failed");
      }

      len = raw_buf.length;

      System.arraycopy(this.ffBlock, 0, raw_buf, 0, len);

      raw_buf[0] = -86;

      int addr = page * 8 + this.startPhysicalAddress;

      raw_buf[1] = (byte)(addr & 0xFF);
      raw_buf[2] = (byte)((addr & 0xFFFF) >>> 8 & 0xFF);
    }
    else
    {
      len = 10;

      System.arraycopy(this.ffBlock, 0, raw_buf, 0, len);
    }

    this.ib.adapter.dataBlock(raw_buf, 0, len);

    if (CRC16.compute(raw_buf, 0, len, 0) != 45057)
    {
      forceVerify();

      throw new OneWireIOException("Invalid CRC16 read from device");
    }

    System.arraycopy(raw_buf, len - 2 - 8, readBuf, offset, 8);
  }

  public void readPageCRC(int page, boolean readContinue, byte[] readBuf, int offset, byte[] extraInfo)
    throws OneWireIOException, OneWireException
  {
    throw new OneWireException("Read page with CRC and extra-info not supported by this memory bank");
  }

  public void checkSpeed()
    throws OneWireIOException, OneWireException
  {
    synchronized (this)
    {
      if (this.doSetSpeed)
      {
        this.ib.doSpeed();

        this.doSetSpeed = false;
      }
    }
  }

  public void forceVerify()
  {
    synchronized (this)
    {
      this.doSetSpeed = true;
    }
  }
}