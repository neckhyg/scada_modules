package com.dalsemi.onewire.container;

import com.dalsemi.onewire.adapter.DSPortAdapter;
import java.util.Enumeration;
import java.util.Vector;

public class OneWireContainer08 extends OneWireContainer
{
  public OneWireContainer08()
  {
  }

  public OneWireContainer08(DSPortAdapter sourceAdapter, byte[] newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public OneWireContainer08(DSPortAdapter sourceAdapter, long newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public OneWireContainer08(DSPortAdapter sourceAdapter, String newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public String getName()
  {
    return "DS1992";
  }

  public String getDescription()
  {
    return "1024 bit read/write nonvolatile memory partitioned into four pages of 256 bits each.";
  }

  public Enumeration getMemoryBanks()
  {
    Vector bank_vector = new Vector(2);

    MemoryBankScratch scratch = new MemoryBankScratch(this);

    bank_vector.addElement(scratch);

    MemoryBankNV nv = new MemoryBankNV(this, scratch);

    nv.numberPages = 4;
    nv.size = 128;

    bank_vector.addElement(nv);

    return bank_vector.elements();
  }
}