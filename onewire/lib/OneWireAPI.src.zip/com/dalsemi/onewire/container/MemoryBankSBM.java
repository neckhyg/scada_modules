package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import com.dalsemi.onewire.utils.CRC8;

class MemoryBankSBM
  implements MemoryBank
{
  private static final byte READ_SCRATCHPAD_COMMAND = -66;
  private static final byte RECALL_MEMORY_COMMAND = -72;
  private static final byte COPY_SCRATCHPAD_COMMAND = 72;
  private static final byte WRITE_SCRATCHPAD_COMMAND = 78;
  protected int startPhysicalAddress;
  protected int size;
  protected String bankDescription;
  protected boolean generalPurposeMemory;
  protected boolean readWrite;
  protected boolean writeOnce;
  protected boolean readOnly;
  protected boolean nonVolatile;
  protected boolean powerDelivery;
  protected OneWireContainer ib;
  protected byte[] ffBlock;
  protected boolean writeVerification;
  protected boolean doSetSpeed;

  public MemoryBankSBM(OneWireContainer ibutton)
  {
    this.ib = ibutton;

    this.bankDescription = "Status/Configuration";
    this.generalPurposeMemory = false;
    this.startPhysicalAddress = 0;
    this.size = 1;
    this.readWrite = true;
    this.readOnly = false;
    this.nonVolatile = true;
    this.powerDelivery = true;
    this.writeVerification = true;

    this.ffBlock = new byte[20];

    for (int i = 0; i < 20; i++) {
      this.ffBlock[i] = -1;
    }

    this.doSetSpeed = true;
  }

  public String getBankDescription()
  {
    return this.bankDescription;
  }

  public boolean isGeneralPurposeMemory()
  {
    return this.generalPurposeMemory;
  }

  public boolean isReadWrite()
  {
    return this.readWrite;
  }

  public boolean isWriteOnce()
  {
    return false;
  }

  public boolean isReadOnly()
  {
    return this.readOnly;
  }

  public boolean isNonVolatile()
  {
    return this.nonVolatile;
  }

  public boolean needsProgramPulse()
  {
    return false;
  }

  public boolean needsPowerDelivery()
  {
    return this.powerDelivery;
  }

  public int getStartPhysicalAddress()
  {
    return this.startPhysicalAddress;
  }

  public int getSize()
  {
    return this.size;
  }

  public void setWriteVerification(boolean doReadVerf)
  {
    this.writeVerification = doReadVerf;
  }

  public void read(int startAddr, boolean readContinue, byte[] readBuf, int offset, int len)
    throws OneWireIOException, OneWireException
  {
    if ((startAddr < 0) || (startAddr + len > this.size)) {
      throw new OneWireException("Read exceeds memory bank");
    }

    if (len == 0) {
      return;
    }

    checkSpeed();

    int page = (startAddr + this.startPhysicalAddress) / 8;
    int page_offset = (startAddr + this.startPhysicalAddress) % 8;
    int data_len = 8 - page_offset;
    if (data_len > len)
      data_len = len;
    int page_cnt = 0;
    int data_read = 0;

    while (data_read < len)
    {
      byte[] temp_buf = readRawPage(page + page_cnt);

      System.arraycopy(temp_buf, page_offset, readBuf, offset + data_read, data_len);

      page_cnt++;
      data_read += data_len;
      page_offset = 0;
      data_len = len - data_read;
      if (data_len > 8)
        data_len = 8;
    }
  }

  public void write(int startAddr, byte[] writeBuf, int offset, int len)
    throws OneWireIOException, OneWireException
  {
    if (len == 0) {
      return;
    }

    if (!this.ib.adapter.canDeliverPower()) {
      throw new OneWireException("Power delivery required but not available");
    }

    checkSpeed();

    int page = (startAddr + this.startPhysicalAddress) / 8;
    int page_offset = (startAddr + this.startPhysicalAddress) % 8;
    int data_len = 8 - page_offset;
    if (data_len > len)
      data_len = len;
    int page_cnt = 0;
    int data_written = 0;
    byte[] page_buf = new byte[8];

    while (data_written < len)
    {
      if ((page_offset != 0) || (data_len != 8))
      {
        byte[] temp_buf = readRawPage(page + page_cnt);
        System.arraycopy(temp_buf, 0, page_buf, 0, 8);
      }

      System.arraycopy(writeBuf, offset + data_written, page_buf, page_offset, data_len);

      writeRawPage(page + page_cnt, page_buf, 0);

      page_cnt++;
      data_written += data_len;
      page_offset = 0;
      data_len = len - data_written;
      if (data_len > 8)
        data_len = 8;
    }
  }

  protected byte[] readRawPage(int page)
    throws OneWireIOException, OneWireException
  {
    byte[] buffer = new byte[11];
    byte[] result = new byte[8];

    if (this.ib.adapter.select(this.ib.address))
    {
      buffer[0] = -72;
      buffer[1] = (byte)page;

      this.ib.adapter.dataBlock(buffer, 0, 2);

      this.ib.adapter.select(this.ib.address);

      buffer[0] = -66;
      buffer[1] = (byte)page;

      for (int i = 2; i < 11; i++) {
        buffer[i] = -1;
      }
      this.ib.adapter.dataBlock(buffer, 0, 11);

      int crc8 = CRC8.compute(buffer, 2, 9);

      if (crc8 != 0) {
        throw new OneWireIOException("Bad CRC during page read " + crc8);
      }

      System.arraycopy(buffer, 2, result, 0, 8);
    }
    else {
      throw new OneWireIOException("Device not found during read page.");
    }
    return result;
  }

  protected void writeRawPage(int page, byte[] source, int offset)
    throws OneWireIOException, OneWireException
  {
    byte[] buffer = new byte[12];

    if (this.ib.adapter.select(this.ib.address))
    {
      buffer[0] = 78;
      buffer[1] = (byte)page;

      System.arraycopy(source, offset, buffer, 2, 8);
      this.ib.adapter.dataBlock(buffer, 0, 10);

      if (this.ib.adapter.select(this.ib.address))
      {
        buffer[0] = -66;
        buffer[1] = (byte)page;

        System.arraycopy(this.ffBlock, 0, buffer, 2, 9);
        this.ib.adapter.dataBlock(buffer, 0, 11);

        int crc8 = CRC8.compute(buffer, 2, 9);

        if (crc8 != 0) {
          throw new OneWireIOException("Bad CRC during scratchpad read " + crc8);
        }

        if (this.ib.adapter.select(this.ib.address))
        {
          buffer[0] = 72;
          buffer[1] = (byte)page;

          this.ib.adapter.dataBlock(buffer, 0, 2);
          try
          {
            Thread.sleep(12L);
          }
          catch (InterruptedException e)
          {
          }
          if ((byte)this.ib.adapter.getByte() != -1) {
            throw new OneWireIOException("Copy scratchpad verification not found.");
          }
          return;
        }
      }
    }

    throw new OneWireIOException("Device not found during write page.");
  }

  public void checkSpeed()
    throws OneWireIOException, OneWireException
  {
    synchronized (this)
    {
      if (this.doSetSpeed)
      {
        this.ib.doSpeed();

        this.doSetSpeed = false;
      }
    }
  }

  public void forceVerify()
  {
    synchronized (this)
    {
      this.doSetSpeed = true;
    }
  }
}