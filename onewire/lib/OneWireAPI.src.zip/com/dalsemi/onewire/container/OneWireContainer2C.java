package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;

public class OneWireContainer2C extends OneWireContainer
  implements PotentiometerContainer
{
  private byte[] buffer = new byte[4];
  private static final byte WRITE_CONTROL = 85;
  private static final byte READ_CONTROL = -86;
  private static final byte WRITE_POSITION = 15;
  private static final byte READ_POSITION = -16;
  private static final byte INCREMENT = -61;
  private static final byte DECREMENT = -103;

  public OneWireContainer2C()
  {
  }

  public OneWireContainer2C(DSPortAdapter sourceAdapter, byte[] newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public OneWireContainer2C(DSPortAdapter sourceAdapter, long newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public OneWireContainer2C(DSPortAdapter sourceAdapter, String newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public String getName()
  {
    return "DS2890";
  }

  public String getAlternateNames()
  {
    return "Digital Potentiometer";
  }

  public String getDescription()
  {
    return "1-Wire linear taper digitally controlled potentiometer with 256 wiper positions.  0-11 Volt working range.";
  }

  public int getMaxSpeed()
  {
    return 2;
  }

  public boolean isLinear(byte[] state)
  {
    return (state[0] & 0x1) == 1;
  }

  public boolean wiperSettingsAreVolatile(byte[] state)
  {
    return (state[0] & 0x2) == 2;
  }

  public int numberOfPotentiometers(byte[] state)
  {
    return (state[0] >> 2 & 0x3) + 1;
  }

  public int numberOfWiperSettings(byte[] state)
  {
    switch (state[0] & 0x30)
    {
    case 0:
      return 32;
    case 16:
      return 64;
    case 32:
      return 128;
    }
    return 256;
  }

  public int potentiometerResistance(byte[] state)
  {
    switch (state[0] & 0xC0)
    {
    case 0:
      return 5;
    case 64:
      return 10;
    case 128:
      return 50;
    }
    return 100;
  }

  public int getCurrentWiperNumber(byte[] state)
  {
    int wiper = state[1] & 0x3;
    int wiper_inverse = state[1] >> 2 & 0x3;

    if (wiper + wiper_inverse == 3) {
      return wiper;
    }
    return -1;
  }

  public void setCurrentWiperNumber(int wiper_number, byte[] state)
  {
    if (wiper_number != (wiper_number & 0x3)) {
      return;
    }
    int wiper_inverse = wiper_number ^ 0xFFFFFFFF;

    wiper_number |= (wiper_inverse & 0x3) << 2;
    state[1] = (byte)(state[1] & 0xF0 | wiper_number & 0xF);
  }

  public boolean isChargePumpOn(byte[] state)
  {
    return (state[1] & 0x40) == 64;
  }

  public void setChargePump(boolean charge_pump_on, byte[] state)
  {
    state[1] = (byte)(state[1] & 0xBF);

    if (charge_pump_on)
      state[1] = (byte)(state[1] | 0x40);
  }

  public int getWiperPosition()
    throws OneWireIOException, OneWireException
  {
    return readRegisters(-16) & 0xFF;
  }

  public boolean setWiperPosition(int position)
    throws OneWireIOException, OneWireException
  {
    return writeTransaction(15, (byte)position);
  }

  public int increment(boolean reselect)
    throws OneWireIOException, OneWireException
  {
    return unitChange(-61, reselect);
  }

  public int decrement(boolean reselect)
    throws OneWireIOException, OneWireException
  {
    return unitChange(-103, reselect);
  }

  public int increment()
    throws OneWireIOException, OneWireException
  {
    return unitChange(-61, true);
  }

  public int decrement()
    throws OneWireIOException, OneWireException
  {
    return unitChange(-103, true);
  }

  public byte[] readDevice()
    throws OneWireIOException, OneWireException
  {
    byte[] state = new byte[2];

    doSpeed();

    if (!this.adapter.select(this.address)) {
      throw new OneWireIOException("Could not select the part!");
    }
    byte[] buf = new byte[3];

    buf[0] = -86;
    byte tmp46_45 = -1; buf[2] = tmp46_45; buf[1] = tmp46_45;

    this.adapter.dataBlock(buf, 0, 3);

    state[0] = buf[1];
    state[1] = buf[2];

    return state;
  }

  public void writeDevice(byte[] state)
    throws OneWireIOException, OneWireException
  {
    if (!writeTransaction(85, state[1]))
      throw new OneWireIOException("Device may not have been present!");
  }

  private synchronized int readRegisters(byte COMMAND)
    throws OneWireIOException, OneWireException
  {
    doSpeed();

    if (!this.adapter.select(this.address)) {
      throw new OneWireIOException("Could not select the part!");
    }
    this.buffer[0] = COMMAND;
    byte tmp46_45 = -1; this.buffer[2] = tmp46_45; this.buffer[1] = tmp46_45;

    this.adapter.dataBlock(this.buffer, 0, 3);

    return 0xFF & this.buffer[2];
  }

  private synchronized boolean writeTransaction(byte COMMAND, byte value)
    throws OneWireIOException, OneWireException
  {
    doSpeed();

    if (this.adapter.select(this.address))
    {
      this.buffer[0] = COMMAND;
      this.buffer[1] = value;
      this.buffer[2] = -1;

      this.adapter.dataBlock(this.buffer, 0, 3);

      if (this.buffer[2] == value)
      {
        this.buffer[0] = -106;
        this.buffer[1] = -1;

        this.adapter.dataBlock(this.buffer, 0, 2);

        if (this.buffer[1] == 0) {
          return true;
        }
      }
    }
    return false;
  }

  private synchronized int unitChange(byte COMMAND, boolean reselect)
    throws OneWireIOException, OneWireException
  {
    if (reselect)
    {
      doSpeed();
      this.adapter.select(this.address);
    }

    this.buffer[0] = COMMAND;
    this.buffer[1] = -1;

    this.adapter.dataBlock(this.buffer, 0, 2);

    return 0xFF & this.buffer[1];
  }
}