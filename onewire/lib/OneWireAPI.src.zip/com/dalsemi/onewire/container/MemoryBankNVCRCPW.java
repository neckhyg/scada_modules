package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import com.dalsemi.onewire.utils.CRC16;

public class MemoryBankNVCRCPW extends MemoryBankNVCRC
{
  public static final byte READ_MEMORY_CRC_PW_COMMAND = 105;
  protected MemoryBankScratchCRCPW scratchpadPW = null;

  protected PasswordContainer ibPass = null;

  public boolean enablePower = false;

  public MemoryBankNVCRCPW(PasswordContainer ibutton, MemoryBankScratchCRCPW scratch)
  {
    super((OneWireContainer)ibutton, scratch);

    this.ibPass = ibutton;

    this.pageAutoCRC = true;
    this.readContinuePossible = true;
    this.numVerifyBytes = 0;

    this.scratchpadPW = scratch;
  }

  public void readPageCRC(int page, boolean readContinue, byte[] readBuf, int offset, byte[] extraInfo)
    throws OneWireIOException, OneWireException
  {
    readPageCRC(page, readContinue, readBuf, offset, extraInfo, this.extraInfoLength);
  }

  protected void readPageCRC(int page, boolean readContinue, byte[] readBuf, int offset, byte[] extraInfo, int extraLength)
    throws OneWireIOException, OneWireException
  {
    int last_crc = 0;

    if (!this.pageAutoCRC) {
      throw new OneWireException("Read page with CRC not supported in this memory bank");
    }

    if (!readContinue) {
      this.sp.checkSpeed();
    }

    if (page > this.numberPages)
      throw new OneWireException("Read exceeds memory bank end");
    byte temp;
    if ((!readContinue) || (!this.readContinuePossible))
    {
      if (!this.ib.adapter.select(this.ib.address))
      {
        this.sp.forceVerify();

        throw new OneWireIOException("Device select failed");
      }

      raw_buf = new byte[11];
      raw_buf[0] = 105;

      int addr = page * this.pageLength + this.startPhysicalAddress;

      raw_buf[1] = (byte)(addr & 0xFF);
      raw_buf[2] = (byte)((addr & 0xFFFF) >>> 8 & 0xFF);

      if (this.ibPass.isContainerReadWritePasswordSet())
        this.ibPass.getContainerReadWritePassword(raw_buf, 3);
      else {
        this.ibPass.getContainerReadOnlyPassword(raw_buf, 3);
      }

      last_crc = CRC16.compute(raw_buf, 0, 3, last_crc);

      if (this.enablePower)
      {
        this.ib.adapter.dataBlock(raw_buf, 0, 10);

        this.ib.adapter.startPowerDelivery(2);

        this.ib.adapter.putByte(raw_buf[10]);
      }
      else
      {
        this.ib.adapter.dataBlock(raw_buf, 0, 11);
      }

    }
    else if (this.enablePower)
    {
      this.ib.adapter.startPowerDelivery(2);
      temp = (byte)this.ib.adapter.getByte();
    }

    if (this.enablePower)
    {
      msWait(3L);

      this.ib.adapter.setPowerNormal();
    }

    byte[] raw_buf = new byte[this.pageLength + extraLength + 2 + this.numVerifyBytes];

    System.arraycopy(this.ffBlock, 0, raw_buf, 0, raw_buf.length);

    if (this.enablePower)
    {
      this.ib.adapter.dataBlock(raw_buf, 0, raw_buf.length - 1);
      last_crc = CRC16.compute(raw_buf, 0, raw_buf.length - this.numVerifyBytes - 2, last_crc);

      if ((last_crc & 0xFF) != ((raw_buf[(raw_buf.length - 2)] ^ 0xFFFFFFFF) & 0xFF))
      {
        this.sp.forceVerify();
        throw new OneWireIOException("Invalid CRC16 read from device.  Password may be incorrect.");
      }
    }
    else
    {
      this.ib.adapter.dataBlock(raw_buf, 0, raw_buf.length);

      if (CRC16.compute(raw_buf, 0, raw_buf.length - this.numVerifyBytes, last_crc) != 45057)
      {
        this.sp.forceVerify();
        throw new OneWireIOException("Invalid CRC16 read from device.  Password may be incorrect.");
      }

    }

    System.arraycopy(raw_buf, 0, readBuf, offset, this.pageLength);

    if (extraInfo != null)
      System.arraycopy(raw_buf, this.pageLength, extraInfo, 0, extraLength);
  }

  public void read(int startAddr, boolean readContinue, byte[] readBuf, int offset, int len)
    throws OneWireIOException, OneWireException
  {
    byte[] raw_buf = new byte[64];

    if (!readContinue)
    {
      this.sp.checkSpeed();
    }

    if (startAddr + len > this.size) {
      throw new OneWireException("Read exceeds memory bank end");
    }

    if (!readContinue)
    {
      if (!this.ib.adapter.select(this.ib.address))
      {
        this.sp.forceVerify();

        throw new OneWireIOException("Device select failed");
      }

      int addr = startAddr + this.startPhysicalAddress;

      raw_buf[0] = 105;

      raw_buf[1] = (byte)(addr & 0xFF);
      raw_buf[2] = (byte)((addr & 0xFFFF) >>> 8 & 0xFF);

      if (this.ibPass.isContainerReadWritePasswordSet())
        this.ibPass.getContainerReadWritePassword(raw_buf, 3);
      else {
        this.ibPass.getContainerReadOnlyPassword(raw_buf, 3);
      }

      if (this.enablePower)
      {
        this.ib.adapter.dataBlock(raw_buf, 0, 10);
        this.ib.adapter.startPowerDelivery(2);
        this.ib.adapter.putByte(raw_buf[10]);

        msWait(10L);

        this.ib.adapter.setPowerNormal();
      }
      else
      {
        this.ib.adapter.dataBlock(raw_buf, 0, 11);
      }

    }

    int startOffset = startAddr % this.pageLength;

    int bytesLeftover = len % this.pageLength;

    int pgs = len / this.pageLength;

    if (startOffset > 0)
    {
      pgs++;

      bytesLeftover -= this.pageLength - startOffset;
    }

    if (bytesLeftover > 0) {
      pgs++;
    }
    int startPage = startAddr / this.pageLength;

    for (int i = 0; i < pgs; i++)
    {
      readPageCRC(startPage + i, false, raw_buf, 0, null, 0);

      if (i == 0)
      {
        System.arraycopy(raw_buf, startOffset, readBuf, offset, this.pageLength - startOffset);
      }
      else if ((i == pgs - 1) && (bytesLeftover != 0))
      {
        System.arraycopy(raw_buf, 0, readBuf, offset + (this.pageLength - startOffset) + (i - 1) * this.pageLength, bytesLeftover);
      }
      else
      {
        System.arraycopy(raw_buf, 0, readBuf, offset + (this.pageLength - startOffset) + (i - 1) * this.pageLength, this.pageLength);
      }
    }
  }

  public void write(int startAddr, byte[] writeBuf, int offset, int len)
    throws OneWireIOException, OneWireException
  {
    int endingOffset = startAddr + len;
    if (((endingOffset & 0x1F) > 0) && (!this.enablePower))
    {
      int numBytes = this.pageLength - (endingOffset & 0x1F);
      if (((this.ibPass.hasReadWritePassword()) && ((0xFFE0 & endingOffset) == (0xFFE0 & this.ibPass.getReadWritePasswordAddress())) && (endingOffset < this.ibPass.getReadWritePasswordAddress() + this.ibPass.getReadWritePasswordLength())) || ((this.ibPass.hasReadOnlyPassword()) && ((0xFFE0 & endingOffset) == (0xFFE0 & this.ibPass.getReadOnlyPasswordAddress())) && (endingOffset < this.ibPass.getReadOnlyPasswordAddress() + this.ibPass.getReadOnlyPasswordLength())) || ((this.ibPass.hasWriteOnlyPassword()) && ((0xFFE0 & endingOffset) == (0xFFE0 & this.ibPass.getWriteOnlyPasswordAddress())) && (endingOffset < this.ibPass.getWriteOnlyPasswordAddress() + this.ibPass.getWriteOnlyPasswordLength())))
      {
        throw new OneWireException("Executing write would overwrite password control registers with potentially invalid data.  Please ensure write does not occur overpassword control register page, or the password control data is specified exactly in the write buffer.");
      }

      byte[] tempBuf = new byte[len + numBytes];
      System.arraycopy(writeBuf, offset, tempBuf, 0, len);
      read(endingOffset, false, tempBuf, len, numBytes);

      super.write(startAddr, tempBuf, 0, tempBuf.length);
    }
    else
    {
      super.write(startAddr, writeBuf, offset, len);
    }
  }

  private static final void msWait(long ms)
  {
    try
    {
      Thread.sleep(ms);
    }
    catch (InterruptedException ie)
    {
    }
  }
}