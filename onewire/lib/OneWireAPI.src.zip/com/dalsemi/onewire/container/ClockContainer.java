package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;

public abstract interface ClockContainer extends OneWireSensor
{
  public abstract boolean hasClockAlarm();

  public abstract boolean canDisableClock();

  public abstract long getClockResolution();

  public abstract long getClock(byte[] paramArrayOfByte);

  public abstract long getClockAlarm(byte[] paramArrayOfByte)
    throws OneWireException;

  public abstract boolean isClockAlarming(byte[] paramArrayOfByte);

  public abstract boolean isClockAlarmEnabled(byte[] paramArrayOfByte);

  public abstract boolean isClockRunning(byte[] paramArrayOfByte);

  public abstract void setClock(long paramLong, byte[] paramArrayOfByte);

  public abstract void setClockAlarm(long paramLong, byte[] paramArrayOfByte)
    throws OneWireException;

  public abstract void setClockRunEnable(boolean paramBoolean, byte[] paramArrayOfByte)
    throws OneWireException;

  public abstract void setClockAlarmEnable(boolean paramBoolean, byte[] paramArrayOfByte)
    throws OneWireException;
}