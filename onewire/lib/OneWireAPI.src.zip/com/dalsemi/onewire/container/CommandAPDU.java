package com.dalsemi.onewire.container;

public class CommandAPDU
{
  public static final int CLA = 0;
  public static final int INS = 1;
  public static final int P1 = 2;
  public static final int P2 = 3;
  public static final int LC = 4;
  protected byte[] apduBuffer = null;
  protected int apduLength;

  public CommandAPDU(byte[] buffer)
  {
    this.apduLength = buffer.length;
    this.apduBuffer = new byte[this.apduLength];

    System.arraycopy(buffer, 0, this.apduBuffer, 0, this.apduLength);
  }

  public CommandAPDU(byte cla, byte ins, byte p1, byte p2)
  {
    this(cla, ins, p1, p2, null, -1);
  }

  public CommandAPDU(byte cla, byte ins, byte p1, byte p2, int le)
  {
    this(cla, ins, p1, p2, null, le);
  }

  public CommandAPDU(byte cla, byte ins, byte p1, byte p2, byte[] data)
  {
    this(cla, ins, p1, p2, data, -1);
  }

  public CommandAPDU(byte cla, byte ins, byte p1, byte p2, byte[] data, int le)
  {
    this.apduLength = 5;

    if (data != null)
    {
      this.apduLength += data.length;
    }

    if (le >= 0)
    {
      this.apduLength += 1;
    }

    this.apduBuffer = new byte[this.apduLength];

    this.apduBuffer[0] = cla;
    this.apduBuffer[1] = ins;
    this.apduBuffer[2] = p1;
    this.apduBuffer[3] = p2;

    if (data != null)
    {
      this.apduBuffer[4] = (byte)data.length;

      System.arraycopy(data, 0, this.apduBuffer, 5, data.length);
    }
    else
    {
      this.apduBuffer[4] = 0;
    }

    if (le >= 0)
      this.apduBuffer[(this.apduLength - 1)] = (byte)le;
  }

  public byte getCLA()
  {
    return this.apduBuffer[0];
  }

  public byte getINS()
  {
    return this.apduBuffer[1];
  }

  public byte getP1()
  {
    return this.apduBuffer[2];
  }

  public byte getP2()
  {
    return this.apduBuffer[3];
  }

  public int getLC()
  {
    if (this.apduLength >= 6) {
      return this.apduBuffer[4];
    }
    return 0;
  }

  public int getLE()
  {
    if ((this.apduLength == 5) || (this.apduLength == 6 + getLC())) {
      return this.apduBuffer[(this.apduLength - 1)];
    }
    return -1;
  }

  public final byte[] getBuffer()
  {
    return this.apduBuffer;
  }

  public final byte getByte(int index)
  {
    if (index >= this.apduLength) {
      return -1;
    }
    return this.apduBuffer[index];
  }

  public final byte[] getBytes()
  {
    byte[] apdu = new byte[this.apduLength];

    System.arraycopy(this.apduBuffer, 0, apdu, 0, this.apduLength);

    return apdu;
  }

  public final int getLength()
  {
    return this.apduLength;
  }

  public final void setByte(int index, byte value)
  {
    if (index < this.apduLength)
      this.apduBuffer[index] = value;
  }

  public String toString()
  {
    String apduString = "";

    apduString = apduString + "CLA = " + Integer.toHexString(this.apduBuffer[0] & 0xFF);
    apduString = apduString + " INS = " + Integer.toHexString(this.apduBuffer[1] & 0xFF);
    apduString = apduString + " P1 = " + Integer.toHexString(this.apduBuffer[2] & 0xFF);
    apduString = apduString + " P2 = " + Integer.toHexString(this.apduBuffer[3] & 0xFF);
    apduString = apduString + " LC = " + Integer.toHexString(getLC() & 0xFF);

    if (getLE() == -1)
      apduString = apduString + " LE = " + getLE();
    else {
      apduString = apduString + " LE = " + Integer.toHexString(getLE() & 0xFF);
    }
    if (this.apduLength > 5)
    {
      apduString = apduString + "\nDATA = ";

      for (int i = 5; i < getLC() + 5; i++)
      {
        if ((this.apduBuffer[i] & 0xFF) < 16) {
          apduString = apduString + '0';
        }
        apduString = apduString + Integer.toHexString(this.apduBuffer[i] & 0xFF) + " ";
      }

    }

    return apduString.toUpperCase();
  }
}