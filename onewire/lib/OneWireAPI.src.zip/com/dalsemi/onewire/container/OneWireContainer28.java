package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import com.dalsemi.onewire.utils.CRC8;
import com.dalsemi.onewire.utils.Convert;

public class OneWireContainer28 extends OneWireContainer
  implements TemperatureContainer
{
  public static final byte WRITE_SCRATCHPAD_COMMAND = 78;
  public static final byte READ_SCRATCHPAD_COMMAND = -66;
  public static final byte COPY_SCRATCHPAD_COMMAND = 72;
  public static final byte CONVERT_TEMPERATURE_COMMAND = 68;
  public static final byte RECALL_E2MEMORY_COMMAND = -72;
  public static final byte READ_POWER_SUPPLY_COMMAND = -76;
  public static final byte RESOLUTION_12_BIT = 127;
  public static final byte RESOLUTION_11_BIT = 95;
  public static final byte RESOLUTION_10_BIT = 63;
  public static final byte RESOLUTION_9_BIT = 31;

  public OneWireContainer28()
  {
  }

  public OneWireContainer28(DSPortAdapter sourceAdapter, byte[] newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public OneWireContainer28(DSPortAdapter sourceAdapter, long newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public OneWireContainer28(DSPortAdapter sourceAdapter, String newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public String getName()
  {
    return "DS18B20";
  }

  public String getAlternateNames()
  {
    return "DS1820B, DS18B20X";
  }

  public String getDescription()
  {
    return "Digital thermometer measures temperatures from -55C to 125C in 0.75 seconds (max).  +/- 0.5C accuracy between -10C and 85C. Thermometer resolution is programmable at 9, 10, 11, and 12 bits. ";
  }

  public boolean hasTemperatureAlarms()
  {
    return true;
  }

  public boolean hasSelectableTemperatureResolution()
  {
    return true;
  }

  public double[] getTemperatureResolutions()
  {
    double[] resolutions = new double[4];

    resolutions[0] = 0.5D;
    resolutions[1] = 0.25D;
    resolutions[2] = 0.125D;
    resolutions[3] = 0.0625D;

    return resolutions;
  }

  public double getTemperatureAlarmResolution()
  {
    return 1.0D;
  }

  public double getMaxTemperature()
  {
    return 125.0D;
  }

  public double getMinTemperature()
  {
    return -55.0D;
  }

  public void doTemperatureConvert(byte[] state)
    throws OneWireIOException, OneWireException
  {
    int msDelay = 750;

    if (this.adapter.select(this.address))
    {
      this.adapter.setPowerDuration(5);
      this.adapter.startPowerDelivery(2);

      this.adapter.putByte(68);

      switch (state[4])
      {
      case 31:
        msDelay = 94;
        break;
      case 63:
        msDelay = 188;
        break;
      case 95:
        msDelay = 375;
        break;
      case 127:
        msDelay = 750;
        break;
      default:
        msDelay = 750;
      }

      try
      {
        Thread.sleep(msDelay);
      }
      catch (InterruptedException e)
      {
      }
      this.adapter.setPowerNormal();

      if (this.adapter.getByte() != 255) {
        throw new OneWireIOException("OneWireContainer28-temperature conversion not complete");
      }

    }
    else
    {
      throw new OneWireIOException("OneWireContainer28-device not present");
    }
  }

  public double getTemperature(byte[] state)
    throws OneWireIOException
  {
    double theTemperature = 0.0D;
    int inttemperature = state[1];

    inttemperature = inttemperature << 8 | state[0] & 0xFF;
    theTemperature = inttemperature / 16.0D;

    return theTemperature;
  }

  public double getTemperatureAlarm(int alarmType, byte[] state)
  {
    return state[2];
  }

  public double getTemperatureResolution(byte[] state)
  {
    double tempres = 0.0D;

    switch (state[4])
    {
    case 31:
      tempres = 0.5D;
      break;
    case 63:
      tempres = 0.25D;
      break;
    case 95:
      tempres = 0.125D;
      break;
    case 127:
      tempres = 0.0625D;
      break;
    default:
      tempres = 0.0D;
    }

    return tempres;
  }

  public void setTemperatureAlarm(int alarmType, double alarmValue, byte[] state)
    throws OneWireException, OneWireIOException
  {
    if ((alarmType != 0) && (alarmType != 1)) {
      throw new IllegalArgumentException("Invalid alarm type.");
    }
    if ((alarmValue > 125.0D) || (alarmValue < -55.0D)) {
      throw new IllegalArgumentException("Value for alarm not in accepted range.  Must be -55 C <-> +125 C.");
    }

    state[(alarmType == 0 ? 3 : 2)] = (byte)(int)alarmValue;
  }

  public void setTemperatureResolution(double resolution, byte[] state)
    throws OneWireException
  {
    byte configbyte = 127;

    synchronized (this)
    {
      if (resolution == 0.5D) {
        configbyte = 31;
      }
      if (resolution == 0.25D) {
        configbyte = 63;
      }
      if (resolution == 0.125D) {
        configbyte = 95;
      }
      if (resolution == 0.0625D) {
        configbyte = 127;
      }
      state[4] = configbyte;
    }
  }

  public byte[] readDevice()
    throws OneWireIOException, OneWireException
  {
    byte[] data = recallE2();

    return data;
  }

  public void writeDevice(byte[] state)
    throws OneWireIOException, OneWireException
  {
    byte[] temp = new byte[3];

    temp[0] = state[2];
    temp[1] = state[3];
    temp[2] = state[4];

    writeScratchpad(temp);

    copyScratchpad();
  }

  public byte[] readScratchpad()
    throws OneWireIOException, OneWireException
  {
    if (this.adapter.select(this.address))
    {
      byte[] send_block = new byte[10];

      send_block[0] = -66;

      for (int i = 1; i < 10; i++) {
        send_block[i] = -1;
      }

      this.adapter.dataBlock(send_block, 0, send_block.length);

      byte[] result_block = new byte[9];

      for (int i = 0; i < 9; i++)
      {
        result_block[i] = send_block[(i + 1)];
      }

      if (CRC8.compute(send_block, 1, 9) == 0) {
        return result_block;
      }
      throw new OneWireIOException("OneWireContainer28-Error reading CRC8 from device.");
    }

    throw new OneWireIOException("OneWireContainer28-Device not found on 1-Wire Network");
  }

  public void writeScratchpad(byte[] data)
    throws OneWireIOException, OneWireException
  {
    byte[] writeBuffer = new byte[4];

    writeBuffer[0] = 78;
    writeBuffer[1] = data[0];
    writeBuffer[2] = data[1];
    writeBuffer[3] = data[2];

    if (this.adapter.select(this.address))
    {
      this.adapter.dataBlock(writeBuffer, 0, writeBuffer.length);
    }
    else
    {
      throw new OneWireIOException("OneWireContainer28-Device not found on 1-Wire Network");
    }

    byte[] readBuffer = readScratchpad();

    if ((readBuffer[2] != data[0]) || (readBuffer[3] != data[1]) || (readBuffer[4] != data[2]))
    {
      throw new OneWireIOException("OneWireContainer28-Error writing to scratchpad");
    }
  }

  public void copyScratchpad()
    throws OneWireIOException, OneWireException
  {
    byte[] readfirstbuffer = readScratchpad();

    if (this.adapter.select(this.address))
    {
      this.adapter.setPowerDuration(5);
      this.adapter.startPowerDelivery(2);

      this.adapter.putByte(72);
      try
      {
        Thread.sleep(10L);
      }
      catch (InterruptedException e)
      {
      }

      this.adapter.setPowerNormal();
    }
    else
    {
      throw new OneWireIOException("OneWireContainer28-Device not found on 1-Wire Network");
    }

    byte[] readlastbuffer = recallE2();

    if ((readfirstbuffer[2] != readlastbuffer[2]) || (readfirstbuffer[3] != readlastbuffer[3]) || (readfirstbuffer[4] != readlastbuffer[4]))
    {
      throw new OneWireIOException("OneWireContainer28-Error copying scratchpad to E2 memory.");
    }
  }

  public byte[] recallE2()
    throws OneWireIOException, OneWireException
  {
    if (this.adapter.select(this.address))
    {
      this.adapter.putByte(-72);

      byte[] ScratchBuff = readScratchpad();

      return ScratchBuff;
    }

    throw new OneWireIOException("OneWireContainer28-Device not found on 1-Wire Network");
  }

  public boolean isExternalPowerSupplied()
    throws OneWireIOException, OneWireException
  {
    int intresult = 0;
    boolean result = false;

    if (this.adapter.select(this.address))
    {
      this.adapter.putByte(-76);

      intresult = this.adapter.getByte();
    }
    else
    {
      throw new OneWireIOException("OneWireContainer28-Device not found on 1-Wire Network");
    }

    if (intresult != 0) {
      result = true;
    }
    return result;
  }

  /** @deprecated */
  public float convertToFahrenheit(float celsiusTemperature)
  {
    return (float)Convert.toFahrenheit(celsiusTemperature);
  }
}