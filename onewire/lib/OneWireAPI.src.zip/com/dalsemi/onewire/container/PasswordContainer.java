package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.OneWireIOException;

public abstract interface PasswordContainer
{
  public abstract int getReadOnlyPasswordLength()
    throws OneWireException;

  public abstract int getReadWritePasswordLength()
    throws OneWireException;

  public abstract int getWriteOnlyPasswordLength()
    throws OneWireException;

  public abstract int getReadOnlyPasswordAddress()
    throws OneWireException;

  public abstract int getReadWritePasswordAddress()
    throws OneWireException;

  public abstract int getWriteOnlyPasswordAddress()
    throws OneWireException;

  public abstract boolean hasReadOnlyPassword();

  public abstract boolean hasReadWritePassword();

  public abstract boolean hasWriteOnlyPassword();

  public abstract boolean getDeviceReadOnlyPasswordEnable()
    throws OneWireException;

  public abstract boolean getDeviceReadWritePasswordEnable()
    throws OneWireException;

  public abstract boolean getDeviceWriteOnlyPasswordEnable()
    throws OneWireException;

  public abstract boolean hasSinglePasswordEnable();

  public abstract void setDevicePasswordEnable(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3)
    throws OneWireException, OneWireIOException;

  public abstract void setDevicePasswordEnableAll(boolean paramBoolean)
    throws OneWireException, OneWireIOException;

  public abstract void setDeviceReadOnlyPassword(byte[] paramArrayOfByte, int paramInt)
    throws OneWireException, OneWireIOException;

  public abstract void setDeviceReadWritePassword(byte[] paramArrayOfByte, int paramInt)
    throws OneWireException, OneWireIOException;

  public abstract void setDeviceWriteOnlyPassword(byte[] paramArrayOfByte, int paramInt)
    throws OneWireException, OneWireIOException;

  public abstract void setContainerReadOnlyPassword(byte[] paramArrayOfByte, int paramInt)
    throws OneWireException;

  public abstract void setContainerReadWritePassword(byte[] paramArrayOfByte, int paramInt)
    throws OneWireException;

  public abstract void setContainerWriteOnlyPassword(byte[] paramArrayOfByte, int paramInt)
    throws OneWireException;

  public abstract boolean isContainerReadOnlyPasswordSet()
    throws OneWireException;

  public abstract boolean isContainerReadWritePasswordSet()
    throws OneWireException;

  public abstract boolean isContainerWriteOnlyPasswordSet()
    throws OneWireException;

  public abstract void getContainerReadOnlyPassword(byte[] paramArrayOfByte, int paramInt)
    throws OneWireException;

  public abstract void getContainerReadWritePassword(byte[] paramArrayOfByte, int paramInt)
    throws OneWireException;

  public abstract void getContainerWriteOnlyPassword(byte[] paramArrayOfByte, int paramInt)
    throws OneWireException;
}