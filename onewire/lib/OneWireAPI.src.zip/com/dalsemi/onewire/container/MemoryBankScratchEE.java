package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import com.dalsemi.onewire.utils.CRC16;

class MemoryBankScratchEE extends MemoryBankScratch
{
  protected byte COPY_DELAY_LEN;
  protected byte ES_MASK;
  protected int numVerificationBytes = 1;

  public MemoryBankScratchEE(OneWireContainer ibutton)
  {
    super(ibutton);

    this.COPY_DELAY_LEN = 5;

    this.ES_MASK = 0;
  }

  public void writeScratchpad(int startAddr, byte[] writeBuf, int offset, int len)
    throws OneWireIOException, OneWireException
  {
    boolean calcCRC = false;

    if (!this.ib.adapter.select(this.ib.address))
    {
      forceVerify();

      throw new OneWireIOException("Device select failed");
    }

    byte[] raw_buf = new byte[37];

    raw_buf[0] = 15;
    raw_buf[1] = (byte)(startAddr & 0xFF);
    raw_buf[2] = (byte)((startAddr & 0xFFFF) >>> 8 & 0xFF);

    System.arraycopy(writeBuf, offset, raw_buf, 3, len);

    if ((startAddr + len) % this.pageLength == 0)
    {
      System.arraycopy(this.ffBlock, 0, raw_buf, len + 3, 2);

      calcCRC = true;
    }

    this.ib.adapter.dataBlock(raw_buf, 0, len + 3 + (calcCRC ? 2 : 0));

    if (calcCRC)
    {
      if (CRC16.compute(raw_buf, 0, len + 5, 0) != 45057)
      {
        forceVerify();

        throw new OneWireIOException("Invalid CRC16 read from device");
      }
    }
  }

  public void copyScratchpad(int startAddr, int len)
    throws OneWireIOException, OneWireException
  {
    if (!this.ib.adapter.select(this.ib.address))
    {
      forceVerify();

      throw new OneWireIOException("Device select failed");
    }

    byte[] raw_buf = new byte[3];

    raw_buf[0] = this.COPY_SCRATCHPAD_COMMAND;
    raw_buf[1] = (byte)(startAddr & 0xFF);
    raw_buf[2] = (byte)((startAddr & 0xFFFF) >>> 8 & 0xFF);

    this.ib.adapter.dataBlock(raw_buf, 0, 3);
    try
    {
      this.ib.adapter.setPowerDuration(5);
      this.ib.adapter.startPowerDelivery(2);

      this.ib.adapter.putByte((byte)(startAddr + len - 1 & this.pageLength - 1) | this.ES_MASK);

      Thread.sleep(this.COPY_DELAY_LEN);

      this.ib.adapter.setPowerNormal();

      byte rslt = 0;
      if (this.numVerificationBytes == 1) {
        rslt = (byte)this.ib.adapter.getByte();
      }
      else {
        raw_buf = new byte[this.numVerificationBytes];
        this.ib.adapter.getBlock(raw_buf, 0, this.numVerificationBytes);
        rslt = raw_buf[(this.numVerificationBytes - 1)];
      }

      if (((byte)(rslt & 0xF0) != -96) && ((byte)(rslt & 0xF0) != 80))
      {
        forceVerify();

        throw new OneWireIOException("Copy scratchpad complete not found");
      }
    }
    catch (InterruptedException e)
    {
    }
  }
}