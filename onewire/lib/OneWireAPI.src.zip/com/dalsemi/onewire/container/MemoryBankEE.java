package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import com.dalsemi.onewire.utils.CRC16;

class MemoryBankEE
  implements PagedMemoryBank
{
  public static final byte READ_MEMORY_COMMAND = -16;
  public static final byte WRITE_SCRATCHPAD_COMMAND = 15;
  public static final byte READ_SCRATCHPAD_COMMAND = -86;
  public static final byte COPY_SCRATCHPAD_COMMAND = 85;
  public static final int PAGE_LENGTH = 32;
  protected OneWireContainer ib;
  protected byte[] ffBlock;
  protected boolean writeVerification;
  protected boolean doSetSpeed;

  public MemoryBankEE(OneWireContainer ibutton)
  {
    synchronized (this)
    {
      this.ib = ibutton;

      this.ffBlock = new byte[50];

      for (int i = 0; i < 50; i++) {
        this.ffBlock[i] = -1;
      }

      this.writeVerification = true;

      this.doSetSpeed = true;
    }
  }

  public String getBankDescription()
  {
    return "Main Memory";
  }

  public boolean isGeneralPurposeMemory()
  {
    return true;
  }

  public boolean isReadWrite()
  {
    return true;
  }

  public boolean isWriteOnce()
  {
    return false;
  }

  public boolean isReadOnly()
  {
    return false;
  }

  public boolean isNonVolatile()
  {
    return true;
  }

  public boolean needsProgramPulse()
  {
    return false;
  }

  public boolean needsPowerDelivery()
  {
    return true;
  }

  public int getStartPhysicalAddress()
  {
    return 0;
  }

  public int getSize()
  {
    return 32;
  }

  public void setWriteVerification(boolean doReadVerf)
  {
    this.writeVerification = doReadVerf;
  }

  public int getNumberPages()
  {
    return 1;
  }

  public int getPageLength()
  {
    return 32;
  }

  public int getMaxPacketDataLength()
  {
    return 29;
  }

  public boolean hasPageAutoCRC()
  {
    return false;
  }

  /** @deprecated */
  public boolean haveExtraInfo()
  {
    return false;
  }

  public boolean hasExtraInfo()
  {
    return false;
  }

  public int getExtraInfoLength()
  {
    return 0;
  }

  public String getExtraInfoDescription()
  {
    return null;
  }

  public void read(int startAddr, boolean readContinue, byte[] readBuf, int offset, int len)
    throws OneWireIOException, OneWireException
  {
    int cnt = 0;
    byte[] raw_buf = new byte[2];

    if (!readContinue) {
      checkSpeed();
    }

    if (startAddr + len > 32) {
      throw new OneWireException("Read exceeds memory bank end");
    }

    do
    {
      if (!this.ib.adapter.select(this.ib.address))
      {
        forceVerify();

        throw new OneWireIOException("Device select failed");
      }

      raw_buf[0] = -16;
      raw_buf[1] = (byte)(startAddr & 0xFF);

      this.ib.adapter.dataBlock(raw_buf, 0, 2);

      System.arraycopy(this.ffBlock, 0, readBuf, offset, len);

      this.ib.adapter.dataBlock(readBuf, offset, len);

      for (int i = 0; i < len; i++) {
        if (readBuf[(offset + i)] != -1)
          return;
      }
      try
      {
        Thread.sleep(10L);
      }
      catch (InterruptedException e)
      {
      }
      if (!this.ib.isPresent())
      {
        forceVerify();

        throw new OneWireIOException("Device not present on 1-Wire");
      }

      cnt++; } while (cnt < 6);
  }

  public void write(int startAddr, byte[] writeBuf, int offset, int len)
    throws OneWireIOException, OneWireException
  {
    if (len == 0) {
      return;
    }

    if (!this.ib.adapter.canDeliverPower()) {
      throw new OneWireException("Power delivery required but not available");
    }

    checkSpeed();

    if (startAddr + len > 32) {
      throw new OneWireException("Write exceeds memory bank end");
    }

    writeScratchpad(startAddr, writeBuf, offset, len);

    byte[] raw_buf = new byte[32];

    readScratchpad(raw_buf, startAddr, 0, 32);

    for (int i = 0; i < len; i++) {
      if (raw_buf[i] == writeBuf[(i + offset)])
        continue;
      forceVerify();

      throw new OneWireIOException("Read back scratchpad verify had incorrect data");
    }

    copyScratchpad();

    if (this.writeVerification)
    {
      read(startAddr, false, raw_buf, 0, len);

      for (i = 0; i < len; i++) {
        if (raw_buf[i] == writeBuf[(i + offset)])
          continue;
        forceVerify();

        throw new OneWireIOException("Read back verify had incorrect data");
      }
    }
  }

  public void readPage(int page, boolean readContinue, byte[] readBuf, int offset)
    throws OneWireIOException, OneWireException
  {
    if (page != 0) {
      throw new OneWireException("Page read exceeds memory bank end");
    }
    read(0, readContinue, readBuf, offset, 32);
  }

  public void readPage(int page, boolean readContinue, byte[] readBuf, int offset, byte[] extraInfo)
    throws OneWireIOException, OneWireException
  {
    throw new OneWireException("Read page with extra-info not supported by this memory bank");
  }

  public int readPagePacket(int page, boolean readContinue, byte[] readBuf, int offset)
    throws OneWireIOException, OneWireException
  {
    byte[] raw_buf = new byte[32];

    checkSpeed();

    readPage(page, readContinue, raw_buf, 0);

    if (raw_buf[0] > 29)
    {
      forceVerify();

      throw new OneWireIOException("Invalid length in packet");
    }

    if (CRC16.compute(raw_buf, 0, raw_buf[0] + 3, page) == 45057)
    {
      System.arraycopy(raw_buf, 1, readBuf, offset, raw_buf[0]);

      return raw_buf[0];
    }

    forceVerify();

    throw new OneWireIOException("Invalid CRC16 in packet read");
  }

  public int readPagePacket(int page, boolean readContinue, byte[] readBuf, int offset, byte[] extraInfo)
    throws OneWireIOException, OneWireException
  {
    throw new OneWireException("Read page packet with extra-info not supported by this memory bank");
  }

  public void writePagePacket(int page, byte[] writeBuf, int offset, int len)
    throws OneWireIOException, OneWireException
  {
    if (len > 29) {
      throw new OneWireIOException("Length of packet requested exceeds page size");
    }

    byte[] raw_buf = new byte[len + 3];

    raw_buf[0] = (byte)len;

    System.arraycopy(writeBuf, offset, raw_buf, 1, len);

    int crc = CRC16.compute(raw_buf, 0, len + 1, page);

    raw_buf[(len + 1)] = (byte)((crc ^ 0xFFFFFFFF) & 0xFF);
    raw_buf[(len + 2)] = (byte)(((crc ^ 0xFFFFFFFF) & 0xFFFF) >>> 8 & 0xFF);

    write(page * 32, raw_buf, 0, len + 3);
  }

  public void readPageCRC(int page, boolean readContinue, byte[] readBuf, int offset)
    throws OneWireIOException, OneWireException
  {
    throw new OneWireException("Read page with CRC not supported by this memory bank");
  }

  public void readPageCRC(int page, boolean readContinue, byte[] readBuf, int offset, byte[] extraInfo)
    throws OneWireIOException, OneWireException
  {
    throw new OneWireException("Read page with CRC and extra-info not supported by this memory bank");
  }

  protected void readScratchpad(byte[] readBuf, int startAddr, int offset, int len)
    throws OneWireIOException, OneWireException
  {
    if (!this.ib.adapter.select(this.ib.address))
    {
      forceVerify();

      throw new OneWireIOException("Device select failed");
    }

    byte[] raw_buf = new byte[2];

    raw_buf[0] = -86;
    raw_buf[1] = (byte)startAddr;

    this.ib.adapter.dataBlock(raw_buf, 0, 2);

    System.arraycopy(this.ffBlock, 0, readBuf, offset, len);

    this.ib.adapter.dataBlock(readBuf, offset, len);
  }

  protected void writeScratchpad(int startAddr, byte[] writeBuf, int offset, int len)
    throws OneWireIOException, OneWireException
  {
    if (!this.ib.adapter.select(this.ib.address))
    {
      forceVerify();

      throw new OneWireIOException("Device select failed");
    }

    byte[] raw_buf = new byte[len + 2];

    raw_buf[0] = 15;
    raw_buf[1] = (byte)(startAddr & 0xFF);

    System.arraycopy(writeBuf, offset, raw_buf, 2, len);

    this.ib.adapter.dataBlock(raw_buf, 0, len + 2);
  }

  protected void copyScratchpad()
    throws OneWireIOException, OneWireException
  {
    if (!this.ib.adapter.select(this.ib.address))
    {
      forceVerify();

      throw new OneWireIOException("Device select failed");
    }

    try
    {
      this.ib.adapter.putByte(85);

      this.ib.adapter.setPowerDuration(5);
      this.ib.adapter.startPowerDelivery(2);

      this.ib.adapter.putByte(-91);

      Thread.sleep(10L);

      this.ib.adapter.setPowerNormal();
    }
    catch (InterruptedException e)
    {
    }
  }

  public void checkSpeed()
    throws OneWireIOException, OneWireException
  {
    synchronized (this)
    {
      if (this.doSetSpeed)
      {
        this.ib.doSpeed();

        this.doSetSpeed = false;
      }
    }
  }

  public void forceVerify()
  {
    synchronized (this)
    {
      this.doSetSpeed = true;
    }
  }
}