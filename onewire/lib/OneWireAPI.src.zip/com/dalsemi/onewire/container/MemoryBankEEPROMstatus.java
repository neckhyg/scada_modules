package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import com.dalsemi.onewire.utils.CRC16;
import com.dalsemi.onewire.utils.Convert;

class MemoryBankEEPROMstatus
  implements MemoryBank
{
  public static final byte READ_MEMORY_COMMAND = -16;
  public static final byte WRITE_SCRATCHPAD_COMMAND = 15;
  public static final byte READ_SCRATCHPAD_COMMAND = -86;
  public static final byte COPY_SCRATCHPAD_COMMAND = 85;
  public static final byte CHANNEL_ACCESS_WRITE = 90;
  protected OneWireContainer ib;
  protected byte[] ffBlock;
  protected boolean doSetSpeed;
  protected int size;
  protected String bankDescription;
  protected boolean generalPurposeMemory;
  protected boolean readWrite;
  protected boolean writeOnce;
  protected boolean readOnly;
  protected boolean nonVolatile;
  protected boolean programPulse;
  protected boolean powerDelivery;
  protected int startPhysicalAddress;
  protected boolean writeVerification;
  protected int numberPages;
  protected int pageLength;
  protected int maxPacketDataLength;
  protected boolean pageAutoCRC;

  public MemoryBankEEPROMstatus(OneWireContainer ibutton)
  {
    this.ib = ibutton;

    this.generalPurposeMemory = false;
    this.bankDescription = "Main Memory";
    this.numberPages = 1;
    this.readWrite = false;
    this.writeOnce = false;
    this.readOnly = false;
    this.nonVolatile = true;
    this.pageAutoCRC = true;
    this.programPulse = false;
    this.powerDelivery = false;
    this.writeVerification = false;
    this.startPhysicalAddress = 0;
    this.doSetSpeed = true;

    this.ffBlock = new byte[20];

    for (int i = 0; i < 20; i++)
      this.ffBlock[i] = -1;
  }

  public String getBankDescription()
  {
    return this.bankDescription;
  }

  public boolean isGeneralPurposeMemory()
  {
    return this.generalPurposeMemory;
  }

  public boolean isReadWrite()
  {
    return this.readWrite;
  }

  public boolean isWriteOnce()
  {
    return this.writeOnce;
  }

  public boolean isReadOnly()
  {
    return this.readOnly;
  }

  public boolean isNonVolatile()
  {
    return this.nonVolatile;
  }

  public boolean needsProgramPulse()
  {
    return this.programPulse;
  }

  public boolean needsPowerDelivery()
  {
    return this.powerDelivery;
  }

  public int getStartPhysicalAddress()
  {
    return this.startPhysicalAddress;
  }

  public int getSize()
  {
    return this.size;
  }

  public int getNumberPages()
  {
    return this.numberPages;
  }

  public int getPageLength()
  {
    return this.pageLength;
  }

  public int getMaxPacketDataLength()
  {
    return this.maxPacketDataLength;
  }

  public boolean hasPageAutoCRC()
  {
    return this.pageAutoCRC;
  }

  public boolean hasExtraInfo()
  {
    return false;
  }

  public int getExtraInfoLength()
  {
    return 0;
  }

  public String getExtraInfoDescription()
  {
    return null;
  }

  public void setWriteVerification(boolean doReadVerf)
  {
    this.writeVerification = doReadVerf;
  }

  public void read(int startAddr, boolean readContinue, byte[] readBuf, int offset, int len)
    throws OneWireIOException, OneWireException
  {
    byte[] buff = new byte[20];
    int addr = this.startPhysicalAddress + startAddr;

    System.arraycopy(this.ffBlock, 0, buff, 0, 20);

    if (startAddr + len > this.size) {
      throw new OneWireException("Read exceeds memory bank end");
    }

    if (!readContinue)
    {
      checkSpeed();

      if (this.ib.adapter.select(this.ib.address))
      {
        buff[0] = -16;

        buff[1] = (byte)(addr & 0xFF);

        buff[2] = (byte)((addr & 0xFFFF) >>> 8 & 0xFF);

        this.ib.adapter.dataBlock(buff, 0, len + 3);

        System.arraycopy(buff, 3, readBuf, offset, len);
      }
      else {
        throw new OneWireIOException("Device select failed");
      }
    }
    else {
      this.ib.adapter.dataBlock(buff, 0, len);

      System.arraycopy(buff, 0, readBuf, offset, len);
    }
  }

  public void write(int startAddr, byte[] writeBuf, int offset, int len)
    throws OneWireIOException, OneWireException
  {
    byte[] es_data = new byte[3];
    byte[] scratchpad = new byte[8];

    if (len == 0) {
      return;
    }

    checkSpeed();

    if (startAddr + len > this.size) {
      throw new OneWireException("Write exceeds memory bank end");
    }

    if ((isReadOnly()) && (this.startPhysicalAddress + startAddr != 137) && (len != 1)) {
      throw new OneWireException("Trying to write read-only memory bank");
    }
    if ((this.startPhysicalAddress + startAddr == 137) && (len == 1))
    {
      this.ib.adapter.select(this.ib.address);

      byte[] buffer = new byte[5];

      buffer[0] = 90;
      buffer[1] = writeBuf[offset];
      buffer[2] = (byte)(writeBuf[offset] ^ 0xFFFFFFFF);
      System.arraycopy(this.ffBlock, 0, buffer, 3, 2);

      this.ib.adapter.dataBlock(buffer, 0, 5);

      if (buffer[3] != -86)
      {
        throw new OneWireIOException("Failure to change DS2408 latch state: buffer=" + Convert.toHexString(buffer));
      }
    }
    else if ((this.startPhysicalAddress + startAddr > 138) && (this.startPhysicalAddress + startAddr + len < 143))
    {
      this.ib.adapter.select(this.ib.address);

      byte[] buffer = new byte[6];

      buffer[0] = -52;
      buffer[1] = (byte)(startAddr + this.startPhysicalAddress & 0xFF);
      buffer[2] = (byte)((startAddr + this.startPhysicalAddress & 0xFFFF) >>> 8 & 0xFF);

      System.arraycopy(writeBuf, offset, buffer, 3, len);

      this.ib.adapter.dataBlock(buffer, 0, len + 3);
    }
    else if ((this.startPhysicalAddress + startAddr > 127) && (this.startPhysicalAddress + startAddr + len < 130))
    {
      byte[] buffer = new byte[8];
      int addr = 128;
      byte[] buff = new byte[11];

      System.arraycopy(this.ffBlock, 0, buff, 0, 11);

      this.ib.adapter.select(this.ib.address);

      buff[0] = -16;

      buff[1] = (byte)(addr & 0xFF);

      buff[2] = (byte)((addr & 0xFFFF) >>> 8 & 0xFF);

      this.ib.adapter.dataBlock(buff, 0, 11);

      System.arraycopy(buff, 3, buffer, 0, 8);

      System.arraycopy(writeBuf, offset, buffer, 0, len);

      if (!writeScratchpad(this.startPhysicalAddress + startAddr, buffer, 0, 8)) {
        throw new OneWireIOException("Invalid CRC16 in write");
      }
      if (!readScratchpad(scratchpad, 0, 8, es_data)) {
        throw new OneWireIOException("Read scratchpad was not successful.");
      }
      if ((es_data[2] & 0x20) == 32)
      {
        throw new OneWireIOException("The write scratchpad command was not completed.");
      }

      for (int i = 0; i < 8; i++) {
        if (scratchpad[i] == buffer[i])
          continue;
        throw new OneWireIOException("The read back of the data in the scratch pad did not match.");
      }

      copyScratchpad(es_data);
    }
    else {
      throw new OneWireIOException("Trying to write read-only memory.");
    }
  }

  public void checkSpeed()
    throws OneWireIOException, OneWireException
  {
    synchronized (this)
    {
      if (this.doSetSpeed)
      {
        this.ib.doSpeed();

        this.doSetSpeed = false;
      }
    }
  }

  public void forceVerify()
  {
    synchronized (this)
    {
      this.doSetSpeed = true;
    }
  }

  public boolean writeScratchpad(int addr, byte[] out_buf, int offset, int len)
    throws OneWireIOException, OneWireException
  {
    byte[] send_block = new byte[14];

    if (len > 8) {
      len = 8;
    }

    if (this.ib.adapter.select(this.ib.getAddress()))
    {
      int cnt = 0;

      send_block[(cnt++)] = 15;

      send_block[(cnt++)] = (byte)(addr & 0xFF);
      send_block[(cnt++)] = (byte)((addr & 0xFFFF) >>> 8 & 0xFF);

      System.arraycopy(out_buf, offset, send_block, 3, len);
      cnt += len;

      send_block[(cnt++)] = -1;
      send_block[(cnt++)] = -1;

      this.ib.adapter.dataBlock(send_block, 0, cnt);
    }
    else
    {
      throw new OneWireIOException("Device select failed.");
    }
    return true;
  }

  public synchronized void copyScratchpad(byte[] es_data)
    throws OneWireIOException, OneWireException
  {
    byte[] send_block = new byte[4];

    if (this.ib.adapter.select(this.ib.getAddress()))
    {
      send_block[3] = es_data[2];

      send_block[2] = es_data[1];

      send_block[1] = es_data[0];

      send_block[0] = 85;

      this.ib.adapter.dataBlock(send_block, 0, 3);

      this.ib.adapter.setPowerDuration(5);
      this.ib.adapter.startPowerDelivery(2);
      this.ib.adapter.putByte(send_block[3]);
      try
      {
        Thread.sleep(12L);
      }
      catch (InterruptedException e) {
      }
      this.ib.adapter.setPowerNormal();

      byte test = (byte)this.ib.adapter.getByte();

      if (test == -1)
      {
        throw new OneWireIOException("The scratchpad did not get copied to memory.");
      }
    }
    else {
      throw new OneWireIOException("Device select failed.");
    }
  }

  public boolean readScratchpad(byte[] readBuf, int offset, int len, byte[] es_data)
    throws OneWireIOException, OneWireException
  {
    if (!this.ib.adapter.select(this.ib.address))
    {
      forceVerify();
      throw new OneWireIOException("Device select failed");
    }

    byte[] raw_buf = new byte[14];
    raw_buf[0] = -86;
    System.arraycopy(this.ffBlock, 0, raw_buf, 1, 13);

    this.ib.adapter.dataBlock(raw_buf, 0, 14);

    if (CRC16.compute(raw_buf, 0, 14) == 45057)
    {
      if (es_data != null) {
        System.arraycopy(raw_buf, 1, es_data, 0, 3);
      }
      System.arraycopy(raw_buf, 4, readBuf, offset, len);

      return true;
    }

    throw new OneWireException("Error due to CRC.");
  }
}