package com.dalsemi.onewire.container;

import com.dalsemi.onewire.adapter.DSPortAdapter;
import java.util.Enumeration;
import java.util.Vector;

public class OneWireContainer23 extends OneWireContainer
{
  public OneWireContainer23()
  {
  }

  public OneWireContainer23(DSPortAdapter sourceAdapter, byte[] newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public OneWireContainer23(DSPortAdapter sourceAdapter, long newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public OneWireContainer23(DSPortAdapter sourceAdapter, String newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public String getName()
  {
    return "DS1973";
  }

  public String getAlternateNames()
  {
    return "DS2433";
  }

  public String getDescription()
  {
    return "4096 bit Electrically Erasable Programmable Read Only Memory (EEPROM) organized as sixteen pages of 256 bits.";
  }

  public int getMaxSpeed()
  {
    return 2;
  }

  public Enumeration getMemoryBanks()
  {
    Vector bank_vector = new Vector(2);

    MemoryBankScratchEE mbScratch = new MemoryBankScratchEE(this);
    bank_vector.addElement(mbScratch);

    MemoryBankNV mbNV = new MemoryBankNV(this, mbScratch);
    mbNV.powerDelivery = true;

    bank_vector.addElement(mbNV);

    return bank_vector.elements();
  }
}