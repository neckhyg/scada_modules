package com.dalsemi.onewire.container;

import com.dalsemi.onewire.adapter.DSPortAdapter;
import java.util.Enumeration;
import java.util.Vector;

public class OneWireContainer14 extends OneWireContainer
{
  public OneWireContainer14()
  {
  }

  public OneWireContainer14(DSPortAdapter sourceAdapter, byte[] newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public OneWireContainer14(DSPortAdapter sourceAdapter, long newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public OneWireContainer14(DSPortAdapter sourceAdapter, String newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public String getName()
  {
    return "DS1971";
  }

  public String getAlternateNames()
  {
    return "DS2430A";
  }

  public String getDescription()
  {
    return "Electrically Erasable Programmable Read Only Memory (EEPROM) organized as one page of 256 bits and 64 bit one-time programmable application register.";
  }

  public Enumeration getMemoryBanks()
  {
    Vector bank_vector = new Vector(1);

    bank_vector.addElement(new MemoryBankEE(this));

    bank_vector.addElement(new MemoryBankAppReg(this));

    return bank_vector.elements();
  }
}