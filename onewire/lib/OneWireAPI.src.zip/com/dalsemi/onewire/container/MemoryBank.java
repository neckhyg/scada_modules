package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.OneWireIOException;

public abstract interface MemoryBank
{
  public abstract String getBankDescription();

  public abstract boolean isGeneralPurposeMemory();

  public abstract int getSize();

  public abstract boolean isReadWrite();

  public abstract boolean isWriteOnce();

  public abstract boolean isReadOnly();

  public abstract boolean isNonVolatile();

  public abstract boolean needsProgramPulse();

  public abstract boolean needsPowerDelivery();

  public abstract int getStartPhysicalAddress();

  public abstract void setWriteVerification(boolean paramBoolean);

  public abstract void read(int paramInt1, boolean paramBoolean, byte[] paramArrayOfByte, int paramInt2, int paramInt3)
    throws OneWireIOException, OneWireException;

  public abstract void write(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3)
    throws OneWireIOException, OneWireException;
}