package com.dalsemi.onewire.container;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.OneWireIOException;

public abstract interface MissionContainer extends ClockContainer
{
  public static final int ALARM_HIGH = 1;
  public static final int ALARM_LOW = 0;

  public abstract void startNewMission(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, boolean[] paramArrayOfBoolean)
    throws OneWireException, OneWireIOException;

  public abstract void stopMission()
    throws OneWireException, OneWireIOException;

  public abstract boolean isMissionRunning()
    throws OneWireException, OneWireIOException;

  public abstract boolean isMissionRolloverEnabled()
    throws OneWireException, OneWireIOException;

  public abstract boolean hasMissionRolloverOccurred()
    throws OneWireException, OneWireIOException;

  public abstract void loadMissionResults()
    throws OneWireException, OneWireIOException;

  public abstract boolean isMissionLoaded();

  public abstract void clearMissionResults()
    throws OneWireException, OneWireIOException;

  public abstract int getNumberMissionChannels()
    throws OneWireException, OneWireIOException;

  public abstract void setMissionChannelEnable(int paramInt, boolean paramBoolean)
    throws OneWireException, OneWireIOException;

  public abstract boolean getMissionChannelEnable(int paramInt)
    throws OneWireException, OneWireIOException;

  public abstract String getMissionLabel(int paramInt)
    throws OneWireException, OneWireIOException;

  public abstract long getMissionTimeStamp(int paramInt)
    throws OneWireException, OneWireIOException;

  public abstract long getFirstSampleOffset(int paramInt)
    throws OneWireException, OneWireIOException;

  public abstract int getMissionSampleRate(int paramInt)
    throws OneWireException, OneWireIOException;

  public abstract int getMissionSampleCount(int paramInt)
    throws OneWireException, OneWireIOException;

  public abstract int getMissionSampleCountTotal(int paramInt)
    throws OneWireException, OneWireIOException;

  public abstract double getMissionSample(int paramInt1, int paramInt2)
    throws OneWireException, OneWireIOException;

  public abstract int getMissionSampleAsInteger(int paramInt1, int paramInt2)
    throws OneWireException, OneWireIOException;

  public abstract long getMissionSampleTimeStamp(int paramInt1, int paramInt2)
    throws OneWireException, OneWireIOException;

  public abstract double[] getMissionResolutions(int paramInt)
    throws OneWireException, OneWireIOException;

  public abstract double getMissionResolution(int paramInt)
    throws OneWireException, OneWireIOException;

  public abstract void setMissionResolution(int paramInt, double paramDouble)
    throws OneWireException, OneWireIOException;

  public abstract boolean hasMissionAlarms(int paramInt);

  public abstract boolean hasMissionAlarmed(int paramInt1, int paramInt2)
    throws OneWireException, OneWireIOException;

  public abstract boolean getMissionAlarmEnable(int paramInt1, int paramInt2)
    throws OneWireException, OneWireIOException;

  public abstract void setMissionAlarmEnable(int paramInt1, int paramInt2, boolean paramBoolean)
    throws OneWireException, OneWireIOException;

  public abstract double getMissionAlarm(int paramInt1, int paramInt2)
    throws OneWireException, OneWireIOException;

  public abstract void setMissionAlarm(int paramInt1, int paramInt2, double paramDouble)
    throws OneWireException, OneWireIOException;
}