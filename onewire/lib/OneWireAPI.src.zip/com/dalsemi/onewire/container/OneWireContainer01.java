package com.dalsemi.onewire.container;

import com.dalsemi.onewire.adapter.DSPortAdapter;

public class OneWireContainer01 extends OneWireContainer
{
  public OneWireContainer01()
  {
  }

  public OneWireContainer01(DSPortAdapter sourceAdapter, byte[] newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public OneWireContainer01(DSPortAdapter sourceAdapter, long newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public OneWireContainer01(DSPortAdapter sourceAdapter, String newAddress)
  {
    super(sourceAdapter, newAddress);
  }

  public String getName()
  {
    return "DS1990A";
  }

  public String getAlternateNames()
  {
    return "DS2401,DS2411";
  }

  public String getDescription()
  {
    return "64-bit unique serial number";
  }
}