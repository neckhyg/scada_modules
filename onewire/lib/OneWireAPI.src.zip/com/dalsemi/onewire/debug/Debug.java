package com.dalsemi.onewire.debug;

import com.dalsemi.onewire.OneWireAccessProvider;
import com.dalsemi.onewire.utils.Convert;
import java.io.FileOutputStream;
import java.io.PrintStream;

public class Debug
{
  private static boolean DEBUG = false;
  private static PrintStream out = System.out;

  public static final void setDebugMode(boolean onoff)
  {
    DEBUG = onoff;
  }

  public static final boolean getDebugMode()
  {
    return DEBUG;
  }

  public static final void setPrintStream(PrintStream outStream)
  {
    out = outStream;
  }

  public static final void debug(String x)
  {
    if (DEBUG)
      out.println(">> " + x);
  }

  public static final void debug(String lbl, byte[] bytes)
  {
    if (DEBUG)
      debug(lbl, bytes, 0, bytes.length);
  }

  public static final void debug(String lbl, byte[] bytes, int offset, int length)
  {
    if (DEBUG)
    {
      out.print(">> " + lbl + ", offset=" + offset + ", length=" + length);
      length += offset;
      int inc = 8;
      boolean printHead = true;
      for (int i = offset; i < length; i += inc)
      {
        if (printHead)
        {
          out.println();
          out.print(">>    ");
        }
        else
        {
          out.print(" : ");
        }
        int len = Math.min(inc, length - i);
        out.print(Convert.toHexString(bytes, i, len, " "));
        printHead = !printHead;
      }
      out.println();
    }
  }

  public static final void debug(String lbl, Throwable t)
  {
    if (DEBUG)
    {
      out.println(">> " + lbl);
      out.println(">>    " + t.getMessage());
      t.printStackTrace(out);
    }
  }

  public static final void stackTrace()
  {
    if (DEBUG)
    {
      try
      {
        throw new Exception("DEBUG STACK TRACE");
      }
      catch (Exception e)
      {
        e.printStackTrace(out);
      }
    }
  }

  static
  {
    String enable = OneWireAccessProvider.getProperty("onewire.debug");
    if ((enable != null) && (enable.toLowerCase().equals("true")))
      DEBUG = true;
    else {
      DEBUG = false;
    }
    if (DEBUG)
    {
      String logFile = OneWireAccessProvider.getProperty("onewire.debug.logfile");
      if (logFile != null)
      {
        try
        {
          out = new PrintStream(new FileOutputStream(logFile), true);
        }
        catch (Exception e)
        {
          out = System.out;
          debug("Error in Debug Static Constructor", e);
        }
      }
    }
  }
}