package com.dalsemi.onewire;

public class OneWireException extends Exception
{
  public OneWireException()
  {
  }

  public OneWireException(String desc)
  {
    super(desc);
  }
}