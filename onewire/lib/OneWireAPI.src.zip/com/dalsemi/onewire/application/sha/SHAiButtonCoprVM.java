package com.dalsemi.onewire.application.sha;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.OneWireIOException;
import com.dalsemi.onewire.application.file.OWFileInputStream;
import com.dalsemi.onewire.application.file.OWFileOutputStream;
import com.dalsemi.onewire.container.OneWireContainer;
import com.dalsemi.onewire.container.OneWireContainer18;
import com.dalsemi.onewire.utils.Address;
import com.dalsemi.onewire.utils.SHA;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Random;

public class SHAiButtonCoprVM extends SHAiButtonCopr
{
  protected byte[][] secretPage = new byte[8][8];

  protected byte[] address = new byte[8];

  private static final byte[] digestBuff = new byte[64];

  private static final byte[] NullSecret = { 0, 0, 0, 0, 0, 0, 0, 0 };

  private static Random rand = new Random();

  private byte[] generateChallenge_chlg = new byte[20];

  private byte[] bindSecretToiButton_scratchpad = new byte[32];

  public SHAiButtonCoprVM(byte[] RomID, int l_signPageNumber, int l_authPageNumber, int l_wspcPageNumber, int l_version, int l_encCode, byte l_serviceFileExt, byte[] l_serviceFilename, byte[] l_providerName, byte[] l_bindData, byte[] l_bindCode, byte[] l_auxData, byte[] l_initialSignature, byte[] l_signingChlg, byte[] l_signingSecret, byte[] l_authSecret)
    throws OneWireException, OneWireIOException
  {
    this.lastError = 0;

    System.arraycopy(RomID, 0, this.address, 0, 8);
    this.signPageNumber = l_signPageNumber;
    this.authPageNumber = l_authPageNumber;
    this.wspcPageNumber = l_wspcPageNumber;
    this.version = l_version;
    this.encCode = l_encCode;
    System.arraycopy(l_serviceFilename, 0, this.filename, 0, 4);
    this.filename[4] = l_serviceFileExt;
    this.providerName = new String(l_providerName);
    System.arraycopy(l_bindData, 0, this.bindData, 0, 32);
    System.arraycopy(l_bindCode, 0, this.bindCode, 0, 7);
    this.auxData = new String(l_auxData);
    System.arraycopy(l_initialSignature, 0, this.initialSignature, 0, 20);
    System.arraycopy(l_signingChlg, 0, this.signingChallenge, 0, 3);

    this.DS1961Scompatible = (l_authSecret.length % 47 == 0);
    int secretDiv = l_authSecret.length / 47;
    for (int j = 0; (j < secretDiv) && (this.DS1961Scompatible); j++)
    {
      int offset = 47 * j;
      for (int i = 32; (i < 36) && (this.DS1961Scompatible); i++) {
        this.DS1961Scompatible = (l_authSecret[(i + offset)] == -1);
      }
      for (int i = 44; (i < 47) && (this.DS1961Scompatible); i++) {
        this.DS1961Scompatible = (l_authSecret[(i + offset)] == -1);
      }

    }

    if (!installMasterSecret(this.signPageNumber, l_signingSecret, this.signPageNumber & 0x7)) {
      throw new OneWireIOException("failed to install system signing secret");
    }

    if (!installMasterSecret(this.authPageNumber, l_authSecret, this.authPageNumber & 0x7))
      throw new OneWireIOException("failed to install authentication secret");
  }

  public SHAiButtonCoprVM(String filename)
    throws OneWireException, OneWireIOException
  {
    if (!load(filename))
      throw new OneWireIOException("failed to load config info");
  }

  public SHAiButtonCoprVM(String filename, byte[] sign_secret, byte[] auth_secret)
    throws OneWireException, OneWireIOException
  {
    if (!load(filename))
      throw new OneWireIOException("failed to load config info");
    if (!installMasterSecret(this.signPageNumber, sign_secret, this.signPageNumber & 0x7))
      throw new OneWireIOException("failed to install system signing secret");
    if (!installMasterSecret(this.authPageNumber, auth_secret, this.authPageNumber & 0x7))
      throw new OneWireIOException("failed to install authentication secret");
  }

  public SHAiButtonCoprVM(OneWireContainer owc, String filename)
    throws OneWireException, OneWireIOException
  {
    if (!load(owc, filename))
      throw new OneWireIOException("failed to load config info");
  }

  public SHAiButtonCoprVM(OneWireContainer owc, String filename, byte[] sign_secret, byte[] auth_secret)
    throws OneWireException, OneWireIOException
  {
    if (!load(owc, filename))
      throw new OneWireIOException("failed to load config info");
    if (!installMasterSecret(this.signPageNumber, sign_secret, this.signPageNumber & 0x7))
      throw new OneWireIOException("failed to install system signing secret");
    if (!installMasterSecret(this.authPageNumber, auth_secret, this.authPageNumber & 0x7))
      throw new OneWireIOException("failed to install authentication secret");
  }

  public SHAiButtonCoprVM(OneWireContainer18 owc, String filename, byte[] sign_secret, byte[] auth_secret)
    throws OneWireException, OneWireIOException
  {
    if (!load(owc, filename))
      throw new OneWireIOException("failed to load config info");
    if (!installMasterSecret(this.signPageNumber, sign_secret, this.signPageNumber & 0x7))
      throw new OneWireIOException("failed to install system signing secret");
    if (!installMasterSecret(this.authPageNumber, auth_secret, this.authPageNumber & 0x7))
      throw new OneWireIOException("failed to install authentication secret");
  }

  public boolean save(String filename, boolean saveSecretData)
    throws OneWireException, OneWireIOException
  {
    try
    {
      FileOutputStream fos = new FileOutputStream(filename);

      toStream(fos);

      fos.write(this.address, 0, 8);
      for (int i = 0; i < 8; i++)
      {
        if (saveSecretData)
          fos.write(this.secretPage[i]);
        else
          fos.write(NullSecret);
      }
      fos.flush();
      fos.close();

      return true;
    }
    catch (Exception e) {
    }
    return false;
  }

  public boolean save(OneWireContainer owc, String filename, boolean saveSecretData)
    throws OneWireException, OneWireIOException
  {
    try
    {
      OWFileOutputStream fos = new OWFileOutputStream(owc, filename);

      toStream(fos);

      fos.write(this.address, 0, 8);
      for (int i = 0; i < 8; i++)
      {
        if (saveSecretData)
          fos.write(this.secretPage[i]);
        else
          fos.write(NullSecret);
      }
      fos.flush();
      fos.close();

      return true;
    }
    catch (Exception ioe) {
    }
    return false;
  }

  public boolean load(String filename)
  {
    try
    {
      FileInputStream fis = new FileInputStream(filename);

      fromStream(fis);

      if (fis.available() > 0)
      {
        fis.read(this.address, 0, 8);
        for (int i = 0; (i < 8) && (fis.available() > 0); i++)
        {
          fis.read(this.secretPage[i]);
        }
      }
      fis.close();
      return true;
    }
    catch (Exception e) {
    }
    return false;
  }

  public boolean load(OneWireContainer owc, String filename)
  {
    try
    {
      OWFileInputStream fis = new OWFileInputStream(owc, filename);

      fromStream(fis);

      if (fis.available() > 0)
      {
        fis.read(this.address, 0, 8);
        for (int i = 0; (i < 8) && (fis.available() > 0); i++)
        {
          fis.read(this.secretPage[i]);
        }
      }
      fis.close();
      return true;
    }
    catch (Exception e) {
    }
    return false;
  }

  public boolean load(OneWireContainer18 owc, String filename)
  {
    try
    {
      OWFileInputStream fis = new OWFileInputStream(owc, filename);

      fromStream(fis);

      System.arraycopy(owc.getAddress(), 0, this.address, 0, 8);

      fis.close();
      return true;
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }return false;
  }

  public boolean createDataSignature(byte[] accountData, byte[] signScratchpad, byte[] mac_buffer, int macStart)
    throws OneWireException, OneWireIOException
  {
    this.lastError = 0;

    if (SHAFunction(-61, this.secretPage[(this.signPageNumber & 0x7)], accountData, signScratchpad, null, this.signPageNumber, -1))
    {
      System.arraycopy(signScratchpad, 8, mac_buffer, macStart, 20);
      return true;
    }

    this.lastError = -6;
    return false;
  }

  public synchronized boolean generateChallenge(int offset, byte[] ch, int start)
    throws OneWireIOException, OneWireException
  {
    this.lastError = 0;

    rand.nextBytes(this.generateChallenge_chlg);

    System.arraycopy(this.generateChallenge_chlg, offset, ch, start, 3);

    return true;
  }

  public boolean verifyAuthentication(byte[] fullBindCode, byte[] pageData, byte[] scratchpad, byte[] verify_mac, byte authCmd)
    throws OneWireIOException, OneWireException
  {
    this.lastError = 0;
    int secretNum = this.wspcPageNumber & 0x7;

    bindSecretToiButton(this.authPageNumber, this.bindData, fullBindCode, secretNum);

    if (SHAFunction(authCmd, this.secretPage[secretNum], pageData, scratchpad, null, this.wspcPageNumber, -1))
    {
      for (int i = 0; i < 20; i++)
      {
        if (scratchpad[(i + 8)] == verify_mac[i])
          continue;
        this.lastError = -3;
        return false;
      }

      return true;
    }
    this.lastError = -6;
    return false;
  }

  public boolean createDataSignatureAuth(byte[] accountData, byte[] signScratchpad, byte[] mac_buffer, int macStart, byte[] fullBindCode)
    throws OneWireException, OneWireIOException
  {
    this.lastError = 0;

    if (SHAFunction(-61, this.secretPage[(this.wspcPageNumber & 0x7)], accountData, signScratchpad, null, this.signPageNumber, -1))
    {
      System.arraycopy(signScratchpad, 8, mac_buffer, macStart, 20);
      return true;
    }

    this.lastError = -6;
    return false;
  }

  public boolean verifySignature(byte[] pageData, byte[] scratchpad, byte[] verify_mac)
    throws OneWireIOException, OneWireException
  {
    this.lastError = 0;

    if (SHAFunction(60, this.secretPage[(this.signPageNumber & 0x7)], pageData, scratchpad, this.address, this.signPageNumber, -1))
    {
      for (int i = 0; i < 20; i++)
      {
        if (scratchpad[(i + 8)] == verify_mac[i])
          continue;
        this.lastError = -3;
        return false;
      }

      return true;
    }
    this.lastError = -6;
    return false;
  }

  public synchronized boolean bindSecretToiButton(int pageNum, byte[] bindData, byte[] bindCode, int secretNum)
  {
    byte[] scratchpad = this.bindSecretToiButton_scratchpad;

    if (bindCode.length == 7)
    {
      System.arraycopy(bindCode, 0, scratchpad, 8, 4);
      scratchpad[12] = (byte)pageNum;
      System.arraycopy(this.address, 0, scratchpad, 13, 7);
      System.arraycopy(bindCode, 4, scratchpad, 20, 3);
    }
    else
    {
      System.arraycopy(bindCode, 0, scratchpad, 8, bindCode.length > 15 ? 15 : bindCode.length);
    }

    if (!SHAFunction(-16, this.secretPage[(pageNum & 0x7)], bindData, scratchpad, null, pageNum, 0))
    {
      return false;
    }

    System.arraycopy(scratchpad, 0, this.secretPage[(secretNum & 0x7)], 0, 8);

    return true;
  }

  public boolean installMasterSecret(int pageNum, byte[] secret, int secretNum)
  {
    if (secret.length == 0) {
      return false;
    }
    byte[] input_secret = null;
    int secret_mod_length = secret.length % 47;

    if (secret_mod_length == 0) {
      input_secret = secret;
    }
    else
    {
      input_secret = new byte[secret.length + (47 - secret_mod_length)];

      System.arraycopy(secret, 0, input_secret, 0, secret.length);
    }

    secretNum &= 7;
    int offset = 0;
    byte cmd = 15;
    byte[] scratchpad = new byte[32];
    byte[] dataPage = new byte[32];
    while (offset < input_secret.length)
    {
      for (int i = 0; i < 32; i++) {
        scratchpad[i] = -1;
      }
      System.arraycopy(input_secret, offset, dataPage, 0, 32);
      System.arraycopy(input_secret, offset + 32, scratchpad, 8, 15);
      if (!SHAFunction(cmd, this.secretPage[(pageNum & 0x7)], dataPage, scratchpad, null, this.signPageNumber, 0))
      {
        return false;
      }

      System.arraycopy(scratchpad, 0, this.secretPage[secretNum], 0, 8);

      offset += 47;
      cmd = -16;
    }

    return true;
  }

  private synchronized boolean SHAFunction(byte function, byte[] shaSecret, byte[] shaPage, byte[] scratchpad, byte[] romID, int pageNum, int writeCycleCounter)
  {
    int offset = 8;

    byte shaMX = 0;

    switch (function)
    {
    case 15:
      shaSecret = NullSecret;
    case -16:
      offset = 0;
    case -61:
    case 60:
      scratchpad[12] = (byte)(scratchpad[12] & 0x3F | shaMX & 0xC0);
      break;
    case -86:
      shaMX = (byte)(shaMX | 0x40);

      scratchpad[12] = (byte)(scratchpad[12] & 0x3F | shaMX & 0xC0);
      break;
    case -52:
      shaMX = (byte)(shaMX | 0x40);
    case -91:
      scratchpad[8] = (byte)(writeCycleCounter & 0xFF);
      scratchpad[9] = (byte)(writeCycleCounter >>> 8 & 0xFF);
      scratchpad[10] = (byte)(writeCycleCounter >>> 16 & 0xFF);
      scratchpad[11] = (byte)(writeCycleCounter >>> 24 & 0xFF);

      scratchpad[12] = (byte)(pageNum & 0xF | shaMX & 0xC0);

      System.arraycopy(romID, 0, scratchpad, 13, 7);
      break;
    default:
      return false;
    }

    System.arraycopy(shaSecret, 0, digestBuff, 0, 4);
    System.arraycopy(shaPage, 0, digestBuff, 4, 32);
    System.arraycopy(scratchpad, 8, digestBuff, 36, 12);
    System.arraycopy(shaSecret, 4, digestBuff, 48, 4);
    System.arraycopy(scratchpad, 20, digestBuff, 52, 3);

    digestBuff[55] = -128;
    for (int i = 56; i < 62; i++)
      digestBuff[i] = 0;
    digestBuff[62] = 1;
    digestBuff[63] = -72;

    SHA.ComputeSHA(digestBuff, scratchpad, offset);

    if (offset == 0)
    {
      System.arraycopy(scratchpad, 0, scratchpad, 8, 8);
      System.arraycopy(scratchpad, 0, scratchpad, 16, 8);
      System.arraycopy(scratchpad, 0, scratchpad, 24, 8);
    }

    return true;
  }

  public String toString()
  {
    return "COPRVM: " + Address.toString(this.address) + ", provider: " + this.providerName + ", version: " + this.version;
  }
}