package com.dalsemi.onewire.application.sha;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.OneWireIOException;
import com.dalsemi.onewire.utils.CRC16;
import com.dalsemi.onewire.utils.Convert;
import com.dalsemi.onewire.utils.IOHelper;

public class SHASoftAuth extends SHATransaction
{
  private static final byte[] ffBlock = { -1, -1, -1, -1, -1, -1, -1, -1 };
  public static final int VERIFICATION_DATA = 2;
  public static final int I_FILE_LENGTH = 0;
  public static final int I_DATA_TYPE_CODE = 1;
  public static final int I_SIGNATURE = 2;
  public static final int I_VERDATA = 22;
  public static final int I_CONTINUATION_PTR = 29;
  public static final int I_FILE_CRC16 = 30;
  private byte[] ver_data = { 0, 0, 0, 0, 0, 0, 0 };

  private byte[] master_ver_data = { 0, 0, 0, 0, 0, 0, 0 };

  private byte[] verifyUser_fullBindCode = new byte[15];
  private byte[] verifyUser_scratchpad = new byte[32];
  private byte[] verifyUser_accountData = new byte[32];
  private byte[] verifyUser_mac = new byte[20];
  private byte[] verifyUser_chlg = new byte[3];

  private byte[] verifyData_fullBindCode = new byte[32];
  private byte[] verifyData_scratchpad = new byte[32];
  private byte[] verifyData_accountData = new byte[32];
  private byte[] verifyData_mac = new byte[20];

  private byte[] executeTransaction_accountData = new byte[32];
  private byte[] executeTransaction_oldAcctData = new byte[32];
  private byte[] executeTransaction_newAcctData = new byte[32];

  private byte[] writeTransactionData_scratchpad = new byte[32];

  protected SHASoftAuth()
  {
  }

  public SHASoftAuth(SHAiButtonCopr copr)
  {
    super(copr);

    resetParameters();
  }

  public SHASoftAuth(SHAiButtonCopr copr, byte[] extra_data, int len)
  {
    super(copr);

    System.arraycopy(extra_data, 0, this.master_ver_data, 0, len);
  }

  public boolean setupTransactionData(SHAiButtonUser user)
    throws OneWireException, OneWireIOException
  {
    this.lastError = 0;

    byte[] accountData = new byte[32];

    return writeTransactionData(user, this.master_ver_data, accountData);
  }

  public synchronized boolean verifyUser(SHAiButtonUser user)
    throws OneWireException, OneWireIOException
  {
    this.lastError = 0;

    byte[] fullBindCode = this.verifyUser_fullBindCode;
    byte[] scratchpad = this.verifyUser_scratchpad;
    byte[] accountData = this.verifyUser_accountData;
    byte[] mac = this.verifyUser_mac;
    byte[] chlg = this.verifyUser_chlg;

    if (!this.copr.generateChallenge(0, chlg, 0))
    {
      this.lastError = -6;
      return false;
    }

    int wcc = user.readAccountData(chlg, 0, accountData, 0, mac, 0);

    if (wcc < 0)
    {
      if (user.hasWriteCycleCounter())
      {
        this.lastError = -7;
        return false;
      }
      System.arraycopy(ffBlock, 0, scratchpad, 8, 4);
    }
    else
    {
      Convert.toByteArray(wcc, scratchpad, 8, 4);
    }

    user.getFullBindCode(fullBindCode, 0);

    System.arraycopy(fullBindCode, 4, scratchpad, 12, 8);

    System.arraycopy(chlg, 0, scratchpad, 20, 3);

    if (!this.copr.verifyAuthentication(fullBindCode, accountData, scratchpad, mac, user.getAuthorizationCommand()))
    {
      this.lastError = -6;
      return false;
    }

    return true;
  }

  public synchronized boolean verifyTransactionData(SHAiButtonUser user)
    throws OneWireException, OneWireIOException
  {
    this.lastError = 0;

    byte[] scratchpad = this.verifyData_scratchpad;
    byte[] accountData = this.verifyData_accountData;
    byte[] verify_mac = this.verifyData_mac;

    int wcc = user.getWriteCycleCounter();

    user.readAccountData(accountData, 0);

    System.arraycopy(accountData, 22, this.ver_data, 0, 7);

    System.arraycopy(accountData, 2, verify_mac, 0, 20);

    this.copr.getInitialSignature(accountData, 2);

    accountData[30] = 0;
    accountData[31] = 0;

    if (wcc < 0)
    {
      if (user.hasWriteCycleCounter())
      {
        this.lastError = -7;
        return false;
      }

      System.arraycopy(ffBlock, 0, scratchpad, 8, 4);
    }
    else
    {
      Convert.toByteArray(wcc, scratchpad, 8, 4);
    }
    scratchpad[12] = (byte)user.getAccountPageNumber();
    user.getAddress(scratchpad, 13, 7);

    this.copr.getSigningChallenge(scratchpad, 20);

    if (!this.copr.verifySignature(accountData, scratchpad, verify_mac))
    {
      this.lastError = -6;
      return false;
    }

    return true;
  }

  public synchronized boolean executeTransaction(SHAiButtonUser user, boolean verifySuccess)
    throws OneWireException, OneWireIOException
  {
    this.lastError = 0;

    byte[] accountData = this.executeTransaction_accountData;

    byte[] oldAcctData = this.executeTransaction_oldAcctData;

    byte[] newAcctData = this.executeTransaction_newAcctData;

    user.readAccountData(accountData, 0);

    System.arraycopy(accountData, 0, oldAcctData, 0, 32);

    System.arraycopy(accountData, 22, this.ver_data, 0, 7);

    boolean success = writeTransactionData(user, this.master_ver_data, accountData);

    if ((verifySuccess) || (!success))
    {
      boolean dataOK = false;
      int cnt = 65536;
      do
      {
        if (!verifyUser(user))
        {
          continue;
        }
        if (!user.readAccountData(newAcctData, 0))
          continue;
        boolean isOld = true;
        boolean isCur = true;
        for (int i = 0; (i < 32) && ((isOld) || (isCur)); i++)
        {
          isOld = (isOld) && (newAcctData[i] == oldAcctData[i]);

          isCur = (isCur) && (newAcctData[i] == accountData[i]);
        }
        if (isOld)
        {
          dataOK = true;
          success = false;
        }
        else if (isCur)
        {
          dataOK = true;
        }
        else
        {
          success = writeTransactionData(user, this.ver_data, accountData);
        }

      }

      while ((!dataOK) && (cnt-- > 0));

      if (!dataOK)
      {
        IOHelper.writeLine("Catastrophic Failure!");
        success = false;
      }
    }

    return success;
  }

  private final boolean writeTransactionData(SHAiButtonUser user, byte[] ver_data, byte[] accountData)
    throws OneWireException, OneWireIOException
  {
    SHAiButtonCopr copr = this.copr;
    int acctPageNum = user.getAccountPageNumber();
    byte[] scratchpad = this.writeTransactionData_scratchpad;

    accountData[0] = 29;

    System.arraycopy(ver_data, 0, accountData, 22, 7);

    copr.getInitialSignature(accountData, 2);

    accountData[1] = 1;

    accountData[29] = 0;

    accountData[30] = 0;
    accountData[31] = 0;

    int wcc = user.getWriteCycleCounter();
    if (wcc > 0)
    {
      Convert.toByteArray(wcc + 1, scratchpad, 8, 4);
    }
    else
    {
      if (user.hasWriteCycleCounter())
      {
        this.lastError = -7;
        return false;
      }
      System.arraycopy(ffBlock, 0, scratchpad, 8, 4);
    }

    scratchpad[12] = (byte)acctPageNum;
    user.getAddress(scratchpad, 13, 7);

    copr.getSigningChallenge(scratchpad, 20);

    copr.createDataSignature(accountData, scratchpad, accountData, 2);

    int crc = CRC16.compute(accountData, 0, accountData[0] + 1, acctPageNum) ^ 0xFFFFFFFF;

    accountData[30] = (byte)crc;
    accountData[31] = (byte)(crc >> 8);
    try
    {
      if (user.writeAccountData(accountData, 0)) {
        return true;
      }

    }
    catch (OneWireException owe)
    {
    }

    this.lastError = -8;
    return false;
  }

  public synchronized int getParameter(int type)
  {
    return 0;
  }

  public synchronized int getParameter(int type, byte[] data, int offset, int len)
  {
    if (type == 2)
    {
      System.arraycopy(this.ver_data, 0, data, offset, len);
      return 0;
    }

    throw new IllegalArgumentException("Invalid Parameter type");
  }

  public synchronized boolean setParameter(int type, byte[] data, int offset, int len)
  {
    if (type == 2)
      System.arraycopy(data, offset, this.master_ver_data, 0, len);
    else {
      return false;
    }
    return true;
  }

  public synchronized boolean setParameter(int type, int param)
  {
    return false;
  }

  public synchronized void resetParameters()
  {
    for (int i = 0; i < 7; i++)
    {
      this.ver_data[i] = 0;
      this.master_ver_data[i] = 0;
    }
  }
}