package com.dalsemi.onewire.application.sha;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import com.dalsemi.onewire.container.OneWireContainer;
import com.dalsemi.onewire.container.OneWireContainer33;

public class SHAiButtonUser33 extends SHAiButtonUser
{
  private static final byte[] ffBlock = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };

  protected OneWireContainer33 ibc33 = null;

  protected SHAiButtonCopr copr = null;

  private byte[] writeAccountData_copyAuth = new byte[32];
  private byte[] writeAccountData_scratchpad = new byte[32];
  private byte[] writeAccountData_pageData = new byte[32];

  protected SHAiButtonUser33()
  {
  }

  public SHAiButtonUser33(SHAiButtonCopr copr, OneWireContainer33 owc, boolean formatDevice, byte[] authSecret)
    throws OneWireException, OneWireIOException
  {
    this(copr, copr);

    this.ibc33 = owc;

    this.address = owc.getAddress();

    byte[] NullSecret = new byte[8];
    for (int i = 0; i < 8; i++) {
      NullSecret[i] = 0;
    }
    if (!this.ibc33.loadFirstSecret(NullSecret, 0)) {
      throw new OneWireException("Failed to null out device secret.");
    }
    if (!owc.installMasterSecret(0, authSecret)) {
      throw new OneWireException("Install Master Secret failed");
    }
    if (!createServiceFile(owc, this.strServiceFilename, formatDevice)) {
      throw new OneWireException("Failed to create service file.");
    }

    this.fullBindCode[4] = (byte)this.accountPageNumber;
    System.arraycopy(this.address, 0, this.fullBindCode, 5, 7);

    if (!owc.bindSecretToiButton(this.accountPageNumber, copr.getBindData()))
      throw new OneWireException("Bind Secret to iButton failed");
  }

  public SHAiButtonUser33(byte[] coprBindCode, byte[] fileName, int fileNameExt, OneWireContainer33 owc, boolean formatDevice, byte[] authSecret)
    throws OneWireException, OneWireIOException
  {
    this.strServiceFilename = (new String(fileName) + "." + fileNameExt);

    this.ibc33 = owc;

    this.address = owc.getAddress();

    byte[] NullSecret = new byte[8];
    for (int i = 0; i < 8; i++) {
      NullSecret[i] = 0;
    }
    if (!this.ibc33.loadFirstSecret(NullSecret, 0)) {
      throw new OneWireException("Failed to null out device secret.");
    }
    if (!owc.installMasterSecret(0, authSecret)) {
      throw new OneWireException("Install Master Secret failed");
    }
    if (!createServiceFile(owc, this.strServiceFilename, formatDevice)) {
      throw new OneWireException("Failed to create service file.");
    }

    this.fullBindCode[4] = (byte)this.accountPageNumber;
    System.arraycopy(this.address, 0, this.fullBindCode, 5, 7);

    if (!owc.bindSecretToiButton(this.accountPageNumber, this.copr.getBindData()))
      throw new OneWireException("Bind Secret to iButton failed");
  }

  public SHAiButtonUser33(SHAiButtonCopr copr, SHAiButtonCopr authCopr, OneWireContainer33 owc)
    throws OneWireException, OneWireIOException
  {
    this(copr, authCopr);

    if (!setiButton33(owc))
      throw new OneWireException("Invalid SHA user");
  }

  public SHAiButtonUser33(byte[] coprBindCode, byte[] fileName, int fileNameExt, OneWireContainer33 owc)
    throws OneWireException, OneWireIOException
  {
    System.arraycopy(ffBlock, 0, this.fullBindCode, 0, 15);

    this.copr.getFilename(this.serviceFile, 0);
    this.strServiceFilename = (new String(fileName) + "." + fileNameExt);

    if (!setiButton33(owc))
      throw new OneWireException("Invalid SHA user");
  }

  public SHAiButtonUser33(SHAiButtonCopr copr, SHAiButtonCopr authCopr)
  {
    this.copr = authCopr;

    System.arraycopy(ffBlock, 0, this.fullBindCode, 0, 15);

    copr.getFilename(this.serviceFile, 0);
    this.strServiceFilename = (new String(this.serviceFile) + "." + copr.getFilenameExt());
  }

  public synchronized boolean setiButton33(OneWireContainer33 owc)
    throws OneWireException, OneWireIOException
  {
    this.ibc33 = owc;

    this.address = owc.getAddress();

    this.accountPageNumber = -1;

    if (!checkAccountPageInfo(owc)) {
      return false;
    }

    this.fullBindCode[4] = (byte)this.accountPageNumber;
    System.arraycopy(this.address, 0, this.fullBindCode, 5, 7);

    return true;
  }

  public synchronized boolean setiButtonUser(DSPortAdapter adapter, byte[] address)
    throws OneWireException, OneWireIOException
  {
    if (this.ibc33 == null)
      this.ibc33 = new OneWireContainer33();
    this.ibc33.setupContainer(adapter, address);
    return setiButton33(this.ibc33);
  }

  public synchronized boolean setiButtonUser(byte[] address)
    throws OneWireException, OneWireIOException
  {
    if (this.ibc33 == null) {
      return false;
    }
    this.ibc33.setupContainer(this.ibc33.getAdapter(), address);

    return setiButton33(this.ibc33);
  }

  public synchronized int getWriteCycleCounter()
    throws OneWireException, OneWireIOException
  {
    return -1;
  }

  public synchronized boolean hasWriteCycleCounter()
  {
    return false;
  }

  public void getFullBindCode(byte[] l_fullBindCode, int offset)
  {
    System.arraycopy(this.fullBindCode, 0, l_fullBindCode, offset, 15);
  }

  public byte getAuthorizationCommand()
  {
    return -86;
  }

  public synchronized boolean writeAccountData(byte[] dataBuffer, int offset)
    throws OneWireException, OneWireIOException
  {
    OneWireContainer33 ibcL = this.ibc33;
    byte[] copyAuth = this.writeAccountData_copyAuth;
    byte[] scratchpad = this.writeAccountData_scratchpad;
    byte[] pageData = this.writeAccountData_pageData;
    byte[] fullBindCode = this.fullBindCode;
    SHAiButtonCopr coprL = this.copr;

    if (!checkAccountPageInfo(ibcL)) {
      return false;
    }

    if (ibcL.isContainerSecretSet())
    {
      ibcL.writeDataPage(this.accountPageNumber, dataBuffer);

      System.arraycopy(dataBuffer, offset, this.accountData, 0, 32);
    }
    else
    {
      if (coprL == null)
      {
        throw new OneWireException("No Write Authorization Coprocessor Available!");
      }

      System.arraycopy(this.accountData, 0, pageData, 0, 32);

      for (int i = 24; i >= 0; i -= 8)
      {
        int index = offset + i;

        if ((dataBuffer[index] == this.accountData[i]) && (dataBuffer[(index + 1)] == this.accountData[(i + 1)]) && (dataBuffer[(index + 2)] == this.accountData[(i + 2)]) && (dataBuffer[(index + 3)] == this.accountData[(i + 3)]) && (dataBuffer[(index + 4)] == this.accountData[(i + 4)]) && (dataBuffer[(index + 5)] == this.accountData[(i + 5)]) && (dataBuffer[(index + 6)] == this.accountData[(i + 6)]) && (dataBuffer[(index + 7)] == this.accountData[(i + 7)]))
        {
          continue;
        }

        pageData[28] = dataBuffer[index];
        pageData[29] = dataBuffer[(index + 1)];
        pageData[30] = dataBuffer[(index + 2)];
        pageData[31] = dataBuffer[(index + 3)];

        scratchpad[8] = dataBuffer[(index + 4)];
        scratchpad[9] = dataBuffer[(index + 5)];
        scratchpad[10] = dataBuffer[(index + 6)];
        scratchpad[11] = dataBuffer[(index + 7)];

        System.arraycopy(this.fullBindCode, 4, scratchpad, 12, 11);

        coprL.createDataSignatureAuth(pageData, scratchpad, copyAuth, 0, fullBindCode);

        fullBindCode = null;

        if (!ibcL.writeScratchpad(this.accountPageNumber, i, dataBuffer, index, 8))
        {
          return false;
        }

        if (!ibcL.copyScratchpad(this.accountPageNumber, i, copyAuth, 0))
        {
          return false;
        }

        System.arraycopy(dataBuffer, index, this.accountData, i, 8);

        System.arraycopy(this.accountData, 0, pageData, 0, 32);
      }

    }

    return true;
  }

  public synchronized boolean readAccountData(byte[] dataBuffer, int offset)
    throws OneWireException, OneWireIOException
  {
    OneWireContainer33 ibcL = this.ibc33;

    if (!checkAccountPageInfo(ibcL))
    {
      return false;
    }

    if (this.accountData[0] == 0)
    {
      ibcL.readMemoryPage(this.accountPageNumber, this.accountData, 0);
    }

    System.arraycopy(this.accountData, 0, dataBuffer, offset, 32);

    return true;
  }

  public synchronized int readAccountData(byte[] chlg, int chlgStart, byte[] dataBuffer, int dataStart, byte[] mac, int macStart)
    throws OneWireException, OneWireIOException
  {
    OneWireContainer33 ibcL = this.ibc33;

    if (this.accountPageNumber < 0)
    {
      throw new OneWireException("SHAiButtonUser Not Properly Initialized");
    }

    ibcL.setChallenge(chlg, chlgStart);

    if (ibcL.readAuthenticatedPage(this.accountPageNumber, dataBuffer, dataStart, mac, macStart))
    {
      System.arraycopy(dataBuffer, dataStart, this.accountData, 0, 32);

      return -1;
    }

    throw new OneWireException("SHAiButtonUser ReadAuthenticatedPage Failed");
  }

  public boolean refreshDevice()
    throws OneWireException, OneWireIOException
  {
    return this.ibc33.refreshPage(this.accountPageNumber);
  }
}