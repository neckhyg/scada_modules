package com.dalsemi.onewire.application.sha;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.OneWireIOException;
import com.dalsemi.onewire.utils.CRC16;
import com.dalsemi.onewire.utils.Convert;
import com.dalsemi.onewire.utils.IOHelper;
import java.util.Random;

public class SHADebitUnsigned extends SHATransaction
{
  private static final byte[] ffBlock = { -1, -1, -1, -1, -1, -1, -1, -1 };
  public static final int DEBIT_AMOUNT = 0;
  public static final int INITIAL_AMOUNT = 1;
  public static final int USER_BALANCE = 2;
  private static final int I_FILE_LENGTH = 0;
  private static final int I_DATA_TYPE_CODE = 1;
  private static final int I_CONVERSION_FACTOR = 2;
  private static final int I_DONT_CARE = 4;
  private static final int I_BALANCE_A = 8;
  private static final int I_TRANSACTION_ID_A = 11;
  private static final int I_CONTINUATION_PTR_A = 13;
  private static final int I_FILE_CRC16_A = 14;
  private static final int I_BALANCE_B = 16;
  private static final int I_TRANSACTION_ID_B = 19;
  private static final int I_CONTINUATION_PTR_B = 21;
  private static final int I_FILE_CRC16_B = 22;
  private static final int RECORD_A_LENGTH = 13;
  private static final int RECORD_B_LENGTH = 21;
  private int debitAmount;
  private int initialAmount;
  private int userBalance;
  private byte[] verifyUser_fullBindCode = new byte[15];
  private byte[] verifyUser_scratchpad = new byte[32];
  private byte[] verifyUser_accountData = new byte[32];
  private byte[] verifyUser_mac = new byte[20];
  private byte[] verifyUser_chlg = new byte[3];

  private byte[] verifyData_accountData = new byte[32];

  private byte[] executeTransaction_accountData = new byte[32];
  private byte[] executeTransaction_oldAcctData = new byte[32];
  private byte[] executeTransaction_newAcctData = new byte[32];

  private byte[] writeTransactionData_scratchpad = new byte[32];

  protected SHADebitUnsigned()
  {
  }

  public SHADebitUnsigned(SHAiButtonCopr copr)
  {
    super(copr);

    resetParameters();
  }

  public SHADebitUnsigned(SHAiButtonCopr copr, int initialAmount, int debitAmount)
  {
    super(copr);

    this.initialAmount = initialAmount;
    this.debitAmount = debitAmount;
  }

  public boolean setupTransactionData(SHAiButtonUser user)
    throws OneWireException, OneWireIOException
  {
    this.lastError = 0;

    byte[] accountData = new byte[32];

    return writeTransactionData(user, 0, this.initialAmount, accountData);
  }

  public synchronized boolean verifyUser(SHAiButtonUser user)
    throws OneWireException, OneWireIOException
  {
    this.lastError = 0;

    byte[] fullBindCode = this.verifyUser_fullBindCode;
    byte[] scratchpad = this.verifyUser_scratchpad;
    byte[] accountData = this.verifyUser_accountData;
    byte[] mac = this.verifyUser_mac;
    byte[] chlg = this.verifyUser_chlg;

    if (!this.copr.generateChallenge(0, chlg, 0))
    {
      this.lastError = -6;
      return false;
    }

    int wcc = user.readAccountData(chlg, 0, accountData, 0, mac, 0);

    if (wcc < 0)
    {
      if (user.hasWriteCycleCounter())
      {
        this.lastError = -7;
        return false;
      }
      System.arraycopy(ffBlock, 0, scratchpad, 8, 4);
    }
    else
    {
      Convert.toByteArray(wcc, scratchpad, 8, 4);
    }

    user.getFullBindCode(fullBindCode, 0);

    System.arraycopy(fullBindCode, 4, scratchpad, 12, 8);

    System.arraycopy(chlg, 0, scratchpad, 20, 3);

    if (!this.copr.verifyAuthentication(fullBindCode, accountData, scratchpad, mac, user.getAuthorizationCommand()))
    {
      this.lastError = -6;
      return false;
    }

    return true;
  }

  public synchronized boolean verifyTransactionData(SHAiButtonUser user)
    throws OneWireException, OneWireIOException
  {
    this.lastError = 0;

    byte[] accountData = this.verifyData_accountData;

    user.readAccountData(accountData, 0);

    boolean validPtr = false; boolean validA = false; boolean validB = false;

    byte fileLength = accountData[0];
    int crc16 = CRC16.compute(accountData, 0, fileLength + 3, user.getAccountPageNumber());

    if ((fileLength == 13) || (fileLength == 21)) {
      validPtr = true;
    }

    if (crc16 == 45057)
    {
      if (validPtr)
      {
        return true;
      }

      this.lastError = -9;
      return false;
    }

    accountData[1] = 1;
    accountData[2] = -117;
    accountData[3] = 72;

    accountData[4] = 0;
    accountData[5] = 0;
    accountData[6] = 0;
    accountData[7] = 0;

    accountData[0] = 13;
    crc16 = CRC16.compute(accountData, 0, 16, user.getAccountPageNumber());

    if (crc16 == 45057) {
      validA = true;
    }

    accountData[0] = 21;
    crc16 = CRC16.compute(accountData, 0, 24, user.getAccountPageNumber());

    if (crc16 == 45057) {
      validB = true;
    }
    if ((validA) && (validB))
    {
      accountData[0] = 13;
    }
    else if (validA)
    {
      accountData[0] = 21;
    } else {
      if (validB)
      {
        this.lastError = -9;
        return false;
      }

      this.lastError = -9;
      return false;
    }

    int balance = -1;
    if (accountData[0] == 13)
      balance = Convert.toInt(accountData, 8, 3);
    else if (accountData[0] == 21) {
      balance = Convert.toInt(accountData, 16, 3);
    }
    if (balance < 0)
    {
      this.lastError = -9;
      return false;
    }

    this.userBalance = balance;

    int cnt = 65536;
    do
    {
      if ((user.refreshDevice()) && (writeTransactionData(user, -1, balance, accountData)))
      {
        break;
      }
      cnt--; } while (cnt > 0);

    return false;
  }

  public synchronized boolean executeTransaction(SHAiButtonUser user, boolean verifySuccess)
    throws OneWireException, OneWireIOException
  {
    this.lastError = 0;

    byte[] accountData = this.executeTransaction_accountData;

    byte[] oldAcctData = this.executeTransaction_oldAcctData;

    byte[] newAcctData = this.executeTransaction_newAcctData;

    int transID = SHATransaction.rand.nextInt();

    user.readAccountData(accountData, 0);

    System.arraycopy(accountData, 0, oldAcctData, 0, 32);

    int balance = -1;
    if (accountData[0] == 13)
      balance = Convert.toInt(accountData, 8, 3);
    else if (accountData[0] == 21) {
      balance = Convert.toInt(accountData, 16, 3);
    }

    if (this.debitAmount > balance)
    {
      this.lastError = -9;
      return false;
    }

    this.userBalance = (balance - this.debitAmount);

    boolean success = false;
    try
    {
      success = writeTransactionData(user, transID, this.userBalance, accountData);
    }
    catch (Exception e)
    {
    }

    if ((verifySuccess) || (!success))
    {
      boolean dataOK = false;
      int cnt = 65536;
      do
      {
        try
        {
          user.refreshDevice();

          if (verifyUser(user))
          {
            if (user.readAccountData(newAcctData, 0))
            {
              boolean isOld = true;
              boolean isCur = true;
              for (int i = 0; (i < 32) && ((isOld) || (isCur)); i++)
              {
                isOld = (isOld) && (newAcctData[i] == oldAcctData[i]);

                isCur = (isCur) && (newAcctData[i] == accountData[i]);
              }
              if (isOld)
              {
                dataOK = true;
                success = false;
              }
              else if (isCur)
              {
                dataOK = true;
                success = true;
              }
              else
              {
                int cnt2 = 65536;
                do
                {
                  try
                  {
                    success = writeTransactionData(user, transID, this.userBalance, accountData);
                  }
                  catch (OneWireIOException owioe)
                  {
                    if (cnt2 == 0)
                      throw owioe;
                  }
                  catch (OneWireException owe)
                  {
                    if (cnt2 == 0) {
                      throw owe;
                    }
                  }
                  if (cnt2-- <= 0) break; 
                }while (!success);
              }
            }
          }
        }
        catch (OneWireIOException owioe)
        {
          if (cnt == 0)
            throw owioe;
        }
        catch (OneWireException owe)
        {
          if (cnt == 0)
            throw owe;
        }
      }
      while ((!dataOK) && (cnt-- > 0));

      if (!dataOK)
      {
        IOHelper.writeLine("Catastrophic Failure!");
        success = false;
      }
    }

    return success;
  }

  private final boolean writeTransactionData(SHAiButtonUser user, int transID, int balance, byte[] accountData)
    throws OneWireException, OneWireIOException
  {
    int acctPageNum = user.getAccountPageNumber();

    accountData[1] = 1;

    accountData[2] = -117;
    accountData[3] = 72;

    accountData[4] = 0;
    accountData[5] = 0;
    accountData[6] = 0;
    accountData[7] = 0;

    if (accountData[0] == 13)
    {
      accountData[0] = 21;

      Convert.toByteArray(balance, accountData, 16, 3);

      accountData[19] = (byte)transID;
      accountData[20] = (byte)(transID >>> 8);

      accountData[21] = 0;

      accountData[22] = 0;
      accountData[23] = 0;

      int crc = CRC16.compute(accountData, 0, accountData[0] + 1, acctPageNum) ^ 0xFFFFFFFF;

      accountData[22] = (byte)crc;
      accountData[23] = (byte)(crc >> 8);
    }
    else
    {
      accountData[0] = 13;

      Convert.toByteArray(balance, accountData, 8, 3);

      accountData[11] = (byte)transID;
      accountData[12] = (byte)(transID >>> 8);

      accountData[13] = 0;

      accountData[14] = 0;
      accountData[15] = 0;

      int crc = CRC16.compute(accountData, 0, accountData[0] + 1, acctPageNum) ^ 0xFFFFFFFF;

      accountData[14] = (byte)crc;
      accountData[15] = (byte)(crc >> 8);
    }

    try
    {
      if (user.writeAccountData(accountData, 0)) {
        return true;
      }

    }
    catch (OneWireException owe)
    {
    }

    this.lastError = -8;
    return false;
  }

  public synchronized int getParameter(int type)
  {
    switch (type)
    {
    case 0:
      return this.debitAmount;
    case 1:
      return this.initialAmount;
    case 2:
      return this.userBalance;
    }
    return -1;
  }

  public synchronized boolean setParameter(int type, int param)
  {
    switch (type)
    {
    case 0:
      this.debitAmount = param;
      break;
    case 1:
      this.initialAmount = param;
      break;
    default:
      return false;
    }
    return true;
  }

  public synchronized void resetParameters()
  {
    this.debitAmount = 50;
    this.initialAmount = 90000;
    this.userBalance = 0;
  }
}