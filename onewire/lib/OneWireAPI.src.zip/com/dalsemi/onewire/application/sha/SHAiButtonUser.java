package com.dalsemi.onewire.application.sha;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import com.dalsemi.onewire.application.file.OWFile;
import com.dalsemi.onewire.container.OneWireContainer;
import com.dalsemi.onewire.utils.Address;
import java.io.IOException;

public abstract class SHAiButtonUser
{
  static final boolean DEBUG = false;
  protected byte[] address = null;

  protected final byte[] accountData = new byte[32];

  protected int accountPageNumber = -1;

  protected final byte[] serviceFile = { 68, 76, 83, 77 };

  protected String strServiceFilename = null;

  protected final byte[] fullBindCode = new byte[15];

  protected int writeCycleCounter = -1;

  protected boolean forceOverdrive = false;

  public int getAccountPageNumber()
  {
    return this.accountPageNumber;
  }

  public String getAccountFilename()
  {
    return this.strServiceFilename;
  }

  public byte[] getAddress()
  {
    byte[] data = new byte[8];
    System.arraycopy(this.address, 0, data, 0, 8);
    return data;
  }

  public void getAddress(byte[] data, int offset)
  {
    System.arraycopy(this.address, 0, data, offset, 8);
  }

  public void getAddress(byte[] data, int offset, int cnt)
  {
    System.arraycopy(this.address, 0, data, offset, cnt);
  }

  public void setForceOverdrive(boolean value)
  {
    this.forceOverdrive = value;
  }

  public boolean getForceOverdrive()
  {
    return this.forceOverdrive;
  }

  protected boolean createServiceFile(OneWireContainer owc, String filename, boolean formatDevice)
  {
    boolean bRetVal = false;
    OWFile owf = new OWFile(owc, this.strServiceFilename);
    try
    {
      if (formatDevice) {
        owf.format();
      }
      if (!owf.exists()) {
        owf.createNewFile();
      }

      this.accountPageNumber = owf.getPageList()[0];

      bRetVal = true;
    }
    catch (IOException ioe)
    {
      bRetVal = false;
    }

    try
    {
      owf.close();
      return bRetVal;
    }
    catch (IOException ioe)
    {
    }

    return false;
  }

  protected synchronized boolean checkAccountPageInfo(OneWireContainer ibc)
  {
    if (this.accountPageNumber <= 0)
    {
      try
      {
        OWFile owf = new OWFile(ibc, this.strServiceFilename);

        if (!owf.exists()) {
          return false;
        }

        this.accountPageNumber = owf.getStartPage();

        owf.close();

        this.accountData[0] = 0;

        this.writeCycleCounter = -1;
      }
      catch (Exception e)
      {
        this.accountPageNumber = -1;
      }

    }

    return this.accountPageNumber > 0;
  }

  public abstract boolean setiButtonUser(DSPortAdapter paramDSPortAdapter, byte[] paramArrayOfByte)
    throws OneWireException, OneWireIOException;

  public abstract boolean setiButtonUser(byte[] paramArrayOfByte)
    throws OneWireException, OneWireIOException;

  public abstract int getWriteCycleCounter()
    throws OneWireException, OneWireIOException;

  public abstract boolean hasWriteCycleCounter();

  public abstract void getFullBindCode(byte[] paramArrayOfByte, int paramInt);

  public abstract byte getAuthorizationCommand();

  public abstract boolean writeAccountData(byte[] paramArrayOfByte, int paramInt)
    throws OneWireException, OneWireIOException;

  public abstract boolean readAccountData(byte[] paramArrayOfByte, int paramInt)
    throws OneWireException, OneWireIOException;

  public abstract int readAccountData(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2, byte[] paramArrayOfByte3, int paramInt3)
    throws OneWireException, OneWireIOException;

  public boolean refreshDevice()
    throws OneWireException, OneWireIOException
  {
    return true;
  }

  public String toString()
  {
    StringBuffer sb = new StringBuffer(100);
    sb.append("USER: ");
    sb.append(Address.toString(this.address));
    sb.append(", service: ");
    sb.append(this.strServiceFilename);
    sb.append(", acctPageNum: ");
    sb.append(this.accountPageNumber);
    return sb.toString();
  }
}