package com.dalsemi.onewire.application.sha;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.OneWireIOException;
import com.dalsemi.onewire.application.file.OWFile;
import com.dalsemi.onewire.application.file.OWFileInputStream;
import com.dalsemi.onewire.application.file.OWFileNotFoundException;
import com.dalsemi.onewire.application.file.OWFileOutputStream;
import com.dalsemi.onewire.container.OneWireContainer;
import com.dalsemi.onewire.container.OneWireContainer18;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Calendar;

public class SHAiButtonCopr
{
  static final boolean DEBUG = false;
  public static final int NO_ERROR = 0;
  public static final int WRITE_DATA_PAGE_FAILED = -1;
  public static final int WRITE_SCRATCHPAD_FAILED = -2;
  public static final int MATCH_SCRATCHPAD_FAILED = -3;
  public static final int ERASE_SCRATCHPAD_FAILED = -4;
  public static final int COPY_SCRATCHPAD_FAILED = -5;
  public static final int SHA_FUNCTION_FAILED = -6;
  public static final int BIND_SECRET_FAILED = -7;
  protected int lastError;
  protected OneWireContainer18 ibc = null;

  protected byte[] address = null;

  protected int authPageNumber = -1;
  protected String auxData;
  protected byte[] bindCode = new byte[7];

  protected byte[] bindData = new byte[32];

  protected boolean DS1961Scompatible = false;

  protected int encCode = -1;

  protected byte[] filename = new byte[5];

  protected byte[] initialSignature = new byte[20];
  protected String providerName;
  protected byte[] signingChallenge = new byte[3];

  protected int signPageNumber = 8;

  protected int version = -1;

  protected int wspcPageNumber = -1;

  private byte[] generateChallenge_scratchpad = new byte[32];

  protected SHAiButtonCopr()
  {
  }

  public SHAiButtonCopr(OneWireContainer18 l_owc, String coprFilename, boolean l_formatDevice, int l_signPageNumber, int l_authPageNumber, int l_wspcPageNumber, int l_version, int l_encCode, byte l_serviceFileExt, byte[] l_serviceFilename, byte[] l_providerName, byte[] l_bindData, byte[] l_bindCode, byte[] l_auxData, byte[] l_initialSignature, byte[] l_signingChlg, byte[] l_signingSecret, byte[] l_authSecret)
    throws OneWireException, OneWireIOException
  {
    this.lastError = 0;

    if (l_bindData.length != 32)
      throw new OneWireException("Invalid Binding Data");
    if (l_bindCode.length != 7)
      throw new OneWireException("Invalid Binding Code");
    if (l_signingChlg.length != 3)
      throw new OneWireException("Invalid Signing Challenge");
    if (l_serviceFilename.length < 4)
      throw new OneWireException("Invalid Service Filename");
    if ((l_signPageNumber != 0) && (l_signPageNumber != 8)) {
      throw new OneWireException("Invalid Signing Page Number (must be 0 or 8)");
    }

    this.DS1961Scompatible = (l_authSecret.length % 47 == 0);
    int secretDiv = l_authSecret.length / 47;
    for (int j = 0; (j < secretDiv) && (this.DS1961Scompatible); j++)
    {
      int offset = 47 * j;
      for (int i = 32; (i < 36) && (this.DS1961Scompatible); i++) {
        this.DS1961Scompatible = (l_authSecret[(i + offset)] == -1);
      }
      for (int i = 44; (i < 47) && (this.DS1961Scompatible); i++) {
        this.DS1961Scompatible = (l_authSecret[(i + offset)] == -1);
      }

    }

    Calendar c = Calendar.getInstance();
    int month = c.get(2) + 1;
    int date = c.get(5);
    int year = c.get(1) - 1900;
    byte yearMSB = (byte)(year >> 8 & 0xFF);
    byte yearLSB = (byte)(year & 0xFF);
    try
    {
      if (l_formatDevice)
      {
        OWFile f = new OWFile(l_owc, coprFilename);
        f.format();
        f.close();
      }

      OWFileOutputStream fos = new OWFileOutputStream(l_owc, coprFilename);

      fos.write(l_serviceFilename, 0, 4);
      fos.write(l_serviceFileExt);
      fos.write(l_signPageNumber);
      fos.write(l_authPageNumber);
      fos.write(l_wspcPageNumber);
      fos.write(l_version);
      fos.write(month);
      fos.write(date);
      fos.write(yearMSB);
      fos.write(yearLSB);
      fos.write(l_bindData);
      fos.write(l_bindCode);
      fos.write(l_signingChlg);
      fos.write((byte)l_providerName.length);
      fos.write((byte)l_initialSignature.length);
      fos.write((byte)l_auxData.length);
      fos.write(l_providerName, 0, (byte)l_providerName.length);
      fos.write(l_initialSignature, 0, (byte)l_initialSignature.length);
      fos.write(l_auxData, 0, (byte)l_auxData.length);
      fos.write(l_encCode);
      fos.write(this.DS1961Scompatible ? 85 : 0);
      fos.flush();
      fos.close();
    }
    catch (Exception ioe)
    {
      ioe.printStackTrace();
      throw new OneWireException("Creating Service File failed!");
    }

    if (!l_owc.installMasterSecret(l_signPageNumber, l_signingSecret, l_signPageNumber & 0x7)) {
      throw new OneWireException("Could not install signing secret");
    }

    if (!l_owc.installMasterSecret(l_authPageNumber, l_authSecret, l_authPageNumber & 0x7)) {
      throw new OneWireException("Could not install authentication secret");
    }

    setiButton(l_owc, coprFilename);
  }

  public SHAiButtonCopr(OneWireContainer18 owc, String coprFilename)
    throws OneWireException, OneWireIOException
  {
    setiButton(owc, coprFilename);
  }

  private void setiButton(OneWireContainer18 owc, String coprFilename)
    throws OneWireException, OneWireIOException
  {
    this.ibc = owc;

    this.address = owc.getAddress();

    OWFileInputStream fis = null;
    try
    {
      fis = new OWFileInputStream(owc, coprFilename);
    }
    catch (OWFileNotFoundException e)
    {
      throw new OneWireIOException("Coprocessor service file Not found: " + e);
    }

    try
    {
      fromStream(fis);
    }
    catch (IOException ioe)
    {
      throw new OneWireException("Bad Data in Coproccessor Service File: " + ioe);
    }
    finally
    {
      try
      {
        fis.close();
      }
      catch (IOException ioe)
      {
      }
    }
  }

  public byte[] getAddress()
  {
    byte[] data = new byte[8];
    System.arraycopy(this.address, 0, data, 0, 8);
    return data;
  }

  public void getAddress(byte[] data, int offset)
  {
    System.arraycopy(this.address, 0, data, offset, 8);
  }

  public void getAddress(byte[] data, int offset, int cnt)
  {
    System.arraycopy(this.address, 0, data, offset, cnt);
  }

  public int getAuthenticationPageNumber()
  {
    return this.authPageNumber;
  }

  public String getAuxilliaryData()
  {
    return this.auxData;
  }

  public byte[] getBindCode()
  {
    byte[] data = new byte[7];
    System.arraycopy(this.bindCode, 0, data, 0, 7);
    return data;
  }

  public void getBindCode(byte[] data, int offset)
  {
    System.arraycopy(this.bindCode, 0, data, offset, 7);
  }

  public byte[] getBindData()
  {
    byte[] data = new byte[32];
    System.arraycopy(this.bindData, 0, data, 0, 32);
    return data;
  }

  public void getBindData(byte[] data, int offset)
  {
    System.arraycopy(this.bindData, 0, data, offset, 32);
  }

  public int getEncryptionCode()
  {
    return this.encCode;
  }

  public void getFilename(byte[] l_filename, int offset)
  {
    int cnt = Math.min(l_filename.length - offset, 4);
    System.arraycopy(this.filename, offset, l_filename, offset, cnt);
  }

  public byte getFilenameExt()
  {
    return this.filename[4];
  }

  public byte[] getInitialSignature()
  {
    byte[] data = new byte[20];
    System.arraycopy(this.initialSignature, 0, data, 0, 20);
    return data;
  }

  public void getInitialSignature(byte[] data, int offset)
  {
    System.arraycopy(this.initialSignature, 0, data, offset, 20);
  }

  public int getLastError()
  {
    return this.lastError;
  }

  public String getProviderName()
  {
    return this.providerName;
  }

  public byte[] getSigningChallenge()
  {
    byte[] data = new byte[3];
    System.arraycopy(this.signingChallenge, 0, data, 0, 3);
    return data;
  }

  public void getSigningChallenge(byte[] data, int offset)
  {
    System.arraycopy(this.signingChallenge, 0, data, offset, 3);
  }

  public int getSigningPageNumber()
  {
    return this.signPageNumber;
  }

  public int getVersion()
  {
    return this.version;
  }

  public int getWorkspacePageNumber()
  {
    return this.wspcPageNumber;
  }

  public boolean isDS1961Scompatible()
  {
    return this.DS1961Scompatible;
  }

  public boolean createDataSignature(byte[] accountData, byte[] signScratchpad, byte[] mac_buffer, int macStart)
    throws OneWireException, OneWireIOException
  {
    this.lastError = 0;

    OneWireContainer18 ibcL = this.ibc;
    int addr = this.signPageNumber << 5;

    if (!ibcL.writeDataPage(this.signPageNumber, accountData))
    {
      this.lastError = -1;
      return false;
    }

    ibcL.useResume(true);

    if (!ibcL.writeScratchPad(0, 0, signScratchpad, 0, 32))
    {
      this.lastError = -2;
      ibcL.useResume(false);
      return false;
    }

    if (ibcL.SHAFunction(-61, addr))
    {
      ibcL.readScratchPad(signScratchpad, 0);

      System.arraycopy(signScratchpad, 8, mac_buffer, macStart, 20);

      ibcL.useResume(false);
      return true;
    }

    this.lastError = -6;

    ibcL.useResume(false);
    return false;
  }

  public boolean createDataSignatureAuth(byte[] accountData, byte[] signScratchpad, byte[] mac_buffer, int macStart, byte[] fullBindCode)
    throws OneWireException, OneWireIOException
  {
    this.lastError = 0;

    OneWireContainer18 ibcL = this.ibc;
    int page = this.signPageNumber;
    int addr = page << 5;

    if (fullBindCode != null)
    {
      if (!ibcL.bindSecretToiButton(this.authPageNumber, this.bindData, fullBindCode, page & 0x7))
      {
        this.lastError = -7;
        return false;
      }

    }

    if (!ibcL.writeDataPage(this.signPageNumber, accountData))
    {
      this.lastError = -1;
      return false;
    }

    ibcL.useResume(true);

    if (!ibcL.writeScratchPad(0, 0, signScratchpad, 0, 32))
    {
      this.lastError = -2;
      ibcL.useResume(false);
      return false;
    }

    if (ibcL.SHAFunction(-61, addr))
    {
      ibcL.readScratchPad(signScratchpad, 0);

      System.arraycopy(signScratchpad, 8, mac_buffer, macStart, 20);

      ibcL.useResume(false);
      return true;
    }

    this.lastError = -6;

    ibcL.useResume(false);
    return false;
  }

  public synchronized boolean generateChallenge(int offset, byte[] ch, int start)
    throws OneWireIOException, OneWireException
  {
    this.lastError = 0;

    OneWireContainer18 ibcL = this.ibc;
    byte[] scratchpad = this.generateChallenge_scratchpad;
    int addr = this.authPageNumber << 5;

    if (ibcL.eraseScratchPad(this.authPageNumber))
    {
      if (ibcL.SHAFunction(-52, addr))
      {
        ibcL.readScratchPad(scratchpad, 0);

        System.arraycopy(scratchpad, 8 + offset % 17, ch, start, 3);

        ibcL.useResume(false);
        return true;
      }

      this.lastError = -6;
    }
    else {
      this.lastError = -4;
    }
    ibcL.useResume(false);
    return false;
  }

  public boolean verifyAuthentication(byte[] fullBindCode, byte[] pageData, byte[] scratchpad, byte[] verify_mac, byte authCmd)
    throws OneWireIOException, OneWireException
  {
    this.lastError = 0;

    OneWireContainer18 ibcL = this.ibc;
    int addr = this.wspcPageNumber << 5;
    int wspc = this.wspcPageNumber;

    if (!ibcL.bindSecretToiButton(this.authPageNumber, this.bindData, fullBindCode, wspc))
    {
      this.lastError = -7;
      return false;
    }

    ibcL.useResume(true);

    if (!ibcL.writeDataPage(wspc, pageData))
    {
      this.lastError = -1;
      ibcL.useResume(false);
      return false;
    }

    if (!ibcL.writeScratchPad(wspc, 0, scratchpad, 0, 32))
    {
      this.lastError = -2;
      ibcL.useResume(false);
      return false;
    }

    if (ibcL.SHAFunction(authCmd, addr))
    {
      if (ibcL.matchScratchPad(verify_mac))
      {
        ibcL.useResume(false);
        return true;
      }

      this.lastError = -3;
    }
    else {
      this.lastError = -6;
    }
    ibcL.useResume(false);

    return false;
  }

  public boolean verifySignature(byte[] pageData, byte[] scratchpad, byte[] verify_mac)
    throws OneWireIOException, OneWireException
  {
    this.lastError = 0;

    OneWireContainer18 ibcL = this.ibc;
    int addr = this.signPageNumber << 5;

    if (!ibcL.writeDataPage(this.signPageNumber, pageData))
    {
      this.lastError = -1;
      ibcL.useResume(false);
      return false;
    }

    ibcL.useResume(true);
    if (!ibcL.writeScratchPad(0, 0, scratchpad, 0, 32))
    {
      this.lastError = -2;
      ibcL.useResume(false);
      return false;
    }

    if (ibcL.SHAFunction(60, addr))
    {
      if (ibcL.matchScratchPad(verify_mac))
      {
        ibcL.useResume(false);
        return true;
      }

      this.lastError = -3;
    }
    else {
      this.lastError = -6;
    }
    ibcL.useResume(false);
    return false;
  }

  public String toString()
  {
    return "COPR: " + this.ibc.getAddressAsString() + ", provider: " + this.providerName + ", version: " + this.version;
  }

  protected void fromStream(InputStream is)
    throws IOException
  {
    is.read(this.filename, 0, 5);

    this.signPageNumber = is.read();
    this.authPageNumber = is.read();
    this.wspcPageNumber = is.read();

    this.version = is.read();

    is.skip(4L);

    is.read(this.bindData, 0, 32);
    is.read(this.bindCode, 0, 7);
    is.read(this.signingChallenge, 0, 3);

    int namelen = is.read();
    int siglen = is.read();
    int auxlen = is.read();

    byte[] l_providerName = new byte[namelen];
    is.read(l_providerName);
    this.providerName = new String(l_providerName);

    int cnt = Math.min(this.initialSignature.length, siglen);
    is.read(this.initialSignature, 0, cnt);

    byte[] l_auxData = new byte[auxlen];
    is.read(l_auxData);
    this.auxData = new String(l_auxData);

    this.encCode = is.read();
    this.DS1961Scompatible = (is.read() != 0);
  }

  protected void toStream(OutputStream os)
    throws IOException
  {
    os.write(this.filename, 0, 5);
    os.write(this.signPageNumber);
    os.write(this.authPageNumber);
    os.write(this.wspcPageNumber);
    os.write(this.version);

    os.write(1); os.write(1);
    os.write(0); os.write(100);

    os.write(this.bindData);
    os.write(this.bindCode);
    os.write(this.signingChallenge);

    byte[] l_providerName = this.providerName.getBytes();
    byte[] l_auxData = this.auxData.getBytes();
    os.write((byte)l_providerName.length);
    os.write((byte)this.initialSignature.length);
    os.write((byte)l_auxData.length);
    os.write(l_providerName, 0, (byte)l_providerName.length);
    os.write(this.initialSignature, 0, (byte)this.initialSignature.length);
    os.write(l_auxData, 0, (byte)l_auxData.length);
    os.write(this.encCode);
    os.write(this.DS1961Scompatible ? 85 : 0);

    os.flush();
  }

  public static byte[] reformatFor1961S(byte[] auth_secret)
  {
    int numPartials = auth_secret.length / 47 + 1;
    byte[] new_secret = new byte[47 * numPartials];

    for (int i = 0; i < numPartials; i++)
    {
      int cnt = Math.min(auth_secret.length - i * 47, 47);
      System.arraycopy(auth_secret, i * 47, new_secret, i * 47, cnt);
      new_secret[(i * 47 + 32)] = -1;
      new_secret[(i * 47 + 33)] = -1;
      new_secret[(i * 47 + 34)] = -1;
      new_secret[(i * 47 + 35)] = -1;
      new_secret[(i * 47 + 44)] = -1;
      new_secret[(i * 47 + 45)] = -1;
      new_secret[(i * 47 + 46)] = -1;
    }
    return new_secret;
  }
}