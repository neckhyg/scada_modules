package com.dalsemi.onewire.application.sha;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import com.dalsemi.onewire.container.OneWireContainer;
import com.dalsemi.onewire.container.OneWireContainer18;

public class SHAiButtonUser18 extends SHAiButtonUser
{
  protected OneWireContainer18 ibc = null;

  private byte[] readAccountData_rawData = new byte[42];
  private byte[] readAccountData_scratchpad = new byte[32];

  protected SHAiButtonUser18()
  {
  }

  public SHAiButtonUser18(SHAiButtonCopr copr, OneWireContainer18 owc, boolean formatDevice, byte[] authSecret)
    throws OneWireException, OneWireIOException
  {
    this(copr);

    this.ibc = owc;

    this.address = owc.getAddress();

    if (!createServiceFile(owc, this.strServiceFilename, formatDevice)) {
      throw new OneWireException("Failed to create service file.");
    }

    copr.getBindCode(this.fullBindCode, 0);
    System.arraycopy(this.fullBindCode, 4, this.fullBindCode, 12, 3);

    this.fullBindCode[4] = (byte)this.accountPageNumber;
    System.arraycopy(this.address, 0, this.fullBindCode, 5, 7);

    if (!owc.installMasterSecret(this.accountPageNumber, authSecret, this.accountPageNumber & 0x7))
    {
      throw new OneWireException("Install Master Secret failed");
    }

    if (!owc.bindSecretToiButton(this.accountPageNumber, copr.getBindData(), this.fullBindCode, this.accountPageNumber & 0x7))
    {
      throw new OneWireException("Bind Secret to iButton failed");
    }
  }

  public SHAiButtonUser18(byte[] coprBindData, byte[] coprBindCode, byte[] fileName, int fileNameExt, OneWireContainer18 owc, boolean formatDevice, byte[] authSecret)
    throws OneWireException, OneWireIOException
  {
    this.ibc = owc;

    this.address = owc.getAddress();

    System.arraycopy(fileName, 0, this.serviceFile, 0, 4);

    this.strServiceFilename = (new String(fileName) + "." + fileNameExt);

    if (!createServiceFile(owc, this.strServiceFilename, formatDevice)) {
      throw new OneWireException("Failed to create service file.");
    }

    System.arraycopy(coprBindCode, 0, this.fullBindCode, 0, 7);
    System.arraycopy(this.fullBindCode, 4, this.fullBindCode, 12, 3);

    this.fullBindCode[4] = (byte)this.accountPageNumber;
    System.arraycopy(this.address, 0, this.fullBindCode, 5, 7);

    if (!owc.installMasterSecret(this.accountPageNumber, authSecret, this.accountPageNumber & 0x7))
    {
      throw new OneWireException("Install Master Secret failed");
    }

    if (!owc.bindSecretToiButton(this.accountPageNumber, coprBindData, this.fullBindCode, this.accountPageNumber & 0x7))
    {
      throw new OneWireException("Bind Secret to iButton failed");
    }
  }

  public SHAiButtonUser18(SHAiButtonCopr copr, OneWireContainer18 owc)
    throws OneWireException, OneWireIOException
  {
    this(copr);

    if (!setiButton18(owc))
      throw new OneWireException("Invalid SHA user");
  }

  public SHAiButtonUser18(byte[] coprBindCode, byte[] fileName, int fileNameExt, OneWireContainer18 owc)
    throws OneWireException, OneWireIOException
  {
    System.arraycopy(coprBindCode, 0, this.fullBindCode, 0, 7);
    System.arraycopy(this.fullBindCode, 4, this.fullBindCode, 12, 3);

    System.arraycopy(fileName, 0, this.serviceFile, 0, 4);
    this.strServiceFilename = (new String(fileName) + "." + fileNameExt);

    if (!setiButton18(owc))
      throw new OneWireException("Invalid SHA user");
  }

  public SHAiButtonUser18(SHAiButtonCopr copr)
  {
    copr.getBindCode(this.fullBindCode, 0);
    System.arraycopy(this.fullBindCode, 4, this.fullBindCode, 12, 3);

    copr.getFilename(this.serviceFile, 0);
    this.strServiceFilename = (new String(this.serviceFile) + "." + copr.getFilenameExt());
  }

  public synchronized boolean setiButton18(OneWireContainer18 owc)
    throws OneWireException, OneWireIOException
  {
    this.ibc = owc;

    this.address = owc.getAddress();

    this.accountPageNumber = -1;

    if (!checkAccountPageInfo(owc)) {
      return false;
    }

    this.fullBindCode[4] = (byte)this.accountPageNumber;
    System.arraycopy(this.address, 0, this.fullBindCode, 5, 7);

    return true;
  }

  public synchronized boolean setiButtonUser(DSPortAdapter adapter, byte[] address)
    throws OneWireException, OneWireIOException
  {
    if (this.ibc == null) {
      this.ibc = new OneWireContainer18();
    }
    this.ibc.setupContainer(adapter, address);

    if (this.forceOverdrive) {
      this.ibc.setSpeed(2, false);
    }
    return setiButton18(this.ibc);
  }

  public synchronized boolean setiButtonUser(byte[] address)
    throws OneWireException, OneWireIOException
  {
    if (this.ibc == null) {
      return false;
    }
    this.ibc.setupContainer(this.ibc.getAdapter(), address);

    if (this.forceOverdrive) {
      this.ibc.setSpeed(2, false);
    }
    return setiButton18(this.ibc);
  }

  public synchronized int getWriteCycleCounter()
    throws OneWireException, OneWireIOException
  {
    if (this.writeCycleCounter < 0)
    {
      int wcc = -1;

      byte[] wcc_buffer = new byte[32];

      this.ibc.readMemoryPage(19, wcc_buffer, 0);

      int offset = (this.accountPageNumber & 0x7) << 2;

      wcc = wcc_buffer[(offset + 3)] & 0xFF;
      wcc = wcc << 8 | wcc_buffer[(offset + 2)] & 0xFF;
      wcc = wcc << 8 | wcc_buffer[(offset + 1)] & 0xFF;
      wcc = wcc << 8 | wcc_buffer[offset] & 0xFF;

      this.writeCycleCounter = wcc;
    }
    return this.writeCycleCounter;
  }

  public synchronized boolean hasWriteCycleCounter()
  {
    return this.accountPageNumber > 7;
  }

  public void getFullBindCode(byte[] l_fullBindCode, int offset)
  {
    System.arraycopy(this.fullBindCode, 0, l_fullBindCode, offset, 15);
  }

  public byte getAuthorizationCommand()
  {
    return 60;
  }

  public synchronized boolean writeAccountData(byte[] dataBuffer, int offset)
    throws OneWireException, OneWireIOException
  {
    OneWireContainer18 ibcL = this.ibc;

    if (!checkAccountPageInfo(ibcL)) {
      return false;
    }
    int numBytes = Math.min(32, dataBuffer.length - offset);
    System.arraycopy(dataBuffer, offset, this.accountData, 0, numBytes);
    if (ibcL.writeDataPage(this.accountPageNumber, this.accountData))
    {
      if (this.writeCycleCounter >= 0)
        this.writeCycleCounter += 1;
      return true;
    }

    this.writeCycleCounter = -1;

    this.accountData[0] = 0;
    return false;
  }

  public synchronized boolean readAccountData(byte[] dataBuffer, int offset)
    throws OneWireException, OneWireIOException
  {
    OneWireContainer18 ibcL = this.ibc;

    if (!checkAccountPageInfo(ibcL))
    {
      return false;
    }

    if (this.accountData[0] == 0)
    {
      ibcL.readMemoryPage(this.accountPageNumber, this.accountData, 0);
    }

    System.arraycopy(this.accountData, 0, dataBuffer, offset, 32);

    return true;
  }

  public synchronized int readAccountData(byte[] chlg, int chlgStart, byte[] dataBuffer, int dataStart, byte[] mac, int macStart)
    throws OneWireException, OneWireIOException
  {
    OneWireContainer18 ibcL = this.ibc;
    byte[] rawData = this.readAccountData_rawData;
    byte[] scratchpad = this.readAccountData_scratchpad;

    if (this.accountPageNumber < 0)
    {
      return -1;
    }

    System.arraycopy(chlg, 0, scratchpad, 20, 3);

    if (ibcL.eraseScratchPad(this.accountPageNumber))
    {
      ibcL.useResume(true);

      if (ibcL.writeScratchPad(this.accountPageNumber, 0, scratchpad, 0, 32))
      {
        boolean readOK = ibcL.readAuthenticatedPage(this.accountPageNumber, rawData, 0);

        int len = ibcL.readScratchPad(scratchpad, 0);

        ibcL.useResume(false);

        if ((!readOK) || (len < 0))
        {
          return -1;
        }

        int wcc = rawData[35] & 0xFF;
        wcc = wcc << 8 | rawData[34] & 0xFF;
        wcc = wcc << 8 | rawData[33] & 0xFF;
        wcc = wcc << 8 | rawData[32] & 0xFF;

        System.arraycopy(rawData, 0, this.accountData, 0, 32);

        System.arraycopy(rawData, 0, dataBuffer, dataStart, 32);

        System.arraycopy(scratchpad, 8, mac, macStart, 20);

        this.writeCycleCounter = wcc;

        return wcc;
      }

      return -1;
    }

    return -1;
  }
}