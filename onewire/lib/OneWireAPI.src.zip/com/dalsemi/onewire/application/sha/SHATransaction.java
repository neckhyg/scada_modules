package com.dalsemi.onewire.application.sha;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.OneWireIOException;
import java.util.Random;

public abstract class SHATransaction
{
  static final boolean DEBUG = false;
  static final int MAX_RETRY_CNT = 65536;
  static final Random rand = new Random();
  public static final int NO_ERROR = 0;
  public static final int SHA_FUNCTION_FAILED = -1;
  public static final int MATCH_SCRATCHPAD_FAILED = -2;
  public static final int COPR_WRITE_DATAPAGE_FAILED = -3;
  public static final int COPR_WRITE_SCRATCHPAD_FAILED = -4;
  public static final int COPR_BIND_SECRET_FAILED = -5;
  public static final int COPR_COMPUTE_CHALLENGE_FAILED = -6;
  public static final int COPROCESSOR_FAILURE = -6;
  public static final int USER_READ_AUTH_FAILED = -7;
  public static final int USER_WRITE_DATA_FAILED = -8;
  public static final int USER_BAD_ACCOUNT_DATA = -9;
  public static final int USER_DATA_NOT_UPDATED = -10;
  protected int lastError;
  protected SHAiButtonCopr copr;

  protected SHATransaction()
  {
  }

  protected SHATransaction(SHAiButtonCopr copr)
  {
    this.copr = copr;
    this.lastError = 0;
  }

  public int getLastError()
  {
    return this.lastError;
  }

  public int getLastCoprError()
  {
    return this.copr.getLastError();
  }

  public abstract boolean setupTransactionData(SHAiButtonUser paramSHAiButtonUser)
    throws OneWireException, OneWireIOException;

  public abstract boolean verifyUser(SHAiButtonUser paramSHAiButtonUser)
    throws OneWireException, OneWireIOException;

  public abstract boolean verifyTransactionData(SHAiButtonUser paramSHAiButtonUser)
    throws OneWireException, OneWireIOException;

  public abstract boolean executeTransaction(SHAiButtonUser paramSHAiButtonUser, boolean paramBoolean)
    throws OneWireException, OneWireIOException;

  public abstract boolean setParameter(int paramInt1, int paramInt2);

  public abstract int getParameter(int paramInt);

  public abstract void resetParameters();
}