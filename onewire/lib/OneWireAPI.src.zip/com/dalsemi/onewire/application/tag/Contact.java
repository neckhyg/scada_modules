package com.dalsemi.onewire.application.tag;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.container.OneWireContainer;

public class Contact extends TaggedDevice
  implements TaggedSensor
{
  public Contact()
  {
  }

  public Contact(DSPortAdapter adapter, String netAddress)
  {
    super(adapter, netAddress);
  }

  public String readSensor()
    throws OneWireException
  {
    String returnString = "";

    if (this.DeviceContainer.isPresent())
    {
      returnString = this.max;
    }
    else
    {
      returnString = this.min;
    }
    return returnString;
  }
}