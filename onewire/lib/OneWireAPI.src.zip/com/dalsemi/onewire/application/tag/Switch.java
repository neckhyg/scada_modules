package com.dalsemi.onewire.application.tag;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.container.OneWireSensor;
import com.dalsemi.onewire.container.SwitchContainer;
import java.util.Vector;

public class Switch extends TaggedDevice
  implements TaggedActuator
{
  private Vector ActuatorSelections;

  public Switch()
  {
    this.ActuatorSelections = new Vector();
  }

  public Switch(DSPortAdapter adapter, String netAddress)
  {
    super(adapter, netAddress);
    this.ActuatorSelections = new Vector();
  }

  public Vector getSelections()
  {
    return this.ActuatorSelections;
  }

  public void setSelection(String selection)
    throws OneWireException
  {
    SwitchContainer switchcontainer = (SwitchContainer)getDeviceContainer();
    int Index = 0;
    int channelValue = getChannel();
    Index = this.ActuatorSelections.indexOf(selection);
    boolean switch_state = false;

    if (Index > -1)
    {
      if (Index > 0) switch_state = true;

      byte[] state = switchcontainer.readDevice();

      switchcontainer.setLatchState(channelValue, switch_state, false, state);
      switchcontainer.writeDevice(state);
    }
  }

  public void initActuator()
    throws OneWireException
  {
    SwitchContainer switchcontainer = (SwitchContainer)getDeviceContainer();

    this.ActuatorSelections.addElement(getMin());
    this.ActuatorSelections.addElement(getMax());

    int switchStateIntValue = 0;
    Integer init = new Integer(getInit());
    int initValue = init.intValue();
    int channelValue = getChannel();

    byte[] state = switchcontainer.readDevice();
    boolean switch_state = switchcontainer.getLatchState(channelValue, state);
    if (switch_state) switchStateIntValue = 1; else
      switchStateIntValue = 0;
    if (initValue != switchStateIntValue)
    {
      switchcontainer.setLatchState(channelValue, !switch_state, false, state);
      switchcontainer.writeDevice(state);
    }
  }
}