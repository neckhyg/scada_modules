package com.dalsemi.onewire.application.tag;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.container.OneWireSensor;
import com.dalsemi.onewire.container.SwitchContainer;

public class Level extends TaggedDevice
  implements TaggedSensor
{
  public Level()
  {
  }

  public Level(DSPortAdapter adapter, String netAddress)
  {
    super(adapter, netAddress);
  }

  public String readSensor()
    throws OneWireException
  {
    String returnString = "";

    int switchChannel = getChannel();

    SwitchContainer Container = (SwitchContainer)this.DeviceContainer;

    if (Container.hasLevelSensing())
    {
      byte[] switchState = Container.readDevice();
      if (Container.getLevel(switchChannel, switchState))
      {
        returnString = getMax();
      }
      else
      {
        returnString = getMin();
      }
    }
    return returnString;
  }
}