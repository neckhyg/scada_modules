package com.dalsemi.onewire.application.tag;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.container.OneWireSensor;
import com.dalsemi.onewire.container.PotentiometerContainer;
import java.util.Vector;

public class D2A extends TaggedDevice
  implements TaggedActuator
{
  private Vector ActuatorSelections;

  public D2A()
  {
    this.ActuatorSelections = new Vector();
  }

  public D2A(DSPortAdapter adapter, String netAddress)
  {
    super(adapter, netAddress);
    this.ActuatorSelections = new Vector();
  }

  public Vector getSelections()
  {
    return this.ActuatorSelections;
  }

  public void setSelection(String selection)
    throws OneWireException
  {
    PotentiometerContainer pc = (PotentiometerContainer)getDeviceContainer();
    int Index = 0;
    Index = this.ActuatorSelections.indexOf(selection);

    byte[] state = pc.readDevice();

    pc.setCurrentWiperNumber(getChannel(), state);

    pc.writeDevice(state);

    if (Index > -1)
    {
      state = pc.readDevice();
      pc.setWiperPosition(Index);
      pc.writeDevice(state);
    }
  }

  public void initActuator()
    throws OneWireException
  {
    PotentiometerContainer pc = (PotentiometerContainer)getDeviceContainer();

    double offset = 0.6D;

    byte[] state = pc.readDevice();

    pc.setCurrentWiperNumber(getChannel(), state);

    pc.writeDevice(state);

    int numOfWiperSettings = pc.numberOfWiperSettings(state);

    int resistance = pc.potentiometerResistance(state);

    double wiperResistance = (resistance - offset) / numOfWiperSettings;

    String selectionString = resistance + " k-Ohms";
    this.ActuatorSelections.addElement(selectionString);
    for (int i = numOfWiperSettings - 2; i > -1; i--)
    {
      double newWiperResistance = wiperResistance * i;

      int roundedWiperResistance = (int)((newWiperResistance + offset) * 10000.0D);
      selectionString = roundedWiperResistance / 10000.0D + " k-Ohms";
      this.ActuatorSelections.addElement(selectionString);
    }
  }
}