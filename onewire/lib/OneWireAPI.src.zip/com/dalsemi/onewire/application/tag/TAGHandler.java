package com.dalsemi.onewire.application.tag;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.utils.OWPath;
import java.io.PrintStream;
import java.util.EmptyStackException;
import java.util.Stack;
import java.util.Vector;
import org.xml.sax.AttributeList;
import org.xml.sax.DocumentHandler;
import org.xml.sax.ErrorHandler;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

class TAGHandler
  implements ErrorHandler, DocumentHandler
{
  private DSPortAdapter adapter;
  private String currentElement;
  private TaggedDevice currentDevice;
  private Vector deviceList;
  private Stack clusterStack;
  private Stack branchStack;
  private Vector branchVector;
  private Vector branchVectors;
  private Vector branchPaths;

  public void setDocumentLocator(Locator locator)
  {
  }

  public void startDocument()
    throws SAXException
  {
    this.deviceList = new Vector();
    this.clusterStack = new Stack();
    this.branchStack = new Stack();
    this.branchVector = new Vector();
    this.branchVectors = new Vector();

    this.branchPaths = new Vector();
  }

  public void endDocument()
    throws SAXException
  {
    TaggedDevice device;
    for (int i = 0; i < this.deviceList.size(); i++)
    {
      device = (TaggedDevice)this.deviceList.elementAt(i);

      device.setOWPath(this.adapter, device.getBranches());
    }

    for (int i = 0; i < this.branchVectors.size(); i++)
    {
      Vector singleBranchVector = (Vector)this.branchVectors.elementAt(i);
      OWPath branchPath = new OWPath(this.adapter);
      for (int j = 0; j < singleBranchVector.size(); j++)
      {
        device = (TaggedDevice)singleBranchVector.elementAt(i);

        branchPath.add(device.getDeviceContainer(), device.getChannel());
      }
      this.branchPaths.addElement(branchPath);
    }
  }

  public void startElement(String name, AttributeList atts)
    throws SAXException
  {
    this.currentElement = name;

    String attributeAddr = "null";
    String attributeType = "null";

    int i = 0;

    if (name.toUpperCase().equals("CLUSTER"))
    {
      for (i = 0; i < atts.getLength(); i++)
      {
        if (!atts.getName(i).toUpperCase().equals("NAME"))
          continue;
        this.clusterStack.push(atts.getValue(i));
      }

    }

    if ((name.toUpperCase().equals("SENSOR")) || (name.toUpperCase().equals("ACTUATOR")) || (name.toUpperCase().equals("BRANCH")))
    {
      for (i = 0; i < atts.getLength(); i++)
      {
        String attName = atts.getName(i);

        if (attName.toUpperCase().equals("ADDR"))
        {
          attributeAddr = atts.getValue(i);
        }

        if (!attName.toUpperCase().equals("TYPE"))
          continue;
        attributeType = atts.getValue(i);
      }

      if (name.toUpperCase().equals("BRANCH"))
      {
        attributeType = "branch";
        this.currentDevice = new TaggedDevice();
      }
      else
      {
        String className;
        if (attributeType.indexOf(".") > 0)
        {
          className = attributeType;
        }
        else {
          className = "com.dalsemi.onewire.application.tag." + attributeType;
        }

        try
        {
          Class genericClass = Class.forName(className);

          this.currentDevice = ((TaggedDevice)genericClass.newInstance());
        }
        catch (Exception e)
        {
          throw new RuntimeException("Can't load 1-Wire Tag Type class (" + className + "): " + e.getMessage());
        }

      }

      this.currentDevice.setDeviceContainer(this.adapter, attributeAddr);
      this.currentDevice.setDeviceType(attributeType);
      this.currentDevice.setClusterName(getClusterStackAsString(this.clusterStack, "/"));

      this.currentDevice.setBranches((Vector)this.branchStack.clone());

      if (name.equals("branch"))
      {
        this.branchStack.push(this.currentDevice);

        this.branchVector.addElement(this.currentDevice);

        this.deviceList.addElement(this.currentDevice);
      }
    }
  }

  public void endElement(String name)
    throws SAXException
  {
    if ((name.toUpperCase().equals("SENSOR")) || (name.toUpperCase().equals("ACTUATOR")))
    {
      this.deviceList.addElement(this.currentDevice);

      this.currentDevice = null;
    }

    if (name.toUpperCase().equals("BRANCH"))
    {
      this.branchVectors.addElement(this.branchStack.clone());

      this.branchStack.pop();

      this.currentDevice = null;
    }

    if (name.toUpperCase().equals("CLUSTER"))
    {
      this.clusterStack.pop();
    }
  }

  public void characters(char[] ch, int start, int length)
    throws SAXException
  {
    if (this.currentElement.toUpperCase().equals("LABEL"))
    {
      if (this.currentDevice == null)
      {
        try
        {
          this.currentDevice = ((TaggedDevice)this.branchStack.peek());

          this.currentDevice.setLabel(new String(ch, start, length));

          this.currentDevice = null;
        }
        catch (EmptyStackException ese)
        {
        }

      }
      else
      {
        this.currentDevice.setLabel(new String(ch, start, length));
      }

    }

    if (this.currentElement.toUpperCase().equals("CHANNEL"))
    {
      if (this.currentDevice == null)
      {
        try
        {
          this.currentDevice = ((TaggedDevice)this.branchStack.peek());

          this.currentDevice.setChannelFromString(new String(ch, start, length));

          this.currentDevice = null;
        }
        catch (EmptyStackException ese)
        {
        }

      }
      else
      {
        this.currentDevice.setChannelFromString(new String(ch, start, length));
      }
    }

    if (this.currentElement.toUpperCase().equals("MAX"))
    {
      this.currentDevice.max = new String(ch, start, length);
    }

    if (this.currentElement.toUpperCase().equals("MIN"))
    {
      this.currentDevice.min = new String(ch, start, length);
    }

    if (this.currentElement.toUpperCase().equals("INIT"))
    {
      this.currentDevice.setInit(new String(ch, start, length));
    }
  }

  public void ignorableWhitespace(char[] ch, int start, int length)
    throws SAXException
  {
  }

  public void processingInstruction(String target, String data)
    throws SAXException
  {
  }

  public Vector getTaggedDeviceList()
  {
    return this.deviceList;
  }

  public void setAdapter(DSPortAdapter adapter)
    throws OneWireException
  {
    this.adapter = adapter;
  }

  public void fatalError(SAXParseException exception)
    throws SAXParseException
  {
    System.err.println(exception);

    throw exception;
  }

  public void error(SAXParseException exception)
    throws SAXParseException
  {
    System.err.println(exception);

    throw exception;
  }

  public void warning(SAXParseException exception)
  {
    System.err.println(exception);
  }

  public Vector getAllBranches()
  {
    return this.branchVector;
  }

  public Vector getAllBranchPaths()
  {
    return this.branchPaths;
  }

  private String getClusterStackAsString(Stack clusters, String separator)
  {
    String returnString = "";

    for (int j = 0; j < clusters.size(); j++)
    {
      returnString = returnString + separator + (String)clusters.elementAt(j);
    }

    return returnString;
  }
}