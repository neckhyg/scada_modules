package com.dalsemi.onewire.application.tag;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.container.OneWireSensor;
import com.dalsemi.onewire.container.TemperatureContainer;

public class Thermal extends TaggedDevice
  implements TaggedSensor
{
  public Thermal()
  {
  }

  public Thermal(DSPortAdapter adapter, String netAddress)
  {
    super(adapter, netAddress);
  }

  public String readSensor()
    throws OneWireException
  {
    String returnString = "";

    TemperatureContainer tc = (TemperatureContainer)this.DeviceContainer;

    byte[] state = tc.readDevice();

    tc.doTemperatureConvert(state);

    state = tc.readDevice();

    double theTemperature = tc.getTemperature(state);

    theTemperature = roundDouble(theTemperature * 100.0D) / 100.0D;

    returnString = theTemperature + " °C";

    return returnString;
  }

  private double roundDouble(double d)
  {
    return (int)(d + (d > 0.0D ? 0.5D : -0.5D));
  }
}