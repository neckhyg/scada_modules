package com.dalsemi.onewire.application.tag;

import com.dalsemi.onewire.OneWireAccessProvider;
import java.io.IOException;
import java.util.Locale;
import org.xml.sax.DTDHandler;
import org.xml.sax.DocumentHandler;
import org.xml.sax.EntityResolver;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Parser;
import org.xml.sax.SAXException;

public class SAXParser
  implements Parser
{
  private Parser parser;

  public SAXParser()
  {
    String className = OneWireAccessProvider.getProperty("SAXParser.ClassName");
    if (className == null)
    {
      className = "nanoxml.sax.SAXParser";
    }

    try
    {
      Class c = Class.forName(className);
      this.parser = ((Parser)c.newInstance());
    }
    catch (Exception e)
    {
      throw new RuntimeException("Can't load SAX Parser (" + className + "): " + e.getMessage());
    }
  }

  public void setLocale(Locale locale)
    throws SAXException
  {
    this.parser.setLocale(locale);
  }

  public void setEntityResolver(EntityResolver resolver)
  {
    this.parser.setEntityResolver(resolver);
  }

  public void setDTDHandler(DTDHandler handler)
  {
    this.parser.setDTDHandler(handler);
  }

  public void setDocumentHandler(DocumentHandler handler)
  {
    this.parser.setDocumentHandler(handler);
  }

  public void setErrorHandler(ErrorHandler handler)
  {
    this.parser.setErrorHandler(handler);
  }

  public void parse(InputSource inputSource)
    throws SAXException, IOException
  {
    this.parser.parse(inputSource);
  }

  public void parse(String systemID)
    throws SAXException, IOException
  {
    this.parser.parse(systemID);
  }
}