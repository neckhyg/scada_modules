package com.dalsemi.onewire.application.tag;

import com.dalsemi.onewire.adapter.DSPortAdapter;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.Vector;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class TAGParser
{
  private SAXParser parser;
  private TAGHandler handler;

  public TAGParser(DSPortAdapter adapter)
  {
    this.parser = XML.createSAXParser();
    this.handler = new TAGHandler();
    try
    {
      this.handler.setAdapter(adapter);
    }
    catch (Exception e)
    {
      System.out.println(e);
    }

    this.parser.setDocumentHandler(this.handler);
    this.parser.setErrorHandler(this.handler);
  }

  public Vector parse(InputStream in)
    throws SAXException, IOException
  {
    InputSource insource = new InputSource(in);

    this.parser.parse(insource);

    Vector v = this.handler.getTaggedDeviceList();

    return v;
  }

  public Vector getBranches()
  {
    Vector v = this.handler.getAllBranches();

    return v;
  }

  public Vector getOWPaths()
  {
    Vector v = this.handler.getAllBranchPaths();

    return v;
  }
}