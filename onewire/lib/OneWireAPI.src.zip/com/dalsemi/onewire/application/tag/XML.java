package com.dalsemi.onewire.application.tag;

public class XML
{
  public static SAXParser createSAXParser()
  {
    return new SAXParser();
  }

  public static String escape(String source)
  {
    StringBuffer rc = new StringBuffer(source.length());

    for (int i = 0; i < source.length(); i++)
    {
      char c = source.charAt(i);

      if (((c < ' ') && (c != '\t') && (c != '\n') && (c != '\r')) || (c > '~') || (c == '÷'))
      {
        rc.append("&#").append(Integer.toString(c)).append(';');
      }
      else
      {
        switch (c)
        {
        case '"':
          rc.append("&quot;");
          break;
        case '\'':
          rc.append("&apos;");
          break;
        case '<':
          rc.append("&lt;");
          break;
        case '>':
          rc.append("&gt;");
          break;
        case '&':
          rc.append("&amp;");
          break;
        default:
          rc.append(c);
        }
      }
    }

    return rc.toString();
  }
}