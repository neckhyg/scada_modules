package com.dalsemi.onewire.application.tag;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.OneWireIOException;
import java.util.Vector;

public abstract interface TaggedActuator
{
  public abstract Vector getSelections();

  public abstract void setSelection(String paramString)
    throws OneWireIOException, OneWireException;

  public abstract void initActuator()
    throws OneWireIOException, OneWireException;
}