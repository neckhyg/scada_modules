package com.dalsemi.onewire.application.tag;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.container.HumidityContainer;
import com.dalsemi.onewire.container.OneWireSensor;

public class Humidity extends TaggedDevice
  implements TaggedSensor
{
  public Humidity()
  {
  }

  public Humidity(DSPortAdapter adapter, String netAddress)
  {
    super(adapter, netAddress);
  }

  public String readSensor()
    throws OneWireException
  {
    HumidityContainer hc = (HumidityContainer)this.DeviceContainer;

    byte[] state = hc.readDevice();

    hc.doHumidityConvert(state);

    String return_string = (int)roundDouble(hc.getHumidity(state)) + "%";
    if (hc.isRelative()) {
      return_string = return_string + "RH";
    }
    return return_string;
  }

  private double roundDouble(double d)
  {
    return (int)(d + (d > 0.0D ? 0.5D : -0.5D));
  }
}