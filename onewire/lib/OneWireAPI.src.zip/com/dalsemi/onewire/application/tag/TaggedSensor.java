package com.dalsemi.onewire.application.tag;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.OneWireIOException;

public abstract interface TaggedSensor
{
  public abstract String readSensor()
    throws OneWireIOException, OneWireException;
}