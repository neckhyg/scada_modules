package com.dalsemi.onewire.application.tag;

import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.container.OneWireContainer;
import com.dalsemi.onewire.utils.OWPath;
import java.util.Vector;

public class TaggedDevice
{
  public OneWireContainer DeviceContainer;
  public String DeviceType;
  public String label;
  public Integer channel;
  public String max;
  public String min;
  public Boolean state;
  public String init;
  public String clusterName;
  public Vector branchVector;
  private OWPath branchPath;

  public TaggedDevice(DSPortAdapter adapter, String netAddress)
  {
    this.DeviceContainer = adapter.getDeviceContainer(netAddress);
  }

  public TaggedDevice()
  {
  }

  public void setDeviceContainer(DSPortAdapter adapter, String netAddress)
  {
    this.DeviceContainer = adapter.getDeviceContainer(netAddress);
  }

  public void setDeviceType(String tType)
  {
    this.DeviceType = tType;
  }

  public void setLabel(String Label)
  {
    this.label = Label;
  }

  public void setChannelFromString(String Channel)
  {
    this.channel = new Integer(Channel);
  }

  public void setChannel(int Channel)
  {
    this.channel = new Integer(Channel);
  }

  public void setInit(String Init)
  {
    this.init = Init;
  }

  public void setClusterName(String cluster)
  {
    this.clusterName = cluster;
  }

  public void setBranches(Vector branches)
  {
    this.branchVector = branches;
  }

  public void setOWPath(OWPath branchOWPath)
  {
    this.branchPath = branchOWPath;
  }

  public void setOWPath(DSPortAdapter adapter, Vector Branches)
  {
    this.branchPath = new OWPath(adapter);

    for (int i = 0; i < Branches.size(); i++)
    {
      TaggedDevice TDevice = (TaggedDevice)Branches.elementAt(i);

      this.branchPath.add(TDevice.getDeviceContainer(), TDevice.getChannel());
    }
  }

  public OneWireContainer getDeviceContainer()
  {
    return this.DeviceContainer;
  }

  public String getDeviceType()
  {
    return this.DeviceType;
  }

  public String getLabel()
  {
    return this.label;
  }

  public String getChannelAsString()
  {
    return this.channel.toString();
  }

  public int getChannel()
  {
    return this.channel.intValue();
  }

  public String getInit()
  {
    return this.init;
  }

  public String getMax()
  {
    return this.max;
  }

  public String getMin()
  {
    return this.min;
  }

  public String getClusterName()
  {
    return this.clusterName;
  }

  public Vector getBranches()
  {
    return this.branchVector;
  }

  public OWPath getOWPath()
  {
    return this.branchPath;
  }

  public boolean equals(Object o)
  {
    if (o == this) {
      return true;
    }
    if ((o instanceof TaggedDevice))
    {
      TaggedDevice td = (TaggedDevice)o;
      return (td.DeviceContainer.equals(this.DeviceContainer)) && (td.DeviceType.equals(this.DeviceType)) && (td.min.equals(this.min)) && (td.max.equals(this.max)) && (td.init.equals(this.init)) && (td.clusterName.equals(this.clusterName)) && (td.label.equals(this.label));
    }

    return false;
  }

  public int hashCode()
  {
    return (getDeviceContainer().toString() + getLabel()).hashCode();
  }

  public String toString()
  {
    return getLabel();
  }
}