package com.dalsemi.onewire.application.tag;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.container.OneWireSensor;
import com.dalsemi.onewire.container.SwitchContainer;

public class Event extends TaggedDevice
  implements TaggedSensor
{
  public Event()
  {
  }

  public Event(DSPortAdapter adapter, String netAddress)
  {
    super(adapter, netAddress);
  }

  public String readSensor()
    throws OneWireException
  {
    String returnString = "";

    SwitchContainer Container = (SwitchContainer)this.DeviceContainer;

    if (Container.hasActivitySensing())
    {
      byte[] switchState = Container.readDevice();
      if (Container.getSensedActivity(getChannel(), switchState))
      {
        returnString = getMax();

        Container.clearActivity();
        switchState = Container.readDevice();
      }
    }
    else
    {
      returnString = "";
    }

    return returnString;
  }
}