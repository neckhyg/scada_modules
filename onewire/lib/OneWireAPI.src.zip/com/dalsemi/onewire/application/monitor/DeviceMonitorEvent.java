package com.dalsemi.onewire.application.monitor;

import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.container.OneWireContainer;
import com.dalsemi.onewire.utils.Address;
import com.dalsemi.onewire.utils.OWPath;
import java.util.EventObject;
import java.util.Vector;

public class DeviceMonitorEvent extends EventObject
{
  public static final int ARRIVAL = 0;
  public static final int DEPARTURE = 1;
  protected int eventType = -1;

  protected AbstractDeviceMonitor monitor = null;

  protected DSPortAdapter adapter = null;

  protected Vector vDeviceAddress = null;

  DeviceMonitorEvent(int eventType, AbstractDeviceMonitor source, DSPortAdapter adapter, Vector addresses)
  {
    super(source);

    if ((eventType != 0) && (eventType != 1))
      throw new IllegalArgumentException("Invalid event type: " + eventType);
    this.eventType = eventType;
    this.monitor = source;
    this.adapter = adapter;
    this.vDeviceAddress = addresses;
  }

  public int getEventType()
  {
    return this.eventType;
  }

  public AbstractDeviceMonitor getMonitor()
  {
    return this.monitor;
  }

  public DSPortAdapter getAdapter()
  {
    return this.adapter;
  }

  public int getDeviceCount()
  {
    return this.vDeviceAddress.size();
  }

  public OneWireContainer getContainerAt(int index)
  {
    Long longAddress = (Long)this.vDeviceAddress.elementAt(index);
    return AbstractDeviceMonitor.getDeviceContainer(this.adapter, longAddress);
  }

  public OWPath getPathForContainerAt(int index)
  {
    Long longAddress = (Long)this.vDeviceAddress.elementAt(index);
    return this.monitor.getDevicePath(longAddress);
  }

  public long getAddressAsLongAt(int index)
  {
    return ((Long)this.vDeviceAddress.elementAt(index)).longValue();
  }

  public byte[] getAddressAt(int index)
  {
    return Address.toByteArray(getAddressAsLongAt(index));
  }

  public String getAddressAsStringAt(int index)
  {
    return Address.toString(getAddressAsLongAt(index));
  }
}