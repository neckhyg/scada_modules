package com.dalsemi.onewire.application.monitor;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import com.dalsemi.onewire.container.OneWireContainer;
import com.dalsemi.onewire.utils.Address;
import com.dalsemi.onewire.utils.OWPath;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

public abstract class AbstractDeviceMonitor
  implements Runnable
{
  protected final Object sync_flag = new Object();

  protected final Hashtable deviceAddressHash = new Hashtable();

  protected static final Hashtable deviceContainerHash = new Hashtable();

  protected final Vector listeners = new Vector();

  protected int max_state_count = 3;

  protected int max_error_count = 6;

  protected volatile boolean keepRunning = true; protected volatile boolean hasCompletelyStopped = false;

  protected volatile boolean startRunning = true;

  protected volatile boolean isRunning = false;

  protected DSPortAdapter adapter = null;

  public void cleanUpStaleContainerReferences()
  {
    synchronized (deviceContainerHash)
    {
      Enumeration e = deviceContainerHash.keys();
      while (e.hasMoreElements())
      {
        Object o = e.nextElement();
        if (!this.deviceAddressHash.containsKey(o))
          deviceContainerHash.remove(o);
      }
    }
  }

  public void cleanUpStalePathReferences()
  {
  }

  public void resetSearch()
  {
    synchronized (this.sync_flag)
    {
      if ((this.deviceAddressHash.size() > 0) && (this.listeners.size() > 0))
      {
        Vector v = new Vector(this.deviceAddressHash.size());
        Enumeration e = this.deviceAddressHash.keys();
        while (e.hasMoreElements())
          v.addElement(e.nextElement());
        fireDepartureEvent(this.adapter, v);
      }

      this.deviceAddressHash.clear();
    }
  }

  public int getMaxStateCount()
  {
    return this.max_state_count;
  }

  public void setMaxStateCount(int stateCnt)
  {
    if (stateCnt <= 0) {
      throw new IllegalArgumentException("State Count must be greater than 0");
    }
    this.max_state_count = stateCnt;
  }

  public int getMaxErrorCount()
  {
    return this.max_error_count;
  }

  public void setMaxErrorCount(int errorCnt)
  {
    if (errorCnt <= 0) {
      throw new IllegalArgumentException("Error Count must be greater than 0");
    }
    this.max_error_count = errorCnt;
  }

  public DSPortAdapter getAdapter()
  {
    return this.adapter;
  }

  public abstract void setAdapter(DSPortAdapter paramDSPortAdapter);

  public abstract void search(Vector paramVector1, Vector paramVector2)
    throws OneWireException, OneWireIOException;

  public boolean pauseMonitor(boolean blocking)
  {
    synchronized (this.sync_flag)
    {
      if ((this.hasCompletelyStopped) || ((!this.startRunning) && (!this.isRunning))) {
        return 1;
      }
      this.startRunning = false;
    }

    int i = 0;
    while ((this.isRunning) && ((blocking) || (i++ < 100)))
    {
      msSleep(10L);
    }

    return !this.isRunning;
  }

  public boolean resumeMonitor(boolean blocking)
  {
    synchronized (this.sync_flag)
    {
      if (this.hasCompletelyStopped)
        return 0;
      if ((this.startRunning) && (this.isRunning)) {
        return 1;
      }
      this.startRunning = true;
    }

    int i = 0;
    while ((!this.isRunning) && ((blocking) || (i++ < 100)))
    {
      msSleep(10L);
    }

    return this.isRunning;
  }

  public boolean isMonitorRunning()
  {
    return this.isRunning;
  }

  public void killMonitor()
  {
    synchronized (this.sync_flag)
    {
      this.keepRunning = false;
      this.startRunning = false;
    }

    int i = 0;
    while ((!this.hasCompletelyStopped) && (i < 100))
    {
      msSleep(20L);
    }
  }

  public void run()
  {
    synchronized (this.sync_flag)
    {
      this.hasCompletelyStopped = false;
    }

    Vector arrivals = new Vector(); Vector departures = new Vector();
    while (this.keepRunning)
    {
      if (this.startRunning)
      {
        synchronized (this.sync_flag)
        {
          this.isRunning = true;
        }

        arrivals.setSize(0);
        departures.setSize(0);

        int errorCount = 0;
        boolean done = false;
        while (!done)
        {
          try
          {
            search(arrivals, departures);
            done = true;
          }
          catch (Exception e)
          {
            errorCount++; if (errorCount != this.max_error_count)
              continue;
            fireException(this.adapter, e);
            done = true;
          }

        }

        msSleep(200L);
      }
      else
      {
        synchronized (this.sync_flag)
        {
          this.isRunning = false;
        }
        msSleep(200L);
      }
    }

    synchronized (this.sync_flag)
    {
      this.isRunning = false;
      this.hasCompletelyStopped = true;
    }
  }

  protected void msSleep(long msTime)
  {
    Thread.yield();
    try
    {
      Thread.sleep(msTime);
    }
    catch (InterruptedException e)
    {
    }
  }

  public void addDeviceMonitorEventListener(DeviceMonitorEventListener dmel)
  {
    if (dmel != null)
      this.listeners.addElement(dmel);
  }

  protected void fireArrivalEvent(DSPortAdapter adapter, Vector address)
  {
    DeviceMonitorEvent dme = new DeviceMonitorEvent(0, this, adapter, (Vector)address.clone());

    for (int i = 0; i < this.listeners.size(); i++)
    {
      DeviceMonitorEventListener listener = (DeviceMonitorEventListener)this.listeners.elementAt(i);

      listener.deviceArrival(dme);
    }
  }

  protected void fireDepartureEvent(DSPortAdapter adapter, Vector address)
  {
    DeviceMonitorEvent dme = new DeviceMonitorEvent(1, this, adapter, (Vector)address.clone());

    for (int i = 0; i < this.listeners.size(); i++)
    {
      DeviceMonitorEventListener listener = (DeviceMonitorEventListener)this.listeners.elementAt(i);

      listener.deviceDeparture(dme);
    }
  }

  private void fireException(DSPortAdapter adapter, Exception ex)
  {
    for (int i = 0; i < this.listeners.size(); i++)
    {
      ((DeviceMonitorEventListener)this.listeners.elementAt(i)).networkException(new DeviceMonitorException(this, adapter, ex));
    }
  }

  public OWPath getDevicePath(byte[] address)
  {
    return getDevicePath(Address.toLong(address));
  }

  public OWPath getDevicePath(String address)
  {
    return getDevicePath(Address.toLong(address));
  }

  public OWPath getDevicePath(long address)
  {
    return getDevicePath(new Long(address));
  }

  public abstract OWPath getDevicePath(Long paramLong);

  public Enumeration getAllAddresses()
  {
    return this.deviceAddressHash.keys();
  }

  public static OneWireContainer getDeviceContainer(DSPortAdapter adapter, byte[] address)
  {
    return getDeviceContainer(adapter, Address.toLong(address));
  }

  public static OneWireContainer getDeviceContainer(DSPortAdapter adapter, String address)
  {
    return getDeviceContainer(adapter, Address.toLong(address));
  }

  public static OneWireContainer getDeviceContainer(DSPortAdapter adapter, long address)
  {
    return getDeviceContainer(adapter, new Long(address));
  }

  public static OneWireContainer getDeviceContainer(DSPortAdapter adapter, Long longAddress)
  {
    synchronized (deviceContainerHash)
    {
      Object o = deviceContainerHash.get(longAddress);
      if (o == null)
      {
        o = adapter.getDeviceContainer(longAddress.longValue());
        putDeviceContainer(longAddress, (OneWireContainer)o);
      }
      return (OneWireContainer)o;
    }
  }

  public static void putDeviceContainer(byte[] address, OneWireContainer owc)
  {
    putDeviceContainer(Address.toLong(address), owc);
  }

  public static void putDeviceContainer(String address, OneWireContainer owc)
  {
    putDeviceContainer(Address.toLong(address), owc);
  }

  public static void putDeviceContainer(long address, OneWireContainer owc)
  {
    putDeviceContainer(new Long(address), owc);
  }

  public static void putDeviceContainer(Long longAddress, OneWireContainer owc)
  {
    synchronized (deviceContainerHash)
    {
      deviceContainerHash.put(longAddress, owc);
    }
  }
}