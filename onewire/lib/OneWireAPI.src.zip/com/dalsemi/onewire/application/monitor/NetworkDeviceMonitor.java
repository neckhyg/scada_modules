package com.dalsemi.onewire.application.monitor;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import com.dalsemi.onewire.container.OneWireSensor;
import com.dalsemi.onewire.container.SwitchContainer;
import com.dalsemi.onewire.utils.OWPath;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

public class NetworkDeviceMonitor extends AbstractDeviceMonitor
{
  protected final Hashtable devicePathHash = new Hashtable();

  protected Vector paths = null;

  protected boolean branchAutoSearching = true;

  public NetworkDeviceMonitor(DSPortAdapter adapter)
  {
    setAdapter(adapter);
  }

  public void setAdapter(DSPortAdapter adapter)
  {
    if (adapter == null) {
      throw new IllegalArgumentException("Adapter cannot be null");
    }
    synchronized (this.sync_flag)
    {
      this.adapter = adapter;

      if (this.paths == null)
        this.paths = new Vector();
      else
        this.paths.setSize(0);
      this.paths.addElement(new OWPath(adapter));

      resetSearch();
    }
  }

  public void setBranchAutoSearching(boolean enabled)
  {
    this.branchAutoSearching = enabled;
  }

  public boolean getBranchAutoSearching()
  {
    return this.branchAutoSearching;
  }

  public void addBranch(OWPath path)
  {
    this.paths.addElement(path);
  }

  public OWPath getDevicePath(Long address)
  {
    synchronized (this.devicePathHash)
    {
      return (OWPath)this.devicePathHash.get(address);
    }
  }

  public void cleanUpStalePathReferences()
  {
    synchronized (this.devicePathHash)
    {
      Enumeration e = this.devicePathHash.keys();
      while (e.hasMoreElements())
      {
        Object o = e.nextElement();
        if (!this.deviceAddressHash.containsKey(o))
          this.devicePathHash.remove(o);
      }
    }
  }

  public void search(Vector arrivals, Vector departures)
    throws OneWireException, OneWireIOException
  {
    synchronized (this.sync_flag)
    {
      try
      {
        this.adapter.beginExclusive(true);

        this.adapter.setSearchAllDevices();
        this.adapter.targetAllFamilies();
        this.adapter.setSpeed(0);

        for (int j = 0; j < this.paths.size(); j++)
        {
          try
          {
            ((OWPath)this.paths.elementAt(j)).close();
          }
          catch (Exception e)
          {
          }
        }
        for (int i = 0; i < this.paths.size(); i++)
        {
          this.adapter.setNoResetSearch();

          boolean search_result = false;
          OWPath path = (OWPath)this.paths.elementAt(i);
          try
          {
            path.open();
          }
          catch (Exception e)
          {
            continue;
          }

          search_result = this.adapter.findFirstDevice();

          while (search_result)
          {
            Long longAddress = new Long(this.adapter.getAddressAsLong());

            if (!this.deviceAddressHash.containsKey(longAddress))
            {
              ??? = AbstractDeviceMonitor.getDeviceContainer(this.adapter, longAddress);

              if ((this.branchAutoSearching) && ((??? instanceof SwitchContainer)))
              {
                ??? = (SwitchContainer)???;
                byte[] state = ???.readDevice();
                for (int j = 0; j < ???.getNumberChannels(state); j++)
                {
                  OWPath tmp = new OWPath(this.adapter, path);
                  tmp.add(???, j);
                  if (!this.paths.contains(tmp)) {
                    this.paths.addElement(tmp);
                  }
                }
              }
              synchronized (this.devicePathHash)
              {
                this.devicePathHash.put(longAddress, path);
              }
              if (arrivals != null) {
                arrivals.addElement(longAddress);
              }
            }
            else if (!path.equals((OWPath)this.devicePathHash.get(longAddress)))
            {
              synchronized (this.devicePathHash)
              {
                this.devicePathHash.put(longAddress, path);
              }
              if (departures != null)
                departures.addElement(longAddress);
              if (arrivals != null) {
                arrivals.addElement(longAddress);
              }
            }

            this.deviceAddressHash.put(longAddress, new Integer(this.max_state_count));

            path.open();
            search_result = this.adapter.findNextDevice();
          }
        }
      }
      finally
      {
        this.adapter.endExclusive();
      }

      Enumeration device_enum = this.deviceAddressHash.keys();
      while (device_enum.hasMoreElements())
      {
        Long longAddress = (Long)device_enum.nextElement();

        int cnt = ((Integer)this.deviceAddressHash.get(longAddress)).intValue();
        if (cnt <= 0)
        {
          this.deviceAddressHash.remove(longAddress);
          if (departures != null) {
            departures.addElement(longAddress);
          }
        }
        else
        {
          this.deviceAddressHash.put(longAddress, new Integer(cnt - 1));
        }

      }

      if ((departures != null) && (departures.size() > 0))
        fireDepartureEvent(this.adapter, departures);
      if ((arrivals != null) && (arrivals.size() > 0))
        fireArrivalEvent(this.adapter, arrivals);
    }
  }
}