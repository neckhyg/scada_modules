package com.dalsemi.onewire.application.monitor;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import com.dalsemi.onewire.utils.OWPath;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

public class DeviceMonitor extends AbstractDeviceMonitor
{
  private OWPath defaultPath = null;

  public DeviceMonitor(DSPortAdapter adapter)
  {
    setAdapter(adapter);
  }

  public void setAdapter(DSPortAdapter adapter)
  {
    if (adapter == null) {
      throw new IllegalArgumentException("Adapter cannot be null");
    }
    synchronized (this.sync_flag)
    {
      this.adapter = adapter;
      this.defaultPath = new OWPath(adapter);

      resetSearch();
    }
  }

  public OWPath getDevicePath(Long address)
  {
    return this.defaultPath;
  }

  public void search(Vector arrivals, Vector departures)
    throws OneWireException, OneWireIOException
  {
    synchronized (this.sync_flag)
    {
      try
      {
        this.adapter.beginExclusive(true);

        this.adapter.setSearchAllDevices();
        this.adapter.targetAllFamilies();
        this.adapter.setSpeed(0);

        boolean search_result = this.adapter.findFirstDevice();

        while (search_result)
        {
          Long longAddress = new Long(this.adapter.getAddressAsLong());
          if ((!this.deviceAddressHash.containsKey(longAddress)) && (arrivals != null)) {
            arrivals.addElement(longAddress);
          }
          this.deviceAddressHash.put(longAddress, new Integer(this.max_state_count));

          search_result = this.adapter.findNextDevice();
        }
      }
      finally
      {
        this.adapter.endExclusive();
      }

      Enumeration device_enum = this.deviceAddressHash.keys();
      while (device_enum.hasMoreElements())
      {
        Long longAddress = (Long)device_enum.nextElement();

        int cnt = ((Integer)this.deviceAddressHash.get(longAddress)).intValue();
        if (cnt <= 0)
        {
          this.deviceAddressHash.remove(longAddress);
          if (departures != null) {
            departures.addElement(longAddress);
          }
          synchronized (AbstractDeviceMonitor.deviceContainerHash)
          {
            AbstractDeviceMonitor.deviceContainerHash.remove(longAddress);
          }

        }

        this.deviceAddressHash.put(longAddress, new Integer(cnt - 1));
      }

      if ((arrivals != null) && (arrivals.size() > 0))
        fireArrivalEvent(this.adapter, arrivals);
      if ((departures != null) && (departures.size() > 0))
        fireDepartureEvent(this.adapter, departures);
    }
  }
}