package com.dalsemi.onewire.application.monitor;

public abstract interface DeviceMonitorEventListener
{
  public abstract void deviceArrival(DeviceMonitorEvent paramDeviceMonitorEvent);

  public abstract void deviceDeparture(DeviceMonitorEvent paramDeviceMonitorEvent);

  public abstract void networkException(DeviceMonitorException paramDeviceMonitorException);
}