package com.dalsemi.onewire.application.monitor;

import com.dalsemi.onewire.adapter.DSPortAdapter;

public class DeviceMonitorException extends Exception
{
  protected AbstractDeviceMonitor deviceMonitor = null;

  protected DSPortAdapter adapter = null;
  protected Exception exception;

  DeviceMonitorException(AbstractDeviceMonitor deviceMonitor, DSPortAdapter adapter, Exception exception)
  {
    super("Device Monitor Exception");
    this.deviceMonitor = deviceMonitor;
    this.adapter = adapter;
    this.exception = exception;
  }

  public AbstractDeviceMonitor getMonitor()
  {
    return this.deviceMonitor;
  }

  public DSPortAdapter getAdapter()
  {
    return this.adapter;
  }

  public Exception getException()
  {
    return this.exception;
  }

  public void throwException()
    throws Exception
  {
    throw this.exception;
  }

  public String toString()
  {
    return "Device Monitor Exception: " + this.exception.toString();
  }
}