package com.dalsemi.onewire.application.file;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import com.dalsemi.onewire.container.OneWireContainer;
import com.dalsemi.onewire.container.PagedMemoryBank;
import com.dalsemi.onewire.utils.Address;
import com.dalsemi.onewire.utils.Bit;
import com.dalsemi.onewire.utils.Convert;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Hashtable;
import java.util.Vector;

public class OWFileDescriptor
{
  private static Hashtable memoryCacheHash = new Hashtable(4);
  private static final byte EXT_DIRECTORY = 127;
  private static final byte EXT_UNKNOWN = 126;
  private static final int BM_CACHE = 0;
  private static final int BM_LOCAL = 1;
  private static final int BM_FILE = 2;
  private static final int PAGE_USED = 1;
  private static final int PAGE_NOT_USED = 0;
  private static final int LEN_FILENAME = 5;
  private static final boolean doDebugMessages = false;
  private Long address;
  private MemoryCache cache;
  private OneWireContainer[] owd;
  private String rawPath;
  private Vector path;
  private Vector verbosePath;
  private int fePage;
  private int feOffset;
  private byte[] feData;
  private int feLen;
  private int feNumPages;
  private int feStartPage;
  private int feParentPage;
  private int feParentOffset;
  private int lastPage;
  private int lastOffset;
  private int lastLen;
  private byte[] lastPageData;
  private int filePosition;
  private int markPosition;
  private int markLimit;
  private int totalPages;
  private int rootTotalPages;
  private int maxDataLen;
  private int LEN_PAGE_PTR;
  private int LEN_FILE_ENTRY;
  private int LEN_CONTROL_DATA;
  private boolean openedToWrite;
  private int lastFreePage;
  private int bitmapType;
  private byte[] pbm;
  private int pbmByteOffset;
  private int pbmBitOffset;
  private int pbmStartPage;
  private int pbmNumPages;
  private byte[] tempPage;
  private byte[] initName = { 32, 32, 32, 32, 126 };
  private byte[] smallBuf;
  private byte[] dmBuf;
  private byte[] addrBuf;

  public OWFileDescriptor()
  {
  }

  protected OWFileDescriptor(OneWireContainer owd, String newPath)
  {
    OneWireContainer[] devices = new OneWireContainer[1];
    devices[0] = owd;

    setupFD(devices, newPath);
  }

  protected OWFileDescriptor(OneWireContainer[] owd, String newPath)
  {
    setupFD(owd, newPath);
  }

  protected void setupFD(OneWireContainer[] owd, String newPath)
  {
    synchronized (memoryCacheHash)
    {
      this.owd = owd;

      if (newPath != null)
        this.rawPath = newPath.toUpperCase();
      else {
        this.rawPath = "";
      }

      this.address = new Long(owd[0].getAddressAsLong());
      this.cache = ((MemoryCache)memoryCacheHash.get(this.address));

      if (this.cache == null)
      {
        this.cache = new MemoryCache(owd);

        memoryCacheHash.put(this.address, this.cache);
      }

      this.cache.addOwner(this);

      this.totalPages = this.cache.getNumberPages();
      this.rootTotalPages = this.cache.getNumberPagesInBank(0);
      this.maxDataLen = this.cache.getMaxPacketDataLength();
      this.openedToWrite = false;

      this.lastPageData = new byte[this.maxDataLen];
      this.tempPage = new byte[this.lastPageData.length];
      this.feData = new byte[this.lastPageData.length];
      this.dmBuf = new byte[this.lastPageData.length];
      this.smallBuf = new byte[10];
      this.addrBuf = new byte[8];

      this.LEN_PAGE_PTR = (this.totalPages > 256 ? 2 : 1);

      this.LEN_FILE_ENTRY = (5 + this.LEN_PAGE_PTR * 2);
      this.LEN_CONTROL_DATA = (6 + this.LEN_PAGE_PTR);

      if (this.cache.handlePageBitmap()) {
        this.bitmapType = 0;
      } else if (this.totalPages <= 32)
      {
        this.bitmapType = 1;

        this.pbm = new byte[this.maxDataLen];
        this.pbmByteOffset = 3;
        this.pbmBitOffset = 0;
      }
      else
      {
        this.bitmapType = 2;

        this.pbm = new byte[this.totalPages / 8 + this.LEN_PAGE_PTR];
        this.pbmByteOffset = 0;
        this.pbmBitOffset = 0;
      }
      this.pbmStartPage = -1;

      this.verbosePath = new Vector(3);

      if (!parsePath(this.rawPath, this.verbosePath)) {
        return;
      }

      this.path = new Vector(this.verbosePath.size());

      for (int element_num = 0; element_num < this.verbosePath.size(); )
      {
        byte[] element = (byte[])this.verbosePath.elementAt(element_num);

        if ((element[0] == 46) && (element[1] == 46))
        {
          if (this.path.size() > 0) {
            this.path.removeElementAt(this.path.size() - 1);
          }
          else {
            this.path = null;
            break;
          }

        }
        else if (element[0] != 46)
        {
          this.path.addElement(element);
        }
        element_num++;
      }
    }
  }

  public boolean valid()
  {
    synchronized (this.cache)
    {
      return this.cache != null ? 1 : 0;
    }
  }

  public void sync()
    throws OWSyncFailedException
  {
    try
    {
      synchronized (this.cache)
      {
        this.cache.clearLastPageRead();

        this.cache.sync();
      }
    }
    catch (OneWireIOException e)
    {
      throw new OWSyncFailedException(e.toString());
    }
    catch (OneWireException e)
    {
      throw new OWSyncFailedException(e.toString());
    }
  }

  protected void open()
    throws OWFileNotFoundException
  {
    String last_error = null;
    int cnt = 0;

    synchronized (this.cache)
    {
      this.cache.clearLastPageRead();

      this.lastPage = -1;

      if (this.path == null) {
        throw new OWFileNotFoundException("Invalid path");
      }

      if (this.path.size() == 0) {
        throw new OWFileNotFoundException("Invalid path, no elements");
      }

      if (this.feStartPage <= 0)
      {
        do
        {
          try
          {
            if (verifyPath(this.path.size()))
              return;
          }
          catch (OneWireException e)
          {
            last_error = e.toString();
          }
        }
        while (cnt++ < 2);

        throw new OWFileNotFoundException(last_error);
      }
    }
  }

  protected void close()
    throws IOException
  {
    synchronized (this.cache)
    {
      try
      {
        sync();
      }
      catch (OWSyncFailedException e)
      {
        throw new IOException(e.toString());
      }

      free();
    }
  }

  protected void create(boolean append, boolean isDirectory, boolean makeParents, int startPage, int numberPages)
    throws OWFileNotFoundException
  {
    synchronized (this.cache)
    {
      this.cache.clearLastPageRead();

      this.lastPage = -1;

      if (this.path == null) {
        throw new OWFileNotFoundException("Invalid path");
      }

      if (this.path.size() == 0)
        throw new OWFileNotFoundException("Invalid path, no elements");
      byte[] element;
      if ((isDirectory) || (makeParents))
      {
        element = (byte[])this.path.elementAt(this.path.size() - 1);

        if (((element[4] & 0x7F) != 126) && ((element[4] & 0x7F) != 127))
        {
          throw new OWFileNotFoundException("Invalid path, directory has an extension");
        }

      }

      if (!isDirectory)
      {
        if (this.cache.isOpenedToWrite(this.owd[0].getAddressAsString() + getPath(), true))
        {
          throw new OWFileNotFoundException("File already opened to write");
        }
        this.openedToWrite = true;
      }

      this.feStartPage = 0;
      boolean file_exists = false;
      byte[] prev_element = { 82, 79, 79, 84 };
      int prev_element_start = 0;

      for (int element_num = 0; element_num < this.path.size(); element_num++) {
        element = (byte[])this.path.elementAt(element_num);
        boolean element_found;
        try {
          element_found = findElement(this.feStartPage, element, 0);
        }
        catch (OneWireException e)
        {
          throw new OWFileNotFoundException(e.toString());
        }

        if (!element_found)
        {
          if (isDirectory)
          {
            if (element[4] == 126) {
              element[4] = 127;
            }
            if ((element_num != this.path.size() - 1) && (!makeParents)) {
              throw new OWFileNotFoundException("Invalid path, parent not found");
            }

            createEntry(element, startPage, numberPages, prev_element, prev_element_start);
          }
          else
          {
            if (element[4] == 126) {
              element[4] = 0;
            }
            if (element_num == this.path.size() - 1)
            {
              createEntry(element, startPage, numberPages, prev_element, prev_element_start);
            }
            else
            {
              this.cache.removeWriteOpen(this.owd[0].getAddressAsString() + getPath());
              throw new OWFileNotFoundException("Path not found");
            }
          }
        }
        else if (element_num == this.path.size() - 1)
        {
          if (isDirectory)
          {
            if (startPage != -1) {
              throw new OWFileNotFoundException("Destination File exists");
            }

          }
          else
          {
            if ((element[4] == 127) && (!isDirectory))
            {
              this.cache.removeWriteOpen(this.owd[0].getAddressAsString() + getPath());
              throw new OWFileNotFoundException("Filename provided is a directory!");
            }

            file_exists = true;
          }

        }

        this.feStartPage = Convert.toInt(this.feData, this.feOffset + 5, this.LEN_PAGE_PTR);

        this.feNumPages = Convert.toInt(this.feData, this.feOffset + 5 + this.LEN_PAGE_PTR, this.LEN_PAGE_PTR);

        prev_element = element;
        prev_element_start = this.feStartPage;
      }

      if (file_exists)
      {
        if (!canWrite()) {
          throw new OWFileNotFoundException("File is read only (access is denied)");
        }

        try
        {
          this.lastLen = this.cache.readPagePacket(this.feStartPage, this.lastPageData, 0);

          Convert.toByteArray(0, this.smallBuf, 0, this.LEN_PAGE_PTR);
          this.cache.writePagePacket(this.feStartPage, this.smallBuf, 0, this.LEN_PAGE_PTR);

          int next_page = Convert.toInt(this.lastPageData, this.lastLen - this.LEN_PAGE_PTR, this.LEN_PAGE_PTR);

          while (next_page != 0)
          {
            readBitMap();
            freePage(next_page);
            writeBitMap();

            this.lastLen = this.cache.readPagePacket(next_page, this.lastPageData, 0);

            next_page = Convert.toInt(this.lastPageData, this.lastLen - this.LEN_PAGE_PTR, this.LEN_PAGE_PTR);
          }

          this.feNumPages = 1;
          this.lastLen = this.cache.readPagePacket(this.fePage, this.lastPageData, 0);

          Convert.toByteArray(this.feNumPages, this.lastPageData, this.feOffset + 5 + this.LEN_PAGE_PTR, this.LEN_PAGE_PTR);

          this.cache.writePagePacket(this.fePage, this.lastPageData, 0, this.lastLen);

          this.lastPage = this.feStartPage;
        }
        catch (OneWireException e)
        {
          throw new OWFileNotFoundException(e.toString());
        }
      }
    }
  }

  protected void format()
    throws OneWireException, OneWireIOException
  {
    int cdcnt = 0; int dm_bytes = 0;

    synchronized (this.cache)
    {
      this.cache.clearLastPageRead();

      if (this.totalPages == 0) {
        throw new OneWireException("1-Wire Filesystem does not have memory");
      }
      for (int i = 0; i < this.feData.length; i++) {
        this.feData[i] = 0;
      }

      this.feData[cdcnt] = (this.LEN_PAGE_PTR == 1 ? 10 : 11);
      int tmp94_91 = (cdcnt++);
      byte[] tmp94_86 = this.feData; tmp94_86[tmp94_91] = (byte)(tmp94_86[tmp94_91] | (this.owd.length == 1 ? -96 : 176));

      cdcnt += this.LEN_PAGE_PTR;

      if (this.cache.handlePageBitmap())
      {
        this.bitmapType = 0;
        this.feData[(cdcnt++)] = 0;

        Convert.toByteArray(this.cache.getBitMapPageNumber(), this.feData, cdcnt, this.LEN_PAGE_PTR);

        cdcnt += this.LEN_PAGE_PTR;
        Convert.toByteArray(this.cache.getBitMapNumberOfPages(), this.feData, cdcnt, this.LEN_PAGE_PTR);
      }
      else
      {
        int device_map_pages;
        if (this.owd.length > 1)
        {
          dm_bytes = (this.owd.length - 1) * 8;
          device_map_pages = dm_bytes / (this.maxDataLen - this.LEN_PAGE_PTR);
          if (dm_bytes % (this.maxDataLen - this.LEN_PAGE_PTR) > 0)
            device_map_pages++;
        }
        else {
          device_map_pages = 0;
        }
        int j;
        int cnt;
        int len;
        int next_page;
        if (this.totalPages <= 32)
        {
          this.bitmapType = 1;

          this.pbm = new byte[this.maxDataLen];
          this.pbmByteOffset = 3;
          this.pbmBitOffset = 0;

          this.feData[(cdcnt++)] = (this.owd.length > 1 ? -126 : -128);

          if (device_map_pages >= this.rootTotalPages) {
            throw new OneWireException("ROOT 1-Wire device does not have memory to support this many SATELLITE devices");
          }

          for (i = 0; i <= device_map_pages; i++) {
            Bit.arrayWriteBit(1, i, cdcnt, this.feData);
          }

          if (this.owd.length > 1)
          {
            this.tempPage[0] = this.feData[0];
            this.tempPage[this.LEN_PAGE_PTR] = 0;
            this.tempPage[1] = 1;
            this.tempPage[(this.LEN_PAGE_PTR + 1)] = -128;
            for (j = 2; j <= 5; j++)
              this.tempPage[(this.LEN_PAGE_PTR + j)] = -1;
            for (j = 6; j <= 7; j++) {
              this.tempPage[(this.LEN_PAGE_PTR + j)] = 0;
            }

            System.arraycopy(this.owd[0].getAddress(), 0, this.smallBuf, 0, 8);
            this.smallBuf[8] = 0;
            this.smallBuf[9] = 0;

            for (i = 1; i < this.owd.length; i++)
            {
              this.cache.writePagePacket(this.cache.getPageOffsetForDevice(i), this.tempPage, 0, this.LEN_PAGE_PTR * 2 + 6);
              Bit.arrayWriteBit(1, this.cache.getPageOffsetForDevice(i), cdcnt, this.feData);

              this.cache.writePagePacket(this.cache.getPageOffsetForDevice(i) + 1, this.smallBuf, 0, this.LEN_PAGE_PTR + 8);
              Bit.arrayWriteBit(1, this.cache.getPageOffsetForDevice(i) + 1, cdcnt, this.feData);
            }
          }

        }
        else
        {
          this.bitmapType = 2;
          this.pbmByteOffset = 0;
          this.pbmBitOffset = 0;

          int pbm_bytes = this.totalPages / 8;
          int pgs = pbm_bytes / (this.maxDataLen - this.LEN_PAGE_PTR);

          if (pbm_bytes % (this.maxDataLen - this.LEN_PAGE_PTR) > 0) {
            pgs++;
          }

          if (device_map_pages + pgs >= this.rootTotalPages) {
            throw new OneWireException("ROOT 1-Wire device does not have memory to support this many SATELLITE devices");
          }

          this.feData[(cdcnt++)] = (this.owd.length > 1 ? 2 : 0);

          if (this.LEN_PAGE_PTR == 1)
          {
            this.feData[(cdcnt++)] = 0;
            this.feData[(cdcnt++)] = 0;
          }
          Convert.toByteArray(device_map_pages + 1, this.feData, cdcnt, this.LEN_PAGE_PTR);

          cdcnt += this.LEN_PAGE_PTR;
          Convert.toByteArray(pgs, this.feData, cdcnt, this.LEN_PAGE_PTR);

          for (i = 0; i < this.pbm.length; i++) {
            this.pbm[i] = 0;
          }

          for (i = 0; i <= pgs + device_map_pages; i++) {
            Bit.arrayWriteBit(1, this.pbmBitOffset + i, this.pbmByteOffset, this.pbm);
          }

          if (this.owd.length > 1)
          {
            this.tempPage[0] = this.feData[0];
            this.tempPage[this.LEN_PAGE_PTR] = 0;
            this.tempPage[1] = 1;
            this.tempPage[(this.LEN_PAGE_PTR + 1)] = -128;
            for (j = 2; j <= 5; j++)
              this.tempPage[(this.LEN_PAGE_PTR + j)] = -1;
            for (j = 6; j <= 7; j++) {
              this.tempPage[(this.LEN_PAGE_PTR + j)] = 0;
            }

            System.arraycopy(this.owd[0].getAddress(), 0, this.smallBuf, 0, 8);
            this.smallBuf[8] = 0;
            this.smallBuf[9] = 0;

            for (i = 1; i < this.owd.length; i++)
            {
              this.cache.writePagePacket(this.cache.getPageOffsetForDevice(i), this.tempPage, 0, this.LEN_PAGE_PTR * 2 + 6);
              Bit.arrayWriteBit(1, this.pbmBitOffset + this.cache.getPageOffsetForDevice(i), this.pbmByteOffset, this.pbm);

              this.cache.writePagePacket(this.cache.getPageOffsetForDevice(i) + 1, this.smallBuf, 0, this.LEN_PAGE_PTR + 8);
              Bit.arrayWriteBit(1, this.pbmBitOffset + this.cache.getPageOffsetForDevice(i) + 1, this.pbmByteOffset, this.pbm);
            }

          }

          cnt = 0;
          for (i = device_map_pages + 1; i <= pgs + device_map_pages; i++)
          {
            if (pbm_bytes - cnt > this.maxDataLen - this.LEN_PAGE_PTR)
              len = this.maxDataLen - this.LEN_PAGE_PTR;
            else {
              len = pbm_bytes - cnt;
            }

            System.arraycopy(this.pbm, this.pbmByteOffset + cnt, this.tempPage, 0, len);

            next_page = i == pgs + device_map_pages ? 0 : i + 1;

            Convert.toByteArray(next_page, this.tempPage, len, this.LEN_PAGE_PTR);

            this.cache.writePagePacket(i, this.tempPage, 0, len + this.LEN_PAGE_PTR);

            cnt += len;
          }

        }

        if (this.owd.length > 1)
        {
          Convert.toByteArray(1, this.feData, 1, this.LEN_PAGE_PTR);

          byte[] dmf = new byte[dm_bytes];
          for (i = 1; i < this.owd.length; i++) {
            System.arraycopy(this.owd[i].getAddress(), 0, dmf, (i - 1) * 8, 8);
          }

          cnt = 0;
          for (i = 1; i <= device_map_pages; i++)
          {
            if (dm_bytes - cnt > this.maxDataLen - this.LEN_PAGE_PTR)
              len = this.maxDataLen - this.LEN_PAGE_PTR;
            else {
              len = dm_bytes - cnt;
            }

            System.arraycopy(dmf, cnt, this.tempPage, 0, len);

            next_page = i == device_map_pages ? 0 : i + 1;

            Convert.toByteArray(next_page, this.tempPage, len, this.LEN_PAGE_PTR);

            this.cache.writePagePacket(i, this.tempPage, 0, len + this.LEN_PAGE_PTR);

            cnt += len;
          }
        }

      }

      this.cache.writePagePacket(0, this.feData, 0, this.LEN_CONTROL_DATA + this.LEN_PAGE_PTR);

      if (this.cache.handlePageBitmap()) {
        markPageUsed(0);
      }
      this.fePage = 0;
      this.feLen = (this.LEN_CONTROL_DATA + this.LEN_PAGE_PTR);
    }
  }

  protected int read(byte[] b, int off, int len)
    throws IOException
  {
    int read_count = 0; int next_page = 0;

    synchronized (this.cache)
    {
      this.cache.clearLastPageRead();

      if (this.lastPage == -1)
      {
        this.lastPage = this.feStartPage;
        this.lastOffset = 0;
        this.filePosition = 0;

        fetchPage();
      }

      do
      {
        if (this.lastOffset + this.LEN_PAGE_PTR >= this.lastLen)
        {
          next_page = Convert.toInt(this.lastPageData, this.lastLen - this.LEN_PAGE_PTR, this.LEN_PAGE_PTR);

          if (next_page == 0)
          {
            break;
          }
          this.lastPage = next_page;

          fetchPage();
        }
        int page_data_read;
        if (len >= this.lastLen - this.lastOffset - this.LEN_PAGE_PTR)
          page_data_read = this.lastLen - this.lastOffset - this.LEN_PAGE_PTR;
        else {
          page_data_read = len;
        }

        if (b != null) {
          System.arraycopy(this.lastPageData, this.lastOffset, b, off, page_data_read);
        }

        read_count += page_data_read;
        off += page_data_read;
        len -= page_data_read;
        this.lastOffset += page_data_read;
        this.filePosition += page_data_read;
        next_page = Convert.toInt(this.lastPageData, this.lastLen - this.LEN_PAGE_PTR, this.LEN_PAGE_PTR);
      }

      while ((len != 0) && (next_page != 0));

      if ((read_count == 0) && (len != 0)) {
        return -1;
      }

      return read_count;
    }
  }

  protected int read()
    throws IOException
  {
    synchronized (this.cache)
    {
      int len = read(this.smallBuf, 0, 1);

      if (len == 1) {
        return this.smallBuf[0] & 0xFF;
      }
      return -1;
    }
  }

  protected long skip(long n)
    throws IOException
  {
    synchronized (this.cache)
    {
      return read(null, 0, (int)n);
    }
  }

  protected int available()
    throws IOException
  {
    synchronized (this.cache)
    {
      if (this.lastPage == -1) {
        return 0;
      }
      return this.lastLen - this.lastOffset - 1;
    }
  }

  protected void write(int b)
    throws IOException
  {
    synchronized (this.cache)
    {
      this.smallBuf[0] = (byte)b;

      write(this.smallBuf, 0, 1);
    }
  }

  protected void write(byte[] b, int off, int len)
    throws IOException
  {
    synchronized (this.cache)
    {
      if (len == 0) {
        return;
      }

      this.cache.clearLastPageRead();

      if (this.lastPage == -1)
      {
        this.lastPage = this.feStartPage;
        this.lastOffset = 0;
        this.filePosition = 0;
      }

      try
      {
        this.lastLen = this.cache.readPagePacket(this.lastPage, this.lastPageData, 0);
        do
        {
          if (this.lastLen >= this.maxDataLen)
          {
            readBitMap();

            int new_page = getFirstFreePage(false);

            if (new_page < 0)
            {
              try
              {
                sync();
              }
              catch (OWSyncFailedException e)
              {
              }

              throw new IOException("Out of space on 1-Wire device");
            }

            markPageUsed(new_page);

            Convert.toByteArray(0, this.tempPage, 0, this.LEN_PAGE_PTR);
            this.cache.writePagePacket(new_page, this.tempPage, 0, this.LEN_PAGE_PTR);

            Convert.toByteArray(new_page, this.lastPageData, this.lastLen - this.LEN_PAGE_PTR, this.LEN_PAGE_PTR);

            this.cache.writePagePacket(this.lastPage, this.lastPageData, 0, this.lastLen);

            writeBitMap();

            this.lastLen = this.cache.readPagePacket(this.fePage, this.lastPageData, 0);

            Convert.toByteArray(++this.feNumPages, this.lastPageData, this.feOffset + 5 + this.LEN_PAGE_PTR, this.LEN_PAGE_PTR);

            this.cache.writePagePacket(this.fePage, this.lastPageData, 0, this.lastLen);

            this.lastPageData[0] = 0;
            this.lastPage = new_page;
            this.lastLen = this.LEN_PAGE_PTR;
          }
          int write_len;
          if (len > this.maxDataLen - this.lastLen)
            write_len = this.maxDataLen - this.lastLen;
          else {
            write_len = len;
          }

          System.arraycopy(b, off, this.lastPageData, this.lastLen - this.LEN_PAGE_PTR, write_len);

          len -= write_len;
          off += write_len;
          this.lastLen += write_len;

          Convert.toByteArray(0, this.lastPageData, this.lastLen - this.LEN_PAGE_PTR, this.LEN_PAGE_PTR);

          this.cache.writePagePacket(this.lastPage, this.lastPageData, 0, this.lastLen);
        }
        while (len > 0);
      }
      catch (OneWireException e)
      {
        throw new IOException(e.toString());
      }
    }
  }

  protected String getName()
  {
    synchronized (this.cache)
    {
      return pathToString(this.path, this.path.size() - 1, this.path.size(), true);
    }
  }

  protected String getParent()
  {
    synchronized (this.cache)
    {
      if (this.path == null) {
        throw new NullPointerException("path is not valid");
      }
      if (this.path.size() >= 1) {
        return pathToString(this.path, 0, this.path.size() - 1, false);
      }
      return null;
    }
  }

  protected String getPath()
  {
    synchronized (this.cache)
    {
      if (this.path == null) {
        throw new NullPointerException("path is not valid");
      }
      return pathToString(this.verbosePath, 0, this.verbosePath.size(), false);
    }
  }

  protected boolean exists()
  {
    synchronized (this.cache)
    {
      this.cache.clearLastPageRead();
      int i;
      if ((this.path != null) && (this.path.size() == 0))
      {
        if (this.pbmStartPage == -1)
        {
          try
          {
            readBitMap();
          }
          catch (OneWireException e)
          {
            return 0;
          }
        }

        return 1;
      }

      try
      {
        open();

        return 1;
      }
      catch (OWFileNotFoundException e)
      {
        return 0;
      }
    }
  }

  protected boolean canRead()
  {
    synchronized (this.cache)
    {
      return exists();
    }
  }

  protected boolean canWrite()
  {
    synchronized (this.cache)
    {
      int i;
      if (exists())
      {
        if (isFile()) {
          return (this.feData[(this.feOffset + 5 - 1)] & 0x80) == 0 ? 1 : 0;
        }
        return 1;
      }

      return 0;
    }
  }

  protected boolean isDirectory()
  {
    synchronized (this.cache)
    {
      if (exists()) {
        return !isFile() ? 1 : 0;
      }
      return 0;
    }
  }

  protected boolean isFile()
  {
    synchronized (this.cache)
    {
      if (this.path.size() == 0) {
        return 0;
      }
      if (exists()) {
        return (this.feData[(this.feOffset + 5 - 1)] & 0x7F) != 127 ? 1 : 0;
      }
      return 0;
    }
  }

  protected boolean isHidden()
  {
    synchronized (this.cache)
    {
      byte[] fl;
      if (exists())
      {
        if (this.path.size() > 0)
        {
          if (isDirectory())
          {
            fl = (byte[])this.path.elementAt(this.path.size() - 1);

            return (fl[4] & 0x80) != 0 ? 1 : 0;
          }
        }
      }

      return 0;
    }
  }

  protected long length()
  {
    synchronized (this.cache)
    {
      if (exists()) {
        return this.feNumPages * (this.maxDataLen - this.LEN_PAGE_PTR);
      }
      return 0L;
    }
  }

  protected boolean delete()
  {
    synchronized (this.cache)
    {
      this.cache.clearLastPageRead();
      int i;
      if (isFile())
      {
        try
        {
          System.arraycopy(this.feData, this.feOffset + this.LEN_FILE_ENTRY, this.feData, this.feOffset, this.feLen - this.feOffset - this.LEN_FILE_ENTRY);

          this.feLen -= this.LEN_FILE_ENTRY;

          this.cache.writePagePacket(this.fePage, this.feData, 0, this.feLen);
          int next_page;
          if (this.bitmapType != 0)
          {
            next_page = this.feStartPage;

            while (next_page != 0)
            {
              readBitMap();
              freePage(next_page);
              writeBitMap();

              this.lastLen = this.cache.readPagePacket(next_page, this.lastPageData, 0);

              next_page = Convert.toInt(this.lastPageData, this.lastLen - this.LEN_PAGE_PTR, this.LEN_PAGE_PTR);
            }

            this.lastPage = -1;
            this.feStartPage = -1;
          }

          return 1;
        }
        catch (OneWireException e)
        {
          return 0;
        }
      }
      if (isDirectory())
      {
        try
        {
          int len = this.cache.readPagePacket(this.feStartPage, this.tempPage, 0);

          if (len != this.LEN_CONTROL_DATA + this.LEN_PAGE_PTR) {
            return 0;
          }

          System.arraycopy(this.feData, this.feOffset + this.LEN_CONTROL_DATA, this.feData, this.feOffset, this.feLen - this.feOffset - this.LEN_CONTROL_DATA);

          this.feLen -= this.LEN_CONTROL_DATA;

          this.cache.writePagePacket(this.fePage, this.feData, 0, this.feLen);

          readBitMap();
          freePage(this.feStartPage);
          writeBitMap();

          return 1;
        }
        catch (OneWireException e)
        {
          return 0;
        }

      }

      return 0;
    }
  }

  protected String[] list()
  {
    synchronized (this.cache)
    {
      this.cache.clearLastPageRead();
      Vector entries;
      if (isDirectory())
      {
        entries = new Vector(1);
        int offset;
        try
        {
          int next_page = this.feStartPage;
          StringBuffer build_buffer = new StringBuffer();
          offset = this.LEN_CONTROL_DATA;
          do
          {
            int page = next_page;

            int len = this.cache.readPagePacket(page, this.tempPage, 0);

            for (; offset < len - this.LEN_PAGE_PTR; offset += this.LEN_FILE_ENTRY)
            {
              build_buffer.setLength(0);

              for (int i = 0; i < 4; i++)
              {
                if (this.tempPage[(offset + i)] == 32) break;
                build_buffer.append((char)this.tempPage[(offset + i)]);
              }

              if ((byte)(this.tempPage[(offset + 4)] & 0x7F) != 127) {
                build_buffer.append("." + Integer.toString(this.tempPage[(offset + 4)] & 0x7F));
              }

              if (this.tempPage[(offset + 4)] == -1)
                continue;
              entries.addElement(build_buffer.toString());
            }

            next_page = Convert.toInt(this.tempPage, len - this.LEN_PAGE_PTR, this.LEN_PAGE_PTR);

            offset = 0;

            if (entries.size() > this.totalPages) {
              return null;
            }

          }

          while (next_page != 0);
        }
        catch (OneWireException e)
        {
        }

        String[] strs = new String[entries.size()];
        for (int i = 0; i < strs.length; i++)
          strs[i] = ((String)entries.elementAt(i));
        return strs;
      }

      return null;
    }
  }

  protected boolean renameTo(OWFile dest)
  {
    if (dest == null) {
      throw new NullPointerException("Desitination file is null");
    }
    synchronized (this.cache)
    {
      if (!exists()) {
        return 0;
      }

      try
      {
        OWFileDescriptor dest_fd = dest.getFD();

        dest_fd.create(false, isDirectory(), false, this.feStartPage, this.feNumPages);

        this.feLen = this.cache.readPagePacket(this.fePage, this.feData, 0);
        System.arraycopy(this.feData, this.feOffset + this.LEN_FILE_ENTRY, this.feData, this.feOffset, this.feLen - this.feOffset - this.LEN_FILE_ENTRY);

        this.feLen -= this.LEN_FILE_ENTRY;
        this.cache.writePagePacket(this.fePage, this.feData, 0, this.feLen);

        this.feStartPage = -1;
        try
        {
          open();
        }
        catch (OWFileNotFoundException e)
        {
        }

        return 1;
      }
      catch (IOException e)
      {
        return 0;
      }
      catch (OneWireException e)
      {
        return 0;
      }
    }
  }

  protected boolean setReadOnly()
  {
    synchronized (this.cache)
    {
      if (isFile())
      {
        int tmp26_25 = (this.feOffset + 5 - 1);
        byte[] tmp26_15 = this.feData; tmp26_15[tmp26_25] = (byte)(tmp26_15[tmp26_25] | 0x80);
        try
        {
          this.cache.writePagePacket(this.fePage, this.feData, 0, this.feLen);
        }
        catch (OneWireException e)
        {
          return 0;
        }

        return 1;
      }

      return 0;
    }
  }

  protected void mark(int readlimit)
  {
    synchronized (this.cache)
    {
      this.markPosition = this.filePosition;
      this.markLimit = readlimit;
    }
  }

  protected void reset()
    throws IOException
  {
    synchronized (this.cache)
    {
      if (this.filePosition - this.markPosition > this.markLimit) {
        throw new IOException("File read beyond mark readlimit");
      }

      this.lastPage = -1;

      skip(this.markPosition);
    }
  }

  protected void markPageUsed(int page)
    throws OneWireException
  {
    synchronized (this.cache)
    {
      if (this.bitmapType == 0) {
        this.cache.markPageUsed(page);
      }
      else
      {
        Bit.arrayWriteBit(1, this.pbmBitOffset + page, this.pbmByteOffset, this.pbm);
      }
    }
  }

  protected boolean freePage(int page)
    throws OneWireException
  {
    synchronized (this.cache)
    {
      if (this.bitmapType == 0) {
        return this.cache.freePage(page);
      }

      Bit.arrayWriteBit(0, this.pbmBitOffset + page, this.pbmByteOffset, this.pbm);

      return 1;
    }
  }

  protected int getFirstFreePage(boolean counterPage)
    throws OneWireException
  {
    synchronized (this.cache)
    {
      if (this.bitmapType == 0) {
        return this.cache.getFirstFreePage();
      }

      this.lastFreePage = 0;

      return getNextFreePage(counterPage);
    }
  }

  protected int getNextFreePage(boolean counterPage)
    throws OneWireException
  {
    synchronized (this.cache)
    {
      if (this.bitmapType == 0)
        return this.cache.getNextFreePage();
      PagedMemoryBank pmb;
      for (int pg = this.lastFreePage; pg < this.totalPages; pg++)
      {
        if (Bit.arrayReadBit(this.pbmBitOffset + pg, this.pbmByteOffset, this.pbm) != 0)
        {
          continue;
        }
        if (counterPage)
        {
          pmb = getMemoryBankForPage(pg);
          if ((!pmb.hasExtraInfo()) || (pg == 8))
            continue;
          String ex_info = pmb.getExtraInfoDescription();
          if ((ex_info.indexOf("counter") > -1) || (ex_info.indexOf("MAC") > -1))
          {
            return pg;
          }

        }
        else
        {
          this.lastFreePage = (pg + 1);

          return pg;
        }
      }

      return -1;
    }
  }

  protected int getFreeMemory()
    throws OneWireException
  {
    synchronized (this.cache)
    {
      this.cache.clearLastPageRead();

      if (this.bitmapType == 0) {
        return this.cache.getNumberFreePages() * (this.maxDataLen - this.LEN_PAGE_PTR);
      }

      readBitMap();

      int free_pages = 0;
      for (int pg = 0; pg < this.totalPages; pg++)
      {
        if (Bit.arrayReadBit(this.pbmBitOffset + pg, this.pbmByteOffset, this.pbm) != 0)
          continue;
        free_pages++;
      }

      return free_pages * (this.maxDataLen - this.LEN_PAGE_PTR);
    }
  }

  protected void writeBitMap()
    throws OneWireException
  {
    synchronized (this.cache)
    {
      this.cache.clearLastPageRead();

      if (this.bitmapType == 1)
      {
        int pg_len = this.cache.readPagePacket(0, this.tempPage, 0);

        for (int i = 3; i < 7; i++)
        {
          if ((this.tempPage[i] & 0xFF) == (this.pbm[i] & 0xFF))
            continue;
          System.arraycopy(this.pbm, 3, this.tempPage, 3, 4);
          this.cache.writePagePacket(0, this.tempPage, 0, pg_len);
          break;
        }

      }
      else if (this.bitmapType == 2)
      {
        int offset = 0; int pg = this.pbmStartPage;

        for (int pg_cnt = 0; pg_cnt < this.pbmNumPages; pg_cnt++)
        {
          int len = this.cache.readPagePacket(pg, this.tempPage, 0);

          for (int i = 0; i < len - this.LEN_PAGE_PTR; i++)
          {
            if ((this.tempPage[i] & 0xFF) == (this.pbm[(i + offset)] & 0xFF)) {
              continue;
            }
            System.arraycopy(this.pbm, offset, this.tempPage, 0, len - this.LEN_PAGE_PTR);

            this.cache.writePagePacket(pg, this.tempPage, 0, len);

            break;
          }

          pg = Convert.toInt(this.tempPage, len - this.LEN_PAGE_PTR, this.LEN_PAGE_PTR);
          offset += len - this.LEN_PAGE_PTR;
        }
      }
    }
  }

  protected void readBitMap()
    throws OneWireException
  {
    synchronized (this.cache)
    {
      this.cache.clearLastPageRead();

      if (this.pbmStartPage == -1)
      {
        this.fePage = 0;
        this.feLen = this.cache.readPagePacket(this.fePage, this.feData, 0);
        validateFileSystem();
      }

      if (this.bitmapType == 1)
      {
        this.cache.readPagePacket(0, this.pbm, 0);
      }
      else if (this.bitmapType == 2)
      {
        int offset = 0; int pg = this.pbmStartPage;

        for (int pg_cnt = 0; pg_cnt < this.pbmNumPages; pg_cnt++)
        {
          int len = this.cache.readPagePacket(pg, this.pbm, offset);
          pg = Convert.toInt(this.pbm, offset + len - this.LEN_PAGE_PTR, this.LEN_PAGE_PTR);
          offset += len - this.LEN_PAGE_PTR;
        }
      }
    }
  }

  protected int[] getPageList()
    throws OneWireException
  {
    int[] page_list = new int[this.feNumPages + 10];
    int cnt = 0;
    int next_page = this.feStartPage;

    this.cache.clearLastPageRead();
    do
    {
      if (cnt >= page_list.length)
      {
        int[] temp = new int[page_list.length + 10];
        System.arraycopy(page_list, 0, temp, 0, page_list.length);
        page_list = temp;
      }

      page_list[(cnt++)] = next_page;

      int len = this.cache.readPagePacket(next_page, this.tempPage, 0);

      next_page = Convert.toInt(this.tempPage, len - this.LEN_PAGE_PTR, this.LEN_PAGE_PTR);

      if (cnt > this.totalPages)
        throw new OneWireException("Error in Filesystem, looping pointers");
    }
    while (next_page != 0);

    int[] rt_array = new int[cnt];
    System.arraycopy(page_list, 0, rt_array, 0, cnt);

    return rt_array;
  }

  protected int getStartPage()
    throws IOException
  {
    return this.feStartPage;
  }

  protected PagedMemoryBank getMemoryBankForPage(int page)
  {
    return this.cache.getMemoryBankForPage(page);
  }

  protected int getLocalPage(int page)
  {
    return this.cache.getLocalPage(page);
  }

  private String pathToString(Vector tempPath, int beginIndex, int endIndex, boolean single)
  {
    if (beginIndex < 0) {
      return null;
    }

    StringBuffer build_buffer = new StringBuffer(single ? "" : "/");

    for (int element = beginIndex; element < endIndex; element++)
    {
      byte[] name = (byte[])tempPath.elementAt(element);

      if ((!single) && (element != beginIndex)) {
        build_buffer.append('/');
      }
      for (int i = 0; i < 4; i++)
      {
        if (name[i] == 32) break;
        build_buffer.append((char)name[i]);
      }

      if (((byte)(name[4] & 0x7F) == 127) || (name[4] == 126))
        continue;
      build_buffer.append("." + Integer.toString(name[4] & 0x7F));
    }

    if (build_buffer.length() == 0) {
      return null;
    }
    return build_buffer.toString();
  }

  private boolean verifyPath(int depth)
    throws OneWireException
  {
    this.feStartPage = 0;

    for (int element_num = 0; element_num < depth; element_num++)
    {
      byte[] element = (byte[])this.path.elementAt(element_num);

      this.feParentPage = this.feStartPage;
      this.feParentOffset = this.feOffset;

      if (!findElement(this.feStartPage, element, 0)) {
        return false;
      }

      this.feStartPage = Convert.toInt(this.feData, this.feOffset + 5, this.LEN_PAGE_PTR);

      this.feNumPages = Convert.toInt(this.feData, this.feOffset + 5 + this.LEN_PAGE_PTR, this.LEN_PAGE_PTR);
    }

    return true;
  }

  private boolean findElement(int startPage, byte[] element, int offset)
    throws OneWireException
  {
    int next_page = startPage;

    this.cache.clearLastPageRead();

    this.feOffset = this.LEN_CONTROL_DATA;
    do
    {
      this.fePage = next_page;

      this.feLen = this.cache.readPagePacket(this.fePage, this.feData, 0);

      if (this.fePage == 0) {
        readBitMap();
      }

      for (; this.feOffset < this.feLen - this.LEN_PAGE_PTR; this.feOffset += this.LEN_FILE_ENTRY)
      {
        if (!elementEquals(element, offset, this.feData, this.feOffset))
        {
          continue;
        }
        if ((this.feData[(this.feOffset + 5 - 1)] & 0x80) != 0)
        {
          int tmp101_100 = (offset + 5 - 1);
          byte[] tmp101_95 = element; tmp101_95[tmp101_100] = (byte)(tmp101_95[tmp101_100] | 0x80);
        }

        return true;
      }

      next_page = Convert.toInt(this.feData, this.feLen - this.LEN_PAGE_PTR, this.LEN_PAGE_PTR);

      if (next_page != 0)
        this.feOffset = 0;
    }
    while (next_page != 0);

    return false;
  }

  private boolean elementEquals(byte[] file1, int offset1, byte[] file2, int offset2)
  {
    for (int i = 0; i < 4; i++)
    {
      if (file1[(offset1 + i)] != file2[(offset2 + i)]) {
        return false;
      }
    }

    if (file1[(offset1 + 4)] == 126)
    {
      if ((file2[(offset2 + 4)] & 0x7F) == 0)
        file1[(offset1 + 4)] = 0;
      else if ((file2[(offset2 + 4)] & 0x7F) == 127) {
        file1[(offset1 + 4)] = 127;
      }
    }
    return (byte)(file1[(offset1 + 4)] & 0x7F) == (byte)(file2[(offset2 + 4)] & 0x7F);
  }

  private void fetchPage()
    throws IOException
  {
    try
    {
      this.lastLen = this.cache.readPagePacket(this.lastPage, this.lastPageData, 0);
      this.lastOffset = 0;
    }
    catch (OneWireException e)
    {
      throw new IOException(e.toString());
    }
  }

  private void createEntry(byte[] newEntry, int startPage, int numberPages, byte[] prevEntry, int prevEntryStart)
    throws OWFileNotFoundException
  {
    this.cache.clearLastPageRead();
    try
    {
      int new_page;
      if (this.feLen + this.LEN_FILE_ENTRY <= this.maxDataLen)
      {
        readBitMap();

        if (startPage != -1)
        {
          new_page = startPage;
        }
        else
        {
          new_page = getFirstFreePage((newEntry[4] == 102) || (newEntry[4] == 101));

          if (new_page < 0)
          {
            try
            {
              sync();
            }
            catch (OWSyncFailedException e)
            {
            }

            if ((newEntry[4] == 102) || (newEntry[4] == 101)) {
              throw new OWFileNotFoundException("Out of space on 1-Wire device, or no secure pages available");
            }

            throw new OWFileNotFoundException("Out of space on 1-Wire device");
          }

        }

        int npp = Convert.toInt(this.feData, this.feLen - this.LEN_PAGE_PTR, this.LEN_PAGE_PTR);

        System.arraycopy(newEntry, 0, this.feData, this.feLen - this.LEN_PAGE_PTR, 5);
        Convert.toByteArray(new_page, this.feData, this.feLen - this.LEN_PAGE_PTR + 5, this.LEN_PAGE_PTR);

        Convert.toByteArray(numberPages == -1 ? 1 : numberPages, this.feData, this.feLen - this.LEN_PAGE_PTR + 5 + this.LEN_PAGE_PTR, this.LEN_PAGE_PTR);

        this.feOffset = (this.feLen - this.LEN_PAGE_PTR);
        this.feLen += this.LEN_FILE_ENTRY;

        Convert.toByteArray(npp, this.feData, this.feLen - this.LEN_PAGE_PTR, this.LEN_PAGE_PTR);

        if (startPage == -1)
        {
          markPageUsed(new_page);

          if ((newEntry[4] & 0x7F) == 127)
          {
            this.tempPage[0] = (this.LEN_PAGE_PTR == 1 ? 10 : 11);
            int tmp313_312 = 0;
            byte[] tmp313_309 = this.tempPage; tmp313_309[tmp313_312] = (byte)(tmp313_309[tmp313_312] | (this.owd.length == 1 ? -96 : 176));

            this.tempPage[1] = 0;

            System.arraycopy(prevEntry, 0, this.tempPage, 2, 4);
            Convert.toByteArray(prevEntryStart, this.tempPage, 6, this.LEN_PAGE_PTR);

            Convert.toByteArray(0, this.tempPage, 6 + this.LEN_PAGE_PTR, this.LEN_PAGE_PTR);
            this.cache.writePagePacket(new_page, this.tempPage, 0, 6 + this.LEN_PAGE_PTR * 2);
          }
          else
          {
            Convert.toByteArray(0, this.smallBuf, 0, this.LEN_PAGE_PTR);
            this.cache.writePagePacket(new_page, this.smallBuf, 0, this.LEN_PAGE_PTR);
          }

        }

        this.cache.writePagePacket(this.fePage, this.feData, 0, this.feLen);

        writeBitMap();

        if ((newEntry[4] & 0x7F) != 127)
        {
          this.filePosition = 0;
          this.lastPage = new_page;
          this.lastOffset = 0;
          this.lastLen = 1;
        }

      }
      else
      {
        readBitMap();

        int new_dir_page = getFirstFreePage(false);

        if (new_dir_page < 0)
        {
          try
          {
            sync();
          }
          catch (OWSyncFailedException e)
          {
          }

          throw new OWFileNotFoundException("Out of space on 1-Wire device");
        }

        markPageUsed(new_dir_page);

        if (startPage != -1)
        {
          new_page = startPage;
        }
        else
        {
          new_page = getNextFreePage((newEntry[4] == 102) || (newEntry[4] == 101));

          if (new_page < 0)
          {
            try
            {
              sync();
            }
            catch (OWSyncFailedException e)
            {
            }

            if ((newEntry[4] == 102) || (newEntry[4] == 101)) {
              throw new OWFileNotFoundException("Out of space on 1-Wire device, or no secure pages available");
            }

            throw new OWFileNotFoundException("Out of space on 1-Wire device");
          }

          markPageUsed(new_page);
        }

        System.arraycopy(newEntry, 0, this.lastPageData, 0, 5);
        Convert.toByteArray(new_page, this.lastPageData, 5, this.LEN_PAGE_PTR);
        Convert.toByteArray(numberPages == -1 ? 1 : numberPages, this.lastPageData, 5 + this.LEN_PAGE_PTR, this.LEN_PAGE_PTR);

        this.feOffset = 0;

        Convert.toByteArray(0, this.lastPageData, this.LEN_FILE_ENTRY, this.LEN_PAGE_PTR);

        this.cache.writePagePacket(new_dir_page, this.lastPageData, 0, this.LEN_FILE_ENTRY + this.LEN_PAGE_PTR);

        if (startPage == -1)
        {
          if ((newEntry[4] & 0x7F) == 127)
          {
            this.tempPage[0] = (this.LEN_PAGE_PTR == 1 ? 10 : 11);
            int tmp777_776 = 0;
            byte[] tmp777_773 = this.tempPage; tmp777_773[tmp777_776] = (byte)(tmp777_773[tmp777_776] | (this.owd.length == 1 ? -96 : 176));

            this.tempPage[1] = 0;

            System.arraycopy(prevEntry, 0, this.tempPage, 2, 4);
            Convert.toByteArray(prevEntryStart, this.tempPage, 6, this.LEN_PAGE_PTR);

            Convert.toByteArray(0, this.tempPage, 6 + this.LEN_PAGE_PTR, this.LEN_PAGE_PTR);
            this.cache.writePagePacket(new_page, this.tempPage, 0, 6 + this.LEN_PAGE_PTR * 2);
          }
          else
          {
            Convert.toByteArray(0, this.smallBuf, 0, this.LEN_PAGE_PTR);
            this.cache.writePagePacket(new_page, this.smallBuf, 0, this.LEN_PAGE_PTR);
          }

        }

        Convert.toByteArray(new_dir_page, this.feData, this.feLen - this.LEN_PAGE_PTR, this.LEN_PAGE_PTR);

        this.cache.writePagePacket(this.fePage, this.feData, 0, this.feLen);

        this.fePage = new_dir_page;
        this.feOffset = 0;
        this.feLen = (this.LEN_FILE_ENTRY + this.LEN_PAGE_PTR);
        System.arraycopy(this.lastPageData, 0, this.feData, 0, this.feLen);

        writeBitMap();

        if ((newEntry[4] & 0x7F) != 127)
        {
          this.filePosition = 0;
          this.lastPage = new_page;
          this.lastOffset = 0;
          this.lastLen = 1;
        }
      }
    }
    catch (OneWireException e)
    {
      throw new OWFileNotFoundException(e.toString());
    }
  }

  private void validateFileSystem()
    throws OneWireException
  {
    this.cache.clearLastPageRead();

    this.LEN_PAGE_PTR = ((this.feData[0] & 0xF) == 11 ? 2 : 1);
    if (((this.feData[0] & 0xF0) == 176) && ((this.feData[(1 + this.LEN_PAGE_PTR)] & 0x2) == 0))
    {
      int len = this.cache.readPagePacket(Convert.toInt(this.feData, 1, this.LEN_PAGE_PTR), this.dmBuf, 0);

      if (len >= 8 + this.LEN_PAGE_PTR)
      {
        System.arraycopy(this.dmBuf, 0, this.addrBuf, 0, 8);

        DSPortAdapter adapter = this.owd[0].getAdapter();
        this.owd = new OneWireContainer[1];
        this.owd[0] = adapter.getDeviceContainer(this.addrBuf);

        if ((adapter.getSpeed() == 2) && (this.owd[0].getMaxSpeed() == 2))
        {
          this.owd[0].setSpeed(2, false);
        }

        this.cache.removeOwner(this);
        if (this.cache.noOwners())
        {
          memoryCacheHash.remove(this.address);
          this.cache = null;
        }

        setupFD(this.owd, this.rawPath);

        this.fePage = 0;
        this.feLen = this.cache.readPagePacket(0, this.feData, 0);

        this.LEN_PAGE_PTR = ((this.feData[0] & 0xF) == 11 ? 2 : 1);
        if (((this.feData[0] & 0xF) == 11) && ((this.feData[(1 + this.LEN_PAGE_PTR)] & 0x2) == 0)) {
          throw new OneWireIOException("Invalid filesystem, this is a satellite device, pointing to another satellite?");
        }

        validateFileSystem();
        return;
      }

      throw new OneWireIOException("Invalid filesystem, this is a satellite device with invalid MASTER reference");
    }

    if (((this.feData[0] & 0xF0) == 176) && ((this.feData[(1 + this.LEN_PAGE_PTR)] & 0x2) == 2))
    {
      int page = Convert.toInt(this.feData, 1, this.LEN_PAGE_PTR);

      if ((page == 0) || (page >= this.totalPages)) {
        throw new OneWireIOException("Invalid Filesystem, Device Map page number not valid.");
      }

      int num_devices = verifyDeviceMap(page, 0, false);
      if (num_devices > 0)
      {
        verifyDeviceMap(page, num_devices, this.owd[0].getAdapter().getSpeed() == 2);

        this.cache.removeOwner(this);
        if (this.cache.noOwners())
        {
          memoryCacheHash.remove(this.address);
          this.cache = null;
        }

        setupFD(this.owd, this.rawPath);

        this.fePage = 0;
        this.feLen = this.cache.readPagePacket(0, this.feData, 0);
      }

    }

    if (((this.totalPages <= 256) && ((this.feData[0] & 0xF) != 10)) || ((this.totalPages > 256) && ((this.feData[0] & 0xF) != 11)))
    {
      throw new OneWireIOException("Invalid Filesystem marker found, number of pages incorrect");
    }

    if (((this.owd.length == 1) && ((this.feData[0] & 0xF0) != 160)) || ((this.owd.length > 1) && ((this.feData[0] & 0xF0) != 176)))
    {
      throw new OneWireIOException("Invalid Filesystem marker found, multi-device marker incorrect");
    }

    if ((this.feData[(1 + this.LEN_PAGE_PTR)] & 0x80) != 0)
    {
      this.bitmapType = 1;
      this.pbmByteOffset = (2 + this.LEN_PAGE_PTR);
      this.pbmBitOffset = 0;
      this.pbmStartPage = 0;
    }
    else if (this.bitmapType != 0)
    {
      this.bitmapType = 2;
      this.pbmStartPage = Convert.toInt(this.feData, this.LEN_CONTROL_DATA - this.LEN_PAGE_PTR * 2, this.LEN_PAGE_PTR);
      this.pbmNumPages = Convert.toInt(this.feData, this.LEN_CONTROL_DATA - this.LEN_PAGE_PTR, this.LEN_PAGE_PTR);
      this.pbmByteOffset = 0;
      this.pbmBitOffset = 0;

      int pbm_bytes = this.totalPages / 8;
      int pgs = pbm_bytes / (this.maxDataLen - this.LEN_PAGE_PTR);
      if (pbm_bytes % (this.maxDataLen - this.LEN_PAGE_PTR) > 0) {
        pgs++;
      }
      if (this.pbmNumPages != pgs)
        throw new OneWireIOException("Invalid Filesystem, incorrect number of pages in remote bitmap file!");
    }
    else
    {
      this.pbmStartPage = 0;
    }
  }

  protected int verifyDeviceMap(int startPage, int numberOfContainers, boolean setOverdrive)
    throws OneWireException
  {
    int ow_cnt = 1;
    int addr_offset = 0;
    int pg_offset = 0;

    DSPortAdapter adapter = null;

    boolean list_valid = true;

    int page = startPage;

    this.cache.clearLastPageRead();

    if (numberOfContainers > 0)
    {
      adapter = this.owd[0].getAdapter();

      OneWireContainer master_owc = this.owd[0];
      this.owd = new OneWireContainer[numberOfContainers + 1];
      this.owd[0] = master_owc;
    }

    do
    {
      int len = this.cache.readPagePacket(page, this.dmBuf, 0);
      int data_len = len - this.LEN_PAGE_PTR;

      while (pg_offset < data_len)
      {
        int copy_len;
        if (data_len - pg_offset >= 8 - addr_offset)
          copy_len = 8 - addr_offset;
        else {
          copy_len = data_len - pg_offset;
        }

        System.arraycopy(this.dmBuf, pg_offset, this.addrBuf, addr_offset, copy_len);

        addr_offset += copy_len;
        pg_offset += copy_len;

        if (addr_offset < 8) {
          continue;
        }
        if (numberOfContainers > 0)
        {
          this.owd[ow_cnt] = adapter.getDeviceContainer(this.addrBuf);

          if ((setOverdrive) && (this.owd[ow_cnt].getMaxSpeed() == 2))
          {
            this.owd[ow_cnt].setSpeed(2, false);
          }

        }
        else if (this.owd.length <= ow_cnt) {
          list_valid = false;
        } else if (Address.toLong(this.addrBuf) != this.owd[ow_cnt].getAddressAsLong()) {
          list_valid = false;
        }

        ow_cnt++;
        addr_offset = 0;
      }

      page = Convert.toInt(this.dmBuf, data_len, this.LEN_PAGE_PTR);

      pg_offset = 0;
    }
    while (page != 0);

    return list_valid ? 0 : ow_cnt - 1;
  }

  private boolean parsePath(String rawPath, Vector parsedPath)
  {
    int last_index = 0;
    int index;
    do
    {
      index = rawPath.indexOf("/", last_index);
      int name_len = 0;

      if ((index == -1) && (last_index < rawPath.length())) {
        index = rawPath.length();
      }

      if (index > 0)
      {
        String field = rawPath.substring(last_index, index);

        if (field.length() == 0)
        {
          return false;
        }

        byte[] name = new byte[5];

        System.arraycopy(this.initName, 0, name, 0, 5);

        int period_index = field.indexOf(".", 0);

        if (period_index == -1)
        {
          if (field.length() > 4)
          {
            return false;
          }

          System.arraycopy(field.getBytes(), 0, name, 0, field.length());
          name_len = field.length();

          if (index != rawPath.length()) {
            name[4] = 127;
          }

        }
        else if (period_index == 0)
        {
          if (field.length() > 2)
          {
            return false;
          }

          System.arraycopy(field.getBytes(), 0, name, 0, field.length());

          name[4] = 127;
          name_len = field.length();
        }
        else
        {
          name_len = period_index;

          System.arraycopy(field.getBytes(), 0, name, 0, period_index);
          try
          {
            name[4] = (byte)Integer.parseInt(field.substring(period_index + 1, field.length()));
          }
          catch (NumberFormatException e)
          {
            return false;
          }

          if ((index != rawPath.length()) || ((name[4] & 0xFF) > 102))
          {
            return false;
          }

        }

        for (int i = 0; i < name_len; i++)
        {
          if (((name[i] & 0xFF) < 33) || ((name[i] & 0xFF) > 126))
          {
            return false;
          }

        }

        parsedPath.addElement(name);
      }

      last_index = index + 1;
    }
    while (index > -1);
    return true;
  }

  protected boolean createNewFile()
    throws IOException
  {
    if (exists()) {
      return false;
    }

    try
    {
      create(false, false, false, -1, -1);
    }
    catch (OWFileNotFoundException e)
    {
      throw new IOException(e.toString());
    }

    return true;
  }

  protected int getHashCode()
  {
    synchronized (this.cache)
    {
      int hash = 0;
      String this_path = this.owd[0].getAddressAsString() + getPath();
      byte[] path_bytes = this_path.getBytes();

      for (int i = 0; i < path_bytes.length / 4; i++) {
        hash ^= Convert.toInt(path_bytes, i * 4, 4);
      }
      for (int j = 0; j < path_bytes.length % 4; j++) {
        hash ^= path_bytes[(i * 4 + j)] & 0xFF;
      }
      return hash;
    }
  }

  protected OneWireContainer[] getOneWireContainers()
  {
    return this.owd;
  }

  protected void free()
  {
    synchronized (this.cache)
    {
      if (this.openedToWrite) {
        this.cache.removeWriteOpen(this.owd[0].getAddressAsString() + getPath());
      }

      this.cache.removeOwner(this);

      if (this.cache.noOwners())
      {
        memoryCacheHash.remove(this.address);

        this.cache = null;
      }
    }
  }

  private void debugDump(byte[] buf, int offset, int len)
  {
    for (int i = offset; i < offset + len; i++)
    {
      System.out.print(Integer.toHexString(buf[i] & 0xFF) + " ");
    }

    System.out.println();
  }
}