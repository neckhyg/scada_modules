package com.dalsemi.onewire.application.file;

import java.io.IOException;

public class OWSyncFailedException extends IOException
{
  public OWSyncFailedException(String desc)
  {
    super(desc);
  }
}