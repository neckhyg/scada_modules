package com.dalsemi.onewire.application.file;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.container.OneWireContainer;
import com.dalsemi.onewire.container.PagedMemoryBank;
import java.io.FileNotFoundException;
import java.io.IOException;

public class OWFile
{
  public static final String separator = "/";
  public static final char separatorChar = '/';
  public static final String pathSeparator = ":";
  public static final char pathSeparatorChar = ':';
  private OWFileDescriptor fd;

  public OWFile(OneWireContainer owd, String pathname)
  {
    this.fd = new OWFileDescriptor(owd, pathname);
  }

  public OWFile(OneWireContainer[] owd, String pathname)
  {
    this.fd = new OWFileDescriptor(owd, pathname);
  }

  public OWFile(OneWireContainer owd, String parent, String child)
  {
    if (child == null) {
      throw new NullPointerException("child is null");
    }
    this.fd = new OWFileDescriptor(owd, parent + child);
  }

  public OWFile(OWFile parent, String child)
  {
    if (child == null)
      throw new NullPointerException("child is null");
    String new_path;
    if (parent.getAbsolutePath().endsWith("/"))
      new_path = parent.getAbsolutePath() + child;
    else {
      new_path = parent.getAbsolutePath() + "/" + child;
    }
    this.fd = new OWFileDescriptor(parent.getOneWireContainers(), new_path);
  }

  public String getName()
  {
    return this.fd.getName();
  }

  public String getParent()
  {
    return this.fd.getParent();
  }

  public OWFile getParentFile()
  {
    return new OWFile(this.fd.getOneWireContainers(), this.fd.getParent());
  }

  public String getPath()
  {
    return this.fd.getPath();
  }

  public boolean isAbsolute()
  {
    return true;
  }

  public String getAbsolutePath()
  {
    return this.fd.getPath();
  }

  public OWFile getAbsoluteFile()
  {
    return new OWFile(this.fd.getOneWireContainers(), this.fd.getPath());
  }

  public String getCanonicalPath()
    throws IOException
  {
    return this.fd.getPath();
  }

  public OWFile getCanonicalFile()
    throws IOException
  {
    return new OWFile(this.fd.getOneWireContainers(), this.fd.getPath());
  }

  public boolean canRead()
  {
    return this.fd.canRead();
  }

  public boolean canWrite()
  {
    return this.fd.canWrite();
  }

  public boolean exists()
  {
    return this.fd.exists();
  }

  public boolean isDirectory()
  {
    return this.fd.isDirectory();
  }

  public boolean isFile()
  {
    return this.fd.isFile();
  }

  public boolean isHidden()
  {
    return this.fd.isHidden();
  }

  public long lastModified()
  {
    return 0L;
  }

  public long length()
  {
    return this.fd.length();
  }

  public boolean createNewFile()
    throws IOException
  {
    return this.fd.createNewFile();
  }

  public boolean delete()
  {
    return this.fd.delete();
  }

  public String[] list()
  {
    if ((isFile()) || (!isDirectory())) {
      return null;
    }
    return this.fd.list();
  }

  public OWFile[] listFiles()
  {
    if ((isFile()) || (!isDirectory())) {
      return null;
    }

    String[] str_list = this.fd.list();
    OWFile[] file_list = new OWFile[str_list.length];

    for (int i = 0; i < str_list.length; i++)
    {
      String new_path;
      if ((this.fd.getPath() == null) || (this.fd.getPath().endsWith("/")))
        new_path = "/" + str_list[i];
      else {
        new_path = this.fd.getPath() + "/" + str_list[i];
      }
      file_list[i] = new OWFile(this.fd.getOneWireContainers(), new_path);
    }

    return file_list;
  }

  public boolean mkdir()
  {
    try
    {
      this.fd.create(false, true, false, -1, -1);

      return true;
    }
    catch (OWFileNotFoundException e) {
    }
    return false;
  }

  public boolean mkdirs()
  {
    try
    {
      this.fd.create(false, true, true, -1, -1);

      return true;
    }
    catch (OWFileNotFoundException e) {
    }
    return false;
  }

  public boolean renameTo(OWFile dest)
  {
    return this.fd.renameTo(dest);
  }

  public boolean setLastModified(long time)
  {
    return false;
  }

  public boolean setReadOnly()
  {
    boolean result = this.fd.setReadOnly();

    return result;
  }

  public static OWFile[] listRoots(OneWireContainer owc)
  {
    OWFile[] roots = new OWFile[1];

    roots[0] = new OWFile(owc, "/");

    return roots;
  }

  public int compareTo(OWFile pathname)
  {
    OneWireContainer[] owd = this.fd.getOneWireContainers();
    String this_path = owd[0].getAddressAsString() + getPath();
    String compare_path = pathname.getOneWireContainer().getAddressAsString() + pathname.getPath();

    return this_path.compareTo(compare_path);
  }

  public int compareTo(Object o)
  {
    return compareTo((OWFile)o);
  }

  public boolean equals(Object obj)
  {
    if (obj == null) {
      return false;
    }
    if (!(obj instanceof OWFile)) {
      return false;
    }
    return compareTo((OWFile)obj) == 0;
  }

  public int hashCode()
  {
    return this.fd.getHashCode();
  }

  public String toString()
  {
    return this.fd.getPath();
  }

  public OWFileDescriptor getFD()
    throws IOException
  {
    return this.fd;
  }

  public OneWireContainer getOneWireContainer()
  {
    OneWireContainer[] owd = this.fd.getOneWireContainers();
    return owd[0];
  }

  public OneWireContainer[] getOneWireContainers()
  {
    return this.fd.getOneWireContainers();
  }

  public void format()
    throws IOException
  {
    try
    {
      this.fd.format();
    }
    catch (OneWireException e)
    {
      throw new IOException(e.toString());
    }
  }

  public int getFreeMemory()
    throws IOException
  {
    try
    {
      return this.fd.getFreeMemory();
    }
    catch (OneWireException e) {
    }
    throw new IOException(e.toString());
  }

  public void close()
    throws IOException
  {
    this.fd.close();

    this.fd = null;
  }

  public int[] getPageList()
    throws IOException
  {
    if (this.fd != null)
    {
      if (!this.fd.exists())
        return new int[0];
    }
    else {
      return new int[0];
    }
    try
    {
      return this.fd.getPageList();
    }
    catch (OneWireException e) {
    }
    throw new IOException(e.toString());
  }

  public int getStartPage()
    throws IOException
  {
    if ((this.fd != null) && (this.fd.exists()))
    {
      return this.fd.getStartPage();
    }

    throw new FileNotFoundException();
  }

  public PagedMemoryBank getMemoryBankForPage(int page)
  {
    if (this.fd != null)
    {
      if (!this.fd.exists())
        return null;
    }
    else {
      return null;
    }
    return this.fd.getMemoryBankForPage(page);
  }

  public int getLocalPage(int page)
  {
    if (this.fd != null)
    {
      if (!this.fd.exists())
        return 0;
    }
    else {
      return 0;
    }
    return this.fd.getLocalPage(page);
  }

  protected void finalize()
    throws IOException
  {
    if (this.fd != null)
      this.fd.close();
  }
}