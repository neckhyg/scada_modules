package com.dalsemi.onewire.application.file;

import com.dalsemi.onewire.container.OneWireContainer;
import java.io.IOException;
import java.io.InputStream;

public class OWFileInputStream extends InputStream
{
  private OWFileDescriptor fd;

  public OWFileInputStream(OneWireContainer owd, String name)
    throws OWFileNotFoundException
  {
    this.fd = new OWFileDescriptor(owd, name);
    try
    {
      this.fd.open();
    }
    catch (OWFileNotFoundException e)
    {
      this.fd.free();
      this.fd = null;
      throw new OWFileNotFoundException(e.toString());
    }

    if (!this.fd.isFile())
    {
      this.fd.free();
      this.fd = null;
      throw new OWFileNotFoundException("Not a file");
    }
  }

  public OWFileInputStream(OneWireContainer[] owd, String name)
    throws OWFileNotFoundException
  {
    this.fd = new OWFileDescriptor(owd, name);
    try
    {
      this.fd.open();
    }
    catch (OWFileNotFoundException e)
    {
      this.fd.free();
      this.fd = null;
      throw new OWFileNotFoundException(e.toString());
    }

    if (!this.fd.isFile())
    {
      this.fd.free();
      this.fd = null;
      throw new OWFileNotFoundException("Not a file");
    }
  }

  public OWFileInputStream(OWFile file)
    throws OWFileNotFoundException
  {
    try
    {
      this.fd = file.getFD();
    }
    catch (IOException e)
    {
      this.fd.free();
      this.fd = null;
      throw new OWFileNotFoundException(e.toString());
    }

    try
    {
      this.fd.open();
    }
    catch (OWFileNotFoundException e)
    {
      this.fd.free();
      this.fd = null;
      throw new OWFileNotFoundException(e.toString());
    }

    if (!this.fd.isFile())
    {
      this.fd.free();
      this.fd = null;
      throw new OWFileNotFoundException("Not a file");
    }
  }

  public OWFileInputStream(OWFileDescriptor fdObj)
  {
    if (fdObj == null) {
      throw new NullPointerException("OWFile provided is null");
    }
    this.fd = fdObj;
  }

  public int read()
    throws IOException
  {
    if (this.fd != null) {
      return this.fd.read();
    }
    throw new IOException("1-Wire FileDescriptor is null");
  }

  public int read(byte[] b)
    throws IOException
  {
    if (this.fd != null) {
      return this.fd.read(b, 0, b.length);
    }
    throw new IOException("1-Wire FileDescriptor is null");
  }

  public int read(byte[] b, int off, int len)
    throws IOException
  {
    if (this.fd != null) {
      return this.fd.read(b, off, len);
    }
    throw new IOException("1-Wire FileDescriptor is null");
  }

  public long skip(long n)
    throws IOException
  {
    if (this.fd != null) {
      return this.fd.skip(n);
    }
    throw new IOException("1-Wire FileDescriptor is null");
  }

  public int available()
    throws IOException
  {
    if (this.fd != null) {
      return this.fd.available();
    }
    throw new IOException("1-Wire FileDescriptor is null");
  }

  public void close()
    throws IOException
  {
    if (this.fd != null)
      this.fd.close();
    else {
      throw new IOException("1-Wire FileDescriptor is null");
    }
    this.fd = null;
  }

  public final OWFileDescriptor getFD()
    throws IOException
  {
    if (this.fd != null) {
      return this.fd;
    }
    throw new IOException("1-Wire FileDescriptor is null");
  }

  public void finalize()
    throws IOException
  {
    if (this.fd != null)
    {
      this.fd.close();
    }
  }

  public void mark(int readlimit)
  {
    if (this.fd != null)
      this.fd.mark(readlimit);
  }

  public void reset()
    throws IOException
  {
    if (this.fd != null)
      this.fd.reset();
  }

  public boolean markSupported()
  {
    return true;
  }
}