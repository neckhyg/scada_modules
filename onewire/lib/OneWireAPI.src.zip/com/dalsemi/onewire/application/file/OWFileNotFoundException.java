package com.dalsemi.onewire.application.file;

import java.io.IOException;

public class OWFileNotFoundException extends IOException
{
  public OWFileNotFoundException()
  {
  }

  public OWFileNotFoundException(String s)
  {
    super(s);
  }
}