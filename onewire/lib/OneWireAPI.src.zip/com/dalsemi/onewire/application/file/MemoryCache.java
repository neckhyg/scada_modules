package com.dalsemi.onewire.application.file;

import com.dalsemi.onewire.OneWireException;
import com.dalsemi.onewire.adapter.DSPortAdapter;
import com.dalsemi.onewire.adapter.OneWireIOException;
import com.dalsemi.onewire.container.MemoryBank;
import com.dalsemi.onewire.container.OTPMemoryBank;
import com.dalsemi.onewire.container.OneWireContainer;
import com.dalsemi.onewire.container.PagedMemoryBank;
import com.dalsemi.onewire.utils.Bit;
import com.dalsemi.onewire.utils.CRC16;
import java.io.PrintStream;
import java.util.Enumeration;
import java.util.Vector;

class MemoryCache
{
  private static final int NOT_READ = 0;
  private static final int READ_CRC = 1;
  private static final int READ_NO_CRC = 2;
  private static final int VERIFY = 3;
  private static final int REDIRECT = 4;
  private static final int WRITE = 5;
  private static final int EMPTY = -1;
  private static final int NONE = -100;
  private static final int USED = 0;
  private static final int NOT_USED = 1;
  private static final boolean doDebugMessages = false;
  private OneWireContainer[] owd;
  private byte[][] cache;
  private int[] len;
  private int[] pageState;
  private Vector banks;
  private int totalPages;
  private int lastPageRead;
  private int maxPacketDataLength;
  private int[] bankPages;
  private int[] startPages;
  private int[] writeLog;
  private byte[] tempExtra;
  private byte[] tempPage;
  private int[] redirect;
  private Vector owners;
  private Vector openedToWrite;
  private boolean canRedirect;
  private OTPMemoryBank pbmBank;
  private int pbmByteOffset;
  private int pbmBitOffset;
  private byte[] pbmCache;
  private byte[] pbmCacheModified;
  private boolean pbmRead;
  private int lastFreePage;
  private int lastDevice;
  private boolean autoOverdrive;

  public MemoryCache(OneWireContainer device)
  {
    OneWireContainer[] devices = new OneWireContainer[1];
    devices[0] = device;

    init(devices);
  }

  public MemoryCache(OneWireContainer[] devices)
  {
    init(devices);
  }

  private void init(OneWireContainer[] devices)
  {
    this.owd = devices;
    int mem_size = 0;

    PagedMemoryBank pmb = null;

    this.banks = new Vector(1);
    this.owners = new Vector(1);
    this.openedToWrite = new Vector(1);
    this.startPages = new int[this.owd.length];
    this.lastDevice = 0;
    try
    {
      this.autoOverdrive = devices[0].getAdapter().canOverdrive();
    }
    catch (OneWireException e)
    {
      this.autoOverdrive = false;
    }

    this.totalPages = 0;
    for (int dev = 0; dev < this.owd.length; dev++)
    {
      if (this.owd[dev].getMaxSpeed() != 2) {
        this.autoOverdrive = false;
      }

      this.startPages[dev] = this.totalPages;

      Enumeration bank_enum = this.owd[dev].getMemoryBanks();
      while (bank_enum.hasMoreElements())
      {
        MemoryBank mb = (MemoryBank)bank_enum.nextElement();

        if ((mb.isWriteOnce()) && (!mb.isGeneralPurposeMemory()) && (mb.isNonVolatile()) && ((mb instanceof OTPMemoryBank)))
        {
          if (this.owd.length > 1)
          {
            this.totalPages = 0;
            return;
          }

          if ((mem_size == 128) || (mb.getBankDescription().indexOf("Bitmap") != -1))
          {
            this.pbmBank = ((OTPMemoryBank)mb);

            if (mem_size == 128) {
              this.pbmBitOffset = 4;
            }
            this.pbmByteOffset = 0;
            this.canRedirect = true;
          }

        }

        if ((!mb.isGeneralPurposeMemory()) || (!mb.isNonVolatile()) || (!(mb instanceof PagedMemoryBank)))
        {
          continue;
        }

        this.banks.addElement(mb);
        mem_size += mb.getSize();
        this.totalPages += ((PagedMemoryBank)mb).getNumberPages();
      }

    }

    this.bankPages = new int[this.banks.size()];
    this.totalPages = 0;

    for (int b = 0; b < this.banks.size(); b++)
    {
      pmb = (PagedMemoryBank)this.banks.elementAt(b);
      this.bankPages[b] = pmb.getNumberPages();
      this.totalPages += this.bankPages[b];
    }

    this.len = new int[this.totalPages];
    this.pageState = new int[this.totalPages];
    this.writeLog = new int[this.totalPages];
    this.redirect = new int[this.totalPages];
    if (pmb != null)
    {
      this.maxPacketDataLength = pmb.getMaxPacketDataLength();
      this.cache = new byte[this.totalPages][pmb.getPageLength()];
      this.tempPage = new byte[pmb.getPageLength()];
    }

    for (int p = 0; p < this.totalPages; p++)
    {
      this.pageState[p] = 0;
      this.len[p] = 0;
      this.writeLog[p] = -1;
    }

    if (this.canRedirect)
    {
      this.tempExtra = new byte[pmb.getExtraInfoLength()];
      this.pbmCache = new byte[this.pbmBank.getSize()];
      this.pbmCacheModified = new byte[this.pbmBank.getSize()];
      this.pbmRead = false;
    }
    else {
      this.pbmRead = true;
    }
  }

  public int getNumberPages()
  {
    return this.totalPages;
  }

  public int getNumberPagesInBank(int bankNum)
  {
    if (this.totalPages > 0) {
      return this.bankPages[bankNum];
    }
    return 0;
  }

  public int getPageOffsetForDevice(int deviceNum)
  {
    return this.startPages[deviceNum];
  }

  public int getMaxPacketDataLength()
  {
    return this.maxPacketDataLength;
  }

  public boolean isWriteOnce()
  {
    return this.canRedirect;
  }

  public int readPagePacket(int page, byte[] readBuf, int offset)
    throws OneWireIOException, OneWireException
  {
    if (this.totalPages == 0) {
      throw new OneWireException("1-Wire Filesystem does not have memory");
    }

    if (page >= this.totalPages) {
      throw new OneWireException("Page requested is not in memory space");
    }

    if (this.autoOverdrive)
    {
      this.autoOverdrive = false;
      DSPortAdapter adapter = this.owd[0].getAdapter();
      adapter.setSpeed(0);
      adapter.reset();
      adapter.putByte(60);
      adapter.setSpeed(2);
    }

    if (!this.pbmRead) {
      readPageBitMap();
    }

    if ((this.pageState[page] == 0) || (this.pageState[page] == 2) || (this.redirect[page] != 0))
    {
      int local_page = getLocalPage(page);
      PagedMemoryBank pmb = getMemoryBankForPage(page);
      int local_device_page = page - this.startPages[getDeviceIndex(page)];

      if (this.canRedirect)
      {
        int loopcnt = 0;
        while (true)
        {
          if (this.redirect[page] == 0)
          {
            if ((this.pageState[page] == 1) || (this.pageState[page] == 3) || (this.pageState[page] == 5))
            {
              break;
            }

            if (pmb.hasExtraInfo())
            {
              pmb.readPageCRC(page, this.lastPageRead == page - 1, this.cache[page], 0, this.tempExtra);

              this.lastPageRead = page;

              this.redirect[page] = ((this.tempExtra[0] ^ 0xFFFFFFFF) & 0xFF);
            }
            else
            {
              pmb.readPageCRC(page, this.lastPageRead == page - 1, this.cache[page], 0);

              this.redirect[page] = (byte)((OTPMemoryBank)pmb).getRedirectedPage(page);

              this.lastPageRead = -100;
            }

            this.pageState[page] = 2;

            if (this.redirect[page] == 0)
            {
              if ((this.cache[page][0] & 0xFF) > this.maxPacketDataLength) {
                throw new OneWireIOException("Invalid length in packet");
              }

              if (CRC16.compute(this.cache[page], 0, this.cache[page][0] + 3, page) == 45057)
              {
                this.len[page] = this.cache[page][0];

                this.pageState[page] = 1;

                break;
              }

              throw new OneWireIOException("Invalid CRC16 in packet read " + page);
            }
          }
          else
          {
            page = this.redirect[page];
          }

          if (loopcnt++ > this.totalPages) {
            throw new OneWireIOException("Circular redirection of pages");
          }

        }

        if (readBuf != null) {
          System.arraycopy(this.cache[page], 1, readBuf, offset, this.len[page]);
        }

        return this.len[page];
      }

      while (true)
      {
        pmb.readPage(local_page, this.lastPageRead == page - 1, this.tempPage, 0);

        this.lastPageRead = page;

        if ((this.tempPage[0] & 0xFF) <= this.maxPacketDataLength)
        {
          if (CRC16.compute(this.tempPage, 0, this.tempPage[0] + 3, local_device_page) == 45057)
          {
            System.arraycopy(this.tempPage, 0, this.cache[page], 0, this.tempPage.length);

            this.len[page] = this.tempPage[0];

            this.pageState[page] = 1;

            break;
          }

        }

        boolean same_data = true;

        for (int i = 0; i < this.tempPage.length; i++)
        {
          if ((this.tempPage[i] & 0xFF) == (this.cache[page][i] & 0xFF))
          {
            continue;
          }

          same_data = false;

          break;
        }

        if (same_data)
        {
          this.pageState[page] = 2;

          throw new OneWireIOException("Invalid CRC16 in packet read");
        }

        System.arraycopy(this.tempPage, 0, this.cache[page], 0, this.tempPage.length);
      }

      if (readBuf != null) {
        System.arraycopy(this.cache[page], 1, readBuf, offset, this.len[page]);
      }

      return this.len[page];
    }

    if (readBuf != null) {
      System.arraycopy(this.cache[page], 1, readBuf, offset, this.len[page]);
    }
    return this.len[page];
  }

  public void writePagePacket(int page, byte[] writeBuf, int offset, int buflen)
    throws OneWireIOException, OneWireException
  {
    if (this.totalPages == 0) {
      throw new OneWireException("1-Wire Filesystem does not have memory");
    }

    if (!this.pbmRead) {
      readPageBitMap();
    }

    if (this.canRedirect)
    {
      OTPMemoryBank otp = (OTPMemoryBank)getMemoryBankForPage(page);

      if ((this.redirect[page] == 0) && (this.pageState[page] == 0)) {
        this.redirect[page] = otp.getRedirectedPage(page);
      }

      if (this.redirect[page] != 0)
      {
        int last_page = page; int cnt = 0;
        this.lastPageRead = -100;
        do
        {
          last_page = this.redirect[last_page];

          this.redirect[last_page] = otp.getRedirectedPage(last_page);

          if (cnt++ > this.totalPages)
            throw new OneWireException("Error in Filesystem, circular redirection of pages");
        }
        while (this.redirect[last_page] != 0);

        System.arraycopy(writeBuf, offset, this.cache[last_page], 1, buflen);
        this.len[last_page] = buflen;
        this.cache[last_page][0] = (byte)buflen;
        int crc = CRC16.compute(this.cache[last_page], 0, buflen + 1, last_page);
        this.cache[last_page][(buflen + 1)] = (byte)((crc ^ 0xFFFFFFFF) & 0xFF);
        this.cache[last_page][(buflen + 2)] = (byte)(((crc ^ 0xFFFFFFFF) & 0xFFFF) >>> 8 & 0xFF);

        this.pageState[last_page] = 3;

        page = last_page;
      }
      else
      {
        System.arraycopy(writeBuf, offset, this.cache[page], 1, buflen);
        this.len[page] = buflen;
        this.cache[page][0] = (byte)buflen;
        int crc = CRC16.compute(this.cache[page], 0, buflen + 1, page);
        this.cache[page][(buflen + 1)] = (byte)((crc ^ 0xFFFFFFFF) & 0xFF);
        this.cache[page][(buflen + 2)] = (byte)(((crc ^ 0xFFFFFFFF) & 0xFFFF) >>> 8 & 0xFF);

        this.pageState[page] = 3;
      }

    }
    else
    {
      System.arraycopy(writeBuf, offset, this.cache[page], 1, buflen);

      this.len[page] = buflen;
      this.cache[page][0] = (byte)buflen;

      this.pageState[page] = 5;
    }

    for (int log = 0; log < this.totalPages; log++)
    {
      if ((this.writeLog[log] == page) || (this.writeLog[log] == -1))
      {
        break;
      }
    }
    for (; log > 0; log--) {
      this.writeLog[log] = this.writeLog[(log - 1)];
    }

    this.writeLog[0] = page;
  }

  public void sync()
    throws OneWireIOException, OneWireException
  {
    if (this.totalPages == 0) {
      return;
    }
    boolean jobs;
    do
    {
      jobs = false;

      for (int log = this.totalPages - 1; log >= 0; log--)
      {
        if (this.writeLog[log] == -1)
        {
          continue;
        }
        jobs = true;

        int page = this.writeLog[log];

        PagedMemoryBank pmb = getMemoryBankForPage(page);

        int local_page = getLocalPage(page);

        if (this.pageState[page] == 3)
        {
          pmb.readPageCRC(page, this.lastPageRead == page - 1, this.tempPage, 0);

          this.lastPageRead = page;

          boolean do_redirect = false;
          for (int i = 1; i < this.len[page] + 2; i++)
          {
            if (((this.tempPage[i] & 0xFF ^ this.cache[page][i] & 0xFF) & ((this.tempPage[i] ^ 0xFFFFFFFF) & 0xFF)) <= 0)
            {
              continue;
            }
            do_redirect = true;
            break;
          }

          if (do_redirect)
          {
            int new_page = getFirstFreePage();
            while (new_page == page)
            {
              System.out.println("_can't use this page " + page);
              markPageUsed(new_page);
              new_page = getNextFreePage();
            }

            if (new_page < 0) {
              throw new OneWireException("Redireciton required but out of space on 1-Wire device");
            }

            markPageUsed(new_page);

            System.arraycopy(this.cache[page], 0, this.cache[new_page], 0, this.tempPage.length);
            this.pageState[new_page] = 3;
            this.len[new_page] = this.len[page];

            for (int i = 0; i < this.totalPages; i++)
            {
              if (this.writeLog[i] != -1)
                continue;
              this.writeLog[i] = new_page;
              break;
            }

            this.pageState[page] = 4;
            this.cache[page][0] = (byte)(new_page & 0xFF);
          }
          else
          {
            this.pageState[page] = 5;
          }
        }

        if (this.pageState[page] == 4)
        {
          ((OTPMemoryBank)pmb).redirectPage(page, this.cache[page][0] & 0xFF);

          this.pageState[page] = 0;
          this.lastPageRead = -100;
          this.writeLog[log] = -1;
        }

        if (this.pageState[page] != 5)
        {
          continue;
        }

        int new_index = getDeviceIndex(page);
        if (new_index != this.lastDevice)
        {
          this.lastDevice = new_index;
          this.owd[this.lastDevice].doSpeed();
        }

        pmb.writePagePacket(local_page, this.cache[page], 1, this.len[page]);

        this.pageState[page] = 1;
        this.lastPageRead = -100;
        this.writeLog[log] = -1;
      }

    }

    while (jobs);

    if (this.canRedirect)
    {
      int numBytes = this.totalPages / 8;
      if (numBytes == 0)
        numBytes = 1;
      boolean changed = false;
      byte[] temp_buf = new byte[numBytes];

      for (int i = 0; i < numBytes; i++)
      {
        temp_buf[i] = (byte)((this.pbmCache[i] ^ this.pbmCacheModified[i] ^ 0xFFFFFFFF) & 0xFF);
        if (temp_buf[i] != -1) {
          changed = true;
        }

      }

      if (changed)
      {
        this.pbmBank.setWriteVerification(false);

        this.pbmBank.write(0, temp_buf, 0, numBytes);

        this.pbmBank.read(0, false, temp_buf, 0, numBytes);
        for (int i = 0; i < numBytes; i++)
        {
          if ((temp_buf[i] & 0xFF) != (this.pbmCacheModified[i] & 0xFF)) {
            throw new OneWireException("Readback verfication of page bitmap was not correct");
          }
        }

        System.arraycopy(temp_buf, 0, this.pbmCache, 0, numBytes);
        System.arraycopy(temp_buf, 0, this.pbmCacheModified, 0, numBytes);
      }
    }
  }

  public void addOwner(Object tobj)
  {
    if (this.owners.indexOf(tobj) == -1)
    {
      this.owners.addElement(tobj);
    }
  }

  public void removeOwner(Object tobj)
  {
    this.owners.removeElement(tobj);
  }

  public boolean noOwners()
  {
    return this.owners.isEmpty();
  }

  public void removeWriteOpen(String filePath)
  {
    int index = this.openedToWrite.indexOf(filePath);

    if (index != -1)
      this.openedToWrite.removeElementAt(index);
  }

  public boolean isOpenedToWrite(String filePath, boolean addToList)
  {
    int index = this.openedToWrite.indexOf(filePath);

    if (index != -1) {
      return true;
    }

    if (addToList)
      this.openedToWrite.addElement(filePath);
    return false;
  }

  public boolean handlePageBitmap()
  {
    return this.pbmBank != null;
  }

  public void markPageUsed(int page)
  {
    Bit.arrayWriteBit(0, this.pbmBitOffset + page, this.pbmByteOffset, this.pbmCacheModified);
  }

  public boolean freePage(int page)
  {
    if (Bit.arrayReadBit(this.pbmBitOffset + page, this.pbmByteOffset, this.pbmCache) == 1)
    {
      Bit.arrayWriteBit(1, this.pbmBitOffset + page, this.pbmByteOffset, this.pbmCacheModified);

      return true;
    }

    return false;
  }

  public int getFirstFreePage()
  {
    this.lastFreePage = 0;

    return getNextFreePage();
  }

  public int getNextFreePage()
  {
    for (int pg = this.lastFreePage; pg < this.totalPages; pg++)
    {
      if (Bit.arrayReadBit(this.pbmBitOffset + pg, this.pbmByteOffset, this.pbmCacheModified) != 1)
      {
        continue;
      }

      this.lastFreePage = (pg + 1);

      return pg;
    }

    return -1;
  }

  public int getNumberFreePages()
    throws OneWireException
  {
    if (!this.pbmRead)
    {
      this.pbmBank.read(0, false, this.pbmCache, 0, this.pbmCache.length);

      System.arraycopy(this.pbmCache, 0, this.pbmCacheModified, 0, this.pbmCache.length);

      this.pbmRead = true;
    }

    int free_pages = 0;
    for (int pg = 0; pg < this.totalPages; pg++)
    {
      if (Bit.arrayReadBit(this.pbmBitOffset + pg, this.pbmByteOffset, this.pbmCacheModified) != 1) {
        continue;
      }
      free_pages++;
    }

    return free_pages;
  }

  public int getBitMapPageNumber()
  {
    return this.pbmBank.getStartPhysicalAddress() / this.pbmBank.getPageLength();
  }

  public int getBitMapNumberOfPages()
  {
    return this.totalPages / 8 / this.pbmBank.getPageLength();
  }

  public PagedMemoryBank getMemoryBankForPage(int page)
  {
    int cnt = 0;

    for (int bank_num = 0; bank_num < this.banks.size(); bank_num++)
    {
      if (cnt + this.bankPages[bank_num] > page) {
        return (PagedMemoryBank)this.banks.elementAt(bank_num);
      }
      cnt += this.bankPages[bank_num];
    }

    return null;
  }

  private int getDeviceIndex(int page)
  {
    for (int dev_num = this.startPages.length - 1; dev_num >= 0; dev_num--)
    {
      if (this.startPages[dev_num] < page) {
        return dev_num;
      }
    }

    return 0;
  }

  public int getLocalPage(int page)
  {
    int cnt = 0;

    for (int bank_num = 0; bank_num < this.banks.size(); bank_num++)
    {
      if (cnt + this.bankPages[bank_num] > page) {
        return page - cnt;
      }
      cnt += this.bankPages[bank_num];
    }

    return 0;
  }

  public void clearLastPageRead()
  {
    this.lastPageRead = -100;
  }

  private void readPageBitMap()
    throws OneWireException
  {
    this.pbmBank.read(0, false, this.pbmCache, 0, this.pbmCache.length);

    System.arraycopy(this.pbmCache, 0, this.pbmCacheModified, 0, this.pbmCache.length);

    this.pbmRead = true;
  }

  private void debugDump(byte[] buf, int offset, int len)
  {
    for (int i = offset; i < offset + len; i++)
    {
      System.out.print(Integer.toHexString(buf[i] & 0xFF) + " ");
    }

    System.out.println();
  }
}