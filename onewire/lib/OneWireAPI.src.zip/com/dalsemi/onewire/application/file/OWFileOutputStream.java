package com.dalsemi.onewire.application.file;

import com.dalsemi.onewire.container.OneWireContainer;
import java.io.IOException;
import java.io.OutputStream;

public class OWFileOutputStream extends OutputStream
{
  private OWFileDescriptor fd;

  public OWFileOutputStream(OneWireContainer owd, String name)
    throws OWFileNotFoundException
  {
    OneWireContainer[] devices = new OneWireContainer[1];
    devices[0] = owd;
    this.fd = new OWFileDescriptor(devices, name);
    try
    {
      this.fd.create(false, false, false, -1, -1);
    }
    catch (OWFileNotFoundException e)
    {
      this.fd.free();
      this.fd = null;
      throw new OWFileNotFoundException(e.toString());
    }
  }

  public OWFileOutputStream(OneWireContainer[] owd, String name)
    throws OWFileNotFoundException
  {
    this.fd = new OWFileDescriptor(owd, name);
    try
    {
      this.fd.create(false, false, false, -1, -1);
    }
    catch (OWFileNotFoundException e)
    {
      this.fd.free();
      this.fd = null;
      throw new OWFileNotFoundException(e.toString());
    }
  }

  public OWFileOutputStream(OneWireContainer owd, String name, boolean append)
    throws OWFileNotFoundException
  {
    this.fd = new OWFileDescriptor(owd, name);
    try
    {
      this.fd.create(append, false, false, -1, -1);
    }
    catch (OWFileNotFoundException e)
    {
      this.fd.free();
      this.fd = null;
      throw new OWFileNotFoundException(e.toString());
    }
  }

  public OWFileOutputStream(OneWireContainer[] owd, String name, boolean append)
    throws OWFileNotFoundException
  {
    this.fd = new OWFileDescriptor(owd, name);
    try
    {
      this.fd.create(append, false, false, -1, -1);
    }
    catch (OWFileNotFoundException e)
    {
      this.fd.free();
      this.fd = null;
      throw new OWFileNotFoundException(e.toString());
    }
  }

  public OWFileOutputStream(OWFile file)
    throws OWFileNotFoundException
  {
    try
    {
      this.fd = file.getFD();
    }
    catch (IOException e)
    {
      this.fd.free();
      this.fd = null;
      throw new OWFileNotFoundException(e.toString());
    }

    this.fd.open();
  }

  public OWFileOutputStream(OWFileDescriptor fdObj)
  {
    if (fdObj == null) {
      throw new NullPointerException("1-Wire FileDescriptor provided is null");
    }

    this.fd = fdObj;
  }

  public void write(int b)
    throws IOException
  {
    if (this.fd != null)
      this.fd.write(b);
    else
      throw new IOException("1-Wire FileDescriptor is null");
  }

  public void write(byte[] b)
    throws IOException
  {
    if (this.fd != null)
      this.fd.write(b, 0, b.length);
    else
      throw new IOException("1-Wire FileDescriptor is null");
  }

  public void write(byte[] b, int off, int len)
    throws IOException
  {
    if (this.fd != null)
      this.fd.write(b, off, len);
    else
      throw new IOException("1-Wire FileDescriptor is null");
  }

  public void close()
    throws IOException
  {
    if (this.fd != null)
      this.fd.close();
    else {
      throw new IOException("1-Wire FileDescriptor is null");
    }
    this.fd = null;
  }

  public OWFileDescriptor getFD()
    throws IOException
  {
    if (this.fd != null) {
      return this.fd;
    }
    throw new IOException("1-Wire FileDescriptor is null");
  }

  public void finalize()
    throws IOException
  {
    if (this.fd != null)
      this.fd.close();
  }
}